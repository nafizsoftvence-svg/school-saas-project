import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  Examination,
  ExamSubjectConfig,
  ExaminationStatus,
  ExamScheduleItem,
  ExamStatus,
  ExamScheduleConflict,
  ScheduleConflictCheckPayload,
  ExamMarksSubmission,
  ExamMarksSubmissionStatus,
  StudentMarkItem,
  TeacherAssignedExamSubject,
  SaveDraftMarksPayload,
  SubmitMarksPayload,
  GradingScaleItem,
  StudentExamResult,
  ExamResultSubjectScore,
  CalculateResultsPayload,
  CalculationReadinessInfo,
  AdminResultPreviewFilterParams,
  ResultCalculationSummaryStats,
  ResultWorkflowStatus,
  ResultStatusHistoryItem,
  ResultReviewFilterParams,
  ResultReviewResponse,
  ResultReviewSummaryStats,
  ChangeResultStatusPayload,
  BulkChangeResultStatusPayload,
  ReturnCorrectionPayload,
  BulkApproveResultsPayload,
  PublishResultsPayload,
  UnpublishReopenPayload,
  MeritRankingConfig,
  MeritRankItem,
  MeritListResponse,
  ReportCardDetail,
  ClassResultSummaryData,
  SubjectPerformanceReportResponse,
  StudentPerformanceHistoryResponse
} from '../../src/types/index.js';

export const examinationRouter = Router();

// Helper: Parse human or 24-hr time string (e.g. "09:00 AM", "1:30 PM", "14:00") into minutes from midnight
export function parseTimeToMinutes(timeStr: string): number | null {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const trimmed = timeStr.trim();
  // Support 12-hour AM/PM format (e.g., "09:30 AM", "9:30am", "2:15 PM")
  const match12 = trimmed.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM|am|pm)?$/i);
  if (!match12) return null;
  let hours = parseInt(match12[1], 10);
  const minutes = parseInt(match12[2], 10);
  const meridiem = match12[3]?.toUpperCase();

  if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return null;

  if (meridiem === 'PM' && hours < 12) hours += 12;
  else if (meridiem === 'AM' && hours === 12) hours = 0;

  return hours * 60 + minutes;
}

// Helper: Validate exam scheduling conflicts across Class, Room, Teacher, and Time ranges
export function checkScheduleConflicts(payload: ScheduleConflictCheckPayload): ExamScheduleConflict[] {
  const conflicts: ExamScheduleConflict[] = [];

  // 1. Time string parsing and range check
  const startMin = parseTimeToMinutes(payload.startTime);
  const endMin = parseTimeToMinutes(payload.endTime);

  if (startMin === null) {
    conflicts.push({
      type: 'INVALID_TIME',
      message: `Invalid start time format: "${payload.startTime}". Expected format like "09:00 AM" or "14:00".`
    });
  }

  if (endMin === null) {
    conflicts.push({
      type: 'INVALID_TIME',
      message: `Invalid end time format: "${payload.endTime}". Expected format like "11:30 AM" or "16:30".`
    });
  }

  if (startMin !== null && endMin !== null) {
    if (startMin >= endMin) {
      conflicts.push({
        type: 'INVALID_TIME',
        message: `Start time (${payload.startTime}) must be strictly before end time (${payload.endTime}).`
      });
    }
  }

  // 2. Marks check
  if (payload.fullMarks !== undefined && payload.passMarks !== undefined) {
    const full = Number(payload.fullMarks);
    const pass = Number(payload.passMarks);
    if (full <= 0) {
      conflicts.push({
        type: 'MARKS_MISMATCH',
        message: `Full marks must be greater than 0 (provided: ${full}).`
      });
    }
    if (pass < 0 || pass > full) {
      conflicts.push({
        type: 'MARKS_MISMATCH',
        message: `Pass marks (${pass}) cannot exceed full marks (${full}) and cannot be negative.`
      });
    }
  }

  // 3. Date check
  if (!payload.examDate || isNaN(new Date(payload.examDate).getTime())) {
    conflicts.push({
      type: 'INVALID_DATE',
      message: `Invalid exam date: "${payload.examDate}". Expected format YYYY-MM-DD.`
    });
    return conflicts;
  }

  if (startMin === null || endMin === null || startMin >= endMin) {
    return conflicts;
  }

  const targetDate = payload.examDate;
  const targetClassId = payload.classId;
  const targetSectionId = payload.sectionId || 'ALL';
  const targetRoom = payload.roomNumber?.trim().toLowerCase();
  const targetTeacherId = payload.invigilatorTeacherId;
  const targetTeacherName = payload.invigilatorName?.trim().toLowerCase();

  // Check against all existing exam schedules
  for (const item of database.examSchedules) {
    // Skip self when updating
    if (payload.scheduleId && item.id === payload.scheduleId) continue;
    // Skip cancelled
    if (item.status === 'cancelled') continue;

    // Check duplicate subject in same exam
    if (
      payload.examId &&
      item.examId === payload.examId &&
      item.subjectId === payload.subjectId &&
      (!payload.scheduleId || item.id !== payload.scheduleId)
    ) {
      conflicts.push({
        type: 'DUPLICATE_SUBJECT',
        conflictingScheduleId: item.id,
        conflictingExamName: item.examName,
        conflictingSubjectName: item.subjectName,
        conflictingDetails: `${item.examName} - ${item.examDate} (${item.startTime} - ${item.endTime})`,
        message: `Subject "${item.subjectName}" is already allocated in "${item.examName}".`
      });
    }

    // Check time overlap on same date
    if (item.examDate === targetDate) {
      const itemStart = parseTimeToMinutes(item.startTime);
      const itemEnd = parseTimeToMinutes(item.endTime);

      if (itemStart !== null && itemEnd !== null) {
        const isOverlapping = startMin < itemEnd && endMin > itemStart;

        if (isOverlapping) {
          // A. Class Overlap
          if (targetClassId && item.classId === targetClassId) {
            const isSectionOverlap =
              targetSectionId === 'ALL' ||
              item.sectionId === 'ALL' ||
              item.sectionId === targetSectionId;

            if (isSectionOverlap) {
              conflicts.push({
                type: 'CLASS_OVERLAP',
                conflictingScheduleId: item.id,
                conflictingExamName: item.examName,
                conflictingSubjectName: item.subjectName,
                conflictingDetails: `${item.className} (${item.sectionName}) - ${item.startTime} to ${item.endTime}`,
                message: `Class conflict: ${item.className} (${item.sectionName}) already has an exam "${item.subjectName}" (${item.examName}) scheduled during this time (${item.startTime} - ${item.endTime}).`
              });
            }
          }

          // B. Room Overlap
          if (targetRoom && item.roomNumber && item.roomNumber.trim().toLowerCase() === targetRoom) {
            conflicts.push({
              type: 'ROOM_OVERLAP',
              conflictingScheduleId: item.id,
              conflictingExamName: item.examName,
              conflictingSubjectName: item.subjectName,
              conflictingDetails: `Room ${item.roomNumber} - ${item.startTime} to ${item.endTime}`,
              message: `Room conflict: Room/Hall "${item.roomNumber}" is already booked for "${item.subjectName}" (${item.examName}) from ${item.startTime} to ${item.endTime}.`
            });
          }

          // C. Teacher Overlap
          const isSameTeacherId = targetTeacherId && item.invigilatorTeacherId && targetTeacherId === item.invigilatorTeacherId;
          const isSameTeacherName =
            targetTeacherName &&
            item.invigilatorName &&
            item.invigilatorName.trim().toLowerCase() === targetTeacherName;

          if (isSameTeacherId || isSameTeacherName) {
            const facultyName = item.invigilatorName || 'Assigned Faculty';
            conflicts.push({
              type: 'TEACHER_OVERLAP',
              conflictingScheduleId: item.id,
              conflictingExamName: item.examName,
              conflictingSubjectName: item.subjectName,
              conflictingDetails: `${facultyName} - ${item.startTime} to ${item.endTime} in ${item.roomNumber || 'TBD'}`,
              message: `Teacher conflict: ${facultyName} is already assigned to invigilate "${item.subjectName}" (${item.examName}) from ${item.startTime} to ${item.endTime}.`
            });
          }
        }
      }
    }
  }

  return conflicts;
}

// Helper: Map ExaminationStatus to ExamStatus for student timetable compatibility
function mapToScheduleStatus(status: ExaminationStatus): ExamStatus {
  switch (status) {
    case 'ongoing':
      return 'ongoing';
    case 'completed':
    case 'published':
      return 'completed';
    case 'archived':
      return 'cancelled';
    case 'draft':
    case 'scheduled':
    default:
      return 'scheduled';
  }
}

// Helper: Enrich examination with linked session, class, section details and calculations
function enrichExamination(exam: Examination) {
  const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);
  const schoolClass = database.classes.find((c) => c.id === exam.classId);
  const section =
    exam.sectionId === 'ALL'
      ? { name: 'All Sections' }
      : database.sections.find((s) => s.id === exam.sectionId);

  const subjectsConfig = exam.subjectsConfig || [];
  const subjectCount = subjectsConfig.length;
  const totalFullMarks = subjectsConfig.reduce((sum, s) => sum + (Number(s.fullMarks) || 0), 0);
  const totalPassMarks = subjectsConfig.reduce((sum, s) => sum + (Number(s.passMarks) || 0), 0);

  return {
    ...exam,
    academicSessionName: session ? session.name : exam.academicSessionName || 'Unknown Session',
    className: schoolClass ? schoolClass.name : exam.className || 'Unknown Class',
    sectionName: section ? section.name : exam.sectionId === 'ALL' ? 'All Sections' : 'Specific Section',
    subjectCount,
    totalFullMarks,
    totalPassMarks,
    subjectsConfig
  };
}

// Helper: Synchronize ExamSubjectConfig with database.examSchedules
function syncSubjectToExamSchedule(
  exam: Examination,
  subjectConfig: ExamSubjectConfig
) {
  const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);
  const schoolClass = database.classes.find((c) => c.id === exam.classId);
  const section =
    exam.sectionId === 'ALL'
      ? { name: 'All Sections' }
      : database.sections.find((s) => s.id === exam.sectionId);

  const existingScheduleIdx = database.examSchedules.findIndex(
    (sch) => sch.examId === exam.id && sch.subjectId === subjectConfig.subjectId
  );

  const scheduleItem: ExamScheduleItem = {
    id: existingScheduleIdx >= 0 ? database.examSchedules[existingScheduleIdx].id : `exam-sch-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    examId: exam.id,
    examName: exam.name,
    examType: exam.examType.toLowerCase().replace(/\s+/g, '_'),
    subjectId: subjectConfig.subjectId,
    subjectName: subjectConfig.subjectName,
    subjectCode: subjectConfig.subjectCode,
    classId: exam.classId,
    className: schoolClass ? schoolClass.name : exam.className || '',
    sectionId: exam.sectionId,
    sectionName: section ? section.name : 'All Sections',
    academicSessionId: exam.academicSessionId,
    academicSessionName: session ? session.name : exam.academicSessionName || '',
    examDate: subjectConfig.examDate || exam.startDate,
    startTime: subjectConfig.startTime || '09:00 AM',
    endTime: subjectConfig.endTime || '11:30 AM',
    durationMinutes: Number(subjectConfig.examDurationMinutes) || 120,
    roomNumber: subjectConfig.roomNumber || 'Main Examination Hall',
    fullMarks: Number(subjectConfig.fullMarks) || 100,
    passMarks: Number(subjectConfig.passMarks) || 40,
    instructions: subjectConfig.instructions || exam.instructions,
    status: mapToScheduleStatus(exam.status),
    invigilatorTeacherId: subjectConfig.invigilatorTeacherId || undefined,
    invigilatorName: subjectConfig.invigilatorName || undefined,
    createdAt: existingScheduleIdx >= 0 ? database.examSchedules[existingScheduleIdx].createdAt : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (existingScheduleIdx >= 0) {
    database.examSchedules[existingScheduleIdx] = scheduleItem;
  } else {
    database.examSchedules.push(scheduleItem);
  }
}

// ==========================================
// 1. EXAM TYPES (CONFIGURABLE)
// ==========================================

// Get all available exam types
examinationRouter.get(
  '/exam-types',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    // Combine base types with any unique types present in existing exams
    const dynamicTypes = Array.from(
      new Set([
        ...(database.examTypes || []),
        ...database.examinations.map((e) => e.examType).filter(Boolean)
      ])
    );

    res.json({
      success: true,
      data: dynamicTypes
    });
  }
);

// Add a custom exam type
examinationRouter.post(
  '/exam-types',
  requireAuth,
  requirePermission('examinations.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { name } = req.body;
    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      res.status(400).json({
        success: false,
        error: 'Exam type name must be at least 2 characters.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    const trimmed = name.trim();
    if (!database.examTypes) {
      database.examTypes = [];
    }

    if (database.examTypes.some((t) => t.toLowerCase() === trimmed.toLowerCase())) {
      res.status(400).json({
        success: false,
        error: `Exam type "${trimmed}" already exists.`,
        code: 'DUPLICATE_ERROR'
      });
      return;
    }

    database.examTypes.push(trimmed);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_TYPE_CREATE',
      entityType: 'ExaminationType',
      entityId: trimmed,
      details: `Created custom exam type: ${trimmed}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      message: `Exam type "${trimmed}" added successfully.`,
      data: database.examTypes
    });
  }
);

// ==========================================
// 2. EXAMINATIONS LIST & RETRIEVAL
// ==========================================

// Get examinations with filters and summary stats
examinationRouter.get(
  '/',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      academicSessionId,
      classId,
      sectionId,
      status,
      examType,
      search,
      includeArchived
    } = req.query;

    let exams = [...(database.examinations || [])];

    // Filter by Archive status
    if (includeArchived !== 'true') {
      exams = exams.filter((e) => !e.isArchived && e.status !== 'archived');
    }

    // Filter by Academic Session
    if (academicSessionId && typeof academicSessionId === 'string') {
      exams = exams.filter((e) => e.academicSessionId === academicSessionId);
    }

    // Filter by Class
    if (classId && typeof classId === 'string' && classId !== 'ALL') {
      exams = exams.filter((e) => e.classId === classId);
    }

    // Filter by Section
    if (sectionId && typeof sectionId === 'string' && sectionId !== 'ALL') {
      exams = exams.filter((e) => e.sectionId === 'ALL' || e.sectionId === sectionId);
    }

    // Filter by Status
    if (status && typeof status === 'string' && status !== 'ALL') {
      exams = exams.filter((e) => e.status.toLowerCase() === status.toLowerCase());
    }

    // Filter by Exam Type
    if (examType && typeof examType === 'string' && examType !== 'ALL') {
      exams = exams.filter((e) => e.examType.toLowerCase() === examType.toLowerCase());
    }

    // Search query by name, description, instructions
    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      exams = exams.filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.examType.toLowerCase().includes(q) ||
          (e.description && e.description.toLowerCase().includes(q))
      );
    }

    // Sort by startDate descending
    exams.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());

    const enriched = exams.map(enrichExamination);

    // Calculate Summary Statistics
    const allExams = database.examinations || [];
    const stats = {
      total: allExams.length,
      draft: allExams.filter((e) => e.status === 'draft').length,
      scheduled: allExams.filter((e) => e.status === 'scheduled').length,
      ongoing: allExams.filter((e) => e.status === 'ongoing').length,
      completed: allExams.filter((e) => e.status === 'completed').length,
      published: allExams.filter((e) => e.status === 'published').length,
      archived: allExams.filter((e) => e.isArchived || e.status === 'archived').length
    };

    res.json({
      success: true,
      data: enriched,
      stats
    });
  }
);

// Get single examination by ID
examinationRouter.get(
  '/:id',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === id);

    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const enriched = enrichExamination(exam);

    // Provide available subjects for this class to make configuring effortless
    const classSubjects = database.subjects.filter((s) => s.classId === exam.classId && s.status === 'active');

    // Provide available teachers for invigilator assignment
    const teachers = database.teacherProfiles.map((t) => {
      const user = database.users.find((u) => u.id === t.userId);
      const fullName = `${t.firstName || ''} ${t.lastName || ''}`.trim();
      const displayName = fullName || (user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.name : t.employeeCode || 'Teacher');
      return {
        id: t.id,
        name: displayName,
        designation: t.designation || 'Faculty Member',
        department: t.department || 'Academic'
      };
    });

    res.json({
      success: true,
      data: enriched,
      metadata: {
        availableClassSubjects: classSubjects,
        availableTeachers: teachers
      }
    });
  }
);

// ==========================================
// 3. CREATE EXAMINATION
// ==========================================

examinationRouter.post(
  '/',
  requireAuth,
  requirePermission('examinations.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      name,
      examType,
      academicSessionId,
      classId,
      sectionId = 'ALL',
      startDate,
      endDate,
      status = 'draft',
      description,
      instructions
    } = req.body;

    // 1. Validation: Name
    if (!name || typeof name !== 'string' || name.trim().length < 3) {
      res.status(400).json({
        success: false,
        error: 'Examination name is required and must be at least 3 characters.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    // 2. Validation: Exam Type
    if (!examType || typeof examType !== 'string') {
      res.status(400).json({
        success: false,
        error: 'Exam type is required.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    // 3. Validation: Academic Session
    const session = database.academicSessions.find((s) => s.id === academicSessionId);
    if (!session) {
      res.status(400).json({
        success: false,
        error: 'Selected academic session does not exist.',
        code: 'INVALID_SESSION'
      });
      return;
    }

    // 4. Validation: Class
    const schoolClass = database.classes.find((c) => c.id === classId);
    if (!schoolClass) {
      res.status(400).json({
        success: false,
        error: 'Selected class does not exist.',
        code: 'INVALID_CLASS'
      });
      return;
    }

    // 5. Validation: Section (if specified)
    let sectionName = 'All Sections';
    if (sectionId && sectionId !== 'ALL') {
      const section = database.sections.find((s) => s.id === sectionId && s.classId === classId);
      if (!section) {
        res.status(400).json({
          success: false,
          error: 'Selected section does not belong to the selected class.',
          code: 'INVALID_SECTION'
        });
        return;
      }
      sectionName = section.name;
    }

    // 6. Validation: Dates
    if (!startDate || !endDate) {
      res.status(400).json({
        success: false,
        error: 'Both start date and end date are required.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    const startTimestamp = new Date(startDate).getTime();
    const endTimestamp = new Date(endDate).getTime();

    if (isNaN(startTimestamp) || isNaN(endTimestamp)) {
      res.status(400).json({
        success: false,
        error: 'Invalid date format provided. Please use YYYY-MM-DD.',
        code: 'INVALID_DATE'
      });
      return;
    }

    if (startTimestamp > endTimestamp) {
      res.status(400).json({
        success: false,
        error: 'Start date cannot be after end date.',
        code: 'INVALID_DATE_RANGE'
      });
      return;
    }

    // 7. Validation: Duplicate Exam Check
    const trimmedName = name.trim();
    const duplicate = (database.examinations || []).find(
      (e) =>
        !e.isArchived &&
        e.name.toLowerCase() === trimmedName.toLowerCase() &&
        e.academicSessionId === academicSessionId &&
        e.classId === classId &&
        e.sectionId === sectionId
    );

    if (duplicate) {
      res.status(400).json({
        success: false,
        error: `An examination named "${trimmedName}" already exists for ${schoolClass.name} (${session.name}).`,
        code: 'DUPLICATE_EXAM'
      });
      return;
    }

    // 8. Construct Examination Record
    const newExamId = `exam-${Date.now()}`;
    const newExam: Examination = {
      id: newExamId,
      name: trimmedName,
      examType: examType.trim(),
      academicSessionId,
      academicSessionName: session.name,
      classId,
      className: schoolClass.name,
      sectionId,
      sectionName,
      startDate,
      endDate,
      status: status as ExaminationStatus,
      description: description ? description.trim() : undefined,
      instructions: instructions ? instructions.trim() : undefined,
      isArchived: false,
      subjectsConfig: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.examinations) {
      database.examinations = [];
    }
    database.examinations.push(newExam);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_CREATE',
      entityType: 'Examination',
      entityId: newExamId,
      details: `Created examination "${newExam.name}" (${newExam.examType}) for ${schoolClass.name} - ${session.name}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      message: `Examination "${newExam.name}" created successfully.`,
      data: enrichExamination(newExam)
    });
  }
);

// ==========================================
// 4. UPDATE EXAMINATION
// ==========================================

examinationRouter.put(
  '/:id',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const examIndex = (database.examinations || []).findIndex((e) => e.id === id);

    if (examIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const currentExam = database.examinations[examIndex];
    const {
      name,
      examType,
      academicSessionId,
      classId,
      sectionId,
      startDate,
      endDate,
      status,
      description,
      instructions,
      isArchived
    } = req.body;

    // Validate Name
    if (name !== undefined) {
      if (typeof name !== 'string' || name.trim().length < 3) {
        res.status(400).json({
          success: false,
          error: 'Examination name must be at least 3 characters.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }
    }

    // Validate Dates
    const finalStartDate = startDate || currentExam.startDate;
    const finalEndDate = endDate || currentExam.endDate;

    if (new Date(finalStartDate).getTime() > new Date(finalEndDate).getTime()) {
      res.status(400).json({
        success: false,
        error: 'Start date cannot be after end date.',
        code: 'INVALID_DATE_RANGE'
      });
      return;
    }

    // Validate Academic Session & Class if changed
    let academicSessionName = currentExam.academicSessionName;
    if (academicSessionId && academicSessionId !== currentExam.academicSessionId) {
      const session = database.academicSessions.find((s) => s.id === academicSessionId);
      if (!session) {
        res.status(400).json({
          success: false,
          error: 'Selected academic session does not exist.',
          code: 'INVALID_SESSION'
        });
        return;
      }
      academicSessionName = session.name;
    }

    let className = currentExam.className;
    if (classId && classId !== currentExam.classId) {
      const schoolClass = database.classes.find((c) => c.id === classId);
      if (!schoolClass) {
        res.status(400).json({
          success: false,
          error: 'Selected class does not exist.',
          code: 'INVALID_CLASS'
        });
        return;
      }
      className = schoolClass.name;
    }

    let sectionName = currentExam.sectionName;
    if (sectionId !== undefined) {
      if (sectionId === 'ALL') {
        sectionName = 'All Sections';
      } else {
        const targetClassId = classId || currentExam.classId;
        const section = database.sections.find((s) => s.id === sectionId && s.classId === targetClassId);
        if (!section) {
          res.status(400).json({
            success: false,
            error: 'Selected section does not belong to the class.',
            code: 'INVALID_SECTION'
          });
          return;
        }
        sectionName = section.name;
      }
    }

    // Duplicate Check
    const finalName = name ? name.trim() : currentExam.name;
    const finalSessionId = academicSessionId || currentExam.academicSessionId;
    const finalClassId = classId || currentExam.classId;
    const finalSectionId = sectionId !== undefined ? sectionId : currentExam.sectionId;

    const duplicate = database.examinations.find(
      (e) =>
        e.id !== id &&
        !e.isArchived &&
        e.name.toLowerCase() === finalName.toLowerCase() &&
        e.academicSessionId === finalSessionId &&
        e.classId === finalClassId &&
        e.sectionId === finalSectionId
    );

    if (duplicate) {
      res.status(400).json({
        success: false,
        error: `Another examination named "${finalName}" already exists for this class and session.`,
        code: 'DUPLICATE_EXAM'
      });
      return;
    }

    // Update the record
    const updatedExam: Examination = {
      ...currentExam,
      name: finalName,
      examType: examType !== undefined ? examType.trim() : currentExam.examType,
      academicSessionId: finalSessionId,
      academicSessionName,
      classId: finalClassId,
      className,
      sectionId: finalSectionId,
      sectionName,
      startDate: finalStartDate,
      endDate: finalEndDate,
      status: status !== undefined ? (status as ExaminationStatus) : currentExam.status,
      description: description !== undefined ? (description ? description.trim() : undefined) : currentExam.description,
      instructions: instructions !== undefined ? (instructions ? instructions.trim() : undefined) : currentExam.instructions,
      isArchived: isArchived !== undefined ? Boolean(isArchived) : currentExam.isArchived,
      updatedAt: new Date().toISOString()
    };

    database.examinations[examIndex] = updatedExam;

    // Sync changes to existing schedule items
    (updatedExam.subjectsConfig || []).forEach((subjectConfig) => {
      syncSubjectToExamSchedule(updatedExam, subjectConfig);
    });

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_UPDATE',
      entityType: 'Examination',
      entityId: id,
      details: `Updated examination "${updatedExam.name}" (Status: ${updatedExam.status}, Archived: ${updatedExam.isArchived})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Examination "${updatedExam.name}" updated successfully.`,
      data: enrichExamination(updatedExam)
    });
  }
);

// ==========================================
// 5. UPDATE EXAM STATUS (WORKFLOW TRANSITION)
// ==========================================

examinationRouter.post(
  '/:id/status',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses: ExaminationStatus[] = [
      'draft',
      'scheduled',
      'ongoing',
      'completed',
      'published',
      'archived'
    ];

    if (!status || !validStatuses.includes(status)) {
      res.status(400).json({
        success: false,
        error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
        code: 'INVALID_STATUS'
      });
      return;
    }

    const examIndex = (database.examinations || []).findIndex((e) => e.id === id);
    if (examIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const exam = database.examinations[examIndex];

    // Status Validation Rules
    if (status === 'published' && (!exam.subjectsConfig || exam.subjectsConfig.length === 0)) {
      res.status(400).json({
        success: false,
        error: 'Cannot publish an examination without any configured subjects. Please add subjects first.',
        code: 'NO_SUBJECTS_CONFIGURED'
      });
      return;
    }

    exam.status = status;
    exam.isArchived = status === 'archived';
    exam.updatedAt = new Date().toISOString();

    // Sync schedule items
    const scheduleStatus = mapToScheduleStatus(status);
    database.examSchedules.forEach((sch) => {
      if (sch.examId === exam.id) {
        sch.status = scheduleStatus;
        sch.updatedAt = new Date().toISOString();
      }
    });

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_STATUS_CHANGE',
      entityType: 'Examination',
      entityId: id,
      details: `Changed examination status from ${exam.status} to ${status}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Examination status transitioned to ${status.toUpperCase()}.`,
      data: enrichExamination(exam)
    });
  }
);

// ==========================================
// 6. ARCHIVE / UNARCHIVE EXAMINATION
// ==========================================

examinationRouter.post(
  '/:id/archive',
  requireAuth,
  requirePermission('examinations.archive'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const examIndex = (database.examinations || []).findIndex((e) => e.id === id);

    if (examIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const exam = database.examinations[examIndex];
    exam.isArchived = !exam.isArchived;
    if (exam.isArchived) {
      exam.status = 'archived';
    } else {
      exam.status = 'draft';
    }
    exam.updatedAt = new Date().toISOString();

    // Sync schedules
    database.examSchedules.forEach((sch) => {
      if (sch.examId === exam.id) {
        sch.status = exam.isArchived ? 'cancelled' : 'scheduled';
        sch.updatedAt = new Date().toISOString();
      }
    });

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: exam.isArchived ? 'EXAM_ARCHIVE' : 'EXAM_UNARCHIVE',
      entityType: 'Examination',
      entityId: id,
      details: exam.isArchived ? `Archived examination "${exam.name}"` : `Restored examination "${exam.name}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: exam.isArchived ? `Examination "${exam.name}" archived.` : `Examination "${exam.name}" restored.`,
      data: enrichExamination(exam)
    });
  }
);

// ==========================================
// 7. DELETE EXAMINATION
// ==========================================

examinationRouter.delete(
  '/:id',
  requireAuth,
  requirePermission('examinations.delete'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const examIndex = (database.examinations || []).findIndex((e) => e.id === id);

    if (examIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const exam = database.examinations[examIndex];

    // Prevent deletion if marks/results already exist in database for this exam
    const hasResults = (database.examResults || []).some((r) => r.examId === id);
    if (hasResults) {
      res.status(400).json({
        success: false,
        error: `Cannot delete examination "${exam.name}" because student result records are already associated with it. Please archive it instead.`,
        code: 'EXAM_HAS_RESULTS'
      });
      return;
    }

    // Remove from examinations array
    database.examinations.splice(examIndex, 1);

    // Clean up corresponding exam schedules
    database.examSchedules = database.examSchedules.filter((sch) => sch.examId !== id);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_DELETE',
      entityType: 'Examination',
      entityId: id,
      details: `Deleted examination "${exam.name}" and cleared related schedules`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Examination "${exam.name}" has been permanently deleted.`
    });
  }
);

// ==========================================
// 8. SUBJECT CONFIGURATION ENDPOINTS
// ==========================================

// Add a subject configuration to an exam
examinationRouter.post(
  '/:id/subjects',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === id);

    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const {
      subjectId,
      fullMarks,
      passMarks,
      examDurationMinutes,
      examDate,
      startTime = '09:00 AM',
      endTime = '11:30 AM',
      roomNumber,
      invigilatorTeacherId,
      instructions
    } = req.body;

    // 1. Validate Subject
    const subject = database.subjects.find((s) => s.id === subjectId);
    if (!subject) {
      res.status(400).json({
        success: false,
        error: 'Selected subject does not exist.',
        code: 'INVALID_SUBJECT'
      });
      return;
    }

    // 2. Prevent duplicate subject within the same exam
    if (!exam.subjectsConfig) {
      exam.subjectsConfig = [];
    }

    if (exam.subjectsConfig.some((s) => s.subjectId === subjectId)) {
      res.status(400).json({
        success: false,
        error: `Subject "${subject.name}" (${subject.code}) is already configured for this examination.`,
        code: 'DUPLICATE_SUBJECT'
      });
      return;
    }

    // 3. Validate Marks
    const numFullMarks = Number(fullMarks);
    const numPassMarks = Number(passMarks);

    if (isNaN(numFullMarks) || numFullMarks <= 0) {
      res.status(400).json({
        success: false,
        error: 'Full marks must be a positive number greater than 0.',
        code: 'INVALID_MARKS'
      });
      return;
    }

    if (isNaN(numPassMarks) || numPassMarks < 0) {
      res.status(400).json({
        success: false,
        error: 'Pass marks must be a non-negative number (>= 0).',
        code: 'INVALID_MARKS'
      });
      return;
    }

    if (numPassMarks > numFullMarks) {
      res.status(400).json({
        success: false,
        error: `Pass marks (${numPassMarks}) cannot exceed full marks (${numFullMarks}).`,
        code: 'PASS_MARKS_EXCEED_FULL'
      });
      return;
    }

    // 4. Validate Duration
    const numDuration = Number(examDurationMinutes);
    if (isNaN(numDuration) || numDuration <= 0) {
      res.status(400).json({
        success: false,
        error: 'Exam duration must be greater than 0 minutes.',
        code: 'INVALID_DURATION'
      });
      return;
    }

    // 5. Validate Exam Date
    const targetDate = examDate || exam.startDate;
    if (isNaN(new Date(targetDate).getTime())) {
      res.status(400).json({
        success: false,
        error: 'Invalid exam date format.',
        code: 'INVALID_DATE'
      });
      return;
    }

    // Lookup Invigilator Teacher
    let invigilatorName: string | undefined = undefined;
    if (invigilatorTeacherId) {
      const teacher = database.teacherProfiles.find((t) => t.id === invigilatorTeacherId);
      if (teacher) {
        const user = database.users.find((u) => u.id === teacher.userId);
        invigilatorName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || (user ? `${user.firstName} ${user.lastName}` : teacher.employeeCode);
      }
    }

    // Check Scheduling Conflicts (Class, Room, Teacher, Time, Marks, Date)
    const conflicts = checkScheduleConflicts({
      examId: exam.id,
      subjectId: subject.id,
      classId: exam.classId,
      sectionId: exam.sectionId,
      examDate: targetDate,
      startTime: startTime ? startTime.trim() : '09:00 AM',
      endTime: endTime ? endTime.trim() : '11:30 AM',
      roomNumber: roomNumber ? roomNumber.trim() : 'Main Examination Hall',
      invigilatorTeacherId,
      invigilatorName,
      fullMarks: numFullMarks,
      passMarks: numPassMarks
    });

    if (conflicts.length > 0) {
      res.status(400).json({
        success: false,
        error: conflicts[0].message,
        code: 'SCHEDULE_CONFLICT',
        conflicts
      });
      return;
    }

    const configId = `exam-subj-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newConfig: ExamSubjectConfig = {
      id: configId,
      examId: exam.id,
      subjectId: subject.id,
      subjectName: subject.name,
      subjectCode: subject.code,
      fullMarks: numFullMarks,
      passMarks: numPassMarks,
      examDurationMinutes: numDuration,
      examDate: targetDate,
      startTime: startTime ? startTime.trim() : '09:00 AM',
      endTime: endTime ? endTime.trim() : '11:30 AM',
      roomNumber: roomNumber ? roomNumber.trim() : 'Main Examination Hall',
      invigilatorTeacherId,
      invigilatorName,
      instructions: instructions ? instructions.trim() : undefined,
      orderIndex: exam.subjectsConfig.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    exam.subjectsConfig.push(newConfig);
    exam.updatedAt = new Date().toISOString();

    // Synchronize to exam schedules
    syncSubjectToExamSchedule(exam, newConfig);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SUBJECT_ADD',
      entityType: 'Examination',
      entityId: exam.id,
      details: `Added subject "${subject.name}" (Full: ${numFullMarks}, Pass: ${numPassMarks}) to examination "${exam.name}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      message: `Subject "${subject.name}" added to examination successfully.`,
      data: enrichExamination(exam)
    });
  }
);

// Update subject configuration
examinationRouter.put(
  '/:id/subjects/:configId',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id, configId } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === id);

    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const configIndex = (exam.subjectsConfig || []).findIndex((s) => s.id === configId);
    if (configIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Subject configuration not found in this examination.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const currentConfig = exam.subjectsConfig![configIndex];
    const {
      fullMarks,
      passMarks,
      examDurationMinutes,
      examDate,
      startTime,
      endTime,
      roomNumber,
      invigilatorTeacherId,
      instructions
    } = req.body;

    const numFullMarks = fullMarks !== undefined ? Number(fullMarks) : currentConfig.fullMarks;
    const numPassMarks = passMarks !== undefined ? Number(passMarks) : currentConfig.passMarks;

    if (numFullMarks <= 0 || numPassMarks < 0 || numPassMarks > numFullMarks) {
      res.status(400).json({
        success: false,
        error: 'Pass marks cannot exceed full marks, and full marks must be greater than 0.',
        code: 'INVALID_MARKS'
      });
      return;
    }

    let invigilatorName = currentConfig.invigilatorName;
    if (invigilatorTeacherId !== undefined) {
      if (invigilatorTeacherId) {
        const teacher = database.teacherProfiles.find((t) => t.id === invigilatorTeacherId);
        if (teacher) {
          const user = database.users.find((u) => u.id === teacher.userId);
          invigilatorName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || (user ? `${user.firstName} ${user.lastName}` : teacher.employeeCode);
        } else {
          invigilatorName = undefined;
        }
      } else {
        invigilatorName = undefined;
      }
    }

    // Find linked schedule ID to exclude self during conflict check
    const linkedSchedule = database.examSchedules.find(
      (s) => s.examId === exam.id && s.subjectId === currentConfig.subjectId
    );

    const targetDate = examDate || currentConfig.examDate || exam.startDate;
    const targetStart = startTime || currentConfig.startTime || '09:00 AM';
    const targetEnd = endTime || currentConfig.endTime || '11:30 AM';
    const targetRoom = roomNumber !== undefined ? roomNumber : currentConfig.roomNumber;

    const conflicts = checkScheduleConflicts({
      scheduleId: linkedSchedule ? linkedSchedule.id : undefined,
      examId: exam.id,
      subjectId: currentConfig.subjectId,
      classId: exam.classId,
      sectionId: exam.sectionId,
      examDate: targetDate,
      startTime: targetStart,
      endTime: targetEnd,
      roomNumber: targetRoom,
      invigilatorTeacherId: invigilatorTeacherId !== undefined ? invigilatorTeacherId : currentConfig.invigilatorTeacherId,
      invigilatorName,
      fullMarks: numFullMarks,
      passMarks: numPassMarks
    });

    if (conflicts.length > 0) {
      res.status(400).json({
        success: false,
        error: conflicts[0].message,
        code: 'SCHEDULE_CONFLICT',
        conflicts
      });
      return;
    }

    const updatedConfig: ExamSubjectConfig = {
      ...currentConfig,
      fullMarks: numFullMarks,
      passMarks: numPassMarks,
      examDurationMinutes:
        examDurationMinutes !== undefined ? Number(examDurationMinutes) : currentConfig.examDurationMinutes,
      examDate: targetDate,
      startTime: targetStart,
      endTime: targetEnd,
      roomNumber: targetRoom,
      invigilatorTeacherId: invigilatorTeacherId !== undefined ? invigilatorTeacherId : currentConfig.invigilatorTeacherId,
      invigilatorName,
      instructions: instructions !== undefined ? instructions : currentConfig.instructions,
      updatedAt: new Date().toISOString()
    };

    exam.subjectsConfig![configIndex] = updatedConfig;
    exam.updatedAt = new Date().toISOString();

    // Sync to schedules
    syncSubjectToExamSchedule(exam, updatedConfig);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SUBJECT_UPDATE',
      entityType: 'Examination',
      entityId: exam.id,
      details: `Updated subject "${updatedConfig.subjectName}" (Full: ${numFullMarks}, Pass: ${numPassMarks}) in examination "${exam.name}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Configuration for "${updatedConfig.subjectName}" updated successfully.`,
      data: enrichExamination(exam)
    });
  }
);

// Delete subject configuration
examinationRouter.delete(
  '/:id/subjects/:configId',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id, configId } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === id);

    if (!exam || !exam.subjectsConfig) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const configIndex = exam.subjectsConfig.findIndex((s) => s.id === configId);
    if (configIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Subject configuration not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const removed = exam.subjectsConfig.splice(configIndex, 1)[0];
    exam.updatedAt = new Date().toISOString();

    // Remove from examSchedules
    database.examSchedules = database.examSchedules.filter(
      (sch) => !(sch.examId === exam.id && sch.subjectId === removed.subjectId)
    );

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SUBJECT_DELETE',
      entityType: 'Examination',
      entityId: exam.id,
      details: `Removed subject "${removed.subjectName}" from examination "${exam.name}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Subject "${removed.subjectName}" removed from examination.`,
      data: enrichExamination(exam)
    });
  }
);

// Bulk auto-import all subjects belonging to the class
examinationRouter.post(
  '/:id/bulk-subjects',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === id);

    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    if (!exam.subjectsConfig) {
      exam.subjectsConfig = [];
    }

    const existingSubjectIds = new Set(exam.subjectsConfig.map((s) => s.subjectId));
    const classSubjects = database.subjects.filter(
      (s) => s.classId === exam.classId && s.status === 'active' && !existingSubjectIds.has(s.id)
    );

    if (classSubjects.length === 0) {
      res.status(400).json({
        success: false,
        error: 'All active subjects for this class are already added to this examination.',
        code: 'NO_SUBJECTS_TO_IMPORT'
      });
      return;
    }

    const defaultFullMarks = req.body.defaultFullMarks ? Number(req.body.defaultFullMarks) : 100;
    const defaultPassMarks = req.body.defaultPassMarks ? Number(req.body.defaultPassMarks) : 40;
    const defaultDuration = req.body.defaultDuration ? Number(req.body.defaultDuration) : 120;

    let addedCount = 0;
    classSubjects.forEach((subject, idx) => {
      const configId = `exam-subj-${Date.now()}-${idx}-${Math.floor(Math.random() * 1000)}`;
      const newConfig: ExamSubjectConfig = {
        id: configId,
        examId: exam.id,
        subjectId: subject.id,
        subjectName: subject.name,
        subjectCode: subject.code,
        fullMarks: defaultFullMarks,
        passMarks: defaultPassMarks,
        examDurationMinutes: defaultDuration,
        examDate: exam.startDate,
        startTime: '09:00 AM',
        endTime: '11:00 AM',
        roomNumber: 'Main Examination Hall',
        orderIndex: exam.subjectsConfig!.length + 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      exam.subjectsConfig!.push(newConfig);
      syncSubjectToExamSchedule(exam, newConfig);
      addedCount++;
    });

    exam.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SUBJECTS_BULK_IMPORT',
      entityType: 'Examination',
      entityId: exam.id,
      details: `Bulk imported ${addedCount} class subject(s) to examination "${exam.name}"`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Successfully imported ${addedCount} class subject(s) to examination.`,
      data: enrichExamination(exam)
    });
  }
);

// =========================================================================
// PART 6B: MASTER EXAM SCHEDULES & CONFLICT ENGINE ENDPOINTS
// =========================================================================

// Validate potential schedule conflicts without persisting
examinationRouter.post(
  '/schedules/validate-conflict',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      scheduleId,
      examId,
      subjectId,
      classId,
      sectionId,
      examDate,
      startTime,
      endTime,
      roomNumber,
      invigilatorTeacherId,
      invigilatorName,
      fullMarks,
      passMarks
    } = req.body;

    let resolvedTeacherName = invigilatorName;
    if (invigilatorTeacherId && !resolvedTeacherName) {
      const teacher = database.teacherProfiles.find((t) => t.id === invigilatorTeacherId);
      if (teacher) {
        resolvedTeacherName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim();
      }
    }

    const conflicts = checkScheduleConflicts({
      scheduleId,
      examId,
      subjectId,
      classId,
      sectionId,
      examDate,
      startTime,
      endTime,
      roomNumber,
      invigilatorTeacherId,
      invigilatorName: resolvedTeacherName,
      fullMarks: fullMarks !== undefined ? Number(fullMarks) : undefined,
      passMarks: passMarks !== undefined ? Number(passMarks) : undefined
    });

    res.json({
      success: true,
      hasConflicts: conflicts.length > 0,
      conflicts
    });
  }
);

// Get all master exam schedules with extensive filtering & statistics
examinationRouter.get(
  '/schedules',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      academicSessionId,
      examId,
      classId,
      sectionId,
      subjectId,
      teacherId,
      roomNumber,
      status,
      date,
      startDate,
      endDate,
      search,
      page,
      limit
    } = req.query as Record<string, string | undefined>;

    let results = [...(database.examSchedules || [])];

    // 1. Academic Session filter
    if (academicSessionId && academicSessionId !== 'ALL') {
      results = results.filter((s) => s.academicSessionId === academicSessionId);
    }

    // 2. Examination filter
    if (examId && examId !== 'ALL') {
      results = results.filter((s) => s.examId === examId);
    }

    // 3. Class filter
    if (classId && classId !== 'ALL') {
      results = results.filter((s) => s.classId === classId);
    }

    // 4. Section filter
    if (sectionId && sectionId !== 'ALL') {
      results = results.filter(
        (s) => s.sectionId === 'ALL' || s.sectionId === sectionId
      );
    }

    // 5. Subject filter
    if (subjectId && subjectId !== 'ALL') {
      results = results.filter((s) => s.subjectId === subjectId);
    }

    // 6. Teacher / Invigilator filter
    if (teacherId && teacherId !== 'ALL') {
      results = results.filter((s) => s.invigilatorTeacherId === teacherId);
    }

    // 7. Room filter
    if (roomNumber && roomNumber !== 'ALL') {
      results = results.filter((s) => s.roomNumber?.toLowerCase() === roomNumber.toLowerCase());
    }

    // 8. Status filter
    if (status && status !== 'ALL') {
      results = results.filter((s) => s.status === status);
    }

    // 9. Single Date filter
    if (date) {
      results = results.filter((s) => s.examDate === date);
    }

    // 10. Date range filter
    if (startDate) {
      results = results.filter((s) => s.examDate >= startDate);
    }
    if (endDate) {
      results = results.filter((s) => s.examDate <= endDate);
    }

    // 11. Search query
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (s) =>
          s.examName.toLowerCase().includes(q) ||
          s.subjectName.toLowerCase().includes(q) ||
          s.subjectCode.toLowerCase().includes(q) ||
          s.className.toLowerCase().includes(q) ||
          s.sectionName.toLowerCase().includes(q) ||
          (s.roomNumber && s.roomNumber.toLowerCase().includes(q)) ||
          (s.invigilatorName && s.invigilatorName.toLowerCase().includes(q))
      );
    }

    // Sort by examDate ascending, then by startTime ascending
    results.sort((a, b) => {
      if (a.examDate !== b.examDate) {
        return a.examDate.localeCompare(b.examDate);
      }
      const aStart = parseTimeToMinutes(a.startTime) || 0;
      const bStart = parseTimeToMinutes(b.startTime) || 0;
      return aStart - bStart;
    });

    // Compute Overall Statistics
    const allSchedules = database.examSchedules || [];
    const stats = {
      total: allSchedules.length,
      scheduled: allSchedules.filter((s) => s.status === 'scheduled').length,
      ongoing: allSchedules.filter((s) => s.status === 'ongoing').length,
      completed: allSchedules.filter((s) => s.status === 'completed').length,
      postponed: allSchedules.filter((s) => s.status === 'postponed').length,
      cancelled: allSchedules.filter((s) => s.status === 'cancelled').length
    };

    // Filter options for dropdowns
    const filterOptions = {
      distinctRooms: Array.from(new Set(allSchedules.map((s) => s.roomNumber).filter(Boolean) as string[])).sort(),
      distinctDates: Array.from(new Set(allSchedules.map((s) => s.examDate))).sort()
    };

    // Optional Pagination
    const totalCount = results.length;
    let paginated = results;
    if (page && limit) {
      const pageNum = parseInt(page, 10) || 1;
      const limitNum = parseInt(limit, 10) || 20;
      const startIndex = (pageNum - 1) * limitNum;
      paginated = results.slice(startIndex, startIndex + limitNum);
    }

    res.json({
      success: true,
      data: paginated,
      total: totalCount,
      stats,
      filterOptions
    });
  }
);

// Get single exam schedule by ID
examinationRouter.get(
  '/schedules/:id',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const schedule = (database.examSchedules || []).find((s) => s.id === id);

    if (!schedule) {
      res.status(404).json({
        success: false,
        error: 'Exam schedule slot not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    // Enrich with associated exam and teacher details
    const exam = database.examinations.find((e) => e.id === schedule.examId);
    let invigilatorDetails: any = null;
    if (schedule.invigilatorTeacherId) {
      const teacher = database.teacherProfiles.find((t) => t.id === schedule.invigilatorTeacherId);
      if (teacher) {
        invigilatorDetails = {
          id: teacher.id,
          name: schedule.invigilatorName,
          employeeCode: teacher.employeeCode,
          designation: teacher.designation,
          phone: teacher.phone,
          email: teacher.email
        };
      }
    }

    res.json({
      success: true,
      data: {
        ...schedule,
        examDetails: exam ? enrichExamination(exam) : null,
        invigilatorDetails
      }
    });
  }
);

// Create new schedule slot directly
examinationRouter.post(
  '/schedules',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      examId,
      subjectId,
      classId,
      sectionId,
      academicSessionId,
      examDate,
      startTime,
      endTime,
      durationMinutes,
      roomNumber,
      fullMarks,
      passMarks,
      invigilatorTeacherId,
      instructions,
      status
    } = req.body;

    // 1. Check Exam
    const exam = database.examinations.find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Specified examination does not exist.',
        code: 'EXAM_NOT_FOUND'
      });
      return;
    }

    // 2. Check Subject
    const subject = database.subjects.find((s) => s.id === subjectId);
    if (!subject) {
      res.status(404).json({
        success: false,
        error: 'Specified subject does not exist.',
        code: 'SUBJECT_NOT_FOUND'
      });
      return;
    }

    // 3. Resolve Class & Section
    const targetClassId = classId || exam.classId;
    const targetSectionId = sectionId || exam.sectionId;
    const targetSessionId = academicSessionId || exam.academicSessionId;

    const schoolClass = database.classes.find((c) => c.id === targetClassId);
    const section =
      targetSectionId === 'ALL'
        ? { name: 'All Sections' }
        : database.sections.find((s) => s.id === targetSectionId);
    const session = database.academicSessions.find((s) => s.id === targetSessionId);

    // 4. Resolve Teacher
    let invigilatorName: string | undefined = undefined;
    if (invigilatorTeacherId) {
      const teacher = database.teacherProfiles.find((t) => t.id === invigilatorTeacherId);
      if (teacher) {
        const user = database.users.find((u) => u.id === teacher.userId);
        invigilatorName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || (user ? `${user.firstName} ${user.lastName}` : teacher.employeeCode);
      }
    }

    const numFullMarks = fullMarks !== undefined ? Number(fullMarks) : 100;
    const numPassMarks = passMarks !== undefined ? Number(passMarks) : 40;
    const targetStartTime = startTime ? startTime.trim() : '09:00 AM';
    const targetEndTime = endTime ? endTime.trim() : '11:30 AM';
    const targetRoom = roomNumber ? roomNumber.trim() : 'Main Examination Hall';

    // 5. Run Conflict Engine
    const conflicts = checkScheduleConflicts({
      examId: exam.id,
      subjectId: subject.id,
      classId: targetClassId,
      sectionId: targetSectionId,
      examDate: examDate || exam.startDate,
      startTime: targetStartTime,
      endTime: targetEndTime,
      roomNumber: targetRoom,
      invigilatorTeacherId,
      invigilatorName,
      fullMarks: numFullMarks,
      passMarks: numPassMarks
    });

    if (conflicts.length > 0) {
      res.status(400).json({
        success: false,
        error: conflicts[0].message,
        code: 'SCHEDULE_CONFLICT',
        conflicts
      });
      return;
    }

    const scheduleId = `exam-sch-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const startMin = parseTimeToMinutes(targetStartTime) || 540;
    const endMin = parseTimeToMinutes(targetEndTime) || 690;
    const calculatedDuration = durationMinutes ? Number(durationMinutes) : Math.max(endMin - startMin, 30);

    const newSchedule: ExamScheduleItem = {
      id: scheduleId,
      examId: exam.id,
      examName: exam.name,
      examType: exam.examType.toLowerCase().replace(/\s+/g, '_'),
      subjectId: subject.id,
      subjectName: subject.name,
      subjectCode: subject.code,
      classId: targetClassId,
      className: schoolClass ? schoolClass.name : exam.className || '',
      sectionId: targetSectionId,
      sectionName: section ? section.name : 'All Sections',
      academicSessionId: targetSessionId,
      academicSessionName: session ? session.name : exam.academicSessionName || '',
      examDate: examDate || exam.startDate,
      startTime: targetStartTime,
      endTime: targetEndTime,
      durationMinutes: calculatedDuration,
      roomNumber: targetRoom,
      fullMarks: numFullMarks,
      passMarks: numPassMarks,
      instructions: instructions ? instructions.trim() : exam.instructions,
      status: (status as ExamStatus) || mapToScheduleStatus(exam.status),
      invigilatorTeacherId,
      invigilatorName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.examSchedules.push(newSchedule);

    // Sync into Exam's subjectsConfig
    if (!exam.subjectsConfig) exam.subjectsConfig = [];
    const existingConfigIndex = exam.subjectsConfig.findIndex((c) => c.subjectId === subject.id);
    const configItem: ExamSubjectConfig = {
      id: existingConfigIndex >= 0 ? exam.subjectsConfig[existingConfigIndex].id : `exam-subj-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      examId: exam.id,
      subjectId: subject.id,
      subjectName: subject.name,
      subjectCode: subject.code,
      fullMarks: numFullMarks,
      passMarks: numPassMarks,
      examDurationMinutes: calculatedDuration,
      examDate: newSchedule.examDate,
      startTime: targetStartTime,
      endTime: targetEndTime,
      roomNumber: targetRoom,
      invigilatorTeacherId,
      invigilatorName,
      instructions: newSchedule.instructions,
      orderIndex: existingConfigIndex >= 0 ? exam.subjectsConfig[existingConfigIndex].orderIndex : exam.subjectsConfig.length + 1,
      createdAt: existingConfigIndex >= 0 ? exam.subjectsConfig[existingConfigIndex].createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (existingConfigIndex >= 0) {
      exam.subjectsConfig[existingConfigIndex] = configItem;
    } else {
      exam.subjectsConfig.push(configItem);
    }
    exam.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SCHEDULE_CREATE',
      entityType: 'ExamSchedule',
      entityId: newSchedule.id,
      details: `Created schedule for "${newSchedule.subjectName}" (${newSchedule.examName}) on ${newSchedule.examDate} (${newSchedule.startTime}-${newSchedule.endTime}) in ${newSchedule.roomNumber}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      message: `Schedule for "${newSchedule.subjectName}" created successfully without conflicts.`,
      data: newSchedule
    });
  }
);

// Update existing schedule slot
examinationRouter.put(
  '/schedules/:id',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const scheduleIndex = (database.examSchedules || []).findIndex((s) => s.id === id);

    if (scheduleIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Exam schedule slot not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const currentSchedule = database.examSchedules[scheduleIndex];
    const {
      examDate,
      startTime,
      endTime,
      durationMinutes,
      roomNumber,
      fullMarks,
      passMarks,
      invigilatorTeacherId,
      instructions,
      status,
      sectionId
    } = req.body;

    let invigilatorName = currentSchedule.invigilatorName;
    if (invigilatorTeacherId !== undefined) {
      if (invigilatorTeacherId) {
        const teacher = database.teacherProfiles.find((t) => t.id === invigilatorTeacherId);
        if (teacher) {
          const user = database.users.find((u) => u.id === teacher.userId);
          invigilatorName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || (user ? `${user.firstName} ${user.lastName}` : teacher.employeeCode);
        } else {
          invigilatorName = undefined;
        }
      } else {
        invigilatorName = undefined;
      }
    }

    const targetDate = examDate || currentSchedule.examDate;
    const targetStartTime = startTime ? startTime.trim() : currentSchedule.startTime;
    const targetEndTime = endTime ? endTime.trim() : currentSchedule.endTime;
    const targetRoom = roomNumber !== undefined ? roomNumber.trim() : currentSchedule.roomNumber;
    const targetSectionId = sectionId !== undefined ? sectionId : currentSchedule.sectionId;
    const numFullMarks = fullMarks !== undefined ? Number(fullMarks) : currentSchedule.fullMarks;
    const numPassMarks = passMarks !== undefined ? Number(passMarks) : currentSchedule.passMarks;

    // Run Conflict Engine excluding self
    const conflicts = checkScheduleConflicts({
      scheduleId: currentSchedule.id,
      examId: currentSchedule.examId,
      subjectId: currentSchedule.subjectId,
      classId: currentSchedule.classId,
      sectionId: targetSectionId,
      examDate: targetDate,
      startTime: targetStartTime,
      endTime: targetEndTime,
      roomNumber: targetRoom,
      invigilatorTeacherId: invigilatorTeacherId !== undefined ? invigilatorTeacherId : currentSchedule.invigilatorTeacherId,
      invigilatorName,
      fullMarks: numFullMarks,
      passMarks: numPassMarks
    });

    if (conflicts.length > 0) {
      res.status(400).json({
        success: false,
        error: conflicts[0].message,
        code: 'SCHEDULE_CONFLICT',
        conflicts
      });
      return;
    }

    const startMin = parseTimeToMinutes(targetStartTime) || 540;
    const endMin = parseTimeToMinutes(targetEndTime) || 690;
    const calculatedDuration = durationMinutes ? Number(durationMinutes) : Math.max(endMin - startMin, 30);

    const section =
      targetSectionId === 'ALL'
        ? { name: 'All Sections' }
        : database.sections.find((s) => s.id === targetSectionId);

    const updatedSchedule: ExamScheduleItem = {
      ...currentSchedule,
      examDate: targetDate,
      startTime: targetStartTime,
      endTime: targetEndTime,
      durationMinutes: calculatedDuration,
      roomNumber: targetRoom,
      sectionId: targetSectionId,
      sectionName: section ? section.name : currentSchedule.sectionName,
      fullMarks: numFullMarks,
      passMarks: numPassMarks,
      instructions: instructions !== undefined ? instructions : currentSchedule.instructions,
      status: status !== undefined ? (status as ExamStatus) : currentSchedule.status,
      invigilatorTeacherId: invigilatorTeacherId !== undefined ? invigilatorTeacherId : currentSchedule.invigilatorTeacherId,
      invigilatorName,
      updatedAt: new Date().toISOString()
    };

    database.examSchedules[scheduleIndex] = updatedSchedule;

    // Sync with Examination subjectsConfig
    const exam = database.examinations.find((e) => e.id === updatedSchedule.examId);
    if (exam && exam.subjectsConfig) {
      const cfgIdx = exam.subjectsConfig.findIndex((c) => c.subjectId === updatedSchedule.subjectId);
      if (cfgIdx >= 0) {
        exam.subjectsConfig[cfgIdx] = {
          ...exam.subjectsConfig[cfgIdx],
          examDate: updatedSchedule.examDate,
          startTime: updatedSchedule.startTime,
          endTime: updatedSchedule.endTime,
          roomNumber: updatedSchedule.roomNumber,
          fullMarks: updatedSchedule.fullMarks,
          passMarks: updatedSchedule.passMarks,
          examDurationMinutes: updatedSchedule.durationMinutes,
          invigilatorTeacherId: updatedSchedule.invigilatorTeacherId,
          invigilatorName: updatedSchedule.invigilatorName,
          instructions: updatedSchedule.instructions,
          updatedAt: new Date().toISOString()
        };
        exam.updatedAt = new Date().toISOString();
      }
    }

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SCHEDULE_UPDATE',
      entityType: 'ExamSchedule',
      entityId: updatedSchedule.id,
      details: `Updated schedule slot for "${updatedSchedule.subjectName}" (${updatedSchedule.examName})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Schedule for "${updatedSchedule.subjectName}" updated successfully.`,
      data: updatedSchedule
    });
  }
);

// Quick status transition for a schedule slot
examinationRouter.patch(
  '/schedules/:id/status',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses: ExamStatus[] = ['scheduled', 'ongoing', 'completed', 'postponed', 'cancelled'];
    if (!status || !validStatuses.includes(status as ExamStatus)) {
      res.status(400).json({
        success: false,
        error: `Invalid schedule status "${status}". Allowed values: ${validStatuses.join(', ')}`,
        code: 'INVALID_STATUS'
      });
      return;
    }

    const schedule = (database.examSchedules || []).find((s) => s.id === id);
    if (!schedule) {
      res.status(404).json({
        success: false,
        error: 'Exam schedule slot not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const prevStatus = schedule.status;
    schedule.status = status as ExamStatus;
    schedule.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SCHEDULE_STATUS_UPDATE',
      entityType: 'ExamSchedule',
      entityId: schedule.id,
      details: `Changed status of "${schedule.subjectName}" (${schedule.examName}) from ${prevStatus} to ${status}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Schedule status updated to "${status}".`,
      data: schedule
    });
  }
);

// Quick invigilator assign/reassign
examinationRouter.patch(
  '/schedules/:id/invigilator',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const { teacherId } = req.body;

    const schedule = (database.examSchedules || []).find((s) => s.id === id);
    if (!schedule) {
      res.status(404).json({
        success: false,
        error: 'Exam schedule slot not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    let teacherName: string | undefined = undefined;
    if (teacherId) {
      const teacher = database.teacherProfiles.find((t) => t.id === teacherId);
      if (!teacher) {
        res.status(404).json({
          success: false,
          error: 'Specified teacher profile not found.',
          code: 'TEACHER_NOT_FOUND'
        });
        return;
      }
      const user = database.users.find((u) => u.id === teacher.userId);
      teacherName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || (user ? `${user.firstName} ${user.lastName}` : teacher.employeeCode);

      // Validate teacher overlap conflict!
      const conflicts = checkScheduleConflicts({
        scheduleId: schedule.id,
        examId: schedule.examId,
        subjectId: schedule.subjectId,
        classId: schedule.classId,
        sectionId: schedule.sectionId,
        examDate: schedule.examDate,
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        roomNumber: schedule.roomNumber,
        invigilatorTeacherId: teacherId,
        invigilatorName: teacherName
      });

      const teacherConflicts = conflicts.filter((c) => c.type === 'TEACHER_OVERLAP');
      if (teacherConflicts.length > 0) {
        res.status(400).json({
          success: false,
          error: teacherConflicts[0].message,
          code: 'TEACHER_OVERLAP',
          conflicts: teacherConflicts
        });
        return;
      }
    }

    schedule.invigilatorTeacherId = teacherId || undefined;
    schedule.invigilatorName = teacherName;
    schedule.updatedAt = new Date().toISOString();

    // Sync to Exam subjectsConfig
    const exam = database.examinations.find((e) => e.id === schedule.examId);
    if (exam && exam.subjectsConfig) {
      const cfg = exam.subjectsConfig.find((c) => c.subjectId === schedule.subjectId);
      if (cfg) {
        cfg.invigilatorTeacherId = schedule.invigilatorTeacherId;
        cfg.invigilatorName = schedule.invigilatorName;
        cfg.updatedAt = new Date().toISOString();
        exam.updatedAt = new Date().toISOString();
      }
    }

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SCHEDULE_INVIGILATOR_ASSIGN',
      entityType: 'ExamSchedule',
      entityId: schedule.id,
      details: teacherName
        ? `Assigned invigilator "${teacherName}" to "${schedule.subjectName}" (${schedule.examName})`
        : `Removed invigilator from "${schedule.subjectName}" (${schedule.examName})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: teacherName ? `Assigned ${teacherName} as invigilator.` : 'Invigilator unassigned.',
      data: schedule
    });
  }
);

// Delete schedule slot
examinationRouter.delete(
  '/schedules/:id',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { id } = req.params;
    const scheduleIndex = (database.examSchedules || []).findIndex((s) => s.id === id);

    if (scheduleIndex === -1) {
      res.status(404).json({
        success: false,
        error: 'Exam schedule slot not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const removed = database.examSchedules.splice(scheduleIndex, 1)[0];

    // Remove from linked examination subjectsConfig if present
    const exam = database.examinations.find((e) => e.id === removed.examId);
    if (exam && exam.subjectsConfig) {
      exam.subjectsConfig = exam.subjectsConfig.filter((c) => c.subjectId !== removed.subjectId);
      exam.updatedAt = new Date().toISOString();
    }

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'EXAM_SCHEDULE_DELETE',
      entityType: 'ExamSchedule',
      entityId: removed.id,
      details: `Deleted exam schedule slot for "${removed.subjectName}" (${removed.examName})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Schedule for "${removed.subjectName}" deleted successfully.`
    });
  }
);

// =========================================================================
// PART 6C: TEACHER MARKS ENTRY & SUBMISSION ENDPOINTS
// =========================================================================

// Helper: Check if requesting teacher is authorized for an exam and subject
export function isTeacherAuthorizedForExamSubject(
  user: any,
  teacherProfile: any,
  exam: Examination,
  subjectId: string,
  classId: string,
  sectionId?: string
): boolean {
  const roleStr = String(user.role || '').toUpperCase();
  if (roleStr === 'SUPER_ADMIN' || roleStr === 'ADMIN') return true;
  if (!teacherProfile) return false;

  // 1. Subject config invigilator match
  const hasSubjectConfigMatch = exam.subjectsConfig?.some(
    (c) => c.subjectId === subjectId && c.invigilatorTeacherId === teacherProfile.id
  );
  if (hasSubjectConfigMatch) return true;

  // 2. Exam schedule invigilator match
  const hasScheduleMatch = (database.examSchedules || []).some(
    (s) => s.examId === exam.id && s.subjectId === subjectId && s.invigilatorTeacherId === teacherProfile.id
  );
  if (hasScheduleMatch) return true;

  // 3. Teacher profile assigned class and subject match
  const targetClassId = classId || exam.classId;
  const hasClassMatch =
    teacherProfile.assignedClassIds?.includes(targetClassId) ||
    teacherProfile.assignedClassIds?.includes(exam.classId);
  const hasSubjectMatch = teacherProfile.assignedSubjectIds?.includes(subjectId);
  if (hasClassMatch && hasSubjectMatch) return true;

  // 4. Primary subject teacher
  const subject = database.subjects.find((s) => s.id === subjectId);
  if (subject && (subject.teacherId === teacherProfile.id || subject.teacherId === teacherProfile.userId)) {
    return true;
  }

  // 5. Fallback: Teacher invigilating the exam cycle
  if (teacherProfile.invigilatorExamIds?.includes(exam.id)) return true;

  return false;
}

// 1. Get all assigned exams & subjects for the logged-in teacher
examinationRouter.get(
  '/teacher/assigned-subjects',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);

    if (user.role === 'TEACHER' && !teacherProfile) {
      res.status(403).json({
        success: false,
        error: 'Teacher profile not found for the authenticated user.',
        code: 'TEACHER_PROFILE_NOT_FOUND'
      });
      return;
    }

    const assignedList: TeacherAssignedExamSubject[] = [];
    const allExams = database.examinations || [];

    for (const exam of allExams) {
      // Skip archived exams if desired, or include all active/published
      if (exam.status === 'archived') continue;

      const schoolClass = database.classes.find((c) => c.id === exam.classId);
      const section =
        exam.sectionId === 'ALL'
          ? { name: 'All Sections' }
          : database.sections.find((s) => s.id === exam.sectionId);
      const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);

      // Determine subjects configured for this exam
      const configs = exam.subjectsConfig || [];
      const classSubjects = database.subjects.filter((s) => s.classId === exam.classId);

      // If exam has specific subjectsConfig, use them; otherwise use class subjects
      const subjectsToInspect = configs.length > 0
        ? configs.map((cfg) => {
            const subj = database.subjects.find((s) => s.id === cfg.subjectId);
            return {
              subjectId: cfg.subjectId,
              subjectName: cfg.subjectName || subj?.name || 'Subject',
              subjectCode: cfg.subjectCode || subj?.code || '',
              examDate: cfg.examDate || exam.startDate,
              startTime: cfg.startTime || '09:00 AM',
              endTime: cfg.endTime || '11:30 AM',
              roomNumber: cfg.roomNumber || 'Main Hall',
              fullMarks: Number(cfg.fullMarks) || 100,
              passMarks: Number(cfg.passMarks) || 40,
              invigilatorTeacherId: cfg.invigilatorTeacherId
            };
          })
        : classSubjects.map((subj) => ({
            subjectId: subj.id,
            subjectName: subj.name,
            subjectCode: subj.code,
            examDate: exam.startDate,
            startTime: '09:00 AM',
            endTime: '11:30 AM',
            roomNumber: 'Main Hall',
            fullMarks: 100,
            passMarks: 40,
            invigilatorTeacherId: subj.teacherId
          }));

      for (const subjItem of subjectsToInspect) {
        const isAuthorized = isTeacherAuthorizedForExamSubject(
          user,
          teacherProfile,
          exam,
          subjItem.subjectId,
          exam.classId,
          exam.sectionId
        );

        if (isAuthorized) {
          // Find existing submission
          const existingSubmission = (database.examMarksSubmissions || []).find(
            (sub) => sub.examId === exam.id && sub.subjectId === subjItem.subjectId
          );

          // Count eligible students in this class/section
          const eligibleStudents = database.studentProfiles.filter((s) => {
            const classMatch = s.classId === exam.classId;
            const sectionMatch = exam.sectionId === 'ALL' || s.sectionId === exam.sectionId;
            const statusMatch = s.status === 'active';
            return classMatch && sectionMatch && statusMatch;
          });

          const totalStudents = eligibleStudents.length;
          const enteredCount = existingSubmission
            ? existingSubmission.marks.filter((m) => m.obtainedMarks !== null || m.isAbsent || m.isExempt).length
            : 0;

          assignedList.push({
            examId: exam.id,
            examName: exam.name,
            examType: exam.examType,
            academicSessionId: exam.academicSessionId,
            academicSessionName: session ? session.name : exam.academicSessionName || '',
            classId: exam.classId,
            className: schoolClass ? schoolClass.name : exam.className || '',
            sectionId: exam.sectionId,
            sectionName: section ? section.name : 'All Sections',
            subjectId: subjItem.subjectId,
            subjectName: subjItem.subjectName,
            subjectCode: subjItem.subjectCode,
            examDate: subjItem.examDate,
            startTime: subjItem.startTime,
            endTime: subjItem.endTime,
            roomNumber: subjItem.roomNumber,
            fullMarks: subjItem.fullMarks,
            passMarks: subjItem.passMarks,
            submissionStatus: existingSubmission ? existingSubmission.status : 'not_started',
            submissionId: existingSubmission ? existingSubmission.id : undefined,
            totalStudents,
            enteredCount,
            submittedAt: existingSubmission?.submittedAt,
            submittedBy: existingSubmission?.submittedBy,
            returnedReason: existingSubmission?.returnedReason,
            isAssignedDirectly: !!subjItem.invigilatorTeacherId
          });
        }
      }
    }

    // Sort by examDate descending, then by examName
    assignedList.sort((a, b) => {
      if (a.examDate !== b.examDate) return b.examDate.localeCompare(a.examDate);
      return a.examName.localeCompare(b.examName);
    });

    res.json({
      success: true,
      data: assignedList,
      total: assignedList.length
    });
  }
);

// 2. Get Student Marks Entry Sheet for a specific Exam and Subject
examinationRouter.get(
  '/teacher/marks-sheet',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { examId, subjectId } = req.query as { examId?: string; subjectId?: string };

    if (!examId || !subjectId) {
      res.status(400).json({
        success: false,
        error: 'Both examId and subjectId query parameters are required.',
        code: 'MISSING_PARAMETERS'
      });
      return;
    }

    const exam = database.examinations.find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'EXAM_NOT_FOUND'
      });
      return;
    }

    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
    const isAuthorized = isTeacherAuthorizedForExamSubject(
      user,
      teacherProfile,
      exam,
      subjectId,
      exam.classId,
      exam.sectionId
    );

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to enter marks for this exam and subject.',
        code: 'FORBIDDEN_EXAM_SUBJECT'
      });
      return;
    }

    const subject = database.subjects.find((s) => s.id === subjectId);
    const schoolClass = database.classes.find((c) => c.id === exam.classId);
    const section =
      exam.sectionId === 'ALL'
        ? { id: 'ALL', name: 'All Sections' }
        : database.sections.find((s) => s.id === exam.sectionId);
    const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);

    // Subject config details
    const subjectCfg = exam.subjectsConfig?.find((c) => c.subjectId === subjectId);
    const fullMarks = subjectCfg ? Number(subjectCfg.fullMarks) : 100;
    const passMarks = subjectCfg ? Number(subjectCfg.passMarks) : 40;
    const examDate = subjectCfg?.examDate || exam.startDate;
    const startTime = subjectCfg?.startTime || '09:00 AM';
    const endTime = subjectCfg?.endTime || '11:30 AM';
    const roomNumber = subjectCfg?.roomNumber || 'Main Examination Hall';

    // Retrieve eligible active students
    const eligibleStudents = database.studentProfiles.filter((s) => {
      const classMatch = s.classId === exam.classId;
      const sectionMatch = exam.sectionId === 'ALL' || s.sectionId === exam.sectionId;
      const statusMatch = s.status === 'active';
      return classMatch && sectionMatch && statusMatch;
    });

    // Sort students by rollNumber numeric/asc, then by firstName
    eligibleStudents.sort((a, b) => {
      const rollA = parseInt(a.rollNumber || '0', 10);
      const rollB = parseInt(b.rollNumber || '0', 10);
      if (rollA !== rollB) return rollA - rollB;
      return `${a.firstName} ${a.lastName}`.localeCompare(`${b.firstName} ${b.lastName}`);
    });

    // Find existing submission
    const existingSubmission = (database.examMarksSubmissions || []).find(
      (sub) => sub.examId === exam.id && sub.subjectId === subjectId
    );

    // Build student mark items list
    const studentMarksList: StudentMarkItem[] = eligibleStudents.map((stud) => {
      const studentUser = database.users.find((u) => u.id === stud.userId);
      const studentSection = database.sections.find((sec) => sec.id === stud.sectionId);
      const savedMark = existingSubmission?.marks.find((m) => m.studentId === stud.id);

      const obtainedMarks = savedMark?.obtainedMarks !== undefined ? savedMark.obtainedMarks : null;
      const isAbsent = savedMark?.isAbsent || false;
      const isExempt = savedMark?.isExempt || false;
      const isPassed = obtainedMarks !== null && !isAbsent ? obtainedMarks >= passMarks : undefined;

      return {
        studentId: stud.id,
        userId: stud.userId,
        admissionNumber: stud.admissionNumber,
        rollNumber: stud.rollNumber || 'N/A',
        studentName: `${stud.firstName} ${stud.lastName}`.trim(),
        avatarUrl: studentUser?.avatarUrl || stud.avatarUrl,
        classId: stud.classId,
        className: schoolClass ? schoolClass.name : exam.className || '',
        sectionId: stud.sectionId,
        sectionName: studentSection ? studentSection.name : '',
        obtainedMarks,
        isAbsent,
        isExempt,
        remarks: savedMark?.remarks || '',
        isPassed,
        updatedAt: savedMark?.updatedAt
      };
    });

    const totalStudents = studentMarksList.length;
    const enteredCount = studentMarksList.filter((m) => m.obtainedMarks !== null || m.isAbsent || m.isExempt).length;
    const absentCount = studentMarksList.filter((m) => m.isAbsent).length;
    const exemptCount = studentMarksList.filter((m) => m.isExempt).length;
    const passedCount = studentMarksList.filter((m) => m.isPassed === true).length;
    const failedCount = studentMarksList.filter((m) => m.isPassed === false && !m.isAbsent && !m.isExempt).length;

    const currentStatus: ExamMarksSubmissionStatus = existingSubmission
      ? existingSubmission.status
      : enteredCount > 0 ? 'draft' : 'not_started';

    res.json({
      success: true,
      data: {
        exam: {
          id: exam.id,
          name: exam.name,
          examType: exam.examType,
          status: exam.status,
          startDate: exam.startDate,
          endDate: exam.endDate,
          academicSessionId: exam.academicSessionId,
          academicSessionName: session ? session.name : exam.academicSessionName || '',
          classId: exam.classId,
          className: schoolClass ? schoolClass.name : exam.className || '',
          sectionId: exam.sectionId,
          sectionName: section ? section.name : 'All Sections',
          instructions: exam.instructions
        },
        subject: {
          id: subjectId,
          name: subject?.name || subjectCfg?.subjectName || 'Subject',
          code: subject?.code || subjectCfg?.subjectCode || '',
          fullMarks,
          passMarks,
          examDate,
          startTime,
          endTime,
          roomNumber
        },
        submission: existingSubmission
          ? {
              id: existingSubmission.id,
              status: existingSubmission.status,
              teacherName: existingSubmission.teacherName,
              submittedAt: existingSubmission.submittedAt,
              submittedBy: existingSubmission.submittedBy,
              returnedAt: existingSubmission.returnedAt,
              returnedReason: existingSubmission.returnedReason,
              returnedBy: existingSubmission.returnedBy,
              notes: existingSubmission.notes,
              updatedAt: existingSubmission.updatedAt
            }
          : null,
        status: currentStatus,
        isEditable: currentStatus !== 'submitted' && currentStatus !== 'approved',
        stats: {
          totalStudents,
          enteredCount,
          absentCount,
          exemptCount,
          passedCount,
          failedCount,
          isComplete: enteredCount === totalStudents
        },
        students: studentMarksList
      }
    });
  }
);

// 3. Save Draft Marks (In-Progress / Draft state)
examinationRouter.post(
  '/teacher/save-draft',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { examId, subjectId, marks, notes } = req.body as SaveDraftMarksPayload;

    if (!examId || !subjectId || !Array.isArray(marks)) {
      res.status(400).json({
        success: false,
        error: 'Invalid payload: examId, subjectId, and marks array are required.',
        code: 'INVALID_PAYLOAD'
      });
      return;
    }

    const exam = database.examinations.find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'EXAM_NOT_FOUND'
      });
      return;
    }

    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
    const isAuthorized = isTeacherAuthorizedForExamSubject(
      user,
      teacherProfile,
      exam,
      subjectId,
      exam.classId,
      exam.sectionId
    );

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to edit marks for this subject.',
        code: 'FORBIDDEN_EXAM_SUBJECT'
      });
      return;
    }

    const subjectCfg = exam.subjectsConfig?.find((c) => c.subjectId === subjectId);
    const subject = database.subjects.find((s) => s.id === subjectId);
    const schoolClass = database.classes.find((c) => c.id === exam.classId);
    const section =
      exam.sectionId === 'ALL'
        ? { name: 'All Sections' }
        : database.sections.find((s) => s.id === exam.sectionId);
    const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);

    const fullMarks = subjectCfg ? Number(subjectCfg.fullMarks) : 100;
    const passMarks = subjectCfg ? Number(subjectCfg.passMarks) : 40;

    // Check if already submitted or approved
    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];
    const existingIndex = database.examMarksSubmissions.findIndex(
      (s) => s.examId === examId && s.subjectId === subjectId
    );

    if (existingIndex >= 0) {
      const existing = database.examMarksSubmissions[existingIndex];
      if (existing.status === 'submitted' && user.role === 'TEACHER') {
        res.status(400).json({
          success: false,
          error: 'Marks have already been submitted. Contact Administrator to request corrections.',
          code: 'ALREADY_SUBMITTED'
        });
        return;
      }
      if (existing.status === 'approved') {
        res.status(400).json({
          success: false,
          error: 'Marks have already been approved by administration and cannot be modified.',
          code: 'ALREADY_APPROVED'
        });
        return;
      }
    }

    // Validate Marks
    const validStudentMarks: StudentMarkItem[] = [];
    for (const markItem of marks) {
      const stud = database.studentProfiles.find((s) => s.id === markItem.studentId);
      if (!stud) continue;

      // Ensure student belongs to class
      if (stud.classId !== exam.classId) {
        res.status(400).json({
          success: false,
          error: `Security violation: Student "${stud.firstName} ${stud.lastName}" does not belong to Class ${schoolClass?.name}.`,
          code: 'STUDENT_OUTSIDE_EXAM'
        });
        return;
      }

      const isAbsent = !!markItem.isAbsent;
      const isExempt = !!markItem.isExempt;
      let numericMarks: number | null = null;

      if (!isAbsent && !isExempt && markItem.obtainedMarks !== null && markItem.obtainedMarks !== undefined) {
        const val = Number(markItem.obtainedMarks);
        if (isNaN(val) || val < 0) {
          res.status(400).json({
            success: false,
            error: `Marks for student "${stud.firstName} ${stud.lastName}" cannot be negative or invalid.`,
            code: 'INVALID_MARKS_RANGE'
          });
          return;
        }
        if (val > fullMarks) {
          res.status(400).json({
            success: false,
            error: `Marks (${val}) for student "${stud.firstName} ${stud.lastName}" cannot exceed full marks (${fullMarks}).`,
            code: 'MARKS_EXCEEDS_FULL'
          });
          return;
        }
        numericMarks = val;
      }

      const studentUser = database.users.find((u) => u.id === stud.userId);
      const studentSection = database.sections.find((sec) => sec.id === stud.sectionId);
      const isPassed = numericMarks !== null && !isAbsent ? numericMarks >= passMarks : undefined;

      validStudentMarks.push({
        studentId: stud.id,
        userId: stud.userId,
        admissionNumber: stud.admissionNumber,
        rollNumber: stud.rollNumber || 'N/A',
        studentName: `${stud.firstName} ${stud.lastName}`.trim(),
        avatarUrl: studentUser?.avatarUrl || stud.avatarUrl,
        classId: stud.classId,
        className: schoolClass ? schoolClass.name : exam.className || '',
        sectionId: stud.sectionId,
        sectionName: studentSection ? studentSection.name : '',
        obtainedMarks: numericMarks,
        isAbsent,
        isExempt,
        remarks: markItem.remarks ? markItem.remarks.trim() : undefined,
        isPassed,
        updatedAt: new Date().toISOString()
      });
    }

    // Compute Telemetry Stats
    const eligibleStudents = database.studentProfiles.filter(
      (s) => s.classId === exam.classId && (exam.sectionId === 'ALL' || s.sectionId === exam.sectionId) && s.status === 'active'
    );
    const totalStudents = eligibleStudents.length;
    const enteredCount = validStudentMarks.filter((m) => m.obtainedMarks !== null || m.isAbsent || m.isExempt).length;
    const absentCount = validStudentMarks.filter((m) => m.isAbsent).length;
    const exemptCount = validStudentMarks.filter((m) => m.isExempt).length;
    const passedCount = validStudentMarks.filter((m) => m.isPassed === true).length;
    const failedCount = validStudentMarks.filter((m) => m.isPassed === false && !m.isAbsent && !m.isExempt).length;

    const scoredMarks = validStudentMarks.map((m) => m.obtainedMarks).filter((m): m is number => m !== null);
    const averageMarks = scoredMarks.length > 0 ? Number((scoredMarks.reduce((a, b) => a + b, 0) / scoredMarks.length).toFixed(2)) : 0;
    const highestMarks = scoredMarks.length > 0 ? Math.max(...scoredMarks) : 0;
    const lowestMarks = scoredMarks.length > 0 ? Math.min(...scoredMarks) : 0;

    const teacherName = teacherProfile
      ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() || `${user.firstName} ${user.lastName}`
      : `${user.firstName} ${user.lastName}`;

    const submissionId = existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].id : `sub-marks-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const submissionDoc: ExamMarksSubmission = {
      id: submissionId,
      examId: exam.id,
      examName: exam.name,
      examType: exam.examType,
      academicSessionId: exam.academicSessionId,
      academicSessionName: session ? session.name : exam.academicSessionName || '',
      subjectId,
      subjectName: subject?.name || subjectCfg?.subjectName || 'Subject',
      subjectCode: subject?.code || subjectCfg?.subjectCode || '',
      classId: exam.classId,
      className: schoolClass ? schoolClass.name : exam.className || '',
      sectionId: exam.sectionId,
      sectionName: section ? section.name : 'All Sections',
      examDate: subjectCfg?.examDate || exam.startDate,
      startTime: subjectCfg?.startTime || '09:00 AM',
      endTime: subjectCfg?.endTime || '11:30 AM',
      roomNumber: subjectCfg?.roomNumber || 'Main Examination Hall',
      fullMarks,
      passMarks,
      status: enteredCount > 0 ? 'draft' : 'not_started',
      teacherId: teacherProfile ? teacherProfile.id : 'admin-override',
      teacherName,
      teacherUserId: user.id,
      marks: validStudentMarks,
      totalStudents,
      enteredCount,
      passedCount,
      failedCount,
      absentCount,
      exemptCount,
      averageMarks,
      highestMarks,
      lowestMarks,
      notes: notes !== undefined ? notes : (existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].notes : ''),
      createdAt: existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      database.examMarksSubmissions[existingIndex] = submissionDoc;
    } else {
      database.examMarksSubmissions.push(submissionDoc);
    }

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'EXAM_MARKS_DRAFT_SAVE',
      entityType: 'ExamMarksSubmission',
      entityId: submissionDoc.id,
      details: `Saved draft marks for ${submissionDoc.subjectName} (${submissionDoc.examName}) - ${enteredCount}/${totalStudents} entered.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Draft marks saved successfully (${enteredCount}/${totalStudents} students recorded).`,
      data: submissionDoc
    });
  }
);

// 4. Submit Final Marks (Lock entry, record submission time, transition status to 'submitted')
examinationRouter.post(
  '/teacher/submit-marks',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { examId, subjectId, marks, notes } = req.body as SubmitMarksPayload;

    if (!examId || !subjectId || !Array.isArray(marks)) {
      res.status(400).json({
        success: false,
        error: 'Invalid payload: examId, subjectId, and marks array are required.',
        code: 'INVALID_PAYLOAD'
      });
      return;
    }

    const exam = database.examinations.find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({
        success: false,
        error: 'Examination not found.',
        code: 'EXAM_NOT_FOUND'
      });
      return;
    }

    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
    const isAuthorized = isTeacherAuthorizedForExamSubject(
      user,
      teacherProfile,
      exam,
      subjectId,
      exam.classId,
      exam.sectionId
    );

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to submit marks for this subject.',
        code: 'FORBIDDEN_EXAM_SUBJECT'
      });
      return;
    }

    const subjectCfg = exam.subjectsConfig?.find((c) => c.subjectId === subjectId);
    const subject = database.subjects.find((s) => s.id === subjectId);
    const schoolClass = database.classes.find((c) => c.id === exam.classId);
    const section =
      exam.sectionId === 'ALL'
        ? { name: 'All Sections' }
        : database.sections.find((s) => s.id === exam.sectionId);
    const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);

    const fullMarks = subjectCfg ? Number(subjectCfg.fullMarks) : 100;
    const passMarks = subjectCfg ? Number(subjectCfg.passMarks) : 40;

    // Check if already submitted or approved
    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];
    const existingIndex = database.examMarksSubmissions.findIndex(
      (s) => s.examId === examId && s.subjectId === subjectId
    );

    if (existingIndex >= 0) {
      const existing = database.examMarksSubmissions[existingIndex];
      if (existing.status === 'submitted' && user.role === 'TEACHER') {
        res.status(400).json({
          success: false,
          error: 'Marks have already been submitted. Contact Administrator if you need to request changes.',
          code: 'ALREADY_SUBMITTED'
        });
        return;
      }
      if (existing.status === 'approved') {
        res.status(400).json({
          success: false,
          error: 'Marks are already approved and locked.',
          code: 'ALREADY_APPROVED'
        });
        return;
      }
    }

    // Retrieve all eligible students to ensure complete record entry
    const eligibleStudents = database.studentProfiles.filter(
      (s) => s.classId === exam.classId && (exam.sectionId === 'ALL' || s.sectionId === exam.sectionId) && s.status === 'active'
    );

    // Validate marks for every student
    const validStudentMarks: StudentMarkItem[] = [];
    const missingStudents: string[] = [];

    for (const stud of eligibleStudents) {
      const markEntry = marks.find((m) => m.studentId === stud.id);
      if (!markEntry) {
        missingStudents.push(`${stud.firstName} ${stud.lastName} (Roll: ${stud.rollNumber || 'N/A'})`);
        continue;
      }

      const isAbsent = !!markEntry.isAbsent;
      const isExempt = !!markEntry.isExempt;
      let numericMarks: number | null = null;

      if (!isAbsent && !isExempt) {
        if (markEntry.obtainedMarks === null || markEntry.obtainedMarks === undefined || markEntry.obtainedMarks === ('') as any) {
          missingStudents.push(`${stud.firstName} ${stud.lastName} (Roll: ${stud.rollNumber || 'N/A'})`);
          continue;
        }
        const val = Number(markEntry.obtainedMarks);
        if (isNaN(val) || val < 0) {
          res.status(400).json({
            success: false,
            error: `Invalid marks entered for "${stud.firstName} ${stud.lastName}". Marks must be non-negative.`,
            code: 'INVALID_MARKS'
          });
          return;
        }
        if (val > fullMarks) {
          res.status(400).json({
            success: false,
            error: `Marks (${val}) for "${stud.firstName} ${stud.lastName}" exceed full marks (${fullMarks}).`,
            code: 'MARKS_EXCEEDS_FULL'
          });
          return;
        }
        numericMarks = val;
      }

      const studentUser = database.users.find((u) => u.id === stud.userId);
      const studentSection = database.sections.find((sec) => sec.id === stud.sectionId);
      const isPassed = numericMarks !== null && !isAbsent ? numericMarks >= passMarks : undefined;

      validStudentMarks.push({
        studentId: stud.id,
        userId: stud.userId,
        admissionNumber: stud.admissionNumber,
        rollNumber: stud.rollNumber || 'N/A',
        studentName: `${stud.firstName} ${stud.lastName}`.trim(),
        avatarUrl: studentUser?.avatarUrl || stud.avatarUrl,
        classId: stud.classId,
        className: schoolClass ? schoolClass.name : exam.className || '',
        sectionId: stud.sectionId,
        sectionName: studentSection ? studentSection.name : '',
        obtainedMarks: numericMarks,
        isAbsent,
        isExempt,
        remarks: markEntry.remarks ? markEntry.remarks.trim() : undefined,
        isPassed,
        updatedAt: new Date().toISOString()
      });
    }

    // Require all students to have marks or be flagged absent/exempt before final submission
    if (missingStudents.length > 0) {
      res.status(400).json({
        success: false,
        error: `Cannot submit: ${missingStudents.length} student(s) have unrecorded marks. Please enter marks or mark as Absent/Exempt for: ${missingStudents.slice(0, 3).join(', ')}${missingStudents.length > 3 ? ` and ${missingStudents.length - 3} more` : ''}.`,
        code: 'INCOMPLETE_STUDENT_MARKS',
        missingStudents
      });
      return;
    }

    const totalStudents = eligibleStudents.length;
    const enteredCount = validStudentMarks.length;
    const absentCount = validStudentMarks.filter((m) => m.isAbsent).length;
    const exemptCount = validStudentMarks.filter((m) => m.isExempt).length;
    const passedCount = validStudentMarks.filter((m) => m.isPassed === true).length;
    const failedCount = validStudentMarks.filter((m) => m.isPassed === false && !m.isAbsent && !m.isExempt).length;

    const scoredMarks = validStudentMarks.map((m) => m.obtainedMarks).filter((m): m is number => m !== null);
    const averageMarks = scoredMarks.length > 0 ? Number((scoredMarks.reduce((a, b) => a + b, 0) / scoredMarks.length).toFixed(2)) : 0;
    const highestMarks = scoredMarks.length > 0 ? Math.max(...scoredMarks) : 0;
    const lowestMarks = scoredMarks.length > 0 ? Math.min(...scoredMarks) : 0;

    const teacherName = teacherProfile
      ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() || `${user.firstName} ${user.lastName}`
      : `${user.firstName} ${user.lastName}`;

    const submissionId = existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].id : `sub-marks-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const submissionDoc: ExamMarksSubmission = {
      id: submissionId,
      examId: exam.id,
      examName: exam.name,
      examType: exam.examType,
      academicSessionId: exam.academicSessionId,
      academicSessionName: session ? session.name : exam.academicSessionName || '',
      subjectId,
      subjectName: subject?.name || subjectCfg?.subjectName || 'Subject',
      subjectCode: subject?.code || subjectCfg?.subjectCode || '',
      classId: exam.classId,
      className: schoolClass ? schoolClass.name : exam.className || '',
      sectionId: exam.sectionId,
      sectionName: section ? section.name : 'All Sections',
      examDate: subjectCfg?.examDate || exam.startDate,
      startTime: subjectCfg?.startTime || '09:00 AM',
      endTime: subjectCfg?.endTime || '11:30 AM',
      roomNumber: subjectCfg?.roomNumber || 'Main Examination Hall',
      fullMarks,
      passMarks,
      status: 'submitted',
      teacherId: teacherProfile ? teacherProfile.id : 'admin-override',
      teacherName,
      teacherUserId: user.id,
      marks: validStudentMarks,
      totalStudents,
      enteredCount,
      passedCount,
      failedCount,
      absentCount,
      exemptCount,
      averageMarks,
      highestMarks,
      lowestMarks,
      submittedAt: new Date().toISOString(),
      submittedBy: teacherName,
      returnedAt: undefined,
      returnedReason: undefined,
      returnedBy: undefined,
      notes: notes !== undefined ? notes : (existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].notes : ''),
      createdAt: existingIndex >= 0 ? database.examMarksSubmissions[existingIndex].createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      database.examMarksSubmissions[existingIndex] = submissionDoc;
    } else {
      database.examMarksSubmissions.push(submissionDoc);
    }

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'EXAM_MARKS_SUBMIT',
      entityType: 'ExamMarksSubmission',
      entityId: submissionDoc.id,
      details: `Submitted marks for ${submissionDoc.subjectName} (${submissionDoc.examName}) - ${enteredCount} students submitted by ${teacherName}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Marks for "${submissionDoc.subjectName}" submitted successfully! Records have been forwarded to Administration for review.`,
      data: submissionDoc
    });
  }
);

// 5. ADMIN REVIEW: Get all marks submissions across all exams & subjects
examinationRouter.get(
  '/admin/marks-submissions',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      academicSessionId,
      examId,
      classId,
      sectionId,
      subjectId,
      teacherId,
      status,
      search,
      page,
      limit
    } = req.query as Record<string, string | undefined>;

    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];

    // Also build the full matrix of all active exam-subject pairs to show "not_started" slots
    const allExams = database.examinations || [];
    const fullMatrix: ExamMarksSubmission[] = [];

    for (const exam of allExams) {
      if (exam.status === 'archived') continue;
      const schoolClass = database.classes.find((c) => c.id === exam.classId);
      const section =
        exam.sectionId === 'ALL'
          ? { name: 'All Sections' }
          : database.sections.find((s) => s.id === exam.sectionId);
      const session = database.academicSessions.find((s) => s.id === exam.academicSessionId);

      const configs = exam.subjectsConfig || [];
      const classSubjects = database.subjects.filter((s) => s.classId === exam.classId);

      const subjectsToInspect = configs.length > 0
        ? configs.map((cfg) => {
            const subj = database.subjects.find((s) => s.id === cfg.subjectId);
            const teacher = database.teacherProfiles.find((t) => t.id === cfg.invigilatorTeacherId);
            return {
              subjectId: cfg.subjectId,
              subjectName: cfg.subjectName || subj?.name || 'Subject',
              subjectCode: cfg.subjectCode || subj?.code || '',
              examDate: cfg.examDate || exam.startDate,
              startTime: cfg.startTime || '09:00 AM',
              endTime: cfg.endTime || '11:30 AM',
              roomNumber: cfg.roomNumber || 'Main Hall',
              fullMarks: Number(cfg.fullMarks) || 100,
              passMarks: Number(cfg.passMarks) || 40,
              teacherId: cfg.invigilatorTeacherId || (subj?.teacherId || ''),
              teacherName: cfg.invigilatorName || (teacher ? `${teacher.firstName} ${teacher.lastName}` : 'Unassigned')
            };
          })
        : classSubjects.map((subj) => {
            const teacher = database.teacherProfiles.find((t) => t.id === subj.teacherId);
            return {
              subjectId: subj.id,
              subjectName: subj.name,
              subjectCode: subj.code,
              examDate: exam.startDate,
              startTime: '09:00 AM',
              endTime: '11:30 AM',
              roomNumber: 'Main Hall',
              fullMarks: 100,
              passMarks: 40,
              teacherId: subj.teacherId || '',
              teacherName: teacher ? `${teacher.firstName} ${teacher.lastName}` : 'Unassigned'
            };
          });

      for (const subjItem of subjectsToInspect) {
        const existing = database.examMarksSubmissions.find(
          (sub) => sub.examId === exam.id && sub.subjectId === subjItem.subjectId
        );

        if (existing) {
          fullMatrix.push(existing);
        } else {
          // Virtual un-started entry
          const eligibleStudents = database.studentProfiles.filter(
            (s) => s.classId === exam.classId && (exam.sectionId === 'ALL' || s.sectionId === exam.sectionId) && s.status === 'active'
          );
          fullMatrix.push({
            id: `virtual-${exam.id}-${subjItem.subjectId}`,
            examId: exam.id,
            examName: exam.name,
            examType: exam.examType,
            academicSessionId: exam.academicSessionId,
            academicSessionName: session ? session.name : exam.academicSessionName || '',
            subjectId: subjItem.subjectId,
            subjectName: subjItem.subjectName,
            subjectCode: subjItem.subjectCode,
            classId: exam.classId,
            className: schoolClass ? schoolClass.name : exam.className || '',
            sectionId: exam.sectionId,
            sectionName: section ? section.name : 'All Sections',
            examDate: subjItem.examDate,
            startTime: subjItem.startTime,
            endTime: subjItem.endTime,
            roomNumber: subjItem.roomNumber,
            fullMarks: subjItem.fullMarks,
            passMarks: subjItem.passMarks,
            status: 'not_started',
            teacherId: subjItem.teacherId,
            teacherName: subjItem.teacherName,
            teacherUserId: '',
            marks: [],
            totalStudents: eligibleStudents.length,
            enteredCount: 0,
            passedCount: 0,
            failedCount: 0,
            absentCount: 0,
            exemptCount: 0,
            averageMarks: 0,
            highestMarks: 0,
            lowestMarks: 0,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        }
      }
    }

    let filtered = [...fullMatrix];

    // Filter session
    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((s) => s.academicSessionId === academicSessionId);
    }
    // Filter exam
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((s) => s.examId === examId);
    }
    // Filter class
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((s) => s.classId === classId);
    }
    // Filter section
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((s) => s.sectionId === 'ALL' || s.sectionId === sectionId);
    }
    // Filter subject
    if (subjectId && subjectId !== 'ALL') {
      filtered = filtered.filter((s) => s.subjectId === subjectId);
    }
    // Filter teacher
    if (teacherId && teacherId !== 'ALL') {
      filtered = filtered.filter((s) => s.teacherId === teacherId);
    }
    // Filter status
    if (status && status !== 'ALL') {
      filtered = filtered.filter((s) => s.status === status);
    }
    // Search
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered = filtered.filter(
        (s) =>
          s.examName.toLowerCase().includes(q) ||
          s.subjectName.toLowerCase().includes(q) ||
          s.subjectCode.toLowerCase().includes(q) ||
          s.className.toLowerCase().includes(q) ||
          s.teacherName.toLowerCase().includes(q)
      );
    }

    // Stats
    const stats = {
      total: fullMatrix.length,
      not_started: fullMatrix.filter((s) => s.status === 'not_started').length,
      draft: fullMatrix.filter((s) => s.status === 'draft' || s.status === 'in_progress').length,
      submitted: fullMatrix.filter((s) => s.status === 'submitted').length,
      returned: fullMatrix.filter((s) => s.status === 'returned').length,
      approved: fullMatrix.filter((s) => s.status === 'approved').length
    };

    // Sort by exam date desc
    filtered.sort((a, b) => b.examDate.localeCompare(a.examDate));

    // Pagination
    const totalCount = filtered.length;
    let paginated = filtered;
    if (page && limit) {
      const pageNum = parseInt(page, 10) || 1;
      const limitNum = parseInt(limit, 10) || 20;
      paginated = filtered.slice((pageNum - 1) * limitNum, pageNum * limitNum);
    }

    res.json({
      success: true,
      data: paginated,
      total: totalCount,
      stats
    });
  }
);

// 6. ADMIN ACTION: Return Marks to Teacher for Correction
examinationRouter.post(
  '/admin/return-marks/:submissionId',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { submissionId } = req.params;
    const { reason } = req.body as { reason?: string };

    if (!reason || !reason.trim()) {
      res.status(400).json({
        success: false,
        error: 'A reason for returning the marksheet is required.',
        code: 'REASON_REQUIRED'
      });
      return;
    }

    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];
    const submission = database.examMarksSubmissions.find((s) => s.id === submissionId);

    if (!submission) {
      res.status(404).json({
        success: false,
        error: 'Marks submission record not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    submission.status = 'returned';
    submission.returnedAt = new Date().toISOString();
    submission.returnedReason = reason.trim();
    submission.returnedBy = `${user.firstName} ${user.lastName}`;
    submission.updatedAt = new Date().toISOString();

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'EXAM_MARKS_RETURN',
      entityType: 'ExamMarksSubmission',
      entityId: submission.id,
      details: `Returned marks for ${submission.subjectName} (${submission.examName}) to teacher. Reason: ${reason}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Marksheet returned to ${submission.teacherName} for correction.`,
      data: submission
    });
  }
);

// 7. ADMIN ACTION: Unlock Marks Submission back to Draft
examinationRouter.post(
  '/admin/unlock-marks/:submissionId',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { submissionId } = req.params;

    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];
    const submission = database.examMarksSubmissions.find((s) => s.id === submissionId);

    if (!submission) {
      res.status(404).json({
        success: false,
        error: 'Marks submission record not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    submission.status = 'draft';
    submission.updatedAt = new Date().toISOString();

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'EXAM_MARKS_UNLOCK',
      entityType: 'ExamMarksSubmission',
      entityId: submission.id,
      details: `Unlocked marks for ${submission.subjectName} (${submission.examName}) by admin.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Marksheet unlocked for editing.`,
      data: submission
    });
  }
);

// =========================================================================
// PART 6D: GRADING SYSTEM CONFIGURATION & RESULT/GPA CALCULATION ENGINE
// =========================================================================

/**
 * Institutional Default Grading Scale
 */
const DEFAULT_GRADING_SCALE: GradingScaleItem[] = [
  { grade: 'A+', minPercentage: 90, maxPercentage: 100, gradePoint: 4.0, description: 'Outstanding / High Honors', isPassing: true, orderIndex: 1 },
  { grade: 'A', minPercentage: 80, maxPercentage: 89.99, gradePoint: 3.7, description: 'Excellent Performance', isPassing: true, orderIndex: 2 },
  { grade: 'B+', minPercentage: 75, maxPercentage: 79.99, gradePoint: 3.3, description: 'Very Good Performance', isPassing: true, orderIndex: 3 },
  { grade: 'B', minPercentage: 70, maxPercentage: 74.99, gradePoint: 3.0, description: 'Good Performance', isPassing: true, orderIndex: 4 },
  { grade: 'B-', minPercentage: 65, maxPercentage: 69.99, gradePoint: 2.7, description: 'Above Average', isPassing: true, orderIndex: 5 },
  { grade: 'C+', minPercentage: 60, maxPercentage: 64.99, gradePoint: 2.3, description: 'Average Performance', isPassing: true, orderIndex: 6 },
  { grade: 'C', minPercentage: 50, maxPercentage: 59.99, gradePoint: 2.0, description: 'Satisfactory / Pass', isPassing: true, orderIndex: 7 },
  { grade: 'D', minPercentage: 40, maxPercentage: 49.99, gradePoint: 1.0, description: 'Marginal Pass', isPassing: true, orderIndex: 8 },
  { grade: 'F', minPercentage: 0, maxPercentage: 39.99, gradePoint: 0.0, description: 'Fail / Unsatisfactory', isPassing: false, orderIndex: 9 }
];

/**
 * Helper to match percentage against active grading scale
 */
export function lookupGradeRule(percentage: number, scale: GradingScaleItem[]): {
  grade: string;
  gradePoint: number;
  isPassing: boolean;
  description: string;
} {
  const activeScale = (scale && scale.length > 0) ? scale : DEFAULT_GRADING_SCALE;
  const clamped = Math.max(0, Math.min(100, percentage));

  // Find exact matching range
  const matched = activeScale.find(
    (g) => clamped >= g.minPercentage && clamped <= g.maxPercentage
  );

  if (matched) {
    return {
      grade: matched.grade,
      gradePoint: matched.gradePoint,
      isPassing: matched.isPassing,
      description: matched.description || ''
    };
  }

  // Fallback if boundary rounding edge case
  const sorted = [...activeScale].sort((a, b) => b.minPercentage - a.minPercentage);
  for (const s of sorted) {
    if (clamped >= s.minPercentage) {
      return {
        grade: s.grade,
        gradePoint: s.gradePoint,
        isPassing: s.isPassing,
        description: s.description || ''
      };
    }
  }

  return {
    grade: 'F',
    gradePoint: 0.0,
    isPassing: false,
    description: 'Fail'
  };
}

/**
 * Validate non-overlapping ranges and validity of grading scale items
 */
function validateGradingScaleItems(items: GradingScaleItem[]): { isValid: boolean; error?: string } {
  if (!Array.isArray(items) || items.length === 0) {
    return { isValid: false, error: 'Grading scale must contain at least one grade rule.' };
  }

  const names = new Set<string>();
  for (const item of items) {
    if (!item.grade || !item.grade.trim()) {
      return { isValid: false, error: 'Grade name is required for all rules.' };
    }
    const cleanName = item.grade.trim().toUpperCase();
    if (names.has(cleanName)) {
      return { isValid: false, error: `Duplicate grade name detected: "${item.grade}".` };
    }
    names.add(cleanName);

    if (typeof item.minPercentage !== 'number' || isNaN(item.minPercentage) || item.minPercentage < 0 || item.minPercentage > 100) {
      return { isValid: false, error: `Invalid min percentage for grade ${item.grade}: must be between 0 and 100.` };
    }
    if (typeof item.maxPercentage !== 'number' || isNaN(item.maxPercentage) || item.maxPercentage < 0 || item.maxPercentage > 100) {
      return { isValid: false, error: `Invalid max percentage for grade ${item.grade}: must be between 0 and 100.` };
    }
    if (item.minPercentage > item.maxPercentage) {
      return { isValid: false, error: `Min percentage (${item.minPercentage}%) cannot exceed Max percentage (${item.maxPercentage}%) for grade ${item.grade}.` };
    }
    if (typeof item.gradePoint !== 'number' || isNaN(item.gradePoint) || item.gradePoint < 0) {
      return { isValid: false, error: `Grade point for ${item.grade} must be a non-negative number.` };
    }
  }

  // Check for pairwise overlaps
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      const a = items[i];
      const b = items[j];
      const overlap = (a.minPercentage <= b.maxPercentage && a.maxPercentage >= b.minPercentage);
      if (overlap) {
        return {
          isValid: false,
          error: `Overlapping percentage ranges detected between Grade ${a.grade} (${a.minPercentage}%–${a.maxPercentage}%) and Grade ${b.grade} (${b.minPercentage}%–${b.maxPercentage}%).`
        };
      }
    }
  }

  return { isValid: true };
}

// -------------------------------------------------------------------------
// 1. GET /api/examinations/grading-scale
// Returns current institutional grading scale configuration
// -------------------------------------------------------------------------
examinationRouter.get(
  '/grading-scale',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    if (!database.gradingScale || database.gradingScale.length === 0) {
      database.gradingScale = JSON.parse(JSON.stringify(DEFAULT_GRADING_SCALE));
    }

    // Sort descending by minPercentage
    const sorted = [...database.gradingScale].sort((a, b) => b.minPercentage - a.minPercentage);
    res.json({
      success: true,
      data: sorted,
      total: sorted.length
    });
  }
);

// -------------------------------------------------------------------------
// 2. POST /api/examinations/grading-scale
// Create a new Grade Rule
// -------------------------------------------------------------------------
examinationRouter.post(
  '/grading-scale',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { grade, minPercentage, maxPercentage, gradePoint, description, isPassing } = req.body as Partial<GradingScaleItem>;

    if (!grade || typeof grade !== 'string' || !grade.trim()) {
      res.status(400).json({ success: false, error: 'Grade name is required.' });
      return;
    }

    if (minPercentage === undefined || maxPercentage === undefined || gradePoint === undefined) {
      res.status(400).json({ success: false, error: 'Minimum percentage, maximum percentage, and grade point are required.' });
      return;
    }

    if (!database.gradingScale) {
      database.gradingScale = JSON.parse(JSON.stringify(DEFAULT_GRADING_SCALE));
    }

    const newItem: GradingScaleItem = {
      grade: grade.trim().toUpperCase(),
      minPercentage: Number(minPercentage),
      maxPercentage: Number(maxPercentage),
      gradePoint: Number(gradePoint),
      description: (description || '').trim(),
      isPassing: isPassing !== false,
      orderIndex: database.gradingScale.length + 1
    };

    const candidateList = [...database.gradingScale, newItem];
    const validation = validateGradingScaleItems(candidateList);
    if (!validation.isValid) {
      res.status(400).json({ success: false, error: validation.error });
      return;
    }

    database.gradingScale.push(newItem);
    database.gradingScale.sort((a, b) => b.minPercentage - a.minPercentage);
    database.gradingScale.forEach((item, idx) => {
      item.orderIndex = idx + 1;
    });

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'CREATE_GRADE_RULE',
      entityType: 'GradingScaleItem',
      entityId: newItem.grade,
      details: `Created new grade rule ${newItem.grade} (${newItem.minPercentage}%-${newItem.maxPercentage}%, GP: ${newItem.gradePoint}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      message: `Grade rule for ${newItem.grade} created successfully.`,
      data: database.gradingScale
    });
  }
);

// -------------------------------------------------------------------------
// 3. PUT /api/examinations/grading-scale/:gradeName
// Update an existing Grade Rule
// -------------------------------------------------------------------------
examinationRouter.put(
  '/grading-scale/:gradeName',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const targetGrade = decodeURIComponent(req.params.gradeName).trim().toUpperCase();
    const { grade, minPercentage, maxPercentage, gradePoint, description, isPassing } = req.body as Partial<GradingScaleItem>;

    if (!database.gradingScale) {
      database.gradingScale = JSON.parse(JSON.stringify(DEFAULT_GRADING_SCALE));
    }

    const existingIdx = database.gradingScale.findIndex((g) => g.grade.toUpperCase() === targetGrade);
    if (existingIdx === -1) {
      res.status(404).json({ success: false, error: `Grade rule "${targetGrade}" not found.` });
      return;
    }

    const updatedItem: GradingScaleItem = {
      grade: grade ? grade.trim().toUpperCase() : database.gradingScale[existingIdx].grade,
      minPercentage: minPercentage !== undefined ? Number(minPercentage) : database.gradingScale[existingIdx].minPercentage,
      maxPercentage: maxPercentage !== undefined ? Number(maxPercentage) : database.gradingScale[existingIdx].maxPercentage,
      gradePoint: gradePoint !== undefined ? Number(gradePoint) : database.gradingScale[existingIdx].gradePoint,
      description: description !== undefined ? description.trim() : database.gradingScale[existingIdx].description,
      isPassing: isPassing !== undefined ? Boolean(isPassing) : database.gradingScale[existingIdx].isPassing,
      orderIndex: database.gradingScale[existingIdx].orderIndex
    };

    const candidateList = database.gradingScale.map((item, idx) => (idx === existingIdx ? updatedItem : item));
    const validation = validateGradingScaleItems(candidateList);
    if (!validation.isValid) {
      res.status(400).json({ success: false, error: validation.error });
      return;
    }

    database.gradingScale = candidateList;
    database.gradingScale.sort((a, b) => b.minPercentage - a.minPercentage);
    database.gradingScale.forEach((item, idx) => {
      item.orderIndex = idx + 1;
    });

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'UPDATE_GRADE_RULE',
      entityType: 'GradingScaleItem',
      entityId: updatedItem.grade,
      details: `Updated grade rule ${updatedItem.grade} (${updatedItem.minPercentage}%-${updatedItem.maxPercentage}%, GP: ${updatedItem.gradePoint}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Grade rule ${updatedItem.grade} updated successfully.`,
      data: database.gradingScale
    });
  }
);

// -------------------------------------------------------------------------
// 4. DELETE /api/examinations/grading-scale/:gradeName
// Delete a Grade Rule
// -------------------------------------------------------------------------
examinationRouter.delete(
  '/grading-scale/:gradeName',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const targetGrade = decodeURIComponent(req.params.gradeName).trim().toUpperCase();

    if (!database.gradingScale) {
      database.gradingScale = JSON.parse(JSON.stringify(DEFAULT_GRADING_SCALE));
    }

    if (database.gradingScale.length <= 2) {
      res.status(400).json({
        success: false,
        error: 'Cannot delete grade rule. The system requires at least 2 grade rules to calculate results.'
      });
      return;
    }

    const existingIdx = database.gradingScale.findIndex((g) => g.grade.toUpperCase() === targetGrade);
    if (existingIdx === -1) {
      res.status(404).json({ success: false, error: `Grade rule "${targetGrade}" not found.` });
      return;
    }

    const removed = database.gradingScale.splice(existingIdx, 1)[0];
    database.gradingScale.sort((a, b) => b.minPercentage - a.minPercentage);
    database.gradingScale.forEach((item, idx) => {
      item.orderIndex = idx + 1;
    });

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'DELETE_GRADE_RULE',
      entityType: 'GradingScaleItem',
      entityId: removed.grade,
      details: `Deleted grade rule ${removed.grade}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Grade rule ${removed.grade} deleted successfully.`,
      data: database.gradingScale
    });
  }
);

// -------------------------------------------------------------------------
// 5. POST /api/examinations/grading-scale/batch
// Bulk update/replace entire grading scale
// -------------------------------------------------------------------------
examinationRouter.post(
  '/grading-scale/batch',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { items } = req.body as { items: GradingScaleItem[] };

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ success: false, error: 'A valid array of grading scale items is required.' });
      return;
    }

    const formattedItems: GradingScaleItem[] = items.map((it, idx) => ({
      grade: it.grade.trim().toUpperCase(),
      minPercentage: Number(it.minPercentage),
      maxPercentage: Number(it.maxPercentage),
      gradePoint: Number(it.gradePoint),
      description: (it.description || '').trim(),
      isPassing: it.isPassing !== false,
      orderIndex: idx + 1
    }));

    const validation = validateGradingScaleItems(formattedItems);
    if (!validation.isValid) {
      res.status(400).json({ success: false, error: validation.error });
      return;
    }

    formattedItems.sort((a, b) => b.minPercentage - a.minPercentage);
    formattedItems.forEach((item, idx) => {
      item.orderIndex = idx + 1;
    });

    database.gradingScale = formattedItems;

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'BATCH_UPDATE_GRADING_SCALE',
      entityType: 'GradingScaleItem',
      entityId: 'ALL',
      details: `Updated institutional grading scale configuration (${formattedItems.length} tiers).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: 'Grading scale configuration saved successfully.',
      data: database.gradingScale
    });
  }
);

// -------------------------------------------------------------------------
// 6. POST /api/examinations/grading-scale/reset-default
// Reset grading scale to institutional default 4.0 scale
// -------------------------------------------------------------------------
examinationRouter.post(
  '/grading-scale/reset-default',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    database.gradingScale = JSON.parse(JSON.stringify(DEFAULT_GRADING_SCALE));

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'RESET_GRADING_SCALE',
      entityType: 'GradingScaleItem',
      entityId: 'ALL',
      details: 'Reset institutional grading scale to default standard GPA 4.0 configuration.',
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: 'Grading scale has been reset to default standard.',
      data: database.gradingScale
    });
  }
);

// -------------------------------------------------------------------------
// 7. GET /api/examinations/calculation-status/:examId
// Check calculation readiness and marks submission state for an examination
// -------------------------------------------------------------------------
examinationRouter.get(
  '/calculation-status/:examId',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { examId } = req.params;
    const exam = (database.examinations || []).find((e) => e.id === examId);

    if (!exam) {
      res.status(404).json({ success: false, error: 'Examination not found.' });
      return;
    }

    const configs = exam.subjectsConfig || [];
    const submissions = (database.examMarksSubmissions || []).filter((s) => s.examId === examId);

    let submittedCount = 0;
    let draftCount = 0;
    let unstartedCount = 0;

    const pendingSubjects = configs.map((cfg) => {
      const sub = submissions.find((s) => s.subjectId === cfg.subjectId);
      let status: 'unstarted' | 'draft' | 'submitted' | 'approved' = 'unstarted';
      if (sub) {
        if (sub.status === 'submitted' || sub.status === 'approved') {
          status = sub.status;
          submittedCount++;
        } else if (sub.status === 'draft' || sub.status === 'returned') {
          status = 'draft';
          draftCount++;
        }
      } else {
        unstartedCount++;
      }

      return {
        subjectId: cfg.subjectId,
        subjectName: cfg.subjectName,
        subjectCode: cfg.subjectCode,
        status,
        teacherName: sub?.teacherName || cfg.invigilatorName || 'Assigned Teacher'
      };
    });

    // Find eligible students in the exam's cohort
    const eligibleStudents = (database.studentProfiles || []).filter((st) => {
      if (st.enrollmentStatus === 'suspended' || st.enrollmentStatus === 'withdrawn') return false;
      if (exam.classId && exam.classId !== 'ALL' && st.classId !== exam.classId) return false;
      if (exam.sectionId && exam.sectionId !== 'ALL' && st.sectionId !== exam.sectionId) return false;
      return true;
    });

    const calculatedResults = (database.examResults || []).filter((r) => r.examId === examId);

    const readinessInfo: CalculationReadinessInfo = {
      examId: exam.id,
      examName: exam.name,
      academicSessionName: exam.academicSessionName,
      className: exam.className,
      totalConfiguredSubjects: configs.length,
      submittedSubjectsCount: submittedCount,
      draftSubjectsCount: draftCount,
      unstartedSubjectsCount: unstartedCount,
      isReadyForCalculation: submittedCount > 0,
      totalEligibleStudents: eligibleStudents.length,
      calculatedResultsCount: calculatedResults.length,
      pendingSubjects
    };

    res.json({
      success: true,
      data: readinessInfo
    });
  }
);

// -------------------------------------------------------------------------
// 8. POST /api/examinations/calculate-results
// Execute Grade, GPA, and Result Calculation for an examination
// -------------------------------------------------------------------------
examinationRouter.post(
  '/calculate-results',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { examId, classId, sectionId, forceRecalculate } = req.body as CalculateResultsPayload;

    if (!examId) {
      res.status(400).json({ success: false, error: 'Examination ID is required.' });
      return;
    }

    const exam = (database.examinations || []).find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({ success: false, error: 'Examination not found.' });
      return;
    }

    const configs = exam.subjectsConfig || [];
    if (configs.length === 0) {
      res.status(400).json({
        success: false,
        error: 'Examination does not have any configured subjects. Please configure subjects first.'
      });
      return;
    }

    // Active grading scale
    const activeGradingScale = (database.gradingScale && database.gradingScale.length > 0)
      ? database.gradingScale
      : DEFAULT_GRADING_SCALE;

    // Filter students by class and section
    const targetClassId = classId || exam.classId;
    const targetSectionId = sectionId || exam.sectionId;

    const eligibleStudents = (database.studentProfiles || []).filter((st) => {
      if (st.enrollmentStatus === 'suspended' || st.enrollmentStatus === 'withdrawn') return false;
      if (targetClassId && targetClassId !== 'ALL' && st.classId !== targetClassId) return false;
      if (targetSectionId && targetSectionId !== 'ALL' && st.sectionId !== targetSectionId) return false;
      return true;
    });

    if (eligibleStudents.length === 0) {
      res.status(400).json({
        success: false,
        error: 'No active enrolled students found for the selected examination class and section.'
      });
      return;
    }

    // Retrieve submitted / approved marks submissions for this exam
    if (!database.examMarksSubmissions) database.examMarksSubmissions = [];
    const submissions = database.examMarksSubmissions.filter(
      (s) => s.examId === examId && (s.status === 'submitted' || s.status === 'approved')
    );

    if (!database.examResults) database.examResults = [];

    const calculatedResults: StudentExamResult[] = [];
    const timestamp = new Date().toISOString();

    for (const student of eligibleStudents) {
      const studentUser = (database.users || []).find((u) => u.id === student.userId);
      const studentClass = (database.classes || []).find((c) => c.id === student.classId);
      const studentSection = (database.sections || []).find((s) => s.id === student.sectionId);

      const subjectScores: ExamResultSubjectScore[] = [];
      let totalFullMarks = 0;
      let totalObtainedMarks = 0;
      let totalQualityPoints = 0;
      let totalCredits = 0;
      let passedCount = 0;
      let failedCount = 0;
      let absentCount = 0;
      let exemptCount = 0;
      let missingCount = 0;

      for (const config of configs) {
        // Resolve subject details for credits
        const subjectEntity = (database.subjects || []).find((s) => s.id === config.subjectId);
        const credits = (subjectEntity && subjectEntity.credits) ? subjectEntity.credits : 1;
        const fullMarks = config.fullMarks || 100;
        const passMarks = config.passMarks || 40;

        // Find mark from submission
        const sub = submissions.find((s) => s.subjectId === config.subjectId);
        const studentMark = sub?.marks?.find((m) => m.studentId === student.id || m.userId === student.userId);

        if (studentMark) {
          if (studentMark.isExempt) {
            exemptCount++;
            subjectScores.push({
              subjectId: config.subjectId,
              subjectName: config.subjectName,
              subjectCode: config.subjectCode,
              fullMarks,
              passMarks,
              obtainedMarks: 0,
              percentage: 100,
              grade: 'EX',
              gradePoint: 0,
              isPassing: true,
              credits,
              remarks: studentMark.remarks || 'Exempted from assessment'
            });
          } else if (studentMark.isAbsent) {
            absentCount++;
            failedCount++;
            totalFullMarks += fullMarks;
            totalCredits += credits;
            // 0 quality points for absent
            subjectScores.push({
              subjectId: config.subjectId,
              subjectName: config.subjectName,
              subjectCode: config.subjectCode,
              fullMarks,
              passMarks,
              obtainedMarks: 0,
              percentage: 0,
              grade: 'AB',
              gradePoint: 0,
              isPassing: false,
              credits,
              remarks: studentMark.remarks || 'Absent from examination'
            });
          } else {
            // Valid obtained numeric mark
            const rawMarks = studentMark.obtainedMarks !== null ? Number(studentMark.obtainedMarks) : 0;
            const obtained = Math.max(0, Math.min(fullMarks, rawMarks));
            const percentage = fullMarks > 0 ? (obtained / fullMarks) * 100 : 0;
            const gradeInfo = lookupGradeRule(percentage, activeGradingScale);
            const isPassing = (obtained >= passMarks) && gradeInfo.isPassing;

            if (isPassing) {
              passedCount++;
            } else {
              failedCount++;
            }

            totalFullMarks += fullMarks;
            totalObtainedMarks += obtained;
            totalQualityPoints += (gradeInfo.gradePoint * credits);
            totalCredits += credits;

            subjectScores.push({
              subjectId: config.subjectId,
              subjectName: config.subjectName,
              subjectCode: config.subjectCode,
              fullMarks,
              passMarks,
              obtainedMarks: obtained,
              percentage: Number(percentage.toFixed(2)),
              grade: gradeInfo.grade,
              gradePoint: gradeInfo.gradePoint,
              isPassing,
              credits,
              remarks: studentMark.remarks || ''
            });
          }
        } else {
          // Marks not yet submitted for this subject
          missingCount++;
          failedCount++;
          totalFullMarks += fullMarks;
          totalCredits += credits;

          subjectScores.push({
            subjectId: config.subjectId,
            subjectName: config.subjectName,
            subjectCode: config.subjectCode,
            fullMarks,
            passMarks,
            obtainedMarks: 0,
            percentage: 0,
            grade: 'PENDING',
            gradePoint: 0,
            isPassing: false,
            credits,
            remarks: 'Marks not yet entered/submitted by teacher'
          });
        }
      }

      const overallPercentage = totalFullMarks > 0 ? Number(((totalObtainedMarks / totalFullMarks) * 100).toFixed(2)) : 0;
      const gpa = totalCredits > 0 ? Number((totalQualityPoints / totalCredits).toFixed(2)) : 0;
      const overallGrade = lookupGradeRule(overallPercentage, activeGradingScale).grade;

      let resultStatus: 'PASSED' | 'FAILED' | 'DISTINCTION' | 'WITHHELD' = 'PASSED';
      if (failedCount > 0) {
        resultStatus = 'FAILED';
      } else if (overallPercentage >= 85) {
        resultStatus = 'DISTINCTION';
      }

      // Check existing result record to upsert safely
      const existingIdx = database.examResults.findIndex(
        (r) => r.examId === examId && r.studentId === student.id
      );

      const existingRecord = existingIdx !== -1 ? database.examResults[existingIdx] : null;

      const initialWorkflowStatus: ResultWorkflowStatus = existingRecord?.workflowStatus === 'APPROVED' || existingRecord?.workflowStatus === 'PUBLISHED'
        ? existingRecord.workflowStatus
        : 'CALCULATED';

      const initialHistory: ResultStatusHistoryItem[] = existingRecord?.statusHistory && existingRecord.statusHistory.length > 0
        ? [
            ...existingRecord.statusHistory,
            {
              id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
              fromStatus: existingRecord.workflowStatus || 'DRAFT',
              toStatus: initialWorkflowStatus,
              changedByUserId: user.id,
              changedByUserName: user.name,
              changedByUserRole: user.role,
              timestamp,
              notes: 'Recalculated by Academic GPA & Result Engine'
            }
          ]
        : [
            {
              id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
              fromStatus: 'DRAFT',
              toStatus: initialWorkflowStatus,
              changedByUserId: user.id,
              changedByUserName: user.name,
              changedByUserRole: user.role,
              timestamp,
              notes: 'Initial GPA and grade calculation generated by Result Engine'
            }
          ];

      const calculatedResult: StudentExamResult = {
        id: existingRecord ? existingRecord.id : `res-${exam.id}-${student.id}`,
        examId: exam.id,
        examName: exam.name,
        examType: exam.examType || 'Term Exam',
        academicSessionId: exam.academicSessionId,
        academicSessionName: exam.academicSessionName,
        academicYear: exam.academicSessionName || '2026-2027',
        term: exam.examType || 'Mid Term',
        studentId: student.id,
        userId: student.userId,
        studentName: studentUser?.name || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student',
        admissionNumber: student.admissionNumber,
        rollNumber: student.rollNumber,
        avatarUrl: studentUser?.avatarUrl,
        classId: student.classId,
        className: studentClass?.name || exam.className || 'Grade 10',
        sectionId: student.sectionId,
        sectionName: studentSection?.name || 'Section A',
        publishDate: existingRecord?.publishDate || timestamp,
        isPublished: existingRecord ? existingRecord.isPublished : false,
        publishedBy: existingRecord?.publishedBy,
        publishedByName: existingRecord?.publishedByName,
        publishedAt: existingRecord?.publishedAt,
        workflowStatus: initialWorkflowStatus,
        isApproved: existingRecord ? existingRecord.isApproved : false,
        approvedBy: existingRecord?.approvedBy,
        approvedByName: existingRecord?.approvedByName,
        approvedAt: existingRecord?.approvedAt,
        isLocked: existingRecord ? existingRecord.isLocked : false,
        correctionRequested: existingRecord?.correctionRequested,
        correctionReason: existingRecord?.correctionReason,
        correctionRequestedBy: existingRecord?.correctionRequestedBy,
        correctionRequestedByName: existingRecord?.correctionRequestedByName,
        correctionRequestedAt: existingRecord?.correctionRequestedAt,
        statusHistory: initialHistory,
        subjectScores,
        summary: {
          totalFullMarks,
          totalObtainedMarks,
          overallPercentage,
          gpa,
          overallGrade,
          resultStatus,
          totalSubjects: configs.length,
          passedSubjects: passedCount,
          failedSubjects: failedCount,
          absentSubjects: absentCount,
          exemptSubjects: exemptCount,
          isIncomplete: missingCount > 0,
          missingSubjectCount: missingCount,
          totalStudentsInClass: eligibleStudents.length
        },
        academicProgressNotes: `Calculation generated automatically from ${submissions.length} submitted marksheets on ${new Date().toLocaleDateString()}.`,
        createdAt: existingRecord?.createdAt || timestamp,
        updatedAt: timestamp
      };

      if (existingIdx !== -1) {
        database.examResults[existingIdx] = calculatedResult;
      } else {
        database.examResults.push(calculatedResult);
      }

      calculatedResults.push(calculatedResult);
    }

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'CALCULATE_EXAM_RESULTS',
      entityType: 'Examination',
      entityId: examId,
      details: `Generated academic grades and GPA calculations for ${calculatedResults.length} students in "${exam.name}".`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const passedCount = calculatedResults.filter((r) => r.summary.resultStatus === 'PASSED').length;
    const failedCount = calculatedResults.filter((r) => r.summary.resultStatus === 'FAILED').length;
    const distinctionCount = calculatedResults.filter((r) => r.summary.resultStatus === 'DISTINCTION').length;

    res.json({
      success: true,
      message: `Results and GPA successfully calculated for ${calculatedResults.length} students.`,
      stats: {
        totalCalculated: calculatedResults.length,
        passedCount,
        failedCount,
        distinctionCount,
        averageGpa: Number((calculatedResults.reduce((acc, r) => acc + r.summary.gpa, 0) / (calculatedResults.length || 1)).toFixed(2)),
        averagePercentage: Number((calculatedResults.reduce((acc, r) => acc + r.summary.overallPercentage, 0) / (calculatedResults.length || 1)).toFixed(2))
      },
      data: calculatedResults
    });
  }
);

// -------------------------------------------------------------------------
// 9. GET /api/examinations/results-preview
// Admin Result Preview and Calculation Dashboard List
// -------------------------------------------------------------------------
examinationRouter.get(
  '/results-preview',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    if (!database.examResults) database.examResults = [];

    const {
      academicSessionId,
      examId,
      classId,
      sectionId,
      status,
      search,
      page = 1,
      limit = 50
    } = req.query as AdminResultPreviewFilterParams;

    let filtered = [...database.examResults];

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((r) => r.sectionId === sectionId);
    }
    if (status && status !== 'ALL') {
      const st = status.toUpperCase();
      filtered = filtered.filter((r) => r.summary.resultStatus === st);
    }
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered = filtered.filter(
        (r) =>
          r.studentName.toLowerCase().includes(q) ||
          r.admissionNumber.toLowerCase().includes(q) ||
          r.rollNumber.toLowerCase().includes(q) ||
          r.examName.toLowerCase().includes(q) ||
          r.className.toLowerCase().includes(q) ||
          r.sectionName.toLowerCase().includes(q)
      );
    }

    // Sort by GPA desc, then Percentage desc
    filtered.sort((a, b) => b.summary.gpa - a.summary.gpa || b.summary.overallPercentage - a.summary.overallPercentage);

    // Compute Summary Stats
    const totalCalculated = filtered.length;
    const passedCount = filtered.filter((r) => r.summary.resultStatus === 'PASSED').length;
    const failedCount = filtered.filter((r) => r.summary.resultStatus === 'FAILED').length;
    const distinctionCount = filtered.filter((r) => r.summary.resultStatus === 'DISTINCTION').length;
    const incompleteCount = filtered.filter((r) => r.summary.isIncomplete).length;

    const gpas = filtered.map((r) => r.summary.gpa);
    const percentages = filtered.map((r) => r.summary.overallPercentage);

    const stats: ResultCalculationSummaryStats = {
      totalCalculated,
      passedCount,
      failedCount,
      distinctionCount,
      incompleteCount,
      averagePercentage: totalCalculated > 0 ? Number((percentages.reduce((a, b) => a + b, 0) / totalCalculated).toFixed(2)) : 0,
      averageGpa: totalCalculated > 0 ? Number((gpas.reduce((a, b) => a + b, 0) / totalCalculated).toFixed(2)) : 0,
      highestGpa: gpas.length > 0 ? Math.max(...gpas) : 0,
      lowestGpa: gpas.length > 0 ? Math.min(...gpas) : 0
    };

    const p = Math.max(1, Number(page));
    const l = Math.max(1, Math.min(100, Number(limit)));
    const startIndex = (p - 1) * l;
    const paginatedData = filtered.slice(startIndex, startIndex + l);

    res.json({
      success: true,
      data: paginatedData,
      total: totalCalculated,
      page: p,
      limit: l,
      stats,
      availableExams: (database.examinations || []).map((e) => ({ id: e.id, name: e.name, className: e.className })),
      availableClasses: (database.classes || []).map((c) => ({ id: c.id, name: c.name })),
      availableSessions: (database.academicSessions || []).map((s) => ({ id: s.id, name: s.name }))
    });
  }
);

// -------------------------------------------------------------------------
// 10. GET /api/examinations/results-preview/:resultId
// Single calculated result detail for marksheet breakdown modal
// -------------------------------------------------------------------------
// =========================================================================
// PART 6E: RESULT REVIEW, APPROVAL & PUBLISHING WORKFLOW ENGINE
// =========================================================================

// Valid state machine transitions
export const VALID_WORKFLOW_TRANSITIONS: Record<ResultWorkflowStatus, ResultWorkflowStatus[]> = {
  DRAFT: ['CALCULATED'],
  CALCULATED: ['UNDER_REVIEW', 'CORRECTION_REQUIRED', 'APPROVED'],
  UNDER_REVIEW: ['CALCULATED', 'CORRECTION_REQUIRED', 'APPROVED'],
  CORRECTION_REQUIRED: ['CALCULATED', 'UNDER_REVIEW'],
  APPROVED: ['UNDER_REVIEW', 'CORRECTION_REQUIRED', 'PUBLISHED'],
  PUBLISHED: ['ARCHIVED', 'CORRECTION_REQUIRED', 'UNDER_REVIEW'],
  ARCHIVED: ['PUBLISHED', 'CALCULATED']
};

/**
 * 11. GET /api/examinations/results/review
 * Comprehensive Result Review with cohort grouping, subject scores, GPA, Pass/Fail, and Workflow stats
 */
examinationRouter.get(
  '/results/review',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      if (!database.examResults) database.examResults = [];

      const {
        academicSessionId,
        examId,
        classId,
        sectionId,
        subjectId,
        workflowStatus,
        resultStatus,
        search,
        page = 1,
        limit = 50
      } = req.query as ResultReviewFilterParams;

      let filtered = [...database.examResults];

      if (academicSessionId && academicSessionId !== 'ALL') {
        filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
      }
      if (examId && examId !== 'ALL') {
        filtered = filtered.filter((r) => r.examId === examId);
      }
      if (classId && classId !== 'ALL') {
        filtered = filtered.filter((r) => r.classId === classId);
      }
      if (sectionId && sectionId !== 'ALL') {
        filtered = filtered.filter((r) => r.sectionId === sectionId);
      }
      if (subjectId && subjectId !== 'ALL') {
        filtered = filtered.filter((r) =>
          r.subjectScores.some((s) => s.subjectId === subjectId)
        );
      }
      if (workflowStatus && workflowStatus !== 'ALL') {
        const wf = workflowStatus.toUpperCase();
        filtered = filtered.filter((r) => (r.workflowStatus || 'CALCULATED') === wf);
      }
      if (resultStatus && resultStatus !== 'ALL') {
        const rs = resultStatus.toUpperCase();
        filtered = filtered.filter((r) => r.summary.resultStatus === rs);
      }
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        filtered = filtered.filter(
          (r) =>
            r.studentName.toLowerCase().includes(q) ||
            r.admissionNumber.toLowerCase().includes(q) ||
            r.rollNumber.toLowerCase().includes(q) ||
            r.examName.toLowerCase().includes(q) ||
            r.className.toLowerCase().includes(q) ||
            r.sectionName.toLowerCase().includes(q) ||
            r.subjectScores.some((s) => s.subjectName.toLowerCase().includes(q) || s.subjectCode.toLowerCase().includes(q))
        );
      }

      // Sort by GPA desc, then Percentage desc
      filtered.sort((a, b) => b.summary.gpa - a.summary.gpa || b.summary.overallPercentage - a.summary.overallPercentage);

      // Aggregate comprehensive Workflow and Academic KPIs
      const total = filtered.length;
      const draft = filtered.filter((r) => r.workflowStatus === 'DRAFT').length;
      const calculated = filtered.filter((r) => !r.workflowStatus || r.workflowStatus === 'CALCULATED').length;
      const underReview = filtered.filter((r) => r.workflowStatus === 'UNDER_REVIEW').length;
      const correctionRequired = filtered.filter((r) => r.workflowStatus === 'CORRECTION_REQUIRED').length;
      const approved = filtered.filter((r) => r.workflowStatus === 'APPROVED').length;
      const published = filtered.filter((r) => r.workflowStatus === 'PUBLISHED').length;
      const archived = filtered.filter((r) => r.workflowStatus === 'ARCHIVED').length;

      const passedCount = filtered.filter((r) => r.summary.resultStatus === 'PASSED').length;
      const failedCount = filtered.filter((r) => r.summary.resultStatus === 'FAILED').length;
      const distinctionCount = filtered.filter((r) => r.summary.resultStatus === 'DISTINCTION').length;

      const gpas = filtered.map((r) => r.summary.gpa);
      const percentages = filtered.map((r) => r.summary.overallPercentage);

      const stats: ResultReviewSummaryStats = {
        total,
        draft,
        calculated,
        underReview,
        correctionRequired,
        approved,
        published,
        archived,
        passedCount,
        failedCount,
        distinctionCount,
        averagePercentage: total > 0 ? Number((percentages.reduce((a, b) => a + b, 0) / total).toFixed(2)) : 0,
        averageGpa: total > 0 ? Number((gpas.reduce((a, b) => a + b, 0) / total).toFixed(2)) : 0,
        highestGpa: gpas.length > 0 ? Math.max(...gpas) : 0,
        lowestGpa: gpas.length > 0 ? Math.min(...gpas) : 0
      };

      const p = Math.max(1, Number(page));
      const l = Math.max(1, Math.min(100, Number(limit)));
      const startIndex = (p - 1) * l;
      const paginatedData = filtered.slice(startIndex, startIndex + l);

      // Distinct available filter options
      const availableSessions = (database.academicSessions || []).map((s) => ({ id: s.id, name: s.name }));
      const availableExams = (database.examinations || []).map((e) => ({
        id: e.id,
        name: e.name,
        type: e.examType,
        className: e.className
      }));
      const availableClasses = (database.classes || []).map((c) => ({ id: c.id, name: c.name }));
      const availableSections = (database.sections || []).map((sec) => ({
        id: sec.id,
        name: sec.name,
        classId: sec.classId
      }));
      const availableSubjects = (database.subjects || []).map((sub) => ({
        id: sub.id,
        name: sub.name,
        code: sub.code
      }));

      const response: ResultReviewResponse = {
        data: paginatedData,
        total,
        page: p,
        limit: l,
        stats,
        availableSessions,
        availableExams,
        availableClasses,
        availableSections,
        availableSubjects
      };

      res.json({
        success: true,
        data: response
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
    }
  }
);

/**
 * 12. GET /api/examinations/results/review/:resultId
 * Single Result detail with full audit & status history
 */
examinationRouter.get(
  '/results/review/:resultId',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { resultId } = req.params;
      const result = (database.examResults || []).find((r) => r.id === resultId);

      if (!result) {
        res.status(404).json({ success: false, error: 'Calculated examination result record not found.' });
        return;
      }

      const exam = (database.examinations || []).find((e) => e.id === result.examId);
      const student = (database.studentProfiles || []).find((s) => s.id === result.studentId);
      const user = (database.users || []).find((u) => u.id === result.userId);

      res.json({
        success: true,
        data: {
          ...result,
          examDetails: exam,
          studentDetails: student,
          userDetails: user
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 13. POST /api/examinations/results/:resultId/status
 * Change individual Result Status with state machine validation and audit logging
 */
examinationRouter.post(
  '/results/:resultId/status',
  requireAuth,
  requirePermission('examinations.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { resultId } = req.params;
      const { targetStatus, reason, notes } = req.body as ChangeResultStatusPayload;

      if (!targetStatus) {
        res.status(400).json({ success: false, error: 'Target workflow status is required.' });
        return;
      }

      const resultIndex = (database.examResults || []).findIndex((r) => r.id === resultId);
      if (resultIndex === -1) {
        res.status(404).json({ success: false, error: 'Examination result record not found.' });
        return;
      }

      const current = database.examResults[resultIndex];
      const currentStatus: ResultWorkflowStatus = current.workflowStatus || 'CALCULATED';

      // State machine transition validation
      const allowedNextStatuses = VALID_WORKFLOW_TRANSITIONS[currentStatus] || [];
      if (!allowedNextStatuses.includes(targetStatus)) {
        res.status(400).json({
          success: false,
          error: `Invalid status transition: Cannot change result status from "${currentStatus}" to "${targetStatus}". Allowed transitions: ${allowedNextStatuses.join(', ') || 'None'}.`,
          code: 'INVALID_STATUS_TRANSITION'
        });
        return;
      }

      // Security check: Only Super Admin can approve, publish, or reopen published results
      if (targetStatus === 'PUBLISHED' && currentStatus !== 'APPROVED') {
        res.status(400).json({
          success: false,
          error: 'Strict Policy Violation: Only results with "APPROVED" status can be published.',
          code: 'UNAPPROVED_RESULT_PUBLISH_BLOCKED'
        });
        return;
      }

      if (currentStatus === 'PUBLISHED' && targetStatus !== 'ARCHIVED' && user.role !== 'SUPER_ADMIN') {
        res.status(403).json({
          success: false,
          error: 'Only Super Admin is authorized to reopen or modify published examination results.',
          code: 'SUPER_ADMIN_REQUIRED'
        });
        return;
      }

      if (targetStatus === 'CORRECTION_REQUIRED' && (!reason || reason.trim().length < 5)) {
        res.status(400).json({
          success: false,
          error: 'A specific explanation (at least 5 characters) is required when returning results for correction.'
        });
        return;
      }

      const now = new Date().toISOString();
      const historyItem: ResultStatusHistoryItem = {
        id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        fromStatus: currentStatus,
        toStatus: targetStatus,
        changedByUserId: user.id,
        changedByUserName: user.name,
        changedByUserRole: user.role,
        timestamp: now,
        reason: reason?.trim() || undefined,
        notes: notes?.trim() || undefined
      };

      const updatedHistory = [...(current.statusHistory || []), historyItem];

      // Update state flags
      const isApproved = targetStatus === 'APPROVED' || (targetStatus === 'PUBLISHED' && current.isApproved);
      const isPublished = targetStatus === 'PUBLISHED';
      const isLocked = targetStatus === 'APPROVED' || targetStatus === 'PUBLISHED';

      const updatedResult: StudentExamResult = {
        ...current,
        workflowStatus: targetStatus,
        isApproved,
        approvedBy: targetStatus === 'APPROVED' ? user.id : current.approvedBy,
        approvedByName: targetStatus === 'APPROVED' ? user.name : current.approvedByName,
        approvedAt: targetStatus === 'APPROVED' ? now : current.approvedAt,
        isPublished,
        publishedBy: targetStatus === 'PUBLISHED' ? user.id : current.publishedBy,
        publishedByName: targetStatus === 'PUBLISHED' ? user.name : current.publishedByName,
        publishedAt: targetStatus === 'PUBLISHED' ? now : current.publishedAt,
        isLocked,
        lockedReason: isLocked ? `Locked in ${targetStatus} state` : undefined,
        correctionRequested: targetStatus === 'CORRECTION_REQUIRED',
        correctionReason: targetStatus === 'CORRECTION_REQUIRED' ? reason?.trim() : undefined,
        correctionRequestedBy: targetStatus === 'CORRECTION_REQUIRED' ? user.id : undefined,
        correctionRequestedByName: targetStatus === 'CORRECTION_REQUIRED' ? user.name : undefined,
        correctionRequestedAt: targetStatus === 'CORRECTION_REQUIRED' ? now : undefined,
        statusHistory: updatedHistory,
        updatedAt: now
      };

      database.examResults[resultIndex] = updatedResult;

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'CHANGE_RESULT_STATUS',
        entityType: 'StudentExamResult',
        entityId: resultId,
        details: `Result for student ${current.studentName} (${current.admissionNumber}) transitioned from ${currentStatus} to ${targetStatus}.${reason ? ` Reason: ${reason}` : ''}`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Result status updated to ${targetStatus} successfully.`,
        data: updatedResult
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 14. POST /api/examinations/results/bulk-status
 * Batch status transitions with individual validation and rollback protection
 */
examinationRouter.post(
  '/results/bulk-status',
  requireAuth,
  requirePermission('examinations.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { resultIds, targetStatus, reason, notes } = req.body as BulkChangeResultStatusPayload;

      if (!resultIds || !Array.isArray(resultIds) || resultIds.length === 0) {
        res.status(400).json({ success: false, error: 'Array of resultIds is required.' });
        return;
      }
      if (!targetStatus) {
        res.status(400).json({ success: false, error: 'Target status is required.' });
        return;
      }

      if (targetStatus === 'CORRECTION_REQUIRED' && (!reason || reason.trim().length < 5)) {
        res.status(400).json({
          success: false,
          error: 'A specific explanation (at least 5 characters) is required when returning results for correction.'
        });
        return;
      }

      const now = new Date().toISOString();
      let updatedCount = 0;
      const failedItems: Array<{ id: string; message: string }> = [];
      const updatedResults: StudentExamResult[] = [];

      resultIds.forEach((id) => {
        const idx = (database.examResults || []).findIndex((r) => r.id === id);
        if (idx === -1) {
          failedItems.push({ id, message: 'Result record not found' });
          return;
        }

        const current = database.examResults[idx];
        const currentStatus: ResultWorkflowStatus = current.workflowStatus || 'CALCULATED';

        // Check transition legality
        const allowed = VALID_WORKFLOW_TRANSITIONS[currentStatus] || [];
        if (!allowed.includes(targetStatus)) {
          failedItems.push({
            id,
            message: `Cannot transition from ${currentStatus} to ${targetStatus}`
          });
          return;
        }

        // Publishing constraint
        if (targetStatus === 'PUBLISHED' && currentStatus !== 'APPROVED') {
          failedItems.push({
            id,
            message: `Result is not in APPROVED status (currently ${currentStatus})`
          });
          return;
        }

        const historyItem: ResultStatusHistoryItem = {
          id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          fromStatus: currentStatus,
          toStatus: targetStatus,
          changedByUserId: user.id,
          changedByUserName: user.name,
          changedByUserRole: user.role,
          timestamp: now,
          reason: reason?.trim(),
          notes: notes?.trim()
        };

        const isApproved = targetStatus === 'APPROVED' || (targetStatus === 'PUBLISHED' && current.isApproved);
        const isPublished = targetStatus === 'PUBLISHED';
        const isLocked = targetStatus === 'APPROVED' || targetStatus === 'PUBLISHED';

        const updated: StudentExamResult = {
          ...current,
          workflowStatus: targetStatus,
          isApproved,
          approvedBy: targetStatus === 'APPROVED' ? user.id : current.approvedBy,
          approvedByName: targetStatus === 'APPROVED' ? user.name : current.approvedByName,
          approvedAt: targetStatus === 'APPROVED' ? now : current.approvedAt,
          isPublished,
          publishedBy: targetStatus === 'PUBLISHED' ? user.id : current.publishedBy,
          publishedByName: targetStatus === 'PUBLISHED' ? user.name : current.publishedByName,
          publishedAt: targetStatus === 'PUBLISHED' ? now : current.publishedAt,
          isLocked,
          lockedReason: isLocked ? `Locked in ${targetStatus} state` : undefined,
          correctionRequested: targetStatus === 'CORRECTION_REQUIRED',
          correctionReason: targetStatus === 'CORRECTION_REQUIRED' ? reason?.trim() : undefined,
          correctionRequestedBy: targetStatus === 'CORRECTION_REQUIRED' ? user.id : undefined,
          correctionRequestedByName: targetStatus === 'CORRECTION_REQUIRED' ? user.name : undefined,
          correctionRequestedAt: targetStatus === 'CORRECTION_REQUIRED' ? now : undefined,
          statusHistory: [...(current.statusHistory || []), historyItem],
          updatedAt: now
        };

        database.examResults[idx] = updated;
        updatedResults.push(updated);
        updatedCount++;
      });

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'BULK_CHANGE_RESULT_STATUS',
        entityType: 'StudentExamResult',
        entityId: 'BULK',
        details: `Batch status update to ${targetStatus}: ${updatedCount} succeeded, ${failedItems.length} failed.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Successfully transitioned ${updatedCount} results to ${targetStatus}.`,
        updatedCount,
        failedCount: failedItems.length,
        failedItems,
        data: updatedResults
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 15. POST /api/examinations/results/return-correction
 * Return single or multiple results to Teachers/Examiners for correction with mandatory reason
 */
examinationRouter.post(
  '/results/return-correction',
  requireAuth,
  requirePermission('examinations.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { resultIds, reason, notes } = req.body as ReturnCorrectionPayload;

      if (!resultIds || !Array.isArray(resultIds) || resultIds.length === 0) {
        res.status(400).json({ success: false, error: 'Array of resultIds is required.' });
        return;
      }
      if (!reason || reason.trim().length < 5) {
        res.status(400).json({
          success: false,
          error: 'A specific explanation (at least 5 characters) explaining what needs correction is required.'
        });
        return;
      }

      const now = new Date().toISOString();
      let updatedCount = 0;
      const updatedResults: StudentExamResult[] = [];

      resultIds.forEach((id) => {
        const idx = (database.examResults || []).findIndex((r) => r.id === id);
        if (idx === -1) return;

        const current = database.examResults[idx];
        const currentStatus: ResultWorkflowStatus = current.workflowStatus || 'CALCULATED';

        const historyItem: ResultStatusHistoryItem = {
          id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          fromStatus: currentStatus,
          toStatus: 'CORRECTION_REQUIRED',
          changedByUserId: user.id,
          changedByUserName: user.name,
          changedByUserRole: user.role,
          timestamp: now,
          reason: reason.trim(),
          notes: notes?.trim()
        };

        const updated: StudentExamResult = {
          ...current,
          workflowStatus: 'CORRECTION_REQUIRED',
          isApproved: false,
          isPublished: false,
          isLocked: false,
          lockedReason: undefined,
          correctionRequested: true,
          correctionReason: reason.trim(),
          correctionRequestedBy: user.id,
          correctionRequestedByName: user.name,
          correctionRequestedAt: now,
          statusHistory: [...(current.statusHistory || []), historyItem],
          updatedAt: now
        };

        database.examResults[idx] = updated;
        updatedResults.push(updated);
        updatedCount++;
      });

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'RETURN_RESULTS_FOR_CORRECTION',
        entityType: 'StudentExamResult',
        entityId: 'BULK',
        details: `Returned ${updatedCount} exam results for correction. Reason: "${reason.trim()}"`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `${updatedCount} results returned for correction.`,
        updatedCount,
        data: updatedResults
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 16. POST /api/examinations/results/bulk-approve
 * Approve all eligible calculated/under-review results and lock them from modification
 */
examinationRouter.post(
  '/results/bulk-approve',
  requireAuth,
  requirePermission('examinations.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { resultIds, notes } = req.body as BulkApproveResultsPayload;

      if (!resultIds || !Array.isArray(resultIds) || resultIds.length === 0) {
        res.status(400).json({ success: false, error: 'Array of resultIds is required.' });
        return;
      }

      const now = new Date().toISOString();
      let approvedCount = 0;
      const skippedCount: number[] = [];
      const updatedResults: StudentExamResult[] = [];

      resultIds.forEach((id) => {
        const idx = (database.examResults || []).findIndex((r) => r.id === id);
        if (idx === -1) return;

        const current = database.examResults[idx];
        const currentStatus: ResultWorkflowStatus = current.workflowStatus || 'CALCULATED';

        // Only CALCULATED and UNDER_REVIEW can be approved directly
        if (currentStatus !== 'CALCULATED' && currentStatus !== 'UNDER_REVIEW') {
          skippedCount.push(1);
          return;
        }

        const historyItem: ResultStatusHistoryItem = {
          id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          fromStatus: currentStatus,
          toStatus: 'APPROVED',
          changedByUserId: user.id,
          changedByUserName: user.name,
          changedByUserRole: user.role,
          timestamp: now,
          notes: notes?.trim() || 'Institutional Result Verification and Approval'
        };

        const updated: StudentExamResult = {
          ...current,
          workflowStatus: 'APPROVED',
          isApproved: true,
          approvedBy: user.id,
          approvedByName: user.name,
          approvedAt: now,
          isLocked: true,
          lockedReason: 'Approved by Administrator. Locked against modifications.',
          correctionRequested: false,
          correctionReason: undefined,
          statusHistory: [...(current.statusHistory || []), historyItem],
          updatedAt: now
        };

        database.examResults[idx] = updated;
        updatedResults.push(updated);
        approvedCount++;
      });

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'BULK_APPROVE_EXAM_RESULTS',
        entityType: 'StudentExamResult',
        entityId: 'BULK',
        details: `Approved and locked ${approvedCount} examination results. (${skippedCount.length} skipped as already approved or not eligible)`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Successfully approved and locked ${approvedCount} results.`,
        approvedCount,
        skippedCount: skippedCount.length,
        data: updatedResults
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 17. POST /api/examinations/results/publish
 * Super Admin Publishing View: Publish APPROVED results to make them visible in Student and Parent Portals.
 * STRICT ENFORCEMENT: Only results with workflowStatus === 'APPROVED' can be published!
 */
examinationRouter.post(
  '/results/publish',
  requireAuth,
  requirePermission('examinations.publish'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const {
        examId,
        classId,
        sectionId,
        resultIds,
        publishDate,
        notifyStudentsAndParents = true
      } = req.body as PublishResultsPayload;

      const allResults = database.examResults || [];
      let targetResults: StudentExamResult[] = [];

      if (resultIds && Array.isArray(resultIds) && resultIds.length > 0) {
        targetResults = allResults.filter((r) => resultIds.includes(r.id));
      } else if (examId) {
        targetResults = allResults.filter((r) => {
          if (r.examId !== examId) return false;
          if (classId && classId !== 'ALL' && r.classId !== classId) return false;
          if (sectionId && sectionId !== 'ALL' && r.sectionId !== sectionId) return false;
          return true;
        });
      } else {
        res.status(400).json({
          success: false,
          error: 'Either examId or an array of resultIds must be provided to publish.'
        });
        return;
      }

      if (targetResults.length === 0) {
        res.status(404).json({
          success: false,
          error: 'No examination results matched the selected criteria to publish.'
        });
        return;
      }

      // CRITICAL POLICY: Segregate APPROVED vs UNAPPROVED results
      const approvedCandidates = targetResults.filter((r) => r.workflowStatus === 'APPROVED');
      const unapprovedCandidates = targetResults.filter((r) => r.workflowStatus !== 'APPROVED');

      if (approvedCandidates.length === 0) {
        res.status(400).json({
          success: false,
          error: `Publishing blocked: None of the ${targetResults.length} selected results are in "APPROVED" status. All results must be formally reviewed and approved before publishing to students and guardians.`,
          code: 'NO_APPROVED_RESULTS_FOUND',
          unapprovedCount: unapprovedCandidates.length,
          unapprovedBreakdown: {
            draft: unapprovedCandidates.filter((r) => r.workflowStatus === 'DRAFT').length,
            calculated: unapprovedCandidates.filter((r) => !r.workflowStatus || r.workflowStatus === 'CALCULATED').length,
            underReview: unapprovedCandidates.filter((r) => r.workflowStatus === 'UNDER_REVIEW').length,
            correctionRequired: unapprovedCandidates.filter((r) => r.workflowStatus === 'CORRECTION_REQUIRED').length,
            alreadyPublished: unapprovedCandidates.filter((r) => r.workflowStatus === 'PUBLISHED').length
          }
        });
        return;
      }

      const now = new Date().toISOString();
      const actualPublishDate = publishDate || now.split('T')[0];
      const publishedResults: StudentExamResult[] = [];

      approvedCandidates.forEach((r) => {
        const idx = database.examResults.findIndex((item) => item.id === r.id);
        if (idx === -1) return;

        const historyItem: ResultStatusHistoryItem = {
          id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          fromStatus: 'APPROVED',
          toStatus: 'PUBLISHED',
          changedByUserId: user.id,
          changedByUserName: user.name,
          changedByUserRole: user.role,
          timestamp: now,
          notes: `Official Institutional Publication on ${actualPublishDate}`
        };

        const updated: StudentExamResult = {
          ...r,
          workflowStatus: 'PUBLISHED',
          isPublished: true,
          publishDate: actualPublishDate,
          publishedBy: user.id,
          publishedByName: user.name,
          publishedAt: now,
          isLocked: true,
          lockedReason: 'Published to Student and Parent Portals. Locked against modifications.',
          statusHistory: [...(r.statusHistory || []), historyItem],
          updatedAt: now
        };

        database.examResults[idx] = updated;
        publishedResults.push(updated);

        // Optionally create in-app notifications for the student & guardians
        if (notifyStudentsAndParents && database.notifications) {
          database.notifications.push({
            id: `notif-pub-${r.id}-${Date.now()}`,
            userId: r.userId,
            title: `Examination Results Published: ${r.examName}`,
            message: `Your final examination results for ${r.examName} (${r.term}) have been officially verified and published. Your GPA is ${r.summary.gpa} (Grade ${r.summary.overallGrade}).`,
            type: 'announcement',
            isRead: false,
            createdAt: now,
            roleTarget: 'STUDENT'
          });
        }
      });

      // Also update Examination master record status if all results for it are published
      if (examId) {
        const examRecord = (database.examinations || []).find((e) => e.id === examId);
        if (examRecord) {
          examRecord.status = 'published';
          examRecord.updatedAt = now;
        }
      }

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'PUBLISH_EXAM_RESULTS',
        entityType: 'StudentExamResult',
        entityId: examId || 'BULK',
        details: `Published ${publishedResults.length} approved results to student and guardian portals.${unapprovedCandidates.length > 0 ? ` (${unapprovedCandidates.length} unapproved results were skipped)` : ''}`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Successfully published ${publishedResults.length} verified results to student and guardian portals.`,
        publishedCount: publishedResults.length,
        skippedUnapprovedCount: unapprovedCandidates.length,
        data: publishedResults
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * 18. POST /api/examinations/results/unpublish-reopen
 * Super Admin privilege to unlock and reopen published results for critical corrections
 */
examinationRouter.post(
  '/results/unpublish-reopen',
  requireAuth,
  requirePermission('examinations.publish'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;

      if (user.role !== 'SUPER_ADMIN') {
        res.status(403).json({
          success: false,
          error: 'Security Restriction: Only Super Admin is authorized to reopen published examination results.',
          code: 'SUPER_ADMIN_ONLY'
        });
        return;
      }

      const { resultIds, reason } = req.body as UnpublishReopenPayload;

      if (!resultIds || !Array.isArray(resultIds) || resultIds.length === 0) {
        res.status(400).json({ success: false, error: 'Array of resultIds is required.' });
        return;
      }
      if (!reason || reason.trim().length < 5) {
        res.status(400).json({
          success: false,
          error: 'An institutional audit reason (at least 5 characters) is required to reopen published results.'
        });
        return;
      }

      const now = new Date().toISOString();
      let reopenedCount = 0;
      const reopenedResults: StudentExamResult[] = [];

      resultIds.forEach((id) => {
        const idx = (database.examResults || []).findIndex((r) => r.id === id);
        if (idx === -1) return;

        const current = database.examResults[idx];

        const historyItem: ResultStatusHistoryItem = {
          id: `sh-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          fromStatus: current.workflowStatus || 'PUBLISHED',
          toStatus: 'UNDER_REVIEW',
          changedByUserId: user.id,
          changedByUserName: user.name,
          changedByUserRole: user.role,
          timestamp: now,
          reason: reason.trim(),
          notes: 'Reopened from published state by Super Admin'
        };

        const updated: StudentExamResult = {
          ...current,
          workflowStatus: 'UNDER_REVIEW',
          isPublished: false,
          isApproved: false,
          isLocked: false,
          lockedReason: undefined,
          reopenReason: reason.trim(),
          reopenedBy: user.id,
          reopenedByName: user.name,
          reopenedAt: now,
          statusHistory: [...(current.statusHistory || []), historyItem],
          updatedAt: now
        };

        database.examResults[idx] = updated;
        reopenedResults.push(updated);
        reopenedCount++;
      });

      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'REOPEN_PUBLISHED_EXAM_RESULTS',
        entityType: 'StudentExamResult',
        entityId: 'BULK',
        details: `Super Admin reopened ${reopenedCount} published exam results. Audit Reason: "${reason.trim()}"`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Successfully reopened ${reopenedCount} results for administrative revision.`,
        reopenedCount,
        data: reopenedResults
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// PART 6F: MERIT & POSITION RANKING ENGINE, REPORT CARDS & ACADEMIC REPORTS
// =========================================================================

// Helper: Calculate Merit Ranks for a given set of results based on active MeritRankingConfig
function computeMeritRanks(
  results: StudentExamResult[],
  config: MeritRankingConfig
): MeritRankItem[] {
  if (!results || results.length === 0) return [];

  // Filter based on includeFailedStudents
  const eligibleResults = config.includeFailedStudents
    ? [...results]
    : results.filter((r) => r.summary.resultStatus !== 'FAILED');

  const failedResults = config.includeFailedStudents
    ? []
    : results.filter((r) => r.summary.resultStatus === 'FAILED');

  // Helper to get attendance percentage for a student
  const getAttendancePct = (studentId: string): number => {
    const studentRecords = (database.attendanceRecords || []).filter((a) => a.studentId === studentId);
    if (studentRecords.length === 0) return 95.0; // fallback default
    const presentCount = studentRecords.filter((a) => a.status === 'PRESENT').length;
    return Number(((presentCount / studentRecords.length) * 100).toFixed(1));
  };

  // Compute primary and tie-breaker comparison scores
  const getPrimaryScore = (r: StudentExamResult): number => {
    switch (config.rankingCriteria) {
      case 'GPA':
      case 'WEIGHTED_GPA':
        return r.summary.gpa;
      case 'TOTAL_MARKS':
        return r.summary.totalObtainedMarks;
      case 'PERCENTAGE':
        return r.summary.overallPercentage;
      default:
        return r.summary.gpa;
    }
  };

  // Helper to compare two items using tie breaker priority list
  const compareItems = (a: StudentExamResult, b: StudentExamResult): number => {
    const scoreA = getPrimaryScore(a);
    const scoreB = getPrimaryScore(b);

    if (scoreA !== scoreB) {
      return scoreB - scoreA; // Descending
    }

    // Scores are equal, use tieBreakerPriority chain
    const priorities = config.tieBreakerPriority || ['GPA', 'TOTAL_MARKS', 'ATTENDANCE', 'ROLL_NUMBER'];
    for (const priority of priorities) {
      if (priority === 'GPA') {
        if (a.summary.gpa !== b.summary.gpa) return b.summary.gpa - a.summary.gpa;
      } else if (priority === 'TOTAL_MARKS') {
        if (a.summary.totalObtainedMarks !== b.summary.totalObtainedMarks) {
          return b.summary.totalObtainedMarks - a.summary.totalObtainedMarks;
        }
      } else if (priority === 'ATTENDANCE') {
        const attA = getAttendancePct(a.studentId);
        const attB = getAttendancePct(b.studentId);
        if (attA !== attB) return attB - attA;
      } else if (priority === 'ROLL_NUMBER') {
        const rollA = parseInt(a.rollNumber || '999', 10) || 999;
        const rollB = parseInt(b.rollNumber || '999', 10) || 999;
        if (rollA !== rollB) return rollA - rollB; // Ascending roll
      }
    }

    return 0; // Exactly equal / tied
  };

  // Sort eligible items
  eligibleResults.sort(compareItems);

  // Group items that have identical comparison scores (pure tie)
  const itemsWithScores = eligibleResults.map((r) => {
    const subjectMarks: Record<string, number> = {};
    (r.subjectScores || []).forEach((s) => {
      subjectMarks[s.subjectId] = s.obtainedMarks;
    });

    return {
      result: r,
      primaryScore: getPrimaryScore(r),
      attendancePct: getAttendancePct(r.studentId),
      subjectMarks
    };
  });

  const rankedItems: MeritRankItem[] = [];
  let currentRank = 1;
  let denseRank = 1;

  let i = 0;
  while (i < itemsWithScores.length) {
    // Find how many items have identical scores across primary and all tiebreakers
    let j = i;
    while (
      j < itemsWithScores.length &&
      compareItems(itemsWithScores[i].result, itemsWithScores[j].result) === 0
    ) {
      j++;
    }

    const tieGroupSize = j - i;
    const isTied = tieGroupSize > 1;

    for (let k = i; k < j; k++) {
      const item = itemsWithScores[k];
      let assignedRank = currentRank;
      let displayRank = `${currentRank}`;

      if (config.tieBreakerRule === 'DENSE') {
        assignedRank = denseRank;
        displayRank = `${denseRank}${isTied ? ' (Tied)' : ''}`;
      } else if (config.tieBreakerRule === 'ORDINAL') {
        assignedRank = k + 1;
        displayRank = `${k + 1}`;
      } else if (config.tieBreakerRule === 'FRACTIONAL') {
        // Average rank of the tied slots
        const sumSlots = (tieGroupSize * (2 * currentRank + tieGroupSize - 1)) / 2;
        const avgRank = sumSlots / tieGroupSize;
        assignedRank = avgRank;
        displayRank = `${avgRank.toFixed(1)} (Tied)`;
      } else {
        // STANDARD_COMPETITION (1, 2, 2, 4)
        assignedRank = currentRank;
        displayRank = `${currentRank}${isTied ? ' (Tied)' : ''}`;
      }

      rankedItems.push({
        rank: Math.floor(assignedRank),
        displayRank,
        studentId: item.result.studentId,
        userId: item.result.userId,
        studentName: item.result.studentName,
        admissionNumber: item.result.admissionNumber,
        rollNumber: item.result.rollNumber,
        avatarUrl: item.result.avatarUrl,
        classId: item.result.classId,
        className: item.result.className,
        sectionId: item.result.sectionId,
        sectionName: item.result.sectionName,
        academicSessionName: item.result.academicSessionName,
        examId: item.result.examId,
        examName: item.result.examName,
        totalFullMarks: item.result.summary.totalFullMarks,
        totalObtainedMarks: item.result.summary.totalObtainedMarks,
        overallPercentage: item.result.summary.overallPercentage,
        gpa: item.result.summary.gpa,
        overallGrade: item.result.summary.overallGrade,
        resultStatus: item.result.summary.resultStatus,
        isTied,
        tiedWithCount: isTied ? tieGroupSize : undefined,
        subjectMarks: item.subjectMarks,
        attendancePercentage: item.attendancePct
      });
    }

    currentRank += tieGroupSize;
    denseRank += 1;
    i = j;
  }

  // Append failed results if excluded from ranking
  failedResults.forEach((fr) => {
    const subjectMarks: Record<string, number> = {};
    (fr.subjectScores || []).forEach((s) => {
      subjectMarks[s.subjectId] = s.obtainedMarks;
    });

    rankedItems.push({
      rank: 9999,
      displayRank: 'N/A (Failed)',
      studentId: fr.studentId,
      userId: fr.userId,
      studentName: fr.studentName,
      admissionNumber: fr.admissionNumber,
      rollNumber: fr.rollNumber,
      avatarUrl: fr.avatarUrl,
      classId: fr.classId,
      className: fr.className,
      sectionId: fr.sectionId,
      sectionName: fr.sectionName,
      academicSessionName: fr.academicSessionName,
      examId: fr.examId,
      examName: fr.examName,
      totalFullMarks: fr.summary.totalFullMarks,
      totalObtainedMarks: fr.summary.totalObtainedMarks,
      overallPercentage: fr.summary.overallPercentage,
      gpa: fr.summary.gpa,
      overallGrade: fr.summary.overallGrade,
      resultStatus: fr.summary.resultStatus,
      isTied: false,
      subjectMarks,
      attendancePercentage: getAttendancePct(fr.studentId)
    });
  });

  return rankedItems;
}

// -------------------------------------------------------------------------
// 21. GET /api/examinations/merit-config
// Returns current institutional Merit & Position Ranking Configuration
// -------------------------------------------------------------------------
examinationRouter.get(
  '/merit-config',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const config = database.meritRankingConfig || {
      id: 'mrc-default',
      rankingCriteria: 'GPA',
      tieBreakerRule: 'STANDARD_COMPETITION',
      tieBreakerPriority: ['GPA', 'TOTAL_MARKS', 'ATTENDANCE', 'ROLL_NUMBER'],
      rankingScope: 'CLASS',
      includeFailedStudents: false,
      minimumPassingPercentage: 40,
      updatedAt: new Date().toISOString(),
      updatedBy: 'usr-admin-1',
      updatedByName: 'System Administrator'
    };

    res.json({
      success: true,
      data: config
    });
  }
);

// -------------------------------------------------------------------------
// 22. POST /api/examinations/merit-config
// Updates institutional Merit & Position Ranking Configuration
// -------------------------------------------------------------------------
examinationRouter.post(
  '/merit-config',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const {
      rankingCriteria,
      tieBreakerRule,
      tieBreakerPriority,
      rankingScope,
      includeFailedStudents,
      minimumPassingPercentage
    } = req.body as MeritRankingConfig;

    if (!rankingCriteria || !tieBreakerRule || !rankingScope) {
      res.status(400).json({
        success: false,
        error: 'Ranking criteria, tie breaker rule, and ranking scope are required.'
      });
      return;
    }

    const updatedConfig: MeritRankingConfig = {
      id: database.meritRankingConfig?.id || 'mrc-default',
      rankingCriteria: rankingCriteria || 'GPA',
      tieBreakerRule: tieBreakerRule || 'STANDARD_COMPETITION',
      tieBreakerPriority: tieBreakerPriority && tieBreakerPriority.length > 0
        ? tieBreakerPriority
        : ['GPA', 'TOTAL_MARKS', 'ATTENDANCE', 'ROLL_NUMBER'],
      rankingScope: rankingScope || 'CLASS',
      includeFailedStudents: Boolean(includeFailedStudents),
      minimumPassingPercentage: Number(minimumPassingPercentage) || 40,
      updatedAt: new Date().toISOString(),
      updatedBy: user.id,
      updatedByName: user.name
    };

    database.meritRankingConfig = updatedConfig;

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'UPDATE_MERIT_CONFIG',
      entityType: 'MeritRankingConfig',
      entityId: updatedConfig.id || 'mrc-default',
      details: `Updated institutional merit ranking configuration: Criteria=${updatedConfig.rankingCriteria}, TieRule=${updatedConfig.tieBreakerRule}, Scope=${updatedConfig.rankingScope}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: 'Merit ranking configuration successfully updated.',
      data: updatedConfig
    });
  }
);

// -------------------------------------------------------------------------
// 23. POST /api/examinations/calculate-merit
// Recalculates and persists Merit Ranks across all results for an examination
// -------------------------------------------------------------------------
examinationRouter.post(
  '/calculate-merit',
  requireAuth,
  requirePermission('examinations.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { examId, classId, sectionId } = req.body;

    if (!examId) {
      res.status(400).json({ success: false, error: 'Examination ID is required.' });
      return;
    }

    const exam = (database.examinations || []).find((e) => e.id === examId);
    if (!exam) {
      res.status(404).json({ success: false, error: 'Examination not found.' });
      return;
    }

    if (!database.examResults) database.examResults = [];

    // Filter results for this exam
    let targetResults = database.examResults.filter((r) => r.examId === examId);

    if (classId && classId !== 'ALL') {
      targetResults = targetResults.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      targetResults = targetResults.filter((r) => r.sectionId === sectionId);
    }

    if (targetResults.length === 0) {
      res.status(400).json({
        success: false,
        error: 'No examination results found for this exam and class selection. Please calculate results first.'
      });
      return;
    }

    const config = database.meritRankingConfig || {
      rankingCriteria: 'GPA',
      tieBreakerRule: 'STANDARD_COMPETITION',
      tieBreakerPriority: ['GPA', 'TOTAL_MARKS', 'ATTENDANCE', 'ROLL_NUMBER'],
      rankingScope: 'CLASS',
      includeFailedStudents: false,
      minimumPassingPercentage: 40
    };

    // Calculate Class-wide Ranks
    const classGroups: Record<string, StudentExamResult[]> = {};
    targetResults.forEach((r) => {
      const cId = r.classId || 'default';
      if (!classGroups[cId]) classGroups[cId] = [];
      classGroups[cId].push(r);
    });

    // Calculate Section-wide Ranks
    const sectionGroups: Record<string, StudentExamResult[]> = {};
    targetResults.forEach((r) => {
      const sId = r.sectionId || 'default';
      if (!sectionGroups[sId]) sectionGroups[sId] = [];
      sectionGroups[sId].push(r);
    });

    // Overall Ranks across whole exam
    const overallRankItems = computeMeritRanks(targetResults, config);

    // Apply computed ranks back to database.examResults
    let updatedCount = 0;
    targetResults.forEach((r) => {
      const idx = database.examResults.findIndex((item) => item.id === r.id);
      if (idx !== -1) {
        // Find in class group
        const classItems = computeMeritRanks(classGroups[r.classId || 'default'] || [], config);
        const classRankItem = classItems.find((ci) => ci.studentId === r.studentId);

        // Find in section group
        const sectionItems = computeMeritRanks(sectionGroups[r.sectionId || 'default'] || [], config);
        const sectionRankItem = sectionItems.find((si) => si.studentId === r.studentId);

        // Find in overall
        const overallItem = overallRankItems.find((oi) => oi.studentId === r.studentId);

        database.examResults[idx].summary.classRank = classRankItem ? classRankItem.rank : undefined;
        database.examResults[idx].summary.sectionRank = sectionRankItem ? sectionRankItem.rank : undefined;
        database.examResults[idx].summary.overallRank = overallItem ? overallItem.rank : undefined;
        database.examResults[idx].summary.meritPosition = classRankItem ? classRankItem.rank : undefined;
        database.examResults[idx].summary.rankTie = classRankItem ? classRankItem.isTied : false;
        database.examResults[idx].summary.totalStudentsInClass = (classGroups[r.classId || 'default'] || []).length;
        database.examResults[idx].summary.totalStudentsInSection = (sectionGroups[r.sectionId || 'default'] || []).length;
        database.examResults[idx].updatedAt = new Date().toISOString();

        updatedCount++;
      }
    });

    logAudit({
      userId: user.id,
      userRole: user.role,
      action: 'CALCULATE_MERIT_POSITIONS',
      entityType: 'Examination',
      entityId: examId,
      details: `Calculated merit and class positions for ${updatedCount} students in "${exam.name}".`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Merit and class positions successfully calculated for ${updatedCount} students.`,
      updatedCount,
      data: overallRankItems
    });
  }
);

// -------------------------------------------------------------------------
// 24. GET /api/examinations/merit-list
// Returns Ranked Merit List with full statistics for an Examination
// -------------------------------------------------------------------------
examinationRouter.get(
  '/merit-list',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const {
      academicSessionId,
      examId,
      classId,
      sectionId,
      includeUnpublished = 'false'
    } = req.query as any;

    if (!database.examResults) database.examResults = [];

    let filtered = [...database.examResults];

    // Restrict to Approved / Published results unless explicitly previewing
    if (includeUnpublished !== 'true') {
      filtered = filtered.filter((r) => r.workflowStatus === 'PUBLISHED' || r.workflowStatus === 'APPROVED');
    }

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((r) => r.sectionId === sectionId);
    }

    const config = database.meritRankingConfig || {
      rankingCriteria: 'GPA',
      tieBreakerRule: 'STANDARD_COMPETITION',
      tieBreakerPriority: ['GPA', 'TOTAL_MARKS', 'ATTENDANCE', 'ROLL_NUMBER'],
      rankingScope: 'CLASS',
      includeFailedStudents: false,
      minimumPassingPercentage: 40
    };

    const rankedItems = computeMeritRanks(filtered, config);

    // Resolve exam & class details
    const exam = examId ? (database.examinations || []).find((e) => e.id === examId) : null;
    const schoolClass = classId ? (database.classes || []).find((c) => c.id === classId) : null;
    const section = sectionId ? (database.sections || []).find((s) => s.id === sectionId) : null;

    const scores = rankedItems.map((r) => r.totalObtainedMarks).filter((s) => s > 0);
    const gpas = rankedItems.map((r) => r.gpa).filter((g) => g > 0);

    const highestScore = scores.length > 0 ? Math.max(...scores) : 0;
    const lowestScore = scores.length > 0 ? Math.min(...scores) : 0;
    const averageScore = scores.length > 0 ? Number((scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2)) : 0;
    const averageGpa = gpas.length > 0 ? Number((gpas.reduce((a, b) => a + b, 0) / gpas.length).toFixed(2)) : 0;
    const tiedCount = rankedItems.filter((r) => r.isTied).length;

    const responseData: MeritListResponse = {
      examId: examId || (exam ? exam.id : 'ALL'),
      examName: exam ? exam.name : 'All Examinations',
      classId: classId !== 'ALL' ? classId : undefined,
      className: schoolClass ? schoolClass.name : undefined,
      sectionId: sectionId !== 'ALL' ? sectionId : undefined,
      sectionName: section ? section.name : undefined,
      academicSessionName: exam?.academicSessionName || '2026-2027',
      rankingConfig: config,
      totalRanked: rankedItems.length,
      tiedCount,
      highestScore,
      lowestScore,
      averageScore,
      averageGpa,
      data: rankedItems
    };

    res.json({
      success: true,
      data: responseData
    });
  }
);

// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
// 25. GET /api/examinations/report-cards
// Returns list of report card candidates (approved + published results)
// Strict role-based scoping for Super Admin, Teacher, Student, and Guardian
// -------------------------------------------------------------------------
examinationRouter.get(
  '/report-cards',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const {
      academicSessionId,
      examId,
      classId,
      sectionId,
      studentId,
      search,
      page = 1,
      limit = 50
    } = req.query as any;

    if (!database.examResults) database.examResults = [];

    // Strictly Approved & Published results for official Report Cards
    let filtered = database.examResults.filter(
      (r) => r.workflowStatus === 'PUBLISHED' || r.workflowStatus === 'APPROVED'
    );

    // Role-based data isolation
    if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find(
        (s) => s.id === user.id || s.userId === user.id
      ) || req.session?.studentProfile;
      filtered = filtered.filter(
        (r) =>
          (r.studentId === studentProfile?.id || r.userId === user.id) &&
          r.isPublished &&
          r.workflowStatus === 'PUBLISHED'
      );
    } else if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find(
        (g) => g.id === user.id || g.userId === user.id
      ) || req.session?.guardianProfile;
      const linkedIds: string[] = guardian ? (guardian.studentIds || (guardian as any).linkedStudentIds || []) : [];
      filtered = filtered.filter(
        (r) =>
          linkedIds.includes(r.studentId) &&
          r.isPublished &&
          r.workflowStatus === 'PUBLISHED'
      );
    } else if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      res.status(403).json({ success: false, error: 'Access Denied: Insufficient permissions.' });
      return;
    }

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((r) => r.sectionId === sectionId);
    }
    if (studentId && studentId !== 'ALL') {
      filtered = filtered.filter((r) => r.studentId === studentId || r.userId === studentId);
    }
    if (search && typeof search === 'string' && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered = filtered.filter(
        (r) =>
          r.studentName.toLowerCase().includes(q) ||
          r.admissionNumber.toLowerCase().includes(q) ||
          r.rollNumber.toLowerCase().includes(q) ||
          r.examName.toLowerCase().includes(q)
      );
    }

    const total = filtered.length;
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 50;
    const startIndex = (pageNum - 1) * limitNum;
    const paginated = filtered.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginated,
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum)
    });
  }
);

// -------------------------------------------------------------------------
// 26. GET /api/examinations/report-cards/:resultId
// Returns full Institutional Report Card payload for a specific student result
// Enforces role-based security & student/parent data isolation
// -------------------------------------------------------------------------
examinationRouter.get(
  '/report-cards/:resultId',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { resultId } = req.params;

    const result = (database.examResults || []).find((r) => r.id === resultId);
    if (!result) {
      res.status(404).json({ success: false, error: 'Report card result record not found.' });
      return;
    }

    // Role-based access validation
    let isAuthorized = false;
    if (user.role === 'SUPER_ADMIN' || user.role === 'TEACHER') {
      isAuthorized = true;
    } else if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find(
        (s) => s.id === user.id || s.userId === user.id
      ) || req.session?.studentProfile;
      if (
        (result.studentId === studentProfile?.id || result.userId === user.id) &&
        result.isPublished &&
        result.workflowStatus === 'PUBLISHED'
      ) {
        isAuthorized = true;
      }
    } else if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find(
        (g) => g.id === user.id || g.userId === user.id
      ) || req.session?.guardianProfile;
      const linkedIds: string[] = guardian ? (guardian.studentIds || (guardian as any).linkedStudentIds || []) : [];
      if (
        guardian &&
        linkedIds.includes(result.studentId) &&
        result.isPublished &&
        result.workflowStatus === 'PUBLISHED'
      ) {
        isAuthorized = true;
      }
    }

    if (!isAuthorized) {
      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'UNAUTHORIZED_REPORT_CARD_VIEW_ATTEMPT',
        entityType: 'ReportCard',
        entityId: resultId,
        details: `Access Denied: User ${user.name} (${user.role}) attempted unauthorized access to report card for student ${result.studentName} (${result.studentId}).`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.status(403).json({
        success: false,
        error: 'Access Denied: You do not have permission to view this confidential report card.',
        code: 'FORBIDDEN_REPORT_CARD_ACCESS'
      });
      return;
    }

    // Resolve Student Profile & Guardian
    const studentProfile = (database.studentProfiles || []).find(
      (s) => s.id === result.studentId || s.userId === result.userId
    );
    const studentUser = (database.users || []).find((u) => u.id === result.userId);
    const guardian = studentProfile?.guardianId
      ? (database.guardians || []).find((g) => g.id === studentProfile.guardianId)
      : null;

    // Resolve Attendance stats
    const attendanceRecords = (database.attendanceRecords || []).filter(
      (a) => a.studentId === result.studentId
    );
    const totalWorkingDays = attendanceRecords.length > 0 ? attendanceRecords.length : 90;
    const presentDays = attendanceRecords.length > 0
      ? attendanceRecords.filter((a) => a.status === 'PRESENT').length
      : 86;
    const absentDays = attendanceRecords.length > 0
      ? attendanceRecords.filter((a) => a.status === 'ABSENT').length
      : 3;
    const lateDays = attendanceRecords.length > 0
      ? attendanceRecords.filter((a) => a.status === 'LATE').length
      : 1;
    const attendancePercentage = Number(((presentDays / totalWorkingDays) * 100).toFixed(1));

    // Resolve School Settings
    const school = database.schoolSettings || {
      schoolName: 'Sygmate International Academy',
      name: 'Sygmate International Academy',
      address: '742 Academic Way, Innovation Campus, CA 94105',
      phone: '+1 (555) 839-4628',
      email: 'academics@sygmate.edu',
      website: 'www.sygmate-academy.edu',
      affiliationNumber: 'REG-CAL-2026-9941',
      motto: 'Excellence in Academic Mastery & Ethical Leadership',
      principalName: 'Dr. Eleanor Vance, Ph.D.'
    };

    const gradingScale = (database.gradingScale && database.gradingScale.length > 0)
      ? database.gradingScale
      : [
          { id: '1', grade: 'A+', minPercentage: 90, maxPercentage: 100, gradePoint: 4.0, description: 'Outstanding', isPassing: true },
          { id: '2', grade: 'A', minPercentage: 80, maxPercentage: 89.99, gradePoint: 3.75, description: 'Excellent', isPassing: true },
          { id: '3', grade: 'B+', minPercentage: 70, maxPercentage: 79.99, gradePoint: 3.5, description: 'Very Good', isPassing: true },
          { id: '4', grade: 'B', minPercentage: 60, maxPercentage: 69.99, gradePoint: 3.0, description: 'Good', isPassing: true },
          { id: '5', grade: 'C', minPercentage: 50, maxPercentage: 59.99, gradePoint: 2.0, description: 'Average', isPassing: true },
          { id: '6', grade: 'D', minPercentage: 40, maxPercentage: 49.99, gradePoint: 1.0, description: 'Pass', isPassing: true },
          { id: '7', grade: 'F', minPercentage: 0, maxPercentage: 39.99, gradePoint: 0.0, description: 'Fail', isPassing: false }
        ];

    // Compute Class & Section Totals
    const classResults = (database.examResults || []).filter(
      (r) => r.examId === result.examId && r.classId === result.classId
    );
    const sectionResults = (database.examResults || []).filter(
      (r) => r.examId === result.examId && r.sectionId === result.sectionId
    );

    const reportCard: ReportCardDetail = {
      result,
      school: {
        name: school.schoolName || school.name || 'Sygmate International Academy',
        logoUrl: (school as any).logoUrl,
        address: school.address || '742 Academic Way, Innovation Campus',
        phone: school.phone || '+1 (555) 839-4628',
        email: school.email || 'academics@sygmate.edu',
        website: school.website || 'www.sygmate-academy.edu',
        affiliationNumber: school.affiliationNumber || 'REG-CAL-2026-9941',
        motto: 'Excellence in Academic Mastery & Ethical Leadership',
        principalName: 'Dr. Eleanor Vance, Ph.D.'
      },
      student: {
        id: result.studentId,
        name: result.studentName,
        admissionNumber: result.admissionNumber,
        rollNumber: result.rollNumber,
        className: result.className,
        sectionName: result.sectionName,
        academicSessionName: result.academicSessionName,
        guardianName: guardian ? guardian.name : undefined,
        dateOfBirth: studentProfile?.dateOfBirth || '2009-04-12',
        bloodGroup: studentProfile?.bloodGroup || 'O+',
        avatarUrl: studentUser?.avatarUrl || result.avatarUrl
      },
      gradingScale,
      attendance: {
        totalWorkingDays,
        presentDays,
        absentDays,
        lateDays,
        attendancePercentage
      },
      merit: {
        classRank: result.summary.classRank,
        totalClassStudents: classResults.length,
        sectionRank: result.summary.sectionRank,
        totalSectionStudents: sectionResults.length,
        overallRank: result.summary.overallRank,
        isTied: result.summary.rankTie
      },
      teacherRemarks: result.summary.overallPercentage >= 85
        ? 'Exemplary academic achievement across all disciplines. Demonstrates keen analytical depth.'
        : result.summary.overallPercentage >= 65
        ? 'Consistent effort and positive classroom engagement. Recommended for advanced elective seminars.'
        : 'Satisfactory foundational progress. Dedicated tutoring sessions advised in core STEM subjects.',
      principalRemarks: result.summary.resultStatus === 'PASSED' || result.summary.resultStatus === 'DISTINCTION'
        ? 'Promoted with commendable distinction. Official certification of academic completion.'
        : 'Supplementary academic guidance recommended for remedial examination cycle.',
      issueDate: result.publishDate || result.createdAt || new Date().toISOString(),
      verificationHash: `SYG-VER-${result.id.slice(-8).toUpperCase()}-${Math.abs(result.summary.totalObtainedMarks * 31).toString(16).toUpperCase()}`,
      isOfficial: result.workflowStatus === 'PUBLISHED'
    };

    res.json({
      success: true,
      data: reportCard
    });
  }
);

// -------------------------------------------------------------------------
// 27. GET /api/examinations/class-summary
// Returns full Class Result Summary, Statistics, and Tabulation Ledger
// -------------------------------------------------------------------------
examinationRouter.get(
  '/class-summary',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { academicSessionId, examId, classId, sectionId } = req.query as any;

    if (!database.examResults) database.examResults = [];

    // Filter results
    let filtered = [...database.examResults];

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((r) => r.sectionId === sectionId);
    }

    const exam = examId ? (database.examinations || []).find((e) => e.id === examId) : null;
    const schoolClass = classId ? (database.classes || []).find((c) => c.id === classId) : null;
    const section = sectionId ? (database.sections || []).find((s) => s.id === sectionId) : null;

    const totalEvaluated = filtered.length;
    const enrolledStudents = (database.studentProfiles || []).filter((st) => {
      if (st.enrollmentStatus === 'suspended' || st.enrollmentStatus === 'withdrawn') return false;
      if (classId && classId !== 'ALL' && st.classId !== classId) return false;
      if (sectionId && sectionId !== 'ALL' && st.sectionId !== sectionId) return false;
      return true;
    });

    const passedCount = filtered.filter((r) => r.summary.resultStatus === 'PASSED' || r.summary.resultStatus === 'DISTINCTION').length;
    const failedCount = filtered.filter((r) => r.summary.resultStatus === 'FAILED').length;
    const distinctionCount = filtered.filter((r) => r.summary.resultStatus === 'DISTINCTION').length;
    const withheldCount = filtered.filter((r) => r.summary.resultStatus === 'WITHHELD').length;

    const passRate = totalEvaluated > 0 ? Number(((passedCount / totalEvaluated) * 100).toFixed(2)) : 0;
    const failRate = totalEvaluated > 0 ? Number(((failedCount / totalEvaluated) * 100).toFixed(2)) : 0;

    const obtainedScores = filtered.map((r) => r.summary.totalObtainedMarks);
    const gpaScores = filtered.map((r) => r.summary.gpa);
    const percentageScores = filtered.map((r) => r.summary.overallPercentage);

    const highestMarks = obtainedScores.length > 0 ? Math.max(...obtainedScores) : 0;
    const lowestMarks = obtainedScores.length > 0 ? Math.min(...obtainedScores) : 0;
    const averageMarks = obtainedScores.length > 0 ? Number((obtainedScores.reduce((a, b) => a + b, 0) / obtainedScores.length).toFixed(2)) : 0;

    const highestMarksStudentItem = filtered.find((r) => r.summary.totalObtainedMarks === highestMarks);
    const highestMarksStudent = highestMarksStudentItem?.studentName;

    const highestGpa = gpaScores.length > 0 ? Math.max(...gpaScores) : 0;
    const lowestGpa = gpaScores.length > 0 ? Math.min(...gpaScores) : 0;
    const averageGpa = gpaScores.length > 0 ? Number((gpaScores.reduce((a, b) => a + b, 0) / gpaScores.length).toFixed(2)) : 0;
    const averagePercentage = percentageScores.length > 0 ? Number((percentageScores.reduce((a, b) => a + b, 0) / percentageScores.length).toFixed(2)) : 0;

    // Grade Distribution Breakdown
    const activeGradingScale = (database.gradingScale && database.gradingScale.length > 0)
      ? database.gradingScale
      : [
          { id: '1', grade: 'A+', minPercentage: 90, maxPercentage: 100, gradePoint: 4.0, description: 'Outstanding', isPassing: true },
          { id: '2', grade: 'A', minPercentage: 80, maxPercentage: 89.99, gradePoint: 3.75, description: 'Excellent', isPassing: true },
          { id: '3', grade: 'B+', minPercentage: 70, maxPercentage: 79.99, gradePoint: 3.5, description: 'Very Good', isPassing: true },
          { id: '4', grade: 'B', minPercentage: 60, maxPercentage: 69.99, gradePoint: 3.0, description: 'Good', isPassing: true },
          { id: '5', grade: 'C', minPercentage: 50, maxPercentage: 59.99, gradePoint: 2.0, description: 'Average', isPassing: true },
          { id: '6', grade: 'D', minPercentage: 40, maxPercentage: 49.99, gradePoint: 1.0, description: 'Pass', isPassing: true },
          { id: '7', grade: 'F', minPercentage: 0, maxPercentage: 39.99, gradePoint: 0.0, description: 'Fail', isPassing: false }
        ];

    const gradeDistribution = activeGradingScale.map((gs) => {
      const count = filtered.filter((r) => r.summary.overallGrade === gs.grade).length;
      const percentage = totalEvaluated > 0 ? Number(((count / totalEvaluated) * 100).toFixed(1)) : 0;
      return {
        grade: gs.grade,
        count,
        percentage,
        isPassing: gs.isPassing
      };
    });

    // Subject-wise Summaries in this class
    const subjectMap: Record<string, {
      subjectId: string;
      subjectName: string;
      subjectCode: string;
      credits: number;
      fullMarks: number;
      passMarks: number;
      scores: number[];
      gpas: number[];
      passedCount: number;
      failedCount: number;
    }> = {};

    filtered.forEach((r) => {
      (r.subjectScores || []).forEach((sc) => {
        if (!subjectMap[sc.subjectId]) {
          subjectMap[sc.subjectId] = {
            subjectId: sc.subjectId,
            subjectName: sc.subjectName,
            subjectCode: sc.subjectCode,
            credits: sc.credits || 1,
            fullMarks: sc.fullMarks || 100,
            passMarks: sc.passMarks || 40,
            scores: [],
            gpas: [],
            passedCount: 0,
            failedCount: 0
          };
        }
        subjectMap[sc.subjectId].scores.push(sc.obtainedMarks);
        subjectMap[sc.subjectId].gpas.push(sc.gradePoint);
        if (sc.isPassing) {
          subjectMap[sc.subjectId].passedCount++;
        } else {
          subjectMap[sc.subjectId].failedCount++;
        }
      });
    });

    const subjectSummaries = Object.values(subjectMap).map((sm) => {
      const evaluatedCount = sm.scores.length;
      const highestMarks = evaluatedCount > 0 ? Math.max(...sm.scores) : 0;
      const lowestMarks = evaluatedCount > 0 ? Math.min(...sm.scores) : 0;
      const averageMarks = evaluatedCount > 0 ? Number((sm.scores.reduce((a, b) => a + b, 0) / evaluatedCount).toFixed(2)) : 0;
      const averageGpa = evaluatedCount > 0 ? Number((sm.gpas.reduce((a, b) => a + b, 0) / evaluatedCount).toFixed(2)) : 0;
      const passRate = evaluatedCount > 0 ? Number(((sm.passedCount / evaluatedCount) * 100).toFixed(2)) : 0;

      // Find teacher for this subject in this class
      const subjectEntity = (database.subjects || []).find((s) => s.id === sm.subjectId);
      const teacherUser = subjectEntity?.teacherId ? (database.users || []).find((u) => u.id === subjectEntity.teacherId) : null;

      return {
        subjectId: sm.subjectId,
        subjectName: sm.subjectName,
        subjectCode: sm.subjectCode,
        credits: sm.credits,
        fullMarks: sm.fullMarks,
        passMarks: sm.passMarks,
        evaluatedCount,
        passedCount: sm.passedCount,
        failedCount: sm.failedCount,
        passRate,
        highestMarks,
        lowestMarks,
        averageMarks,
        averageGpa,
        teacherName: teacherUser?.name
      };
    });

    // Tabulation Ledger (Matrix of student by subject scores)
    const tabulationLedger = filtered.map((r) => {
      const scores: Record<string, {
        obtained: number;
        full: number;
        grade: string;
        gradePoint: number;
        isPassing: boolean;
        isAbsent?: boolean;
        isExempt?: boolean;
      }> = {};

      (r.subjectScores || []).forEach((sc) => {
        scores[sc.subjectId] = {
          obtained: sc.obtainedMarks,
          full: sc.fullMarks,
          grade: sc.grade,
          gradePoint: sc.gradePoint,
          isPassing: sc.isPassing,
          isAbsent: sc.grade === 'AB',
          isExempt: sc.grade === 'EX'
        };
      });

      return {
        studentId: r.studentId,
        studentName: r.studentName,
        admissionNumber: r.admissionNumber,
        rollNumber: r.rollNumber,
        sectionName: r.sectionName,
        scores,
        totalFullMarks: r.summary.totalFullMarks,
        totalObtainedMarks: r.summary.totalObtainedMarks,
        percentage: r.summary.overallPercentage,
        gpa: r.summary.gpa,
        overallGrade: r.summary.overallGrade,
        resultStatus: r.summary.resultStatus,
        classRank: r.summary.classRank,
        sectionRank: r.summary.sectionRank,
        meritPosition: r.summary.meritPosition
      };
    });

    // Sort tabulation ledger by roll number or rank
    tabulationLedger.sort((a, b) => {
      if (a.classRank && b.classRank) return a.classRank - b.classRank;
      const rA = parseInt(a.rollNumber || '999', 10) || 999;
      const rB = parseInt(b.rollNumber || '999', 10) || 999;
      return rA - rB;
    });

    const summaryData: ClassResultSummaryData = {
      examId: examId || (exam ? exam.id : 'ALL'),
      examName: exam ? exam.name : 'All Examinations',
      academicSessionId: academicSessionId || 'ALL',
      academicSessionName: exam?.academicSessionName || '2026-2027',
      classId: classId || 'ALL',
      className: schoolClass ? schoolClass.name : 'All Classes',
      sectionId: sectionId || 'ALL',
      sectionName: section ? section.name : 'All Sections',
      totalEnrolled: enrolledStudents.length || totalEvaluated,
      totalEvaluated,
      passedCount,
      failedCount,
      distinctionCount,
      withheldCount,
      passRate,
      failRate,
      highestMarks,
      highestMarksStudent,
      lowestMarks,
      averageMarks,
      highestGpa,
      lowestGpa,
      averageGpa,
      averagePercentage,
      gradeDistribution,
      subjectSummaries,
      tabulationLedger
    };

    res.json({
      success: true,
      data: summaryData
    });
  }
);

// -------------------------------------------------------------------------
// 28. GET /api/examinations/subject-performance
// Returns subject-level performance metrics, highest, lowest, average, pass rate
// -------------------------------------------------------------------------
examinationRouter.get(
  '/subject-performance',
  requireAuth,
  requirePermission('examinations.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    const { academicSessionId, examId, classId, sectionId, subjectId } = req.query as any;

    if (!database.examResults) database.examResults = [];

    let filtered = [...database.examResults];

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((r) => r.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((r) => r.sectionId === sectionId);
    }

    const exam = examId ? (database.examinations || []).find((e) => e.id === examId) : null;
    const schoolClass = classId ? (database.classes || []).find((c) => c.id === classId) : null;
    const section = sectionId ? (database.sections || []).find((s) => s.id === sectionId) : null;

    // Aggregate by Subject
    const subjectMap: Record<string, {
      subjectId: string;
      subjectName: string;
      subjectCode: string;
      credits: number;
      fullMarks: number;
      passMarks: number;
      scores: Array<{ studentName: string; score: number; grade: string; gp: number; isPassing: boolean; isAbsent: boolean; isExempt: boolean }>;
    }> = {};

    filtered.forEach((r) => {
      (r.subjectScores || []).forEach((sc) => {
        if (subjectId && subjectId !== 'ALL' && sc.subjectId !== subjectId) {
          return;
        }

        if (!subjectMap[sc.subjectId]) {
          subjectMap[sc.subjectId] = {
            subjectId: sc.subjectId,
            subjectName: sc.subjectName,
            subjectCode: sc.subjectCode,
            credits: sc.credits || 1,
            fullMarks: sc.fullMarks || 100,
            passMarks: sc.passMarks || 40,
            scores: []
          };
        }

        subjectMap[sc.subjectId].scores.push({
          studentName: r.studentName,
          score: sc.obtainedMarks,
          grade: sc.grade,
          gp: sc.gradePoint,
          isPassing: sc.isPassing,
          isAbsent: sc.grade === 'AB',
          isExempt: sc.grade === 'EX'
        });
      });
    });

    const activeGradingScale = (database.gradingScale && database.gradingScale.length > 0)
      ? database.gradingScale
      : [
          { id: '1', grade: 'A+', minPercentage: 90, maxPercentage: 100, gradePoint: 4.0, description: 'Outstanding', isPassing: true },
          { id: '2', grade: 'A', minPercentage: 80, maxPercentage: 89.99, gradePoint: 3.75, description: 'Excellent', isPassing: true },
          { id: '3', grade: 'B+', minPercentage: 70, maxPercentage: 79.99, gradePoint: 3.5, description: 'Very Good', isPassing: true },
          { id: '4', grade: 'B', minPercentage: 60, maxPercentage: 69.99, gradePoint: 3.0, description: 'Good', isPassing: true },
          { id: '5', grade: 'C', minPercentage: 50, maxPercentage: 59.99, gradePoint: 2.0, description: 'Average', isPassing: true },
          { id: '6', grade: 'D', minPercentage: 40, maxPercentage: 49.99, gradePoint: 1.0, description: 'Pass', isPassing: true },
          { id: '7', grade: 'F', minPercentage: 0, maxPercentage: 39.99, gradePoint: 0.0, description: 'Fail', isPassing: false }
        ];

    let totalPassedSum = 0;
    let totalEvaluatedSum = 0;

    const subjects = Object.values(subjectMap).map((sm) => {
      const totalStudents = sm.scores.length;
      const passedCount = sm.scores.filter((s) => s.isPassing).length;
      const failedCount = sm.scores.filter((s) => !s.isPassing && !s.isAbsent && !s.isExempt).length;
      const absentCount = sm.scores.filter((s) => s.isAbsent).length;
      const exemptCount = sm.scores.filter((s) => s.isExempt).length;

      totalPassedSum += passedCount;
      totalEvaluatedSum += totalStudents;

      const passPercentage = totalStudents > 0 ? Number(((passedCount / totalStudents) * 100).toFixed(2)) : 0;

      const validNumericScores = sm.scores.filter((s) => !s.isAbsent && !s.isExempt).map((s) => s.score);
      const validGps = sm.scores.filter((s) => !s.isAbsent && !s.isExempt).map((s) => s.gp);

      const highestMarks = validNumericScores.length > 0 ? Math.max(...validNumericScores) : 0;
      const lowestMarks = validNumericScores.length > 0 ? Math.min(...validNumericScores) : 0;
      const averageMarks = validNumericScores.length > 0
        ? Number((validNumericScores.reduce((a, b) => a + b, 0) / validNumericScores.length).toFixed(2))
        : 0;

      const highestItem = sm.scores.find((s) => s.score === highestMarks);
      const highestMarksStudent = highestItem?.studentName;

      const averagePercentage = sm.fullMarks > 0 ? Number(((averageMarks / sm.fullMarks) * 100).toFixed(2)) : 0;
      const averageGradePoint = validGps.length > 0 ? Number((validGps.reduce((a, b) => a + b, 0) / validGps.length).toFixed(2)) : 0;

      // Determine average grade from grading scale
      const avgGradeMatch = activeGradingScale.find(
        (g) => averagePercentage >= g.minPercentage && averagePercentage <= g.maxPercentage
      );
      const averageGrade = avgGradeMatch ? avgGradeMatch.grade : 'B';

      // Grade breakdown
      const gradeBreakdown: Record<string, number> = {};
      sm.scores.forEach((s) => {
        gradeBreakdown[s.grade] = (gradeBreakdown[s.grade] || 0) + 1;
      });

      const subjectEntity = (database.subjects || []).find((s) => s.id === sm.subjectId);
      const teacherUser = subjectEntity?.teacherId ? (database.users || []).find((u) => u.id === subjectEntity.teacherId) : null;

      return {
        subjectId: sm.subjectId,
        subjectName: sm.subjectName,
        subjectCode: sm.subjectCode,
        credits: sm.credits,
        fullMarks: sm.fullMarks,
        passMarks: sm.passMarks,
        totalStudents,
        passedCount,
        failedCount,
        absentCount,
        exemptCount,
        passPercentage,
        highestMarks,
        highestMarksStudent,
        lowestMarks,
        averageMarks,
        averagePercentage,
        averageGrade,
        averageGradePoint,
        gradeBreakdown,
        teacherName: teacherUser?.name
      };
    });

    const overallSubjectPassRate = totalEvaluatedSum > 0
      ? Number(((totalPassedSum / totalEvaluatedSum) * 100).toFixed(2))
      : 0;

    const response: SubjectPerformanceReportResponse = {
      examId: examId || (exam ? exam.id : 'ALL'),
      examName: exam ? exam.name : 'All Examinations',
      academicSessionId: academicSessionId || 'ALL',
      academicSessionName: exam?.academicSessionName || '2026-2027',
      classId: classId || 'ALL',
      className: schoolClass ? schoolClass.name : 'All Classes',
      sectionId: sectionId !== 'ALL' ? sectionId : undefined,
      sectionName: section ? section.name : undefined,
      totalSubjects: subjects.length,
      overallSubjectPassRate,
      subjects
    };

    res.json({
      success: true,
      data: response
    });
  }
);

// -------------------------------------------------------------------------
// 29. GET /api/examinations/student-performance/:studentId
// Returns Multi-Exam Historical Performance, Trajectory, and Subject Trends
// -------------------------------------------------------------------------
examinationRouter.get(
  '/student-performance/:studentId',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    const user = req.user!;
    const { studentId } = req.params;

    // Security Check: Students/Guardians can only view their own performance
    if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find((s) => s.userId === user.id);
      if (!studentProfile || (studentProfile.id !== studentId && studentProfile.userId !== studentId)) {
        res.status(403).json({ success: false, error: 'Access Denied: You may only view your own academic performance.' });
        return;
      }
    } else if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find((g) => g.userId === user.id);
      const studentProfile = (database.studentProfiles || []).find((s) => s.id === studentId);
      if (!guardian || !studentProfile || studentProfile.guardianId !== guardian.id) {
        res.status(403).json({ success: false, error: 'Access Denied: You may only view your linked student’s academic performance.' });
        return;
      }
    }

    const studentProfile = (database.studentProfiles || []).find(
      (s) => s.id === studentId || s.userId === studentId
    );
    const studentUser = (database.users || []).find(
      (u) => u.id === studentProfile?.userId || u.id === studentId
    );

    if (!studentProfile && !studentUser) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const studentClass = (database.classes || []).find((c) => c.id === studentProfile?.classId);
    const studentSection = (database.sections || []).find((s) => s.id === studentProfile?.sectionId);
    const guardian = studentProfile?.guardianId
      ? (database.guardians || []).find((g) => g.id === studentProfile.guardianId)
      : null;

    // Find all results for this student (approved + published for students, or all published for admin)
    const allResults = (database.examResults || []).filter(
      (r) => r.studentId === studentProfile?.id || r.userId === studentUser?.id
    );

    // Filter to published for non-admins
    const results = (user.role === 'SUPER_ADMIN' || user.role === 'TEACHER')
      ? allResults
      : allResults.filter((r) => r.workflowStatus === 'PUBLISHED');

    // Sort chronologically
    results.sort((a, b) => new Date(a.publishDate || a.createdAt).getTime() - new Date(b.publishDate || b.createdAt).getTime());

    // Attendance stats for student
    const attendanceRecords = (database.attendanceRecords || []).filter(
      (a) => a.studentId === studentProfile?.id
    );
    const totalWorkingDays = attendanceRecords.length > 0 ? attendanceRecords.length : 90;
    const presentDays = attendanceRecords.length > 0 ? attendanceRecords.filter((a) => a.status === 'PRESENT').length : 86;
    const attendanceAverage = Number(((presentDays / totalWorkingDays) * 100).toFixed(1));

    const examHistory = results.map((r) => ({
      examId: r.examId,
      examName: r.examName,
      examType: r.examType || 'Term Exam',
      academicSessionName: r.academicSessionName || '2026-2027',
      publishDate: r.publishDate || r.createdAt,
      totalFullMarks: r.summary.totalFullMarks,
      totalObtainedMarks: r.summary.totalObtainedMarks,
      overallPercentage: r.summary.overallPercentage,
      gpa: r.summary.gpa,
      overallGrade: r.summary.overallGrade,
      resultStatus: r.summary.resultStatus,
      classRank: r.summary.classRank,
      totalStudentsInClass: r.summary.totalStudentsInClass,
      subjectScores: r.subjectScores,
      attendanceStats: {
        totalWorkingDays,
        presentDays,
        percentage: attendanceAverage
      }
    }));

    // Cumulative stats
    const gpas = results.map((r) => r.summary.gpa).filter((g) => g > 0);
    const percentages = results.map((r) => r.summary.overallPercentage).filter((p) => p > 0);

    const overallCumulativeGpa = gpas.length > 0 ? Number((gpas.reduce((a, b) => a + b, 0) / gpas.length).toFixed(2)) : 0;
    const averagePercentage = percentages.length > 0 ? Number((percentages.reduce((a, b) => a + b, 0) / percentages.length).toFixed(2)) : 0;
    const highestGpa = gpas.length > 0 ? Math.max(...gpas) : 0;
    const lowestGpa = gpas.length > 0 ? Math.min(...gpas) : 0;

    let gpaTrend: 'UPWARD' | 'DOWNWARD' | 'STABLE' = 'STABLE';
    let gpaDelta = 0;
    if (gpas.length >= 2) {
      gpaDelta = Number((gpas[gpas.length - 1] - gpas[0]).toFixed(2));
      if (gpaDelta > 0.05) gpaTrend = 'UPWARD';
      else if (gpaDelta < -0.05) gpaTrend = 'DOWNWARD';
      else gpaTrend = 'STABLE';
    }

    const passedExamsCount = results.filter((r) => r.summary.resultStatus === 'PASSED' || r.summary.resultStatus === 'DISTINCTION').length;
    const failedExamsCount = results.filter((r) => r.summary.resultStatus === 'FAILED').length;

    // Subject trends over time
    const subjectMap: Record<string, {
      subjectName: string;
      subjectCode: string;
      history: Array<{
        examName: string;
        obtainedMarks: number;
        fullMarks: number;
        percentage: number;
        grade: string;
        gradePoint: number;
      }>;
    }> = {};

    results.forEach((r) => {
      (r.subjectScores || []).forEach((sc) => {
        if (!subjectMap[sc.subjectId]) {
          subjectMap[sc.subjectId] = {
            subjectName: sc.subjectName,
            subjectCode: sc.subjectCode,
            history: []
          };
        }
        subjectMap[sc.subjectId].history.push({
          examName: r.examName,
          obtainedMarks: sc.obtainedMarks,
          fullMarks: sc.fullMarks,
          percentage: sc.percentage,
          grade: sc.grade,
          gradePoint: sc.gradePoint
        });
      });
    });

    const subjectTrends = Object.values(subjectMap);

    const performanceResponse: StudentPerformanceHistoryResponse = {
      student: {
        id: studentProfile?.id || studentId,
        userId: studentUser?.id || '',
        name: studentUser?.name || `${studentProfile?.firstName || ''} ${studentProfile?.lastName || ''}`.trim() || 'Student',
        admissionNumber: studentProfile?.admissionNumber || 'ADM-2026-001',
        rollNumber: studentProfile?.rollNumber || '01',
        className: studentClass?.name || 'Grade 10',
        sectionName: studentSection?.name || 'Section A',
        academicSessionName: studentProfile?.academicSessionId || '2026-2027',
        guardianName: guardian?.name,
        avatarUrl: studentUser?.avatarUrl,
        enrollmentDate: studentProfile?.enrollmentDate
      },
      examHistory,
      cumulativeStats: {
        totalExamsTaken: results.length,
        overallCumulativeGpa,
        averagePercentage,
        highestGpa,
        lowestGpa,
        gpaTrend,
        gpaDelta,
        passedExamsCount,
        failedExamsCount,
        attendanceAverage
      },
      subjectTrends
    };

    res.json({
      success: true,
      data: performanceResponse
    });
  }
);


