/**
 * Multi-Tenant SaaS Platform & School Management Routes (Phase 1)
 * Separates Platform Super Admin actions from School-level operations.
 */

import { Router, Response } from 'express';
import { database } from '../db/database.js';
import {
  requireAuth,
  AuthenticatedRequest,
  hashPassword
} from '../security/auth.js';
import {
  requirePlatformAdmin,
  requireTenant,
  ExtendedTenantRequest,
  getUserSchools,
  getUserMemberships,
  verifySchoolAccess
} from '../security/tenant.js';
import { logAudit } from '../security/audit.js';
import {
  School,
  SchoolSettings,
  SchoolMembership,
  SchoolSubscriptionPlan,
  SchoolSubscriptionStatus
} from '../../src/types/index.js';

export const platformRouter = Router();
export const schoolsRouter = Router();

const SEED_SALT = 'sygmate-security-salt-2026';

/**
 * GET /api/platform/schools
 * List all schools in the SaaS platform with operational metrics (Platform Super Admin only)
 */
platformRouter.get('/schools', requireAuth, requirePlatformAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolsWithStats = database.schools.map((school) => {
      // Calculate operational tenant stats
      const studentCount = database.studentProfiles.filter((s) => {
        const studentUser = database.users.find((u) => u.id === s.userId);
        return studentUser?.schoolId === school.id || (!studentUser?.schoolId && school.id === 'school-main');
      }).length;

      const teacherCount = database.teacherProfiles.filter((t) => {
        const teacherUser = database.users.find((u) => u.id === t.userId);
        return teacherUser?.schoolId === school.id || (!teacherUser?.schoolId && school.id === 'school-main');
      }).length;

      const adminMembers = database.schoolMemberships.filter(
        (m) => m.schoolId === school.id && (m.role === 'ADMIN' || m.role === 'SUPER_ADMIN')
      );

      const adminUsers = database.users.filter((u) =>
        adminMembers.some((m) => m.userId === u.id)
      );

      return {
        ...school,
        stats: {
          studentsCount: studentCount,
          teachersCount: teacherCount,
          adminsCount: adminUsers.length,
          classesCount: school.id === 'school-main' ? database.classes.length : 0
        },
        primaryAdmin: adminUsers[0] ? {
          name: adminUsers[0].name,
          email: adminUsers[0].email
        } : undefined
      };
    });

    res.json({
      success: true,
      data: schoolsWithStats,
      total: schoolsWithStats.length
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve schools list.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/platform/stats
 * Platform overview SaaS metrics for Platform Super Admin
 */
platformRouter.get('/stats', requireAuth, requirePlatformAdmin, (_req: AuthenticatedRequest, res: Response): void => {
  try {
    const totalSchools = database.schools.length;
    const activeSchools = database.schools.filter((s) => s.status === 'active').length;
    const trialSchools = database.schools.filter((s) => s.status === 'trial').length;
    const suspendedSchools = database.schools.filter((s) => s.status === 'suspended').length;

    const planBreakdown = {
      enterprise: database.schools.filter((s) => s.plan === 'enterprise').length,
      growth: database.schools.filter((s) => s.plan === 'growth').length,
      starter: database.schools.filter((s) => s.plan === 'starter').length,
      trial: database.schools.filter((s) => s.plan === 'trial').length
    };

    const totalStudents = database.studentProfiles.length;
    const totalTeachers = database.teacherProfiles.length;
    const totalStaff = database.staffProfiles.length;

    res.json({
      success: true,
      data: {
        totalSchools,
        activeSchools,
        trialSchools,
        suspendedSchools,
        planBreakdown,
        totalStudents,
        totalTeachers,
        totalStaff,
        systemHealth: 'OPERATIONAL',
        version: '2.5.0-multitenant-saas'
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve platform statistics.'
    });
  }
});

/**
 * POST /api/platform/schools
 * Provision a new school tenant (Platform Super Admin only)
 */
platformRouter.post('/schools', requireAuth, requirePlatformAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      name,
      code,
      plan = 'starter',
      contactEmail,
      contactPhone = '+1 (555) 000-0000',
      address = '100 University Avenue',
      city = 'New York',
      state = 'NY',
      country = 'United States',
      website,
      adminName,
      adminEmail
    } = req.body;

    if (!name || !code || !contactEmail) {
      res.status(400).json({
        success: false,
        error: 'School Name, School Code, and Contact Email are required fields.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    // Check for duplicate school code
    const existingCode = database.schools.find(
      (s) => s.code.toLowerCase() === code.trim().toLowerCase()
    );
    if (existingCode) {
      res.status(409).json({
        success: false,
        error: `A school with code '${code}' already exists. School code must be unique.`,
        code: 'DUPLICATE_SCHOOL_CODE'
      });
      return;
    }

    const schoolId = `school-${code.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

    // Initialize school settings
    const newSettings: SchoolSettings = {
      id: schoolId,
      schoolName: name.trim(),
      name: name.trim(),
      schoolCode: code.trim().toUpperCase(),
      code: code.trim().toUpperCase(),
      schoolType: 'Private',
      tagline: 'Empowering Next-Generation Leaders',
      contactEmail: contactEmail.trim(),
      email: contactEmail.trim(),
      contactPhone: contactPhone.trim(),
      phone: contactPhone.trim(),
      address: address.trim(),
      city: city.trim(),
      state: state.trim(),
      country: country.trim(),
      website: website || `https://${code.toLowerCase()}.sygmate.edu`,
      timezone: 'America/New_York (EST)',
      currency: 'USD',
      currencySymbol: '$',
      dateFormat: 'MM/DD/YYYY',
      timeFormat: '12-hour',
      weekStartDay: 'Monday',
      academicSessionId: 'session-2026-2027',
      currentTerm: 'Fall Semester 2026',
      establishedYear: new Date().getFullYear(),
      foundedYear: new Date().getFullYear()
    };

    const maxStudentsMap: Record<SchoolSubscriptionPlan, number> = {
      trial: 300,
      starter: 500,
      growth: 1500,
      enterprise: 5000
    };

    const maxStaffMap: Record<SchoolSubscriptionPlan, number> = {
      trial: 25,
      starter: 50,
      growth: 120,
      enterprise: 400
    };

    const validatedPlan = (['starter', 'growth', 'enterprise', 'trial'].includes(plan)
      ? plan
      : 'starter') as SchoolSubscriptionPlan;

    const newSchool: School = {
      id: schoolId,
      name: name.trim(),
      code: code.trim().toUpperCase(),
      slug: code.toLowerCase(),
      status: 'active',
      plan: validatedPlan,
      subscriptionStatus: 'active',
      maxStudents: maxStudentsMap[validatedPlan] || 500,
      maxStaff: maxStaffMap[validatedPlan] || 50,
      contactEmail: contactEmail.trim(),
      contactPhone: contactPhone.trim(),
      address: address.trim(),
      city: city.trim(),
      state: state.trim(),
      country: country.trim(),
      website: website || `https://${code.toLowerCase()}.sygmate.edu`,
      settings: newSettings,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.schools.push(newSchool);

    // If an initial school admin was provided, provision them
    let provisionedAdmin;
    if (adminEmail && adminName) {
      const existingUser = database.users.find(
        (u) => u.email.toLowerCase() === adminEmail.trim().toLowerCase()
      );

      if (!existingUser) {
        const adminId = `usr-admin-${Date.now().toString(36)}`;
        const hashObj = hashPassword('Admin@123', SEED_SALT);
        const newAdmin = {
          id: adminId,
          name: adminName.trim(),
          email: adminEmail.trim(),
          username: adminEmail.split('@')[0],
          role: 'ADMIN' as const,
          status: 'active' as const,
          schoolId,
          isPlatformAdmin: false,
          passwordHash: hashObj.hash,
          passwordSalt: hashObj.salt,
          phoneNumber: contactPhone,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        database.users.push(newAdmin);

        const newMembership: SchoolMembership = {
          id: `mem-${adminId}-${schoolId}`,
          userId: adminId,
          schoolId,
          role: 'ADMIN',
          isDefault: true,
          status: 'active',
          createdAt: new Date().toISOString()
        };
        database.schoolMemberships.push(newMembership);

        provisionedAdmin = {
          id: adminId,
          name: adminName,
          email: adminEmail,
          role: 'ADMIN',
          initialPassword: 'Admin@123'
        };
      } else {
        // Attach membership to existing user
        const newMembership: SchoolMembership = {
          id: `mem-${existingUser.id}-${schoolId}`,
          userId: existingUser.id,
          schoolId,
          role: 'ADMIN',
          isDefault: false,
          status: 'active',
          createdAt: new Date().toISOString()
        };
        database.schoolMemberships.push(newMembership);
        provisionedAdmin = {
          id: existingUser.id,
          name: existingUser.name,
          email: existingUser.email,
          role: 'ADMIN'
        };
      }
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'TENANT',
      details: `Provisioned new school tenant: ${newSchool.name} (${newSchool.code}) on ${newSchool.plan} plan.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      data: {
        school: newSchool,
        provisionedAdmin
      },
      message: `School tenant '${newSchool.name}' created and provisioned successfully.`
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to provision school tenant.'
    });
  }
});

/**
 * GET /api/platform/schools/:id
 * Retrieve specific school tenant details
 */
platformRouter.get('/schools/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const user = req.user!;

    if (!verifySchoolAccess(user, id)) {
      res.status(403).json({
        success: false,
        error: `Forbidden. You do not have permission to view school '${id}'.`,
        code: 'FORBIDDEN_TENANT_ACCESS'
      });
      return;
    }

    const school = database.schools.find((s) => s.id === id);
    if (!school) {
      res.status(404).json({
        success: false,
        error: `School '${id}' not found.`,
        code: 'SCHOOL_NOT_FOUND'
      });
      return;
    }

    res.json({
      success: true,
      data: school
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve school details.'
    });
  }
});

/**
 * PUT /api/platform/schools/:id
 * Update school tenant status, plan, or configuration (Platform Super Admin only)
 */
platformRouter.put('/schools/:id', requireAuth, requirePlatformAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const school = database.schools.find((s) => s.id === id);
    if (!school) {
      res.status(404).json({
        success: false,
        error: `School '${id}' not found.`,
        code: 'SCHOOL_NOT_FOUND'
      });
      return;
    }

    const {
      name,
      plan,
      status,
      subscriptionStatus,
      maxStudents,
      maxStaff,
      contactEmail,
      contactPhone,
      address,
      city,
      country
    } = req.body;

    if (name) school.name = name.trim();
    if (plan && ['starter', 'growth', 'enterprise', 'trial'].includes(plan)) {
      school.plan = plan as SchoolSubscriptionPlan;
    }
    if (status && ['active', 'suspended', 'trial', 'pending'].includes(status)) {
      school.status = status as 'active' | 'suspended' | 'trial' | 'pending';
    }
    if (subscriptionStatus) {
      school.subscriptionStatus = subscriptionStatus as SchoolSubscriptionStatus;
    }
    if (typeof maxStudents === 'number' && maxStudents > 0) school.maxStudents = maxStudents;
    if (typeof maxStaff === 'number' && maxStaff > 0) school.maxStaff = maxStaff;
    if (contactEmail) school.contactEmail = contactEmail.trim();
    if (contactPhone) school.contactPhone = contactPhone.trim();
    if (address) school.address = address.trim();
    if (city) school.city = city.trim();
    if (country) school.country = country.trim();
    school.updatedAt = new Date().toISOString();

    // Sync with settings if exists
    if (school.settings) {
      if (name) {
        school.settings.schoolName = name.trim();
        school.settings.name = name.trim();
      }
      if (contactEmail) {
        school.settings.contactEmail = contactEmail.trim();
        school.settings.email = contactEmail.trim();
      }
      if (contactPhone) {
        school.settings.contactPhone = contactPhone.trim();
        school.settings.phone = contactPhone.trim();
      }
      if (address) school.settings.address = address.trim();
      if (city) school.settings.city = city.trim();
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'TENANT',
      details: `Updated school tenant '${school.name}' (${school.id}). Status: ${school.status}, Plan: ${school.plan}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      data: school,
      message: `School '${school.name}' updated successfully.`
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to update school tenant.'
    });
  }
});

// ==========================================
// School-Level Endpoints (/api/schools)
// ==========================================

/**
 * GET /api/schools/my-schools
 * List all schools accessible to the current user
 */
schoolsRouter.get('/my-schools', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const accessibleSchools = getUserSchools(user.id);
    const userMemberships = getUserMemberships(user.id);

    const data = accessibleSchools.map((school) => {
      const membership = userMemberships.find((m) => m.schoolId === school.id);
      return {
        id: school.id,
        name: school.name,
        code: school.code,
        status: school.status,
        plan: school.plan,
        role: membership?.role || user.role,
        isDefault: membership?.isDefault || school.id === user.schoolId
      };
    });

    res.json({
      success: true,
      data,
      total: data.length
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve user schools.'
    });
  }
});

/**
 * GET /api/schools/current
 * Retrieve current authorized school tenant profile
 */
schoolsRouter.get('/current', requireAuth, requireTenant, (req: ExtendedTenantRequest, res: Response): void => {
  try {
    const tenant = req.tenant!;
    res.json({
      success: true,
      data: {
        school: tenant.school,
        membership: tenant.membership,
        role: tenant.role,
        isPlatformAdmin: tenant.isPlatformAdmin
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve current school context.'
    });
  }
});

/**
 * POST /api/schools/switch-context
 * Switch active tenant context for the authenticated user
 */
schoolsRouter.post('/switch-context', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { schoolId } = req.body;
    if (!schoolId) {
      res.status(400).json({
        success: false,
        error: 'School ID is required.',
        code: 'MISSING_FIELD'
      });
      return;
    }

    const user = req.user!;
    if (!verifySchoolAccess(user, schoolId)) {
      res.status(403).json({
        success: false,
        error: `Forbidden. You do not belong to school '${schoolId}'.`,
        code: 'FORBIDDEN_TENANT_ACCESS'
      });
      return;
    }

    const school = database.schools.find((s) => s.id === schoolId);
    if (!school) {
      res.status(404).json({
        success: false,
        error: `School '${schoolId}' not found.`,
        code: 'SCHOOL_NOT_FOUND'
      });
      return;
    }

    // Update in memory user state
    const storedUser = database.users.find((u) => u.id === user.id);
    if (storedUser) {
      storedUser.schoolId = schoolId;
    }
    user.schoolId = schoolId;

    if (req.session) {
      req.session.schoolContext = {
        id: school.id,
        name: school.name,
        code: school.code,
        plan: school.plan,
        status: school.status
      };
      req.session.user.schoolId = schoolId;
    }

    res.json({
      success: true,
      data: {
        schoolId,
        school,
        session: req.session
      },
      message: `Active school switched to ${school.name}`
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to switch school context.'
    });
  }
});
