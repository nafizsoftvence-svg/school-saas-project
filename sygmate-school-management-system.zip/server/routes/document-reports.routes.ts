/**
 * Part 15F — Document & Certificate Reports, Analytics & Compliance Routes
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, AuthenticatedRequest } from '../security/auth.js';
import { DocumentReportService } from '../services/document-report.service.js';
import { logAudit } from '../security/audit.js';

export const documentReportsRouter = Router();

/**
 * 1. GET /api/documents/reports/analytics
 * Operational dashboard analytics with current-state vs period metrics
 */
documentReportsRouter.get(
  '/analytics',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { preset, startDate, endDate } = req.query as Record<string, string>;

      const data = DocumentReportService.getDocumentAnalytics(
        schoolId,
        (preset as any) || 'LAST_30_DAYS',
        startDate,
        endDate,
        req.user!
      );

      res.json({ success: true, data });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch document analytics.'
      });
    }
  }
);

/**
 * 2. GET /api/documents/reports/compliance
 * Comprehensive entity-level document compliance report
 */
documentReportsRouter.get(
  '/compliance',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const {
        entityType,
        academicSessionId,
        classId,
        department,
        complianceStatus,
        search,
        page,
        limit,
        sortBy,
        sortOrder
      } = req.query as Record<string, string>;

      const result = DocumentReportService.getDocumentComplianceReport(
        schoolId,
        {
          entityType: entityType as any,
          academicSessionId,
          classId,
          department,
          complianceStatus: complianceStatus as any,
          search,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25,
          sortBy: sortBy as any,
          sortOrder: (sortOrder as any) || 'asc'
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        summary: result.summary,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch document compliance report.'
      });
    }
  }
);

/**
 * 3. GET /api/documents/reports/expiry
 * Document expiry, renewal horizons & critical urgency tracking
 */
documentReportsRouter.get(
  '/expiry',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const {
        entityType,
        urgency,
        search,
        horizonDays,
        page,
        limit,
        sortBy,
        sortOrder
      } = req.query as Record<string, string>;

      const result = DocumentReportService.getDocumentExpiryReport(
        schoolId,
        {
          entityType,
          urgency,
          search,
          horizonDays: horizonDays ? parseInt(horizonDays, 10) : 90,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25,
          sortBy,
          sortOrder: (sortOrder as any) || 'asc'
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        summary: result.summary,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch document expiry report.'
      });
    }
  }
);

/**
 * 4. GET /api/documents/reports/certificate-analytics
 * Certificate dashboard analytics & period trend metrics
 */
documentReportsRouter.get(
  '/certificate-analytics',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { preset, startDate, endDate } = req.query as Record<string, string>;

      const data = DocumentReportService.getCertificateAnalytics(
        schoolId,
        (preset as any) || 'LAST_30_DAYS',
        startDate,
        endDate,
        req.user!
      );

      res.json({ success: true, data });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch certificate analytics.'
      });
    }
  }
);

/**
 * 5. GET /api/documents/reports/certificate-lifecycle
 * Lifecycle funnel & measured stage durations
 */
documentReportsRouter.get(
  '/certificate-lifecycle',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const data = DocumentReportService.getCertificateLifecycleAnalytics(schoolId, req.user!);
      res.json({ success: true, data });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch certificate lifecycle analytics.'
      });
    }
  }
);

/**
 * 6. GET /api/documents/reports/certificate-issuance
 * Detailed certificate issuance log with verification & approval audit
 */
documentReportsRouter.get(
  '/certificate-issuance',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const {
        search,
        certificateTypeId,
        status,
        verificationStatus,
        approvalStatus,
        academicSessionId,
        page,
        limit,
        sortBy,
        sortOrder
      } = req.query as Record<string, string>;

      const result = DocumentReportService.getCertificateIssuanceReport(
        schoolId,
        {
          search,
          certificateTypeId,
          status,
          verificationStatus,
          approvalStatus,
          academicSessionId,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25,
          sortBy,
          sortOrder: (sortOrder as any) || 'desc'
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch certificate issuance report.'
      });
    }
  }
);

/**
 * 7. GET /api/documents/reports/certificate-workflow
 * Review pipeline tracking with rejection reasons & verifier/approver logs
 */
documentReportsRouter.get(
  '/certificate-workflow',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { status, search, page, limit } = req.query as Record<string, string>;

      const result = DocumentReportService.getCertificateWorkflowReport(
        schoolId,
        {
          status,
          search,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch certificate workflow report.'
      });
    }
  }
);

/**
 * 8. GET /api/documents/reports/digital-verification
 * Publicly verifiable certificates with privacy shielding
 */
documentReportsRouter.get(
  '/digital-verification',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { search, page, limit } = req.query as Record<string, string>;

      const result = DocumentReportService.getDigitalVerificationReport(
        schoolId,
        {
          search,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch digital verification report.'
      });
    }
  }
);

/**
 * 9. GET /api/documents/reports/audit-activity
 * Document & Certificate audit activity log
 */
documentReportsRouter.get(
  '/audit-activity',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { action, search, page, limit } = req.query as Record<string, string>;

      const result = DocumentReportService.getAuditActivityReport(
        schoolId,
        {
          action,
          search,
          page: page ? parseInt(page, 10) : 1,
          limit: limit ? parseInt(limit, 10) : 25
        },
        req.user!
      );

      res.json({
        success: true,
        data: result.items,
        pagination: result.pagination
      });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to fetch audit activity report.'
      });
    }
  }
);

/**
 * 10. POST /api/documents/reports/reconcile
 * Authoritative data reconciliation between dashboard aggregates and underlying collections
 */
documentReportsRouter.post(
  '/reconcile',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const result = DocumentReportService.reconcileData(schoolId, req.user!);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to reconcile document data.'
      });
    }
  }
);

/**
 * 11. GET /api/documents/reports/export/csv
 * Server-side RFC 4180 CSV export with RBAC & Audit logging
 */
documentReportsRouter.get(
  '/export/csv',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { reportType, ...filters } = req.query as Record<string, string>;

      if (!reportType) {
        res.status(400).json({ success: false, error: 'reportType query parameter is required.' });
        return;
      }

      const { fileName, csvContent } = DocumentReportService.exportToCSV(
        schoolId,
        reportType as any,
        filters,
        req.user!,
        req.ip
      );

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.status(200).send(csvContent);
    } catch (err: any) {
      res.status(err.message?.includes('Access denied') ? 403 : 500).json({
        success: false,
        error: err.message || 'Failed to export report.'
      });
    }
  }
);

/**
 * 12. POST /api/documents/reports/audit-view
 * Log sensitive report viewing
 */
documentReportsRouter.post(
  '/audit-view',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { reportName, details } = req.body as { reportName: string; details?: string };
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'REPORT_VIEWED' as any,
        entityType: 'REPORT',
        entityId: reportName,
        details: details || `Viewed administrative report: ${reportName}.`,
        ipAddress: req.ip || '127.0.0.1'
      });
      res.json({ success: true, message: 'Report viewing audited.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || 'Failed to audit view.' });
    }
  }
);
