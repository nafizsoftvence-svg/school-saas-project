import { Router, Response } from 'express';
import { database } from '../db/database.js';
import {
  AuthenticatedRequest,
  requireAuth,
  requireRole,
  requirePermission
} from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  FeeDiscountRule,
  CreateDiscountRulePayload,
  UpdateDiscountRulePayload,
  ApplyDiscountBatchPayload,
  ApplyDiscountBatchResponse,
  FeeWaiver,
  CreateWaiverPayload,
  ApproveWaiverPayload,
  RejectWaiverPayload,
  FeeScholarship,
  CreateScholarshipPayload,
  UpdateScholarshipPayload,
  FeeFineRule,
  CreateFineRulePayload,
  UpdateFineRulePayload,
  AppliedFineRecord,
  ApplyManualFinePayload,
  WaiveFinePayload,
  AssessLateFinesPayload,
  AssessLateFinesResponse,
  FeeAdjustmentAudit,
  FeeAdjustmentSummaryStats,
  StudentFeeRecord,
  FeePaymentStatus
} from '../../src/types/index.js';

export const feeAdjustmentsRouter = Router();

// Ensure user is authenticated for all fee adjustment actions
feeAdjustmentsRouter.use(requireAuth);

/**
 * Helper: Recalculate and normalize Student Fee Record
 * Order: Original - Discount - Scholarship - Waiver + Fine = Net Payable (min 0)
 */
function recalculateFeeRecord(record: StudentFeeRecord): StudentFeeRecord {
  const totalAmount = Math.max(0, Number(record.totalAmount) || 0);
  const discountAmount = Math.max(0, Number(record.discountAmount) || 0);
  const scholarshipAmount = Math.max(0, Number(record.scholarshipAmount) || 0);
  const waiverAmount = Math.max(0, Number(record.waiverAmount) || 0);
  const fineAmount = Math.max(0, Number(record.fineAmount) || 0);
  const paidAmount = Math.max(0, Number(record.paidAmount) || 0);

  const totalDeductions = discountAmount + scholarshipAmount + waiverAmount;
  const grossNet = totalAmount - totalDeductions + fineAmount;
  const netPayableAmount = Math.max(0, Math.round(grossNet * 100) / 100);
  const dueAmount = Math.max(0, Math.round((netPayableAmount - paidAmount) * 100) / 100);

  let status: FeePaymentStatus = record.status;
  if (record.status !== 'CANCELLED' && record.status !== 'DRAFT') {
    if (dueAmount === 0 && (paidAmount > 0 || netPayableAmount === 0)) {
      status = 'PAID';
    } else if (paidAmount > 0 && dueAmount > 0) {
      status = 'PARTIAL';
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const dueDate = new Date(record.dueDate);
      if (!isNaN(dueDate.getTime()) && dueDate < today && dueAmount > 0) {
        status = 'OVERDUE';
      } else {
        status = 'DUE';
      }
    }
  }

  return {
    ...record,
    totalAmount,
    discountAmount,
    scholarshipAmount,
    waiverAmount,
    fineAmount,
    netPayableAmount,
    paidAmount,
    dueAmount,
    status,
    updatedAt: new Date().toISOString()
  };
}

const getStudentFullName = (st: any): string => {
  if (!st) return 'Student';
  if (st.fullName) return st.fullName;
  const combined = `${st.firstName || ''} ${st.lastName || ''}`.trim();
  return combined || 'Student';
};

// ============================================================================
// 1. DISCOUNT MANAGEMENT ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/discounts
 * List all configurable discounts with optional filters
 */
feeAdjustmentsRouter.get('/discounts', (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      search,
      status,
      discountType,
      scope,
      academicSessionId,
      approvalStatus
    } = req.query;

    let list = [...(database.feeDiscounts || [])];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.code.toLowerCase().includes(q) ||
          (d.studentName && d.studentName.toLowerCase().includes(q)) ||
          (d.className && d.className.toLowerCase().includes(q)) ||
          (d.applicableFeeType && d.applicableFeeType.toLowerCase().includes(q))
      );
    }

    if (status && typeof status === 'string' && status !== 'ALL') {
      list = list.filter((d) => d.status === status);
    }

    if (discountType && typeof discountType === 'string' && discountType !== 'ALL') {
      list = list.filter((d) => d.discountType === discountType);
    }

    if (scope && typeof scope === 'string' && scope !== 'ALL') {
      list = list.filter((d) => d.scope === scope);
    }

    if (academicSessionId && typeof academicSessionId === 'string' && academicSessionId !== 'ALL') {
      list = list.filter((d) => d.academicSessionId === academicSessionId);
    }

    if (approvalStatus && typeof approvalStatus === 'string' && approvalStatus !== 'ALL') {
      list = list.filter((d) => d.approvalStatus === approvalStatus);
    }

    // Sort newest first
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      success: true,
      data: list,
      meta: {
        total: list.length
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch fee discounts',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/discounts/stats
 * Summary statistics for discount management
 */
feeAdjustmentsRouter.get('/discounts/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const list = database.feeDiscounts || [];
    const totalCount = list.length;
    const activeCount = list.filter((d) => d.status === 'ACTIVE').length;
    const pendingCount = list.filter((d) => d.approvalStatus === 'PENDING').length;
    const totalDiscountDisbursed = list.reduce((acc, d) => acc + (d.totalDiscountGiven || 0), 0);
    const totalApplications = list.reduce((acc, d) => acc + (d.appliedCount || 0), 0);

    res.json({
      success: true,
      data: {
        totalCount,
        activeCount,
        pendingCount,
        totalDiscountDisbursed,
        totalApplications
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate discount statistics',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/discounts/:id
 */
feeAdjustmentsRouter.get('/discounts/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const discount = (database.feeDiscounts || []).find((d) => d.id === id);
    if (!discount) {
      res.status(404).json({
        success: false,
        error: 'Fee discount rule not found',
        code: 'NOT_FOUND'
      });
      return;
    }

    // Find student fees where this discount is applied
    const appliedFees = (database.feeRecords || []).filter(
      (f) =>
        f.discountReason &&
        (f.discountReason.includes(discount.name) || f.discountReason.includes(discount.code))
    );

    res.json({
      success: true,
      data: {
        ...discount,
        appliedFees
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch discount',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/discounts
 * Create a new configurable fee discount rule
 */
feeAdjustmentsRouter.post(
  '/discounts',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as CreateDiscountRulePayload;
      const {
        name,
        discountType,
        value,
        scope,
        applicableFeeType,
        academicSessionId,
        startDate,
        endDate,
        studentId,
        classId,
        sectionId,
        description
      } = payload;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Discount name is required', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!discountType || !['FIXED', 'PERCENTAGE'].includes(discountType)) {
        res.status(400).json({ success: false, error: 'Discount type must be FIXED or PERCENTAGE', code: 'VALIDATION_ERROR' });
        return;
      }

      if (typeof value !== 'number' || value <= 0) {
        res.status(400).json({ success: false, error: 'Discount value must be a positive number', code: 'VALIDATION_ERROR' });
        return;
      }

      if (discountType === 'PERCENTAGE' && value > 100) {
        res.status(400).json({ success: false, error: 'Percentage discount cannot exceed 100%', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!academicSessionId) {
        res.status(400).json({ success: false, error: 'Academic session is required', code: 'VALIDATION_ERROR' });
        return;
      }

      const session = (database.academicSessions || []).find((s) => s.id === academicSessionId);
      const student = studentId ? (database.studentProfiles || []).find((st) => st.id === studentId) : undefined;
      const cls = classId ? (database.classes || []).find((c) => c.id === classId) : undefined;
      const sec = sectionId ? (database.sections || []).find((s) => s.id === sectionId) : undefined;

      const code = payload.code?.trim() || `DISC-${name.slice(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
      const now = new Date().toISOString();

      const isSuperAdmin = req.user?.role === 'SUPER_ADMIN';

      const newDiscount: FeeDiscountRule = {
        id: `disc-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
        code,
        name: name.trim(),
        discountType,
        value,
        scope: scope || 'ALL',
        studentId,
        studentName: student ? getStudentFullName(student) : undefined,
        admissionNumber: student?.admissionNumber,
        classId,
        className: cls?.name,
        sectionId,
        sectionName: sec?.name,
        applicableFeeType: applicableFeeType || 'ALL',
        academicSessionId,
        academicSessionName: session?.name || '2026-2027 Academic Year',
        startDate: startDate || new Date().toISOString().slice(0, 10),
        endDate: endDate || '2027-06-30',
        status: payload.status || 'ACTIVE',
        approvalStatus: isSuperAdmin ? 'APPROVED' : 'PENDING',
        description: description?.trim() || '',
        appliedCount: 0,
        totalDiscountGiven: 0,
        createdBy: req.user?.name || 'Authorized Admin',
        createdAt: now,
        updatedAt: now
      };

      if (!database.feeDiscounts) database.feeDiscounts = [];
      database.feeDiscounts.push(newDiscount);

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'DISCOUNT',
        action: 'CREATED',
        referenceId: newDiscount.id,
        referenceName: newDiscount.name,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Created discount rule "${newDiscount.name}" (${newDiscount.discountType === 'PERCENTAGE' ? newDiscount.value + '%' : '$' + newDiscount.value}) for scope: ${newDiscount.scope}.`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'FEE_DISCOUNT',
        details: `Created fee discount rule ${newDiscount.name} (${newDiscount.code})`
      });

      res.status(201).json({
        success: true,
        message: 'Discount rule created successfully',
        data: newDiscount
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create discount rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PUT /api/fees/discounts/:id
 */
feeAdjustmentsRouter.put(
  '/discounts/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeDiscounts || []).findIndex((d) => d.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Discount rule not found', code: 'NOT_FOUND' });
        return;
      }

      const existing = database.feeDiscounts[index];
      const payload = req.body as UpdateDiscountRulePayload;

      const updated: FeeDiscountRule = {
        ...existing,
        ...payload,
        name: payload.name?.trim() || existing.name,
        description: payload.description !== undefined ? payload.description.trim() : existing.description,
        updatedAt: new Date().toISOString()
      };

      database.feeDiscounts[index] = updated;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_DISCOUNT',
        details: `Updated discount rule ${updated.name} (${updated.code})`
      });

      res.json({
        success: true,
        message: 'Discount rule updated successfully',
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update discount rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/fees/discounts/:id/status
 */
feeAdjustmentsRouter.patch(
  '/discounts/:id/status',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const index = (database.feeDiscounts || []).findIndex((d) => d.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Discount rule not found', code: 'NOT_FOUND' });
        return;
      }

      if (!['ACTIVE', 'INACTIVE', 'EXPIRED'].includes(status)) {
        res.status(400).json({ success: false, error: 'Invalid status', code: 'VALIDATION_ERROR' });
        return;
      }

      database.feeDiscounts[index].status = status;
      database.feeDiscounts[index].updatedAt = new Date().toISOString();

      res.json({
        success: true,
        message: `Discount status updated to ${status}`,
        data: database.feeDiscounts[index]
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update discount status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/discounts/:id/approve
 */
feeAdjustmentsRouter.post(
  '/discounts/:id/approve',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeDiscounts || []).findIndex((d) => d.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Discount rule not found', code: 'NOT_FOUND' });
        return;
      }

      const disc = database.feeDiscounts[index];
      disc.approvalStatus = 'APPROVED';
      disc.status = 'ACTIVE';
      disc.updatedAt = new Date().toISOString();

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'DISCOUNT',
        action: 'APPROVED',
        referenceId: disc.id,
        referenceName: disc.name,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Approved discount rule "${disc.name}" (${disc.code}).`,
        timestamp: new Date().toISOString()
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Discount ${disc.name} has been approved`,
        data: disc
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to approve discount',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/discounts/:id/apply
 * Batch apply discount rule to matching student fees
 */
feeAdjustmentsRouter.post(
  '/discounts/:id/apply',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const payload = req.body as ApplyDiscountBatchPayload;
      const disc = (database.feeDiscounts || []).find((d) => d.id === id);
      if (!disc) {
        res.status(404).json({ success: false, error: 'Discount rule not found', code: 'NOT_FOUND' });
        return;
      }

      if (disc.status !== 'ACTIVE' || disc.approvalStatus === 'REJECTED') {
        res.status(400).json({ success: false, error: 'Only ACTIVE and approved discounts can be applied', code: 'INVALID_STATUS' });
        return;
      }

      let matchingFees = [...(database.feeRecords || [])].filter((f) => {
        if (f.status === 'CANCELLED' || f.status === 'PAID') return false;
        if (disc.academicSessionId && f.academicSessionId !== disc.academicSessionId) return false;
        if (disc.applicableFeeType !== 'ALL' && f.feeType !== disc.applicableFeeType) return false;

        if (disc.scope === 'STUDENT' && disc.studentId && f.studentId !== disc.studentId) return false;
        if (disc.scope === 'CLASS' && disc.classId && f.classId !== disc.classId) return false;
        if (disc.scope === 'SECTION' && disc.sectionId && f.sectionId !== disc.sectionId) return false;

        // Check if specific student fee IDs passed in payload
        if (payload.targetStudentFeeIds && payload.targetStudentFeeIds.length > 0) {
          if (!payload.targetStudentFeeIds.includes(f.id)) return false;
        }

        return true;
      });

      let updatedCount = 0;
      let totalAmountApplied = 0;

      matchingFees.forEach((fee) => {
        const feeIdx = database.feeRecords.findIndex((r) => r.id === fee.id);
        if (feeIdx !== -1) {
          let calculatedDiscount = 0;
          if (disc.discountType === 'PERCENTAGE') {
            calculatedDiscount = Math.round((fee.totalAmount * (disc.value / 100)) * 100) / 100;
          } else {
            calculatedDiscount = Math.min(fee.totalAmount, disc.value);
          }

          // Apply discount amount
          const oldDiscount = fee.discountAmount || 0;
          const newDiscount = Math.max(oldDiscount, calculatedDiscount);
          const difference = newDiscount - oldDiscount;

          if (difference > 0) {
            fee.discountAmount = newDiscount;
            fee.discountReason = fee.discountReason
              ? `${fee.discountReason}; ${disc.name} (${disc.code})`
              : `${disc.name} (${disc.code})`;

            const recalculated = recalculateFeeRecord(fee);
            database.feeRecords[feeIdx] = recalculated;

            updatedCount++;
            totalAmountApplied += difference;
          }
        }
      });

      disc.appliedCount = (disc.appliedCount || 0) + updatedCount;
      disc.totalDiscountGiven = (disc.totalDiscountGiven || 0) + totalAmountApplied;
      disc.updatedAt = new Date().toISOString();

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'DISCOUNT',
        action: 'APPLIED',
        referenceId: disc.id,
        referenceName: disc.name,
        newAmount: totalAmountApplied,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Batch-applied discount "${disc.name}" to ${updatedCount} fee record(s). Total discount: $${totalAmountApplied.toFixed(2)}.`,
        timestamp: new Date().toISOString()
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Successfully applied discount to ${updatedCount} invoice(s)`,
        data: {
          discountId: disc.id,
          updatedCount,
          totalAmountApplied,
          discount: disc
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to apply discount',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/discounts/:id
 */
feeAdjustmentsRouter.delete(
  '/discounts/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeDiscounts || []).findIndex((d) => d.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Discount rule not found', code: 'NOT_FOUND' });
        return;
      }

      const disc = database.feeDiscounts[index];
      database.feeDiscounts.splice(index, 1);

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'DISCOUNT',
        action: 'CANCELLED',
        referenceId: disc.id,
        referenceName: disc.name,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Deleted discount rule "${disc.name}".`,
        timestamp: new Date().toISOString()
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Discount rule ${disc.name} has been removed`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete discount rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// 2. WAIVER MANAGEMENT ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/waivers
 * List fee waivers with filtering
 */
feeAdjustmentsRouter.get('/waivers', (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      search,
      status,
      studentId,
      academicSessionId,
      waiverType
    } = req.query;

    let list = [...(database.feeWaivers || [])];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (w) =>
          w.studentName.toLowerCase().includes(q) ||
          w.admissionNumber.toLowerCase().includes(q) ||
          w.invoiceNumber.toLowerCase().includes(q) ||
          w.waiverNumber.toLowerCase().includes(q) ||
          w.reason.toLowerCase().includes(q)
      );
    }

    if (status && typeof status === 'string' && status !== 'ALL') {
      list = list.filter((w) => w.status === status);
    }

    if (studentId && typeof studentId === 'string' && studentId !== 'ALL') {
      list = list.filter((w) => w.studentId === studentId);
    }

    if (academicSessionId && typeof academicSessionId === 'string' && academicSessionId !== 'ALL') {
      list = list.filter((w) => w.academicSessionId === academicSessionId);
    }

    if (waiverType && typeof waiverType === 'string' && waiverType !== 'ALL') {
      list = list.filter((w) => w.waiverType === waiverType);
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      success: true,
      data: list,
      meta: {
        total: list.length
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch fee waivers',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/waivers/stats
 */
feeAdjustmentsRouter.get('/waivers/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const list = database.feeWaivers || [];
    const totalCount = list.length;
    const approvedCount = list.filter((w) => w.status === 'APPROVED').length;
    const pendingCount = list.filter((w) => w.status === 'PENDING').length;
    const rejectedCount = list.filter((w) => w.status === 'REJECTED').length;
    const totalWaivedAmount = list
      .filter((w) => w.status === 'APPROVED')
      .reduce((acc, w) => acc + (w.amount || 0), 0);

    res.json({
      success: true,
      data: {
        totalCount,
        approvedCount,
        pendingCount,
        rejectedCount,
        totalWaivedAmount
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate waiver statistics',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/waivers/:id
 */
feeAdjustmentsRouter.get('/waivers/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const waiver = (database.feeWaivers || []).find((w) => w.id === id);
    if (!waiver) {
      res.status(404).json({ success: false, error: 'Fee waiver not found', code: 'NOT_FOUND' });
      return;
    }
    const feeRecord = (database.feeRecords || []).find((r) => r.id === waiver.feeRecordId);
    res.json({
      success: true,
      data: {
        ...waiver,
        feeRecord
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch waiver details',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/waivers
 * Create or grant fee waiver request
 */
feeAdjustmentsRouter.post(
  '/waivers',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as CreateWaiverPayload;
      const {
        studentId,
        feeRecordId,
        waiverType,
        value,
        reason,
        notes,
        autoApprove
      } = payload;

      if (!studentId || !feeRecordId) {
        res.status(400).json({ success: false, error: 'Student and Fee Invoice are required', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!reason || !reason.trim()) {
        res.status(400).json({ success: false, error: 'Waiver justification reason is required', code: 'VALIDATION_ERROR' });
        return;
      }

      const feeRecord = (database.feeRecords || []).find((r) => r.id === feeRecordId && r.studentId === studentId);
      if (!feeRecord) {
        res.status(404).json({ success: false, error: 'Matching student fee invoice record not found', code: 'NOT_FOUND' });
        return;
      }

      const student = (database.studentProfiles || []).find((s) => s.id === studentId);

      // Compute waiver amount
      let calculatedAmount = 0;
      if (waiverType === 'FULL') {
        // Full waiver wipes out remaining net balance before waiver
        calculatedAmount = feeRecord.totalAmount - (feeRecord.discountAmount || 0) - (feeRecord.scholarshipAmount || 0);
      } else if (waiverType === 'PARTIAL_PERCENTAGE') {
        if (!value || value <= 0 || value > 100) {
          res.status(400).json({ success: false, error: 'Percentage waiver value must be between 1 and 100', code: 'VALIDATION_ERROR' });
          return;
        }
        calculatedAmount = Math.round((feeRecord.totalAmount * (value / 100)) * 100) / 100;
      } else {
        // PARTIAL_FIXED
        if (!value || value <= 0) {
          res.status(400).json({ success: false, error: 'Fixed waiver amount must be a positive number', code: 'VALIDATION_ERROR' });
          return;
        }
        calculatedAmount = Math.min(feeRecord.totalAmount, value);
      }

      calculatedAmount = Math.max(0, Math.round(calculatedAmount * 100) / 100);

      const isSuperAdmin = req.user?.role === 'SUPER_ADMIN';
      const shouldApprove = autoApprove && isSuperAdmin;
      const now = new Date().toISOString();

      const newWaiver: FeeWaiver = {
        id: `waiver-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        waiverNumber: `WV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        studentId: feeRecord.studentId,
        studentName: feeRecord.studentName,
        admissionNumber: feeRecord.admissionNumber,
        classId: feeRecord.classId,
        className: feeRecord.className,
        sectionName: feeRecord.sectionName,
        feeRecordId: feeRecord.id,
        invoiceNumber: feeRecord.invoiceNumber,
        feeTitle: feeRecord.title,
        feeType: feeRecord.feeType,
        academicSessionId: feeRecord.academicSessionId,
        academicSessionName: feeRecord.academicSessionName,
        waiverType,
        value: value || calculatedAmount,
        amount: calculatedAmount,
        originalFeeAmount: feeRecord.totalAmount,
        reason: reason.trim(),
        status: shouldApprove ? 'APPROVED' : 'PENDING',
        requestedById: req.user!.id,
        requestedByName: req.user!.name,
        approvedById: shouldApprove ? req.user!.id : undefined,
        approvedByName: shouldApprove ? req.user!.name : undefined,
        approvedAt: shouldApprove ? now : undefined,
        notes: notes?.trim(),
        createdAt: now,
        updatedAt: now
      };

      if (!database.feeWaivers) database.feeWaivers = [];
      database.feeWaivers.push(newWaiver);

      // If approved immediately, adjust fee record
      if (shouldApprove) {
        const feeIdx = database.feeRecords.findIndex((r) => r.id === feeRecord.id);
        if (feeIdx !== -1) {
          database.feeRecords[feeIdx].waiverAmount = calculatedAmount;
          database.feeRecords[feeIdx].waiverReason = reason.trim();
          database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
        }
      }

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'WAIVER',
        action: shouldApprove ? 'APPROVED' : 'CREATED',
        referenceId: newWaiver.id,
        referenceName: newWaiver.waiverNumber,
        feeRecordId: feeRecord.id,
        invoiceNumber: feeRecord.invoiceNumber,
        studentId: feeRecord.studentId,
        studentName: feeRecord.studentName,
        newAmount: calculatedAmount,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `${shouldApprove ? 'Granted and approved' : 'Submitted'} fee waiver (${newWaiver.waiverNumber}) of $${calculatedAmount.toFixed(2)} on invoice ${feeRecord.invoiceNumber} for ${feeRecord.studentName}. Reason: "${reason.trim()}".`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.status(201).json({
        success: true,
        message: shouldApprove
          ? `Waiver of $${calculatedAmount.toFixed(2)} granted and applied to invoice ${feeRecord.invoiceNumber}.`
          : `Waiver request ${newWaiver.waiverNumber} submitted for approval.`,
        data: newWaiver
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create fee waiver',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/waivers/:id/approve
 */
feeAdjustmentsRouter.post(
  '/waivers/:id/approve',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const payload = req.body as ApproveWaiverPayload;
      const index = (database.feeWaivers || []).findIndex((w) => w.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Waiver not found', code: 'NOT_FOUND' });
        return;
      }

      const waiver = database.feeWaivers[index];
      const now = new Date().toISOString();

      waiver.status = 'APPROVED';
      waiver.approvedById = req.user!.id;
      waiver.approvedByName = req.user!.name;
      waiver.approvedAt = now;
      if (payload.notes) waiver.notes = payload.notes.trim();
      waiver.updatedAt = now;

      // Apply to fee record
      const feeIdx = (database.feeRecords || []).findIndex((r) => r.id === waiver.feeRecordId);
      if (feeIdx !== -1) {
        database.feeRecords[feeIdx].waiverAmount = waiver.amount;
        database.feeRecords[feeIdx].waiverReason = waiver.reason;
        database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
      }

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'WAIVER',
        action: 'APPROVED',
        referenceId: waiver.id,
        referenceName: waiver.waiverNumber,
        feeRecordId: waiver.feeRecordId,
        invoiceNumber: waiver.invoiceNumber,
        studentId: waiver.studentId,
        studentName: waiver.studentName,
        newAmount: waiver.amount,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Approved fee waiver ${waiver.waiverNumber} ($${waiver.amount.toFixed(2)}) for invoice ${waiver.invoiceNumber} (${waiver.studentName}).`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Waiver ${waiver.waiverNumber} approved and applied to invoice balance.`,
        data: waiver
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to approve waiver',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/waivers/:id/reject
 */
feeAdjustmentsRouter.post(
  '/waivers/:id/reject',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { rejectionReason } = req.body as RejectWaiverPayload;

      if (!rejectionReason || !rejectionReason.trim()) {
        res.status(400).json({ success: false, error: 'Rejection reason is mandatory', code: 'VALIDATION_ERROR' });
        return;
      }

      const index = (database.feeWaivers || []).findIndex((w) => w.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Waiver not found', code: 'NOT_FOUND' });
        return;
      }

      const waiver = database.feeWaivers[index];
      const now = new Date().toISOString();

      waiver.status = 'REJECTED';
      waiver.rejectionReason = rejectionReason.trim();
      waiver.updatedAt = now;

      // If it was previously approved, remove waiver amount from fee
      const feeIdx = (database.feeRecords || []).findIndex((r) => r.id === waiver.feeRecordId);
      if (feeIdx !== -1 && database.feeRecords[feeIdx].waiverAmount === waiver.amount) {
        database.feeRecords[feeIdx].waiverAmount = 0;
        database.feeRecords[feeIdx].waiverReason = undefined;
        database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
      }

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'WAIVER',
        action: 'REJECTED',
        referenceId: waiver.id,
        referenceName: waiver.waiverNumber,
        feeRecordId: waiver.feeRecordId,
        invoiceNumber: waiver.invoiceNumber,
        studentId: waiver.studentId,
        studentName: waiver.studentName,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Rejected fee waiver ${waiver.waiverNumber} on invoice ${waiver.invoiceNumber}. Reason: "${rejectionReason.trim()}".`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Waiver ${waiver.waiverNumber} has been rejected.`,
        data: waiver
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to reject waiver',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/waivers/:id/cancel
 */
feeAdjustmentsRouter.post(
  '/waivers/:id/cancel',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeWaivers || []).findIndex((w) => w.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Waiver not found', code: 'NOT_FOUND' });
        return;
      }

      const waiver = database.feeWaivers[index];
      waiver.status = 'CANCELLED';
      waiver.updatedAt = new Date().toISOString();

      // Clear waiver from fee record
      const feeIdx = (database.feeRecords || []).findIndex((r) => r.id === waiver.feeRecordId);
      if (feeIdx !== -1) {
        database.feeRecords[feeIdx].waiverAmount = 0;
        database.feeRecords[feeIdx].waiverReason = undefined;
        database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
      }

      res.json({
        success: true,
        message: `Waiver ${waiver.waiverNumber} has been cancelled.`,
        data: waiver
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to cancel waiver',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// 3. SCHOLARSHIP MANAGEMENT ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/scholarships
 */
feeAdjustmentsRouter.get('/scholarships', (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      search,
      status,
      studentId,
      academicSessionId,
      scholarshipType
    } = req.query;

    let list = [...(database.feeScholarships || [])];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.studentName.toLowerCase().includes(q) ||
          s.admissionNumber.toLowerCase().includes(q) ||
          (s.applicableFeeType && s.applicableFeeType.toLowerCase().includes(q))
      );
    }

    if (status && typeof status === 'string' && status !== 'ALL') {
      list = list.filter((s) => s.status === status);
    }

    if (studentId && typeof studentId === 'string' && studentId !== 'ALL') {
      list = list.filter((s) => s.studentId === studentId);
    }

    if (academicSessionId && typeof academicSessionId === 'string' && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }

    if (scholarshipType && typeof scholarshipType === 'string' && scholarshipType !== 'ALL') {
      list = list.filter((s) => s.scholarshipType === scholarshipType);
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      success: true,
      data: list,
      meta: { total: list.length }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch scholarships',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/scholarships/stats
 */
feeAdjustmentsRouter.get('/scholarships/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const list = database.feeScholarships || [];
    const totalCount = list.length;
    const activeCount = list.filter((s) => s.status === 'ACTIVE').length;
    const totalDisbursed = list
      .filter((s) => s.status === 'ACTIVE')
      .reduce((acc, s) => acc + (s.totalDisbursed || s.amount || 0), 0);
    const uniqueRecipients = new Set(list.filter((s) => s.status === 'ACTIVE').map((s) => s.studentId)).size;

    res.json({
      success: true,
      data: {
        totalCount,
        activeCount,
        totalDisbursed,
        uniqueRecipients
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate scholarship stats',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/scholarships/:id
 */
feeAdjustmentsRouter.get('/scholarships/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const scholarship = (database.feeScholarships || []).find((s) => s.id === id);
    if (!scholarship) {
      res.status(404).json({ success: false, error: 'Scholarship record not found', code: 'NOT_FOUND' });
      return;
    }

    // Find student fee invoices linked
    const linkedFees = (database.feeRecords || []).filter((f) => f.studentId === scholarship.studentId);

    res.json({
      success: true,
      data: {
        ...scholarship,
        linkedFees
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch scholarship details',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/scholarships
 * Create a new student scholarship endowment
 */
feeAdjustmentsRouter.post(
  '/scholarships',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as CreateScholarshipPayload;
      const {
        name,
        studentId,
        scholarshipType,
        value,
        applicableFeeType,
        academicSessionId,
        startDate,
        endDate,
        notes
      } = payload;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Scholarship award name is required', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!studentId) {
        res.status(400).json({ success: false, error: 'Recipient student is required', code: 'VALIDATION_ERROR' });
        return;
      }

      const student = (database.studentProfiles || []).find((s) => s.id === studentId);
      if (!student) {
        res.status(404).json({ success: false, error: 'Student profile not found', code: 'NOT_FOUND' });
        return;
      }

      const session = (database.academicSessions || []).find((s) => s.id === academicSessionId);
      const code = payload.code?.trim() || `SCH-${name.slice(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
      const now = new Date().toISOString();

      let calculatedAmount = value || 0;
      if (scholarshipType === 'FULL_TUITION') {
        // Find matching tuition fee for estimated amount
        const tuitionFee = (database.feeRecords || []).find(
          (f) => f.studentId === studentId && f.feeType === 'Tuition Fee'
        );
        calculatedAmount = tuitionFee ? tuitionFee.totalAmount : 1000;
      }

      const studentFullName = getStudentFullName(student);

      const newScholarship: FeeScholarship = {
        id: `sch-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        code,
        name: name.trim(),
        studentId: student.id,
        studentName: studentFullName,
        admissionNumber: student.admissionNumber,
        classId: student.classId,
        className: (student as any).className || 'Class',
        academicSessionId: academicSessionId || 'session-2026-2027',
        academicSessionName: session?.name || '2026-2027 Academic Year',
        scholarshipType,
        value: scholarshipType === 'FULL_TUITION' ? 100 : value,
        amount: calculatedAmount,
        applicableFeeType: applicableFeeType || 'Tuition Fee',
        startDate: startDate || new Date().toISOString().slice(0, 10),
        endDate: endDate || '2027-06-30',
        status: payload.status || 'ACTIVE',
        approvedById: req.user!.id,
        approvedByName: req.user!.name,
        approvedAt: now,
        notes: notes?.trim(),
        appliedCount: 0,
        totalDisbursed: 0,
        createdAt: now,
        updatedAt: now
      };

      if (!database.feeScholarships) database.feeScholarships = [];
      database.feeScholarships.push(newScholarship);

      // Automatically apply deduction to matching student fee records if active
      if (newScholarship.status === 'ACTIVE') {
        const studentFees = (database.feeRecords || []).filter(
          (f) =>
            f.studentId === studentId &&
            f.status !== 'CANCELLED' &&
            (newScholarship.applicableFeeType === 'ALL' || f.feeType === newScholarship.applicableFeeType)
        );

        let disbursed = 0;
        let appliedCount = 0;

        studentFees.forEach((fee) => {
          const feeIdx = database.feeRecords.findIndex((r) => r.id === fee.id);
          if (feeIdx !== -1) {
            let feeScholarshipDeduction = 0;
            if (newScholarship.scholarshipType === 'PERCENTAGE' || newScholarship.scholarshipType === 'FULL_TUITION') {
              const pct = newScholarship.scholarshipType === 'FULL_TUITION' ? 100 : newScholarship.value;
              feeScholarshipDeduction = Math.round((fee.totalAmount * (pct / 100)) * 100) / 100;
            } else {
              feeScholarshipDeduction = Math.min(fee.totalAmount, newScholarship.value);
            }

            database.feeRecords[feeIdx].scholarshipAmount = feeScholarshipDeduction;
            database.feeRecords[feeIdx].scholarshipName = newScholarship.name;
            database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);

            disbursed += feeScholarshipDeduction;
            appliedCount++;
          }
        });

        newScholarship.appliedCount = appliedCount;
        newScholarship.totalDisbursed = disbursed;
      }

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'SCHOLARSHIP',
        action: 'CREATED',
        referenceId: newScholarship.id,
        referenceName: newScholarship.name,
        studentId: student.id,
        studentName: studentFullName,
        newAmount: newScholarship.amount,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Awarded scholarship "${newScholarship.name}" to ${studentFullName} (${student.admissionNumber}). Value: ${newScholarship.scholarshipType === 'PERCENTAGE' ? newScholarship.value + '%' : '$' + newScholarship.amount.toFixed(2)}.`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.status(201).json({
        success: true,
        message: `Scholarship "${newScholarship.name}" granted to ${studentFullName}.`,
        data: newScholarship
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create scholarship',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PUT /api/fees/scholarships/:id
 */
feeAdjustmentsRouter.put(
  '/scholarships/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeScholarships || []).findIndex((s) => s.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Scholarship not found', code: 'NOT_FOUND' });
        return;
      }

      const existing = database.feeScholarships[index];
      const payload = req.body as UpdateScholarshipPayload;

      const updated: FeeScholarship = {
        ...existing,
        ...payload,
        name: payload.name?.trim() || existing.name,
        notes: payload.notes !== undefined ? payload.notes.trim() : existing.notes,
        updatedAt: new Date().toISOString()
      };

      database.feeScholarships[index] = updated;

      res.json({
        success: true,
        message: 'Scholarship updated successfully',
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update scholarship',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/scholarships/:id/approve
 */
feeAdjustmentsRouter.post(
  '/scholarships/:id/approve',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeScholarships || []).findIndex((s) => s.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Scholarship not found', code: 'NOT_FOUND' });
        return;
      }

      const sch = database.feeScholarships[index];
      sch.status = 'ACTIVE';
      sch.approvedById = req.user!.id;
      sch.approvedByName = req.user!.name;
      sch.approvedAt = new Date().toISOString();
      sch.updatedAt = new Date().toISOString();

      // Recalculate student fee records
      const studentFees = (database.feeRecords || []).filter(
        (f) =>
          f.studentId === sch.studentId &&
          f.status !== 'CANCELLED' &&
          (sch.applicableFeeType === 'ALL' || f.feeType === sch.applicableFeeType)
      );

      let disbursed = 0;
      studentFees.forEach((fee) => {
        const feeIdx = database.feeRecords.findIndex((r) => r.id === fee.id);
        if (feeIdx !== -1) {
          let feeScholarshipDeduction = 0;
          if (sch.scholarshipType === 'PERCENTAGE' || sch.scholarshipType === 'FULL_TUITION') {
            const pct = sch.scholarshipType === 'FULL_TUITION' ? 100 : sch.value;
            feeScholarshipDeduction = Math.round((fee.totalAmount * (pct / 100)) * 100) / 100;
          } else {
            feeScholarshipDeduction = Math.min(fee.totalAmount, sch.value);
          }

          database.feeRecords[feeIdx].scholarshipAmount = feeScholarshipDeduction;
          database.feeRecords[feeIdx].scholarshipName = sch.name;
          database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
          disbursed += feeScholarshipDeduction;
        }
      });

      sch.totalDisbursed = disbursed;

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'SCHOLARSHIP',
        action: 'APPROVED',
        referenceId: sch.id,
        referenceName: sch.name,
        studentId: sch.studentId,
        studentName: sch.studentName,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Approved scholarship "${sch.name}" for ${sch.studentName}. Total active offset: $${disbursed.toFixed(2)}.`,
        timestamp: new Date().toISOString()
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Scholarship ${sch.name} approved and applied to active student fees.`,
        data: sch
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to approve scholarship',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/scholarships/:id
 */
feeAdjustmentsRouter.delete(
  '/scholarships/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeScholarships || []).findIndex((s) => s.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Scholarship not found', code: 'NOT_FOUND' });
        return;
      }

      const sch = database.feeScholarships[index];
      database.feeScholarships.splice(index, 1);

      // Remove scholarship amount from student fees
      const studentFees = (database.feeRecords || []).filter((f) => f.studentId === sch.studentId);
      studentFees.forEach((fee) => {
        const feeIdx = database.feeRecords.findIndex((r) => r.id === fee.id);
        if (feeIdx !== -1 && database.feeRecords[feeIdx].scholarshipName === sch.name) {
          database.feeRecords[feeIdx].scholarshipAmount = 0;
          database.feeRecords[feeIdx].scholarshipName = undefined;
          database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
        }
      });

      res.json({
        success: true,
        message: `Scholarship ${sch.name} removed and invoice balances recalculated.`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete scholarship',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// 4. FINE MANAGEMENT & LATE ASSESSMENT POLICY ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/fines/rules
 * List all configurable fine rules
 */
feeAdjustmentsRouter.get('/fines/rules', (req: AuthenticatedRequest, res: Response) => {
  try {
    const list = database.feeFineRules || [];
    res.json({
      success: true,
      data: list,
      meta: { total: list.length }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch fine rules',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/fines/rules/:id
 */
feeAdjustmentsRouter.get('/fines/rules/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const rule = (database.feeFineRules || []).find((r) => r.id === id);
    if (!rule) {
      res.status(404).json({ success: false, error: 'Fine rule not found', code: 'NOT_FOUND' });
      return;
    }
    res.json({ success: true, data: rule });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch fine rule',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/fines/rules
 * Create a new late fine assessment policy
 */
feeAdjustmentsRouter.post(
  '/fines/rules',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as CreateFineRulePayload;
      const {
        name,
        fineType,
        amount,
        gracePeriodDays,
        maxFineAmount,
        applicableFeeType,
        academicSessionId,
        startDate,
        endDate,
        autoApply,
        description
      } = payload;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Fine rule name is required', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!fineType || !['FIXED', 'PERCENTAGE', 'DAILY_FIXED'].includes(fineType)) {
        res.status(400).json({ success: false, error: 'Fine type must be FIXED, PERCENTAGE, or DAILY_FIXED', code: 'VALIDATION_ERROR' });
        return;
      }

      if (typeof amount !== 'number' || amount <= 0) {
        res.status(400).json({ success: false, error: 'Fine amount must be a positive number', code: 'VALIDATION_ERROR' });
        return;
      }

      const session = (database.academicSessions || []).find((s) => s.id === academicSessionId);
      const code = payload.code?.trim() || `FINE-${name.slice(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
      const now = new Date().toISOString();

      const newRule: FeeFineRule = {
        id: `fine-rule-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        code,
        name: name.trim(),
        fineType,
        amount,
        gracePeriodDays: typeof gracePeriodDays === 'number' ? Math.max(0, gracePeriodDays) : 7,
        maxFineAmount: typeof maxFineAmount === 'number' ? maxFineAmount : undefined,
        applicableFeeType: applicableFeeType || 'ALL',
        academicSessionId: academicSessionId || 'session-2026-2027',
        academicSessionName: session?.name || '2026-2027 Academic Year',
        startDate: startDate || new Date().toISOString().slice(0, 10),
        endDate,
        status: payload.status || 'ACTIVE',
        description: description?.trim() || '',
        autoApply: autoApply !== undefined ? autoApply : true,
        appliedCount: 0,
        totalFinesAssessed: 0,
        createdAt: now,
        updatedAt: now
      };

      if (!database.feeFineRules) database.feeFineRules = [];
      database.feeFineRules.push(newRule);

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'FINE',
        action: 'CREATED',
        referenceId: newRule.id,
        referenceName: newRule.name,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Created fine rule "${newRule.name}" (${newRule.fineType}: ${newRule.amount}, Grace: ${newRule.gracePeriodDays} days).`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.status(201).json({
        success: true,
        message: 'Fine policy rule created successfully',
        data: newRule
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create fine rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PUT /api/fees/fines/rules/:id
 */
feeAdjustmentsRouter.put(
  '/fines/rules/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeFineRules || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Fine rule not found', code: 'NOT_FOUND' });
        return;
      }

      const existing = database.feeFineRules[index];
      const payload = req.body as UpdateFineRulePayload;

      const updated: FeeFineRule = {
        ...existing,
        ...payload,
        name: payload.name?.trim() || existing.name,
        description: payload.description !== undefined ? payload.description.trim() : existing.description,
        updatedAt: new Date().toISOString()
      };

      database.feeFineRules[index] = updated;

      res.json({
        success: true,
        message: 'Fine policy rule updated',
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fine rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/fees/fines/rules/:id/status
 */
feeAdjustmentsRouter.patch(
  '/fines/rules/:id/status',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const index = (database.feeFineRules || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Fine rule not found', code: 'NOT_FOUND' });
        return;
      }

      if (!['ACTIVE', 'INACTIVE'].includes(status)) {
        res.status(400).json({ success: false, error: 'Status must be ACTIVE or INACTIVE', code: 'VALIDATION_ERROR' });
        return;
      }

      database.feeFineRules[index].status = status;
      database.feeFineRules[index].updatedAt = new Date().toISOString();

      res.json({
        success: true,
        message: `Fine policy status set to ${status}`,
        data: database.feeFineRules[index]
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fine rule status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/fines/rules/:id
 */
feeAdjustmentsRouter.delete(
  '/fines/rules/:id',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeFineRules || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Fine rule not found', code: 'NOT_FOUND' });
        return;
      }

      const rule = database.feeFineRules[index];
      database.feeFineRules.splice(index, 1);

      res.json({
        success: true,
        message: `Fine rule ${rule.name} removed successfully.`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete fine rule',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/fines/applied
 * List all levied fines across invoices
 */
feeAdjustmentsRouter.get('/fines/applied', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { search, status, studentId, feeRecordId } = req.query;

    let list = [...(database.feeAppliedFines || [])];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (f) =>
          f.studentName.toLowerCase().includes(q) ||
          f.admissionNumber.toLowerCase().includes(q) ||
          f.invoiceNumber.toLowerCase().includes(q) ||
          f.fineRuleName.toLowerCase().includes(q) ||
          (f.reason && f.reason.toLowerCase().includes(q))
      );
    }

    if (status && typeof status === 'string' && status !== 'ALL') {
      list = list.filter((f) => f.status === status);
    }

    if (studentId && typeof studentId === 'string') {
      list = list.filter((f) => f.studentId === studentId);
    }

    if (feeRecordId && typeof feeRecordId === 'string') {
      list = list.filter((f) => f.feeRecordId === feeRecordId);
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      success: true,
      data: list,
      meta: { total: list.length }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch applied fines',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/fines/assess-overdue
 * Automated late fine assessment runner
 * Evaluates all overdue invoices against active late fine rules
 */
feeAdjustmentsRouter.post(
  '/fines/assess-overdue',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as AssessLateFinesPayload;
      const { academicSessionId, fineRuleId, dryRun } = payload;

      const activeRules = (database.feeFineRules || []).filter(
        (r) => r.status === 'ACTIVE' && (fineRuleId ? r.id === fineRuleId : true)
      );

      if (activeRules.length === 0) {
        res.status(400).json({
          success: false,
          error: 'No active fine policies found to assess',
          code: 'NO_RULES'
        });
        return;
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const feeRecords = (database.feeRecords || []).filter((f) => {
        if (f.status === 'CANCELLED' || f.status === 'PAID') return false;
        if (academicSessionId && f.academicSessionId !== academicSessionId) return false;
        if (f.dueAmount <= 0) return false;

        const dueDate = new Date(f.dueDate);
        if (isNaN(dueDate.getTime())) return false;

        return dueDate < today;
      });

      const assessedList: AppliedFineRecord[] = [];
      let totalFinesAssessed = 0;
      let recordsUpdatedCount = 0;

      feeRecords.forEach((fee) => {
        const dueDate = new Date(fee.dueDate);
        const daysPastDue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

        // Find applicable fine rule
        const rule = activeRules.find((r) => {
          if (r.academicSessionId && r.academicSessionId !== fee.academicSessionId) return false;
          if (r.applicableFeeType !== 'ALL' && r.applicableFeeType !== fee.feeType) return false;
          // Must exceed grace period
          if (daysPastDue < r.gracePeriodDays) return false;
          return true;
        });

        if (!rule) return;

        // Check if fine from this rule is already applied to this invoice
        const alreadyApplied = (database.feeAppliedFines || []).some(
          (af) => af.feeRecordId === fee.id && af.fineRuleId === rule.id && af.status === 'APPLIED'
        );

        if (alreadyApplied) return;

        let fineAmount = 0;
        if (rule.fineType === 'PERCENTAGE') {
          fineAmount = Math.round((fee.dueAmount * (rule.amount / 100)) * 100) / 100;
        } else if (rule.fineType === 'DAILY_FIXED') {
          const chargeableDays = daysPastDue - rule.gracePeriodDays;
          fineAmount = chargeableDays * rule.amount;
        } else {
          fineAmount = rule.amount;
        }

        if (rule.maxFineAmount && fineAmount > rule.maxFineAmount) {
          fineAmount = rule.maxFineAmount;
        }

        if (fineAmount <= 0) return;

        const appliedFine: AppliedFineRecord = {
          id: `fine-app-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
          feeRecordId: fee.id,
          invoiceNumber: fee.invoiceNumber,
          studentId: fee.studentId,
          studentName: fee.studentName,
          admissionNumber: fee.admissionNumber,
          className: fee.className,
          fineRuleId: rule.id,
          fineRuleName: rule.name,
          fineType: rule.fineType,
          fineAmount,
          amount: fineAmount,
          calculatedDate: today.toISOString().slice(0, 10),
          dueDate: fee.dueDate,
          daysOverdue: daysPastDue,
          gracePeriodDays: rule.gracePeriodDays,
          reason: `Automatic late penalty assessed (${daysPastDue} days overdue, exceeded ${rule.gracePeriodDays} days grace)`,
          status: 'APPLIED',
          appliedById: req.user!.id,
          appliedByName: req.user!.name || 'Automated Assessment Engine',
          createdAt: new Date().toISOString()
        };

        assessedList.push(appliedFine);
        totalFinesAssessed += fineAmount;

        if (!dryRun) {
          if (!database.feeAppliedFines) database.feeAppliedFines = [];
          database.feeAppliedFines.push(appliedFine);

          // Update fee record
          const feeIdx = database.feeRecords.findIndex((r) => r.id === fee.id);
          if (feeIdx !== -1) {
            database.feeRecords[feeIdx].fineAmount = (database.feeRecords[feeIdx].fineAmount || 0) + fineAmount;
            database.feeRecords[feeIdx].fineReason = database.feeRecords[feeIdx].fineReason
              ? `${database.feeRecords[feeIdx].fineReason}; ${rule.name}`
              : rule.name;
            database.feeRecords[feeIdx] = recalculateFeeRecord(database.feeRecords[feeIdx]);
            recordsUpdatedCount++;
          }

          rule.appliedCount = (rule.appliedCount || 0) + 1;
          rule.totalFinesAssessed = (rule.totalFinesAssessed || 0) + fineAmount;
        }
      });

      if (!dryRun && assessedList.length > 0) {
        // Audit Log
        const auditEntry: FeeAdjustmentAudit = {
          id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
          adjustmentType: 'FINE',
          action: 'APPLIED',
          referenceId: 'batch-assessment',
          referenceName: 'Automated Late Fine Assessment',
          newAmount: totalFinesAssessed,
          performedById: req.user!.id,
          performedByName: req.user!.name,
          performedByRole: req.user!.role,
          details: `Automated assessment levied ${assessedList.length} fine(s) totaling $${totalFinesAssessed.toFixed(2)} on overdue invoices.`,
          timestamp: new Date().toISOString()
        };
        if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
        database.feeAdjustmentAudits.unshift(auditEntry);
      }

      res.json({
        success: true,
        message: dryRun
          ? `Preview: ${assessedList.length} invoices eligible for late fines totaling $${totalFinesAssessed.toFixed(2)}`
          : `Successfully assessed ${assessedList.length} overdue fines totaling $${totalFinesAssessed.toFixed(2)}`,
        data: {
          assessedCount: assessedList.length,
          totalFinesAssessed,
          recordsUpdated: dryRun ? 0 : recordsUpdatedCount,
          finesList: assessedList,
          dryRun: !!dryRun
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to assess overdue late fines',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/fines/apply-manual
 * Apply a manual fine to a specific invoice
 */
feeAdjustmentsRouter.post(
  '/fines/apply-manual',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as ApplyManualFinePayload;
      const { feeRecordId, fineAmount, fineReason } = payload;

      if (!feeRecordId) {
        res.status(400).json({ success: false, error: 'Fee record ID is required', code: 'VALIDATION_ERROR' });
        return;
      }

      if (typeof fineAmount !== 'number' || fineAmount <= 0) {
        res.status(400).json({ success: false, error: 'Fine amount must be a positive number', code: 'VALIDATION_ERROR' });
        return;
      }

      if (!fineReason || !fineReason.trim()) {
        res.status(400).json({ success: false, error: 'Fine justification reason is required', code: 'VALIDATION_ERROR' });
        return;
      }

      const feeIndex = (database.feeRecords || []).findIndex((r) => r.id === feeRecordId);
      if (feeIndex === -1) {
        res.status(404).json({ success: false, error: 'Student fee invoice not found', code: 'NOT_FOUND' });
        return;
      }

      const fee = database.feeRecords[feeIndex];
      const now = new Date().toISOString();

      const newFineRecord: AppliedFineRecord = {
        id: `fine-app-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        feeRecordId: fee.id,
        invoiceNumber: fee.invoiceNumber,
        studentId: fee.studentId,
        studentName: fee.studentName,
        admissionNumber: fee.admissionNumber,
        className: fee.className,
        fineRuleName: 'Manual Administrative Fine',
        fineType: 'FIXED',
        fineAmount,
        amount: fineAmount,
        calculatedDate: now.slice(0, 10),
        dueDate: fee.dueDate,
        reason: fineReason.trim(),
        status: 'APPLIED',
        appliedById: req.user!.id,
        appliedByName: req.user!.name,
        createdAt: now
      };

      if (!database.feeAppliedFines) database.feeAppliedFines = [];
      database.feeAppliedFines.push(newFineRecord);

      // Update fee record
      fee.fineAmount = (fee.fineAmount || 0) + fineAmount;
      fee.fineReason = fee.fineReason ? `${fee.fineReason}; ${fineReason.trim()}` : fineReason.trim();
      database.feeRecords[feeIndex] = recalculateFeeRecord(fee);

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'FINE',
        action: 'APPLIED',
        referenceId: newFineRecord.id,
        referenceName: 'Manual Administrative Fine',
        feeRecordId: fee.id,
        invoiceNumber: fee.invoiceNumber,
        studentId: fee.studentId,
        studentName: fee.studentName,
        newAmount: fineAmount,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Assessed manual administrative fine of $${fineAmount.toFixed(2)} on invoice ${fee.invoiceNumber} for ${fee.studentName}. Reason: "${fineReason.trim()}".`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.status(201).json({
        success: true,
        message: `Fine of $${fineAmount.toFixed(2)} applied to invoice ${fee.invoiceNumber}.`,
        data: {
          fineRecord: newFineRecord,
          feeRecord: database.feeRecords[feeIndex]
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to apply manual fine',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/fines/:id/waive
 * Waive an applied fine with mandatory justification
 */
feeAdjustmentsRouter.post(
  '/fines/:id/waive',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const body = req.body as WaiveFinePayload;
      const waiverReason = body.waiverReason || body.waiveReason || body.reason;

      if (!waiverReason || !waiverReason.trim()) {
        res.status(400).json({ success: false, error: 'Reason for waiving fine is mandatory', code: 'VALIDATION_ERROR' });
        return;
      }

      const fineIndex = (database.feeAppliedFines || []).findIndex((f) => f.id === id);
      if (fineIndex === -1) {
        res.status(404).json({ success: false, error: 'Applied fine record not found', code: 'NOT_FOUND' });
        return;
      }

      const fine = database.feeAppliedFines[fineIndex];
      const now = new Date().toISOString();
      const fineVal = fine.amount ?? fine.fineAmount ?? 0;

      fine.status = 'WAIVED';
      fine.waivedById = req.user!.id;
      fine.waivedByName = req.user!.name;
      fine.waivedAt = now;
      fine.waiverReason = waiverReason.trim();
      fine.waiveReason = waiverReason.trim();

      // Deduct fine amount from fee record
      const feeIndex = (database.feeRecords || []).findIndex((r) => r.id === fine.feeRecordId);
      if (feeIndex !== -1) {
        const currentFee = database.feeRecords[feeIndex];
        currentFee.fineAmount = Math.max(0, (currentFee.fineAmount || 0) - fineVal);
        database.feeRecords[feeIndex] = recalculateFeeRecord(currentFee);
      }

      // Audit Log
      const auditEntry: FeeAdjustmentAudit = {
        id: `adj-audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        adjustmentType: 'FINE',
        action: 'WAIVED',
        referenceId: fine.id,
        referenceName: fine.fineRuleName || 'Late Fine',
        feeRecordId: fine.feeRecordId,
        invoiceNumber: fine.invoiceNumber,
        studentId: fine.studentId,
        studentName: fine.studentName,
        newAmount: 0,
        performedById: req.user!.id,
        performedByName: req.user!.name,
        performedByRole: req.user!.role,
        details: `Waived fine ($${fineVal.toFixed(2)}) on invoice ${fine.invoiceNumber} for ${fine.studentName}. Reason: "${waiverReason.trim()}".`,
        timestamp: now
      };
      if (!database.feeAdjustmentAudits) database.feeAdjustmentAudits = [];
      database.feeAdjustmentAudits.unshift(auditEntry);

      res.json({
        success: true,
        message: `Fine of $${fineVal.toFixed(2)} on invoice ${fine.invoiceNumber} has been waived.`,
        data: fine
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to waive fine',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// 5. CONSOLIDATED ADJUSTMENT STATS & AUDIT LOGS
// ============================================================================

/**
 * GET /api/fees/adjustments/stats
 * Consolidated overview of all fee adjustments
 */
feeAdjustmentsRouter.get('/adjustments/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const discounts = database.feeDiscounts || [];
    const waivers = database.feeWaivers || [];
    const scholarships = database.feeScholarships || [];
    const appliedFines = database.feeAppliedFines || [];
    const fineRules = database.feeFineRules || [];

    const totalDiscounts = discounts.reduce((acc, d) => acc + (d.totalDiscountGiven || 0), 0);
    const activeDiscountRules = discounts.filter((d) => d.status === 'ACTIVE').length;
    const totalDiscountApps = discounts.reduce((acc, d) => acc + (d.appliedCount || 0), 0);

    const totalWaiversApproved = waivers
      .filter((w) => w.status === 'APPROVED')
      .reduce((acc, w) => acc + (w.amount || 0), 0);
    const pendingWaiverRequests = waivers.filter((w) => w.status === 'PENDING').length;
    const rejectedWaivers = waivers.filter((w) => w.status === 'REJECTED').length;
    const approvedWaiversCount = waivers.filter((w) => w.status === 'APPROVED').length;

    const totalScholarshipsDisbursed = scholarships
      .filter((s) => s.status === 'ACTIVE')
      .reduce((acc, s) => acc + (s.totalDisbursed || s.amount || 0), 0);
    const activeScholarshipsCount = scholarships.filter((s) => s.status === 'ACTIVE').length;
    const uniqueRecipients = new Set(scholarships.filter((s) => s.status === 'ACTIVE').map((s) => s.studentId)).size;

    const totalFinesLevied = appliedFines
      .filter((f) => f.status === 'APPLIED')
      .reduce((acc, f) => acc + (f.amount || (f as any).fineAmount || 0), 0);
    const totalFinesWaived = appliedFines
      .filter((f) => f.status === 'WAIVED')
      .reduce((acc, f) => acc + (f.amount || (f as any).fineAmount || 0), 0);
    const activeFinesCount = appliedFines.filter((f) => f.status === 'APPLIED').length;
    const activeRulesCount = fineRules.filter((r) => r.status === 'ACTIVE').length;

    const stats: FeeAdjustmentSummaryStats = {
      discounts: {
        activeRulesCount: activeDiscountRules,
        totalDisbursed: totalDiscounts,
        totalApplications: totalDiscountApps
      },
      waivers: {
        approvedCount: approvedWaiversCount,
        pendingCount: pendingWaiverRequests,
        rejectedCount: rejectedWaivers,
        totalAmountWaived: totalWaiversApproved
      },
      scholarships: {
        activeCount: activeScholarshipsCount,
        totalDisbursed: totalScholarshipsDisbursed,
        uniqueRecipients
      },
      fines: {
        activeRulesCount: activeRulesCount,
        activeFinesCount,
        totalFinesAssessed: totalFinesLevied,
        totalFinesWaived
      },
      totalActiveDiscounts: activeDiscountRules,
      totalDiscountAmountGiven: totalDiscounts,
      totalActiveScholarships: activeScholarshipsCount,
      totalScholarshipsDisbursed,
      totalPendingWaivers: pendingWaiverRequests,
      totalApprovedWaiversCount: approvedWaiversCount,
      totalWaiverAmountGranted: totalWaiversApproved,
      totalActiveFineRules: activeRulesCount,
      totalFinesAssessedAmount: totalFinesLevied,
      totalFinesWaivedAmount: totalFinesWaived,
      pendingApprovalsCount: pendingWaiverRequests
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate adjustments overview',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/adjustments/history
 * Comprehensive audit trail of all adjustments
 */
feeAdjustmentsRouter.get('/adjustments/history', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { search, adjustmentType, action, studentId } = req.query;

    let list = [...(database.feeAdjustmentAudits || [])];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (a) =>
          a.details.toLowerCase().includes(q) ||
          a.referenceName.toLowerCase().includes(q) ||
          a.performedByName.toLowerCase().includes(q) ||
          (a.studentName && a.studentName.toLowerCase().includes(q)) ||
          (a.invoiceNumber && a.invoiceNumber.toLowerCase().includes(q))
      );
    }

    if (adjustmentType && typeof adjustmentType === 'string' && adjustmentType !== 'ALL') {
      list = list.filter((a) => a.adjustmentType === adjustmentType);
    }

    if (action && typeof action === 'string' && action !== 'ALL') {
      list = list.filter((a) => a.action === action);
    }

    if (studentId && typeof studentId === 'string') {
      list = list.filter((a) => a.studentId === studentId);
    }

    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    res.json({
      success: true,
      data: list,
      meta: { total: list.length }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch adjustments audit trail',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/student-fees/:id/recalculate
 * Recalculates and persists proper fee totals
 */
feeAdjustmentsRouter.post(
  '/student-fees/:id/recalculate',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const index = (database.feeRecords || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({ success: false, error: 'Fee record not found', code: 'NOT_FOUND' });
        return;
      }

      const recalculated = recalculateFeeRecord(database.feeRecords[index]);
      database.feeRecords[index] = recalculated;

      res.json({
        success: true,
        message: `Invoice ${recalculated.invoiceNumber} recalculated. Net payable: $${recalculated.netPayableAmount}, Remaining Due: $${recalculated.dueAmount}.`,
        data: recalculated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to recalculate fee invoice',
        code: 'SERVER_ERROR'
      });
    }
  }
);
