import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import { AcademicSession, SchoolClass, Section, Subject, Department } from '../../src/types/index.js';

export const academicRouter = Router();

// ==========================================
// 1. ACADEMIC SESSIONS MANAGEMENT
// ==========================================

// Get Academic Sessions with enriched metadata
academicRouter.get('/sessions', requireAuth, requirePermission('academic_sessions.view'), (req: AuthenticatedRequest, res: Response): void => {
  const currentSettingsSessionId = database.schoolSettings.academicSessionId;
  const enriched = database.academicSessions.map((session) => {
    const isCurrent = session.isActive || session.id === currentSettingsSessionId;
    const studentCount = database.studentProfiles.filter((s) => s.academicSessionId === session.id).length;
    return {
      ...session,
      isCurrent,
      studentCount
    };
  });

  // Sort active first, then latest start date
  enriched.sort((a, b) => {
    if (a.isActive && !b.isActive) return -1;
    if (!a.isActive && b.isActive) return 1;
    return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
  });

  res.json({
    success: true,
    data: enriched
  });
});

// Create Academic Session
academicRouter.post('/sessions', requireAuth, requirePermission('academic_sessions.create'), (req: AuthenticatedRequest, res: Response): void => {
  const { sessionName, startDate, endDate, terms, description, isActive } = req.body;

  if (!sessionName || !sessionName.trim()) {
    res.status(400).json({ success: false, error: 'Academic session name is required.' });
    return;
  }

  if (!startDate || !endDate) {
    res.status(400).json({ success: false, error: 'Start date and End date are required.' });
    return;
  }

  if (new Date(startDate) >= new Date(endDate)) {
    res.status(400).json({ success: false, error: 'Start date must be strictly before End date.' });
    return;
  }

  // Check duplicate session name
  const existingName = database.academicSessions.find(
    (s) => s.sessionName.toLowerCase().trim() === sessionName.toLowerCase().trim()
  );
  if (existingName) {
    res.status(400).json({ success: false, error: `An academic session named '${sessionName}' already exists.` });
    return;
  }

  const newId = `session-${Date.now()}`;
  const willBeActive = Boolean(isActive);

  if (willBeActive) {
    // Deactivate all others
    database.academicSessions.forEach((s) => {
      s.isActive = false;
      if (s.status === 'active') s.status = 'completed';
    });
    database.schoolSettings.academicSessionId = newId;
  }

  const cleanTerms = Array.isArray(terms) && terms.length > 0
    ? terms.filter((t: any) => typeof t === 'string' && t.trim().length > 0)
    : ['Term 1 / Fall', 'Term 2 / Spring'];

  const now = new Date().toISOString();
  const newSession: AcademicSession = {
    id: newId,
    sessionName: sessionName.trim(),
    startDate,
    endDate,
    isActive: willBeActive,
    status: willBeActive ? 'active' : 'upcoming',
    isArchived: false,
    description: description?.trim() || '',
    terms: cleanTerms,
    createdAt: now,
    updatedAt: now
  };

  database.academicSessions.push(newSession);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'ACADEMIC_SESSION_CREATE',
    entity: 'AcademicSession',
    entityType: 'AcademicSession',
    entityId: newId,
    details: `Created academic session '${newSession.sessionName}' (${newSession.startDate} to ${newSession.endDate})${willBeActive ? ' as active session' : ''}`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { session: newSession }
  });

  res.status(201).json({
    success: true,
    data: newSession,
    message: 'Academic session created successfully.'
  });
});

// Update Academic Session
academicRouter.put('/sessions/:id', requireAuth, requirePermission('academic_sessions.edit'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const session = database.academicSessions.find((s) => s.id === id);

  if (!session) {
    res.status(404).json({ success: false, error: 'Academic session not found.' });
    return;
  }

  const { sessionName, startDate, endDate, terms, description, status, isActive } = req.body;

  if (sessionName && sessionName.trim()) {
    const existingName = database.academicSessions.find(
      (s) => s.id !== id && s.sessionName.toLowerCase().trim() === sessionName.toLowerCase().trim()
    );
    if (existingName) {
      res.status(400).json({ success: false, error: `An academic session named '${sessionName}' already exists.` });
      return;
    }
    session.sessionName = sessionName.trim();
  }

  if (startDate) session.startDate = startDate;
  if (endDate) session.endDate = endDate;

  if (new Date(session.startDate) >= new Date(session.endDate)) {
    res.status(400).json({ success: false, error: 'Start date must be strictly before End date.' });
    return;
  }

  if (Array.isArray(terms)) {
    session.terms = terms.filter((t: any) => typeof t === 'string' && t.trim().length > 0);
  }

  if (description !== undefined) {
    session.description = description.trim();
  }

  if (status !== undefined) {
    session.status = status;
  }

  if (isActive === true) {
    database.academicSessions.forEach((s) => {
      s.isActive = false;
      if (s.status === 'active' && s.id !== id) s.status = 'completed';
    });
    session.isActive = true;
    session.status = 'active';
    session.isArchived = false;
    database.schoolSettings.academicSessionId = session.id;
  }

  session.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'ACADEMIC_SESSION_UPDATE',
    entity: 'AcademicSession',
    entityType: 'AcademicSession',
    entityId: session.id,
    details: `Updated academic session '${session.sessionName}'`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { session }
  });

  res.json({
    success: true,
    data: session,
    message: 'Academic session updated successfully.'
  });
});

// Activate Academic Session
academicRouter.post('/sessions/:id/activate', requireAuth, requirePermission('academic_sessions.activate'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const session = database.academicSessions.find((s) => s.id === id);

  if (!session) {
    res.status(404).json({ success: false, error: 'Academic session not found.' });
    return;
  }

  database.academicSessions.forEach((s) => {
    s.isActive = false;
    if (s.status === 'active' && s.id !== id) {
      s.status = 'completed';
    }
  });

  session.isActive = true;
  session.status = 'active';
  session.isArchived = false;
  session.updatedAt = new Date().toISOString();
  database.schoolSettings.academicSessionId = session.id;

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'ACADEMIC_SESSION_ACTIVATE',
    entity: 'AcademicSession',
    entityType: 'AcademicSession',
    entityId: session.id,
    details: `Activated academic session '${session.sessionName}' as primary school session`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: session,
    message: `Academic session '${session.sessionName}' is now active.`
  });
});

// Archive/Unarchive Academic Session
academicRouter.post('/sessions/:id/archive', requireAuth, requirePermission('academic_sessions.archive'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const session = database.academicSessions.find((s) => s.id === id);

  if (!session) {
    res.status(404).json({ success: false, error: 'Academic session not found.' });
    return;
  }

  if (session.isActive) {
    res.status(400).json({
      success: false,
      error: 'Cannot archive the currently active academic session. Please activate another session first.'
    });
    return;
  }

  session.isArchived = !session.isArchived;
  session.status = session.isArchived ? 'archived' : 'completed';
  session.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: session.isArchived ? 'ACADEMIC_SESSION_ARCHIVE' : 'ACADEMIC_SESSION_UNARCHIVE',
    entity: 'AcademicSession',
    entityType: 'AcademicSession',
    entityId: session.id,
    details: `${session.isArchived ? 'Archived' : 'Restored'} academic session '${session.sessionName}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: session,
    message: `Academic session ${session.isArchived ? 'archived' : 'restored'} successfully.`
  });
});

// Delete Academic Session with safe dependency checks
academicRouter.delete('/sessions/:id', requireAuth, requirePermission('academic_sessions.delete'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const index = database.academicSessions.findIndex((s) => s.id === id);

  if (index === -1) {
    res.status(404).json({ success: false, error: 'Academic session not found.' });
    return;
  }

  const session = database.academicSessions[index];

  if (session.isActive) {
    res.status(400).json({
      success: false,
      error: 'Cannot delete the active academic session. Activate another session first.'
    });
    return;
  }

  // Check student references
  const enrolledStudents = database.studentProfiles.filter((s) => s.academicSessionId === id);
  if (enrolledStudents.length > 0) {
    res.status(400).json({
      success: false,
      error: `Cannot delete session: ${enrolledStudents.length} student profile(s) are linked to this academic session.`
    });
    return;
  }

  database.academicSessions.splice(index, 1);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'ACADEMIC_SESSION_DELETE',
    entity: 'AcademicSession',
    entityType: 'AcademicSession',
    entityId: id,
    details: `Deleted academic session '${session.sessionName}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    message: `Academic session '${session.sessionName}' deleted successfully.`
  });
});

// ==========================================
// 2. CLASSES MANAGEMENT
// ==========================================

// Get Classes with sections, student count, subject count
academicRouter.get('/classes', requireAuth, requirePermission('classes.view'), (req: AuthenticatedRequest, res: Response): void => {
  const enriched = database.classes.map((cls) => {
    const classSections = database.sections
      .filter((s) => s.classId === cls.id)
      .map((sec) => {
        const studentCount = database.studentProfiles.filter((st) => st.sectionId === sec.id).length;
        let classTeacherName = undefined;
        if (sec.classTeacherId) {
          const tp = database.teacherProfiles.find((t) => t.id === sec.classTeacherId);
          if (tp) {
            const u = database.users.find((user) => user.id === tp.userId);
            if (u) classTeacherName = u.name;
          }
        }
        return {
          ...sec,
          studentCount,
          availableCapacity: Math.max(0, sec.capacity - studentCount),
          classTeacherName
        };
      });

    const totalStudents = database.studentProfiles.filter((s) => s.classId === cls.id).length;
    const assignedSubjects = database.subjects.filter(
      (subj) => (subj.classIds && subj.classIds.includes(cls.id)) || subj.classId === cls.id
    );

    return {
      ...cls,
      displayOrder: cls.displayOrder ?? 0,
      status: cls.status || 'active',
      sections: classSections,
      studentCount: totalStudents,
      subjectCount: assignedSubjects.length
    };
  });

  // Sort by displayOrder ascending, then numericGrade
  enriched.sort((a, b) => (a.displayOrder ?? 0) - (b.displayOrder ?? 0) || (a.numericGrade ?? 0) - (b.numericGrade ?? 0));

  res.json({
    success: true,
    data: enriched
  });
});

// Create Class
academicRouter.post('/classes', requireAuth, requirePermission('classes.create'), (req: AuthenticatedRequest, res: Response): void => {
  const { name, code, numericGrade, displayOrder, description } = req.body;

  if (!name || !name.trim()) {
    res.status(400).json({ success: false, error: 'Class name is required (e.g., Grade 9).' });
    return;
  }

  if (!code || !code.trim()) {
    res.status(400).json({ success: false, error: 'Class code is required (e.g., G09).' });
    return;
  }

  const cleanCode = code.trim().toUpperCase();
  const existingCode = database.classes.find((c) => c.code.toUpperCase() === cleanCode);
  if (existingCode) {
    res.status(400).json({ success: false, error: `A class with code '${cleanCode}' already exists.` });
    return;
  }

  const newId = `class-${cleanCode.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now()}`;
  const now = new Date().toISOString();
  const defaultOrder = database.classes.length > 0
    ? Math.max(...database.classes.map((c) => c.displayOrder ?? 0)) + 1
    : 1;

  const newClass: SchoolClass = {
    id: newId,
    name: name.trim(),
    code: cleanCode,
    numericGrade: numericGrade !== undefined && numericGrade !== '' ? Number(numericGrade) : undefined,
    displayOrder: displayOrder !== undefined && displayOrder !== '' ? Number(displayOrder) : defaultOrder,
    sectionIds: [],
    description: description?.trim() || '',
    status: 'active',
    createdAt: now,
    updatedAt: now
  };

  database.classes.push(newClass);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'CLASS_CREATE',
    entity: 'SchoolClass',
    entityType: 'SchoolClass',
    entityId: newId,
    details: `Created class '${newClass.name}' (Code: ${newClass.code})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { class: newClass }
  });

  res.status(201).json({
    success: true,
    data: newClass,
    message: `Class '${newClass.name}' created successfully.`
  });
});

// Update Class
academicRouter.put('/classes/:id', requireAuth, requirePermission('classes.edit'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const cls = database.classes.find((c) => c.id === id);

  if (!cls) {
    res.status(404).json({ success: false, error: 'Class not found.' });
    return;
  }

  const { name, code, numericGrade, displayOrder, description, status } = req.body;

  if (code && code.trim()) {
    const cleanCode = code.trim().toUpperCase();
    const existing = database.classes.find((c) => c.id !== id && c.code.toUpperCase() === cleanCode);
    if (existing) {
      res.status(400).json({ success: false, error: `A class with code '${cleanCode}' already exists.` });
      return;
    }
    cls.code = cleanCode;
  }

  if (name && name.trim()) cls.name = name.trim();
  if (numericGrade !== undefined) cls.numericGrade = numericGrade !== '' ? Number(numericGrade) : undefined;
  if (displayOrder !== undefined) cls.displayOrder = Number(displayOrder);
  if (description !== undefined) cls.description = description.trim();
  if (status !== undefined) cls.status = status;

  cls.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'CLASS_UPDATE',
    entity: 'SchoolClass',
    entityType: 'SchoolClass',
    entityId: cls.id,
    details: `Updated class '${cls.name}' (Code: ${cls.code})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { class: cls }
  });

  res.json({
    success: true,
    data: cls,
    message: `Class '${cls.name}' updated successfully.`
  });
});

// Archive/Restore Class
academicRouter.post('/classes/:id/archive', requireAuth, requirePermission('classes.archive'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const cls = database.classes.find((c) => c.id === id);

  if (!cls) {
    res.status(404).json({ success: false, error: 'Class not found.' });
    return;
  }

  cls.status = cls.status === 'archived' ? 'active' : 'archived';
  cls.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: cls.status === 'archived' ? 'CLASS_ARCHIVE' : 'CLASS_RESTORE',
    entity: 'SchoolClass',
    entityType: 'SchoolClass',
    entityId: cls.id,
    details: `${cls.status === 'archived' ? 'Archived' : 'Restored'} class '${cls.name}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: cls,
    message: `Class '${cls.name}' is now ${cls.status}.`
  });
});

// Delete Class (with safe dependency checks)
academicRouter.delete('/classes/:id', requireAuth, requirePermission('classes.delete'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const index = database.classes.findIndex((c) => c.id === id);

  if (index === -1) {
    res.status(404).json({ success: false, error: 'Class not found.' });
    return;
  }

  const cls = database.classes[index];

  // Dependency checks
  const existingSections = database.sections.filter((s) => s.classId === id);
  if (existingSections.length > 0) {
    res.status(400).json({
      success: false,
      error: `Cannot delete class: ${existingSections.length} active section(s) exist within this class. Please remove or reassign the sections first.`
    });
    return;
  }

  const enrolledStudents = database.studentProfiles.filter((s) => s.classId === id);
  if (enrolledStudents.length > 0) {
    res.status(400).json({
      success: false,
      error: `Cannot delete class: ${enrolledStudents.length} student(s) are currently enrolled in this class.`
    });
    return;
  }

  database.classes.splice(index, 1);

  // Clean up references from subjects
  database.subjects.forEach((subj) => {
    if (subj.classIds) {
      subj.classIds = subj.classIds.filter((cid) => cid !== id);
    }
  });

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'CLASS_DELETE',
    entity: 'SchoolClass',
    entityType: 'SchoolClass',
    entityId: id,
    details: `Deleted class '${cls.name}' (Code: ${cls.code})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    message: `Class '${cls.name}' deleted successfully.`
  });
});

// ==========================================
// 3. SECTIONS MANAGEMENT
// ==========================================

// Get Sections with class details & capacity math
academicRouter.get('/sections', requireAuth, requirePermission('sections.view'), (req: AuthenticatedRequest, res: Response): void => {
  const enriched = database.sections.map((sec) => {
    const cls = database.classes.find((c) => c.id === sec.classId);
    const studentCount = database.studentProfiles.filter((st) => st.sectionId === sec.id).length;
    let classTeacherName = undefined;
    if (sec.classTeacherId) {
      const tp = database.teacherProfiles.find((t) => t.id === sec.classTeacherId);
      if (tp) {
        const u = database.users.find((user) => user.id === tp.userId);
        if (u) classTeacherName = u.name;
      }
    }

    return {
      ...sec,
      className: cls?.name || 'Unassigned Class',
      classCode: cls?.code || '',
      studentCount,
      availableCapacity: Math.max(0, sec.capacity - studentCount),
      classTeacherName,
      status: sec.status || 'active'
    };
  });

  res.json({
    success: true,
    data: enriched
  });
});

// Create Section
academicRouter.post('/sections', requireAuth, requirePermission('sections.create'), (req: AuthenticatedRequest, res: Response): void => {
  const { name, code, classId, roomNumber, capacity, classTeacherId, description } = req.body;

  if (!name || !name.trim()) {
    res.status(400).json({ success: false, error: 'Section name is required (e.g., Section A).' });
    return;
  }

  if (!classId) {
    res.status(400).json({ success: false, error: 'A parent Class is required for the section.' });
    return;
  }

  const cls = database.classes.find((c) => c.id === classId);
  if (!cls) {
    res.status(404).json({ success: false, error: 'Selected parent class does not exist.' });
    return;
  }

  // Duplicate name check within same class
  const existingSectionInClass = database.sections.find(
    (s) => s.classId === classId && s.name.toLowerCase().trim() === name.toLowerCase().trim()
  );
  if (existingSectionInClass) {
    res.status(400).json({
      success: false,
      error: `A section named '${name}' already exists in ${cls.name}.`
    });
    return;
  }

  const numCapacity = capacity ? Number(capacity) : 30;
  if (isNaN(numCapacity) || numCapacity < 1 || numCapacity > 200) {
    res.status(400).json({ success: false, error: 'Capacity must be a positive number between 1 and 200.' });
    return;
  }

  const newId = `sec-${cls.code.toLowerCase()}-${Date.now()}`;
  const autoCode = code?.trim() || `SEC-${cls.code}-${name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 4).toUpperCase()}`;
  const now = new Date().toISOString();

  const newSection: Section = {
    id: newId,
    name: name.trim(),
    code: autoCode,
    classId,
    roomNumber: roomNumber?.trim() || '',
    capacity: numCapacity,
    classTeacherId: classTeacherId || undefined,
    description: description?.trim() || '',
    status: 'active',
    createdAt: now,
    updatedAt: now
  };

  database.sections.push(newSection);

  // Link to class sectionIds
  if (!cls.sectionIds) cls.sectionIds = [];
  if (!cls.sectionIds.includes(newId)) {
    cls.sectionIds.push(newId);
  }

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SECTION_CREATE',
    entity: 'Section',
    entityType: 'Section',
    entityId: newId,
    details: `Created section '${newSection.name}' in class '${cls.name}' (Room: ${newSection.roomNumber || 'N/A'}, Capacity: ${newSection.capacity})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { section: newSection }
  });

  res.status(201).json({
    success: true,
    data: newSection,
    message: `Section '${newSection.name}' created successfully.`
  });
});

// Update Section
academicRouter.put('/sections/:id', requireAuth, requirePermission('sections.edit'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const sec = database.sections.find((s) => s.id === id);

  if (!sec) {
    res.status(404).json({ success: false, error: 'Section not found.' });
    return;
  }

  const { name, code, classId, roomNumber, capacity, classTeacherId, description, status } = req.body;

  const targetClassId = classId || sec.classId;
  const targetClass = database.classes.find((c) => c.id === targetClassId);
  if (!targetClass) {
    res.status(404).json({ success: false, error: 'Target parent class not found.' });
    return;
  }

  if (name && name.trim()) {
    const existing = database.sections.find(
      (s) => s.id !== id && s.classId === targetClassId && s.name.toLowerCase().trim() === name.toLowerCase().trim()
    );
    if (existing) {
      res.status(400).json({ success: false, error: `A section named '${name}' already exists in ${targetClass.name}.` });
      return;
    }
    sec.name = name.trim();
  }

  if (classId && classId !== sec.classId) {
    // Remove from old class
    const oldClass = database.classes.find((c) => c.id === sec.classId);
    if (oldClass && oldClass.sectionIds) {
      oldClass.sectionIds = oldClass.sectionIds.filter((sid) => sid !== id);
    }
    // Add to new class
    if (!targetClass.sectionIds) targetClass.sectionIds = [];
    if (!targetClass.sectionIds.includes(id)) targetClass.sectionIds.push(id);
    sec.classId = classId;
  }

  if (code !== undefined) sec.code = code.trim();
  if (roomNumber !== undefined) sec.roomNumber = roomNumber.trim();
  if (capacity !== undefined) {
    const numCap = Number(capacity);
    if (isNaN(numCap) || numCap < 1) {
      res.status(400).json({ success: false, error: 'Capacity must be at least 1.' });
      return;
    }
    sec.capacity = numCap;
  }
  if (classTeacherId !== undefined) sec.classTeacherId = classTeacherId || undefined;
  if (description !== undefined) sec.description = description.trim();
  if (status !== undefined) sec.status = status;

  sec.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SECTION_UPDATE',
    entity: 'Section',
    entityType: 'Section',
    entityId: sec.id,
    details: `Updated section '${sec.name}' in class '${targetClass.name}'`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { section: sec }
  });

  res.json({
    success: true,
    data: sec,
    message: `Section '${sec.name}' updated successfully.`
  });
});

// Archive/Restore Section
academicRouter.post('/sections/:id/archive', requireAuth, requirePermission('sections.archive'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const sec = database.sections.find((s) => s.id === id);

  if (!sec) {
    res.status(404).json({ success: false, error: 'Section not found.' });
    return;
  }

  sec.status = sec.status === 'archived' ? 'active' : 'archived';
  sec.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: sec.status === 'archived' ? 'SECTION_ARCHIVE' : 'SECTION_RESTORE',
    entity: 'Section',
    entityType: 'Section',
    entityId: sec.id,
    details: `${sec.status === 'archived' ? 'Archived' : 'Restored'} section '${sec.name}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: sec,
    message: `Section '${sec.name}' is now ${sec.status}.`
  });
});

// Delete Section (with safe dependency check)
academicRouter.delete('/sections/:id', requireAuth, requirePermission('sections.delete'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const index = database.sections.findIndex((s) => s.id === id);

  if (index === -1) {
    res.status(404).json({ success: false, error: 'Section not found.' });
    return;
  }

  const sec = database.sections[index];

  const enrolledStudents = database.studentProfiles.filter((s) => s.sectionId === id);
  if (enrolledStudents.length > 0) {
    res.status(400).json({
      success: false,
      error: `Cannot delete section: ${enrolledStudents.length} enrolled student(s) belong to this section. Reassign students first.`
    });
    return;
  }

  database.sections.splice(index, 1);

  // Remove from class sectionIds
  const parentClass = database.classes.find((c) => c.id === sec.classId);
  if (parentClass && parentClass.sectionIds) {
    parentClass.sectionIds = parentClass.sectionIds.filter((sid) => sid !== id);
  }

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SECTION_DELETE',
    entity: 'Section',
    entityType: 'Section',
    entityId: id,
    details: `Deleted section '${sec.name}' from class '${parentClass?.name || 'N/A'}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    message: `Section '${sec.name}' deleted successfully.`
  });
});

// ==========================================
// 4. SUBJECTS & CURRICULUM MANAGEMENT
// ==========================================

// Get Subjects enriched with class and department info
academicRouter.get('/subjects', requireAuth, requirePermission('subjects.view'), (req: AuthenticatedRequest, res: Response): void => {
  const enriched = database.subjects.map((sub) => {
    // Normalize classIds
    const classIds = sub.classIds && Array.isArray(sub.classIds)
      ? sub.classIds
      : sub.classId ? [sub.classId] : [];

    const assignedClasses = classIds
      .map((cid) => database.classes.find((c) => c.id === cid))
      .filter(Boolean)
      .map((c) => ({ id: c!.id, name: c!.name, code: c!.code }));

    const dept = sub.departmentId ? database.departments?.find((d) => d.id === sub.departmentId) : undefined;

    let teacherName = undefined;
    if (sub.teacherId) {
      const tp = database.teacherProfiles.find((t) => t.id === sub.teacherId);
      if (tp) {
        const u = database.users.find((user) => user.id === tp.userId);
        if (u) teacherName = u.name;
      }
    }

    return {
      ...sub,
      classIds,
      assignedClasses,
      className: assignedClasses.length > 0 ? assignedClasses.map((ac) => ac.name).join(', ') : 'Unassigned',
      departmentName: dept?.name || 'General / Unassigned',
      teacherName,
      status: sub.status || 'active',
      displayOrder: sub.displayOrder ?? 0
    };
  });

  enriched.sort((a, b) => (a.displayOrder ?? 0) - (b.displayOrder ?? 0) || a.name.localeCompare(b.name));

  res.json({
    success: true,
    data: enriched
  });
});

// Create Subject
academicRouter.post('/subjects', requireAuth, requirePermission('subjects.create'), (req: AuthenticatedRequest, res: Response): void => {
  const { name, code, type, credits, departmentId, classIds, classId, teacherId, displayOrder, description } = req.body;

  if (!name || !name.trim()) {
    res.status(400).json({ success: false, error: 'Subject name is required.' });
    return;
  }

  if (!code || !code.trim()) {
    res.status(400).json({ success: false, error: 'Subject code is required (e.g., MTH-201).' });
    return;
  }

  const cleanCode = code.trim().toUpperCase();
  const existingCode = database.subjects.find((s) => s.code.toUpperCase() === cleanCode);
  if (existingCode) {
    res.status(400).json({ success: false, error: `A subject with code '${cleanCode}' already exists.` });
    return;
  }

  const numCredits = credits !== undefined && credits !== '' ? Number(credits) : 3;
  if (isNaN(numCredits) || numCredits < 0 || numCredits > 20) {
    res.status(400).json({ success: false, error: 'Credits must be a valid number between 0 and 20.' });
    return;
  }

  // Normalize classIds
  let finalClassIds: string[] = [];
  if (Array.isArray(classIds)) {
    finalClassIds = classIds;
  } else if (classId) {
    finalClassIds = [classId];
  }

  const newId = `subj-${cleanCode.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now()}`;
  const now = new Date().toISOString();

  const newSubject: Subject = {
    id: newId,
    name: name.trim(),
    code: cleanCode,
    type: type || 'core',
    credits: numCredits,
    classIds: finalClassIds,
    classId: finalClassIds[0] || undefined,
    departmentId: departmentId || undefined,
    teacherId: teacherId || undefined,
    displayOrder: displayOrder !== undefined && displayOrder !== '' ? Number(displayOrder) : database.subjects.length + 1,
    description: description?.trim() || '',
    status: 'active',
    createdAt: now,
    updatedAt: now
  };

  database.subjects.push(newSubject);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SUBJECT_CREATE',
    entity: 'Subject',
    entityType: 'Subject',
    entityId: newId,
    details: `Created subject '${newSubject.name}' (${newSubject.code}, Type: ${newSubject.type}, Credits: ${newSubject.credits})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { subject: newSubject }
  });

  res.status(201).json({
    success: true,
    data: newSubject,
    message: `Subject '${newSubject.name}' created successfully.`
  });
});

// Update Subject
academicRouter.put('/subjects/:id', requireAuth, requirePermission('subjects.edit'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const sub = database.subjects.find((s) => s.id === id);

  if (!sub) {
    res.status(404).json({ success: false, error: 'Subject not found.' });
    return;
  }

  const { name, code, type, credits, departmentId, classIds, classId, teacherId, displayOrder, description, status } = req.body;

  if (code && code.trim()) {
    const cleanCode = code.trim().toUpperCase();
    const existing = database.subjects.find((s) => s.id !== id && s.code.toUpperCase() === cleanCode);
    if (existing) {
      res.status(400).json({ success: false, error: `A subject with code '${cleanCode}' already exists.` });
      return;
    }
    sub.code = cleanCode;
  }

  if (name && name.trim()) sub.name = name.trim();
  if (type !== undefined) sub.type = type;
  if (credits !== undefined) sub.credits = Number(credits);
  if (departmentId !== undefined) sub.departmentId = departmentId || undefined;
  if (teacherId !== undefined) sub.teacherId = teacherId || undefined;
  if (displayOrder !== undefined) sub.displayOrder = Number(displayOrder);
  if (description !== undefined) sub.description = description.trim();
  if (status !== undefined) sub.status = status;

  if (Array.isArray(classIds)) {
    sub.classIds = classIds;
    sub.classId = classIds[0] || undefined;
  } else if (classId !== undefined) {
    sub.classId = classId;
    sub.classIds = classId ? [classId] : [];
  }

  sub.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SUBJECT_UPDATE',
    entity: 'Subject',
    entityType: 'Subject',
    entityId: sub.id,
    details: `Updated subject '${sub.name}' (${sub.code})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { subject: sub }
  });

  res.json({
    success: true,
    data: sub,
    message: `Subject '${sub.name}' updated successfully.`
  });
});

// Assign Classes to Subject (Subject ↔ Class Association)
academicRouter.post('/subjects/:id/assign-classes', requireAuth, requirePermission('subjects.assign'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const sub = database.subjects.find((s) => s.id === id);

  if (!sub) {
    res.status(404).json({ success: false, error: 'Subject not found.' });
    return;
  }

  const { classIds } = req.body;
  if (!Array.isArray(classIds)) {
    res.status(400).json({ success: false, error: 'classIds must be an array of class IDs.' });
    return;
  }

  // Validate all classes exist
  const validClassIds = classIds.filter((cid) => database.classes.some((c) => c.id === cid));

  sub.classIds = validClassIds;
  sub.classId = validClassIds[0] || undefined;
  sub.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SUBJECT_ASSIGN_CLASSES',
    entity: 'Subject',
    entityType: 'Subject',
    entityId: sub.id,
    details: `Assigned subject '${sub.name}' to ${validClassIds.length} class(es)`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { assignedClassIds: validClassIds }
  });

  res.json({
    success: true,
    data: sub,
    message: `Assigned classes to '${sub.name}' successfully.`
  });
});

// Archive/Restore Subject
academicRouter.post('/subjects/:id/archive', requireAuth, requirePermission('subjects.archive'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const sub = database.subjects.find((s) => s.id === id);

  if (!sub) {
    res.status(404).json({ success: false, error: 'Subject not found.' });
    return;
  }

  sub.status = sub.status === 'archived' ? 'active' : 'archived';
  sub.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: sub.status === 'archived' ? 'SUBJECT_ARCHIVE' : 'SUBJECT_RESTORE',
    entity: 'Subject',
    entityType: 'Subject',
    entityId: sub.id,
    details: `${sub.status === 'archived' ? 'Archived' : 'Restored'} subject '${sub.name}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: sub,
    message: `Subject '${sub.name}' is now ${sub.status}.`
  });
});

// Delete Subject
academicRouter.delete('/subjects/:id', requireAuth, requirePermission('subjects.delete'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const index = database.subjects.findIndex((s) => s.id === id);

  if (index === -1) {
    res.status(404).json({ success: false, error: 'Subject not found.' });
    return;
  }

  const sub = database.subjects[index];
  database.subjects.splice(index, 1);

  // Remove from teacher assignments
  database.teacherProfiles.forEach((tp) => {
    if (tp.assignedSubjectIds) {
      tp.assignedSubjectIds = tp.assignedSubjectIds.filter((sid) => sid !== id);
    }
  });

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'SUBJECT_DELETE',
    entity: 'Subject',
    entityType: 'Subject',
    entityId: id,
    details: `Deleted subject '${sub.name}' (${sub.code})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    message: `Subject '${sub.name}' deleted successfully.`
  });
});

// ==========================================
// 5. DEPARTMENTS MANAGEMENT
// ==========================================

// Get Departments enriched with faculty & subject counts
academicRouter.get('/departments', requireAuth, requirePermission('departments.view'), (req: AuthenticatedRequest, res: Response): void => {
  if (!database.departments) {
    database.departments = [];
  }

  const enriched = database.departments.map((dept) => {
    const teacherCount = database.teacherProfiles.filter(
      (tp) => tp.department?.toLowerCase().includes(dept.name.toLowerCase()) || tp.department?.toLowerCase().includes(dept.code.toLowerCase())
    ).length;

    const subjectCount = database.subjects.filter((s) => s.departmentId === dept.id).length;

    let headOfDepartmentName = undefined;
    if (dept.headOfDepartmentId) {
      const tp = database.teacherProfiles.find((t) => t.id === dept.headOfDepartmentId);
      if (tp) {
        const u = database.users.find((user) => user.id === tp.userId);
        if (u) headOfDepartmentName = u.name;
      }
    }

    return {
      ...dept,
      teacherCount,
      subjectCount,
      headOfDepartmentName,
      status: dept.status || 'active'
    };
  });

  enriched.sort((a, b) => a.name.localeCompare(b.name));

  res.json({
    success: true,
    data: enriched
  });
});

// Create Department
academicRouter.post('/departments', requireAuth, requirePermission('departments.create'), (req: AuthenticatedRequest, res: Response): void => {
  const { name, code, description, headOfDepartmentId } = req.body;

  if (!name || !name.trim()) {
    res.status(400).json({ success: false, error: 'Department name is required.' });
    return;
  }

  if (!code || !code.trim()) {
    res.status(400).json({ success: false, error: 'Department code is required (e.g., DEP-MTH).' });
    return;
  }

  const cleanCode = code.trim().toUpperCase();
  if (!database.departments) database.departments = [];

  const existingCode = database.departments.find((d) => d.code.toUpperCase() === cleanCode);
  if (existingCode) {
    res.status(400).json({ success: false, error: `A department with code '${cleanCode}' already exists.` });
    return;
  }

  const newId = `dept-${cleanCode.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now()}`;
  const now = new Date().toISOString();

  const newDept: Department = {
    id: newId,
    name: name.trim(),
    code: cleanCode,
    description: description?.trim() || '',
    headOfDepartmentId: headOfDepartmentId || undefined,
    status: 'active',
    createdAt: now,
    updatedAt: now
  };

  database.departments.push(newDept);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'DEPARTMENT_CREATE',
    entity: 'Department',
    entityType: 'Department',
    entityId: newId,
    details: `Created department '${newDept.name}' (${newDept.code})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { department: newDept }
  });

  res.status(201).json({
    success: true,
    data: newDept,
    message: `Department '${newDept.name}' created successfully.`
  });
});

// Update Department
academicRouter.put('/departments/:id', requireAuth, requirePermission('departments.edit'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  if (!database.departments) database.departments = [];
  const dept = database.departments.find((d) => d.id === id);

  if (!dept) {
    res.status(404).json({ success: false, error: 'Department not found.' });
    return;
  }

  const { name, code, description, headOfDepartmentId, status } = req.body;

  if (code && code.trim()) {
    const cleanCode = code.trim().toUpperCase();
    const existing = database.departments.find((d) => d.id !== id && d.code.toUpperCase() === cleanCode);
    if (existing) {
      res.status(400).json({ success: false, error: `A department with code '${cleanCode}' already exists.` });
      return;
    }
    dept.code = cleanCode;
  }

  if (name && name.trim()) dept.name = name.trim();
  if (description !== undefined) dept.description = description.trim();
  if (headOfDepartmentId !== undefined) dept.headOfDepartmentId = headOfDepartmentId || undefined;
  if (status !== undefined) dept.status = status;

  dept.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'DEPARTMENT_UPDATE',
    entity: 'Department',
    entityType: 'Department',
    entityId: dept.id,
    details: `Updated department '${dept.name}' (${dept.code})`,
    ipAddress: req.ip || '127.0.0.1',
    metadata: { department: dept }
  });

  res.json({
    success: true,
    data: dept,
    message: `Department '${dept.name}' updated successfully.`
  });
});

// Archive/Restore Department
academicRouter.post('/departments/:id/archive', requireAuth, requirePermission('departments.archive'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  if (!database.departments) database.departments = [];
  const dept = database.departments.find((d) => d.id === id);

  if (!dept) {
    res.status(404).json({ success: false, error: 'Department not found.' });
    return;
  }

  dept.status = dept.status === 'archived' ? 'active' : 'archived';
  dept.updatedAt = new Date().toISOString();

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: dept.status === 'archived' ? 'DEPARTMENT_ARCHIVE' : 'DEPARTMENT_RESTORE',
    entity: 'Department',
    entityType: 'Department',
    entityId: dept.id,
    details: `${dept.status === 'archived' ? 'Archived' : 'Restored'} department '${dept.name}'`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: dept,
    message: `Department '${dept.name}' is now ${dept.status}.`
  });
});

// Delete Department (with dependency checks)
academicRouter.delete('/departments/:id', requireAuth, requirePermission('departments.delete'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  if (!database.departments) database.departments = [];
  const index = database.departments.findIndex((d) => d.id === id);

  if (index === -1) {
    res.status(404).json({ success: false, error: 'Department not found.' });
    return;
  }

  const dept = database.departments[index];

  // Check subjects linked to this department
  const linkedSubjects = database.subjects.filter((s) => s.departmentId === id);
  if (linkedSubjects.length > 0) {
    res.status(400).json({
      success: false,
      error: `Cannot delete department: ${linkedSubjects.length} subject(s) are assigned to this department. Please reassign the subjects first.`
    });
    return;
  }

  database.departments.splice(index, 1);

  logAudit({
    userId: req.user!.id,
    userRole: req.user!.role,
    action: 'DEPARTMENT_DELETE',
    entity: 'Department',
    entityType: 'Department',
    entityId: id,
    details: `Deleted department '${dept.name}' (${dept.code})`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    message: `Department '${dept.name}' deleted successfully.`
  });
});

