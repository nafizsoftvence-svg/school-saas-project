import { Router, Response } from 'express';
import { database } from '../db/database.js';
import {
  AuthenticatedRequest,
  requireAuth,
  requireRole,
  requirePermission
} from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  StudentFeeRecord,
  FeePaymentStatus,
  FeeDueDashboardStats,
  FeeDueStudentItem,
  FeeDueFilterParams,
  FeeDueStudentListResponse,
  FeeDueAgingSummary,
  ClassWiseDueSummary,
  FeeTypeDueSummary,
  DueAgingBracket,
  FeeReminderLog,
  SendFeeReminderPayload,
  SendFeeReminderResponse,
  ReminderChannel,
  ReminderType
} from '../../src/types/index.js';

export const feeDueRouter = Router();

// Ensure user is authenticated
feeDueRouter.use(requireAuth);

/**
 * Helper: Normalize calculations on student fee records
 */
function normalizeRecord(record: StudentFeeRecord): StudentFeeRecord {
  const totalAmount = Math.max(0, Number(record.totalAmount) || 0);
  const discountAmount = Math.max(0, Number(record.discountAmount) || 0);
  const scholarshipAmount = Math.max(0, Number(record.scholarshipAmount) || 0);
  const waiverAmount = Math.max(0, Number(record.waiverAmount) || 0);
  const fineAmount = Math.max(0, Number(record.fineAmount) || 0);
  const paidAmount = Math.max(0, Number(record.paidAmount) || 0);

  const totalDeductions = discountAmount + scholarshipAmount + waiverAmount;
  const grossNet = totalAmount - totalDeductions + fineAmount;
  const netPayableAmount = Math.max(0, Math.round(grossNet * 100) / 100);
  const dueAmount = Math.max(0, Math.round((netPayableAmount - paidAmount) * 100) / 100);

  let status: FeePaymentStatus = record.status;
  if (record.status !== 'CANCELLED' && record.status !== 'DRAFT') {
    if (dueAmount === 0 && (paidAmount > 0 || netPayableAmount === 0)) {
      status = 'PAID';
    } else if (paidAmount > 0 && dueAmount > 0) {
      status = 'PARTIAL';
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const dueDate = new Date(record.dueDate);
      if (!isNaN(dueDate.getTime()) && dueDate < today && dueAmount > 0) {
        status = 'OVERDUE';
      } else {
        status = 'DUE';
      }
    }
  }

  return {
    ...record,
    totalAmount,
    discountAmount,
    scholarshipAmount,
    waiverAmount,
    fineAmount,
    netPayableAmount,
    paidAmount,
    dueAmount,
    status
  };
}

/**
 * Helper: Calculate days overdue and aging bracket
 */
function computeAgingDetails(dueDateStr: string, dueAmount: number) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const dueDate = new Date(dueDateStr);
  dueDate.setHours(0, 0, 0, 0);

  const diffTime = today.getTime() - dueDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  const daysOverdue = diffDays > 0 && dueAmount > 0 ? diffDays : 0;
  const isDueSoon = dueAmount > 0 && diffDays <= 0 && diffDays >= -7;

  let agingBracket: DueAgingBracket = 'NOT_DUE';
  if (dueAmount <= 0) {
    agingBracket = 'NOT_DUE';
  } else if (isDueSoon) {
    agingBracket = 'DUE_SOON';
  } else if (diffDays <= 0) {
    agingBracket = 'NOT_DUE';
  } else if (diffDays <= 15) {
    agingBracket = '1_15_DAYS';
  } else if (diffDays <= 30) {
    agingBracket = '16_30_DAYS';
  } else if (diffDays <= 60) {
    agingBracket = '31_60_DAYS';
  } else {
    agingBracket = '60_PLUS_DAYS';
  }

  return {
    daysOverdue,
    isDueSoon,
    agingBracket
  };
}

/**
 * Ensure database.feeReminderLogs exists
 */
function ensureReminderLogs() {
  if (!(database as any).feeReminderLogs) {
    (database as any).feeReminderLogs = [
      {
        id: 'rem-log-001',
        feeRecordId: 'fee-sof-004',
        invoiceNumber: 'INV-2026-S04',
        studentId: 'stud-prof-3',
        studentName: 'Sofia Rivera',
        admissionNumber: 'ADM-2026-0844',
        className: 'Grade 9',
        guardianId: 'guard-1',
        guardianName: 'Carlos Rivera',
        recipientContact: 'carlos.rivera@example.com',
        channel: 'IN_APP_NOTIFICATION',
        reminderType: 'OVERDUE_FIRST_NOTICE',
        title: 'Overdue Fee Notice: Library & Digital Periodicals (INV-2026-S04)',
        message: 'Dear Carlos Rivera, the fee invoice INV-2026-S04 for Sofia Rivera ($200.00) was due on Aug 10, 2026 and is currently overdue. Kindly settle via the portal.',
        dueAmountAtSend: 200,
        dueDate: '2026-08-10',
        daysOverdueAtSend: 21,
        sentAt: '2026-08-25T10:30:00.000Z',
        sentById: 'usr-admin-1',
        sentByName: 'System Administrator',
        sentByRole: 'SUPER_ADMIN',
        status: 'DELIVERED',
        notes: 'Automated overdue first demand notice sent to primary guardian'
      }
    ] as FeeReminderLog[];
  }
}

/**
 * GET /api/fees/due-management/stats
 * Complete Fee Due Dashboard statistics, totals, aging breakdown, class-wise and fee-type breakdowns
 */
feeDueRouter.get(
  '/due-management/stats',
  requirePermission('fees.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { academicSessionId, classId } = req.query as {
        academicSessionId?: string;
        classId?: string;
      };

      if (!database.feeRecords) {
        database.feeRecords = [];
      }

      // Recalculate dynamic statuses & balances on database records
      database.feeRecords = database.feeRecords.map(normalizeRecord);

      let records = database.feeRecords.filter((r) => r.status !== 'CANCELLED' && r.status !== 'DRAFT');

      if (academicSessionId && academicSessionId !== 'ALL') {
        records = records.filter((r) => r.academicSessionId === academicSessionId);
      }
      if (classId && classId !== 'ALL') {
        records = records.filter((r) => r.classId === classId);
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      let totalReceivable = 0;
      let totalCollected = 0;
      let totalDue = 0;
      let totalOverdue = 0;
      let paidInvoicesCount = 0;
      let partialInvoicesCount = 0;
      let overdueInvoicesCount = 0;
      let dueSoonInvoicesCount = 0;

      const studentsWithDue = new Set<string>();

      const agingBreakdown: FeeDueAgingSummary = {
        notDueYet: { count: 0, amount: 0 },
        dueSoon: { count: 0, amount: 0 },
        overdue1to15: { count: 0, amount: 0 },
        overdue16to30: { count: 0, amount: 0 },
        overdue31to60: { count: 0, amount: 0 },
        overdue60Plus: { count: 0, amount: 0 }
      };

      for (const rec of records) {
        totalReceivable += rec.netPayableAmount || 0;
        totalCollected += rec.paidAmount || 0;
        totalDue += rec.dueAmount || 0;

        if (rec.dueAmount === 0) {
          paidInvoicesCount++;
        } else {
          studentsWithDue.add(rec.studentId);
          if (rec.paidAmount > 0) {
            partialInvoicesCount++;
          }

          const dueDate = new Date(rec.dueDate);
          dueDate.setHours(0, 0, 0, 0);
          const diffDays = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

          if (diffDays > 0) {
            totalOverdue += rec.dueAmount;
            overdueInvoicesCount++;

            if (diffDays <= 15) {
              agingBreakdown.overdue1to15.count++;
              agingBreakdown.overdue1to15.amount += rec.dueAmount;
            } else if (diffDays <= 30) {
              agingBreakdown.overdue16to30.count++;
              agingBreakdown.overdue16to30.amount += rec.dueAmount;
            } else if (diffDays <= 60) {
              agingBreakdown.overdue31to60.count++;
              agingBreakdown.overdue31to60.amount += rec.dueAmount;
            } else {
              agingBreakdown.overdue60Plus.count++;
              agingBreakdown.overdue60Plus.amount += rec.dueAmount;
            }
          } else if (diffDays >= -7) {
            dueSoonInvoicesCount++;
            agingBreakdown.dueSoon.count++;
            agingBreakdown.dueSoon.amount += rec.dueAmount;
          } else {
            agingBreakdown.notDueYet.count++;
            agingBreakdown.notDueYet.amount += rec.dueAmount;
          }
        }
      }

      // Round aging amounts
      agingBreakdown.notDueYet.amount = Math.round(agingBreakdown.notDueYet.amount * 100) / 100;
      agingBreakdown.dueSoon.amount = Math.round(agingBreakdown.dueSoon.amount * 100) / 100;
      agingBreakdown.overdue1to15.amount = Math.round(agingBreakdown.overdue1to15.amount * 100) / 100;
      agingBreakdown.overdue16to30.amount = Math.round(agingBreakdown.overdue16to30.amount * 100) / 100;
      agingBreakdown.overdue31to60.amount = Math.round(agingBreakdown.overdue31to60.amount * 100) / 100;
      agingBreakdown.overdue60Plus.amount = Math.round(agingBreakdown.overdue60Plus.amount * 100) / 100;

      // Class-wise breakdown
      const classWiseMap = new Map<string, ClassWiseDueSummary>();
      const allClasses = database.classes || [];

      for (const cls of allClasses) {
        // Enrolled students in class
        const studentsInClass = (database.studentProfiles || []).filter((s) => s.classId === cls.id);
        const classRecords = records.filter((r) => r.classId === cls.id);

        let clsReceivable = 0;
        let clsCollected = 0;
        let clsDue = 0;
        let clsOverdue = 0;
        const clsStudentsWithDue = new Set<string>();

        for (const r of classRecords) {
          clsReceivable += r.netPayableAmount || 0;
          clsCollected += r.paidAmount || 0;
          clsDue += r.dueAmount || 0;

          if (r.dueAmount > 0) {
            clsStudentsWithDue.add(r.studentId);
            const dueDate = new Date(r.dueDate);
            dueDate.setHours(0, 0, 0, 0);
            if (dueDate < today) {
              clsOverdue += r.dueAmount;
            }
          }
        }

        const totalStudents = Math.max(studentsInClass.length, clsStudentsWithDue.size);
        const defaulterRate = totalStudents > 0 ? Math.round((clsStudentsWithDue.size / totalStudents) * 10000) / 100 : 0;
        const collectionRate = clsReceivable > 0 ? Math.round((clsCollected / clsReceivable) * 10000) / 100 : 0;

        classWiseMap.set(cls.id, {
          classId: cls.id,
          className: cls.name,
          totalStudents,
          totalStudentsWithDue: clsStudentsWithDue.size,
          totalReceivable: Math.round(clsReceivable * 100) / 100,
          totalCollected: Math.round(clsCollected * 100) / 100,
          totalDue: Math.round(clsDue * 100) / 100,
          totalOverdue: Math.round(clsOverdue * 100) / 100,
          defaulterRate,
          collectionRate
        });
      }

      // Fee Type breakdown
      const feeTypeMap = new Map<string, FeeTypeDueSummary>();
      for (const r of records) {
        const key = r.feeType || 'General Fee';
        const existing = feeTypeMap.get(key) || {
          feeTypeId: r.feeTypeId,
          feeTypeName: key,
          feeTypeCode: (r as any).feeTypeCode || key.toUpperCase().replace(/\s+/g, '_'),
          category: (r as any).category || 'ACADEMIC',
          totalInvoicesCount: 0,
          totalInvoiced: 0,
          totalCollected: 0,
          totalDue: 0,
          totalOverdue: 0,
          collectionRate: 0
        };

        existing.totalInvoicesCount++;
        existing.totalInvoiced += r.netPayableAmount || 0;
        existing.totalCollected += r.paidAmount || 0;
        existing.totalDue += r.dueAmount || 0;

        if (r.dueAmount > 0) {
          const dueDate = new Date(r.dueDate);
          dueDate.setHours(0, 0, 0, 0);
          if (dueDate < today) {
            existing.totalOverdue += r.dueAmount;
          }
        }

        feeTypeMap.set(key, existing);
      }

      const feeTypeBreakdown = Array.from(feeTypeMap.values()).map((item) => ({
        ...item,
        totalInvoiced: Math.round(item.totalInvoiced * 100) / 100,
        totalCollected: Math.round(item.totalCollected * 100) / 100,
        totalDue: Math.round(item.totalDue * 100) / 100,
        totalOverdue: Math.round(item.totalOverdue * 100) / 100,
        collectionRate: item.totalInvoiced > 0 ? Math.round((item.totalCollected / item.totalInvoiced) * 10000) / 100 : 0
      }));

      const collectionEfficiencyRate =
        totalReceivable > 0 ? Math.round((totalCollected / totalReceivable) * 10000) / 100 : 0;

      const stats: FeeDueDashboardStats = {
        totalReceivable: Math.round(totalReceivable * 100) / 100,
        totalCollected: Math.round(totalCollected * 100) / 100,
        totalDue: Math.round(totalDue * 100) / 100,
        totalOverdue: Math.round(totalOverdue * 100) / 100,
        studentsWithDueCount: studentsWithDue.size,
        overdueInvoicesCount,
        totalActiveInvoices: records.length,
        paidInvoicesCount,
        partialInvoicesCount,
        dueSoonInvoicesCount,
        collectionEfficiencyRate,
        agingBreakdown,
        classWiseBreakdown: Array.from(classWiseMap.values()),
        feeTypeBreakdown
      };

      res.json({
        success: true,
        data: stats
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to fetch fee due statistics',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/due-management/students
 * Filterable, searchable, and sortable list of student dues with aging calculations and guardian contacts
 */
feeDueRouter.get(
  '/due-management/students',
  requirePermission('fees.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const {
        academicSessionId,
        classId,
        sectionId,
        feeTypeId,
        status,
        agingBracket,
        minDueAmount,
        maxDueAmount,
        dueDateFrom,
        dueDateTo,
        search,
        sortBy = 'daysOverdue',
        sortOrder = 'desc',
        page = '1',
        limit = '15'
      } = req.query as {
        academicSessionId?: string;
        classId?: string;
        sectionId?: string;
        feeTypeId?: string;
        status?: string;
        agingBracket?: string;
        minDueAmount?: string;
        maxDueAmount?: string;
        dueDateFrom?: string;
        dueDateTo?: string;
        search?: string;
        sortBy?: string;
        sortOrder?: 'asc' | 'desc';
        page?: string;
        limit?: string;
      };

      ensureReminderLogs();

      if (!database.feeRecords) {
        database.feeRecords = [];
      }

      // Recalculate dynamic statuses & balances on database records
      database.feeRecords = database.feeRecords.map(normalizeRecord);

      let rawRecords = database.feeRecords.filter((r) => r.status !== 'CANCELLED');

      // Filter by session
      if (academicSessionId && academicSessionId !== 'ALL') {
        rawRecords = rawRecords.filter((r) => r.academicSessionId === academicSessionId);
      }
      // Filter by class
      if (classId && classId !== 'ALL') {
        rawRecords = rawRecords.filter((r) => r.classId === classId);
      }
      // Filter by section
      if (sectionId && sectionId !== 'ALL') {
        rawRecords = rawRecords.filter((r) => r.sectionId === sectionId);
      }
      // Filter by fee type
      if (feeTypeId && feeTypeId !== 'ALL') {
        rawRecords = rawRecords.filter((r) => {
          if (r.feeTypeId && r.feeTypeId === feeTypeId) return true;
          const ft = (database.feeTypes || []).find((t) => t.id === feeTypeId);
          return ft && r.feeType.toLowerCase() === ft.name.toLowerCase();
        });
      }
      // Filter by due date range
      if (dueDateFrom) {
        rawRecords = rawRecords.filter((r) => r.dueDate >= dueDateFrom);
      }
      if (dueDateTo) {
        rawRecords = rawRecords.filter((r) => r.dueDate <= dueDateTo);
      }

      // Map to enriched FeeDueStudentItem
      const reminderLogs = (database as any).feeReminderLogs as FeeReminderLog[];

      let items: FeeDueStudentItem[] = rawRecords.map((r) => {
        const { daysOverdue, isDueSoon, agingBracket: bracket } = computeAgingDetails(r.dueDate, r.dueAmount);

        // Find student profile & guardian details
        const student = (database.studentProfiles || []).find((s) => s.id === r.studentId);
        const guardian = (database.guardians || []).find((g) => g.studentIds && g.studentIds.includes(r.studentId));

        // Find reminders sent for this invoice
        const invoiceReminders = (reminderLogs || []).filter(
          (log) => log.feeRecordId === r.id || log.invoiceNumber === r.invoiceNumber
        );
        const lastReminder = invoiceReminders.length > 0 ? invoiceReminders[invoiceReminders.length - 1] : null;

        let displayStatus: 'PAID' | 'PARTIAL' | 'DUE' | 'DUE_SOON' | 'OVERDUE' | 'CANCELLED' =
          r.status === 'CANCELLED'
            ? 'CANCELLED'
            : r.dueAmount === 0
            ? 'PAID'
            : daysOverdue > 0
            ? 'OVERDUE'
            : isDueSoon
            ? 'DUE_SOON'
            : r.paidAmount > 0
            ? 'PARTIAL'
            : 'DUE';

        return {
          feeRecordId: r.id,
          invoiceNumber: r.invoiceNumber,
          studentId: r.studentId,
          studentName: r.studentName,
          admissionNumber: r.admissionNumber,
          rollNumber: student?.rollNumber || (student as any)?.rollNo,
          classId: r.classId,
          className: r.className,
          sectionId: r.sectionId || undefined,
          sectionName: r.sectionName || undefined,
          feeType: r.feeType,
          feeTitle: r.title,
          academicSessionId: r.academicSessionId,
          academicSessionName: r.academicSessionName,
          term: r.term,
          totalAmount: r.totalAmount,
          discountAmount: r.discountAmount,
          scholarshipAmount: r.scholarshipAmount,
          waiverAmount: r.waiverAmount,
          fineAmount: r.fineAmount,
          netPayableAmount: r.netPayableAmount,
          paidAmount: r.paidAmount,
          dueAmount: r.dueAmount,
          dueDate: r.dueDate,
          daysOverdue,
          isDueSoon,
          status: displayStatus,
          agingBracket: bracket,
          guardianName: guardian ? guardian.name : student?.guardianName,
          guardianPhone: guardian ? guardian.phone : student?.guardianPhone,
          guardianEmail: guardian ? guardian.email : student?.guardianEmail,
          guardianRelation: (guardian as any)?.relation || (guardian as any)?.relationship,
          lastReminderSentAt: lastReminder ? lastReminder.sentAt : undefined,
          remindersCount: invoiceReminders.length,
          createdAt: r.createdAt
        };
      });

      // Filter by Status
      if (status && status !== 'ALL') {
        if (status === 'DUE' || status === 'UNPAID') {
          items = items.filter((i) => i.dueAmount > 0);
        } else if (status === 'OVERDUE') {
          items = items.filter((i) => i.status === 'OVERDUE' || i.daysOverdue > 0);
        } else if (status === 'DUE_SOON') {
          items = items.filter((i) => i.isDueSoon);
        } else if (status === 'PARTIAL' || status === 'PARTIALLY_PAID') {
          items = items.filter((i) => i.status === 'PARTIAL' || (i.paidAmount > 0 && i.dueAmount > 0));
        } else if (status === 'PAID') {
          items = items.filter((i) => i.status === 'PAID' || i.dueAmount === 0);
        }
      }

      // Filter by Aging Bracket
      if (agingBracket && agingBracket !== 'ALL') {
        items = items.filter((i) => i.agingBracket === agingBracket);
      }

      // Filter by min/max due amount
      if (minDueAmount !== undefined && minDueAmount !== '') {
        const minVal = parseFloat(minDueAmount);
        if (!isNaN(minVal)) {
          items = items.filter((i) => i.dueAmount >= minVal);
        }
      }
      if (maxDueAmount !== undefined && maxDueAmount !== '') {
        const maxVal = parseFloat(maxDueAmount);
        if (!isNaN(maxVal)) {
          items = items.filter((i) => i.dueAmount <= maxVal);
        }
      }

      // Search query (student name, roll, admission, invoice #, parent, fee type)
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        items = items.filter(
          (i) =>
            i.studentName.toLowerCase().includes(q) ||
            i.admissionNumber.toLowerCase().includes(q) ||
            i.invoiceNumber.toLowerCase().includes(q) ||
            i.feeTitle.toLowerCase().includes(q) ||
            i.feeType.toLowerCase().includes(q) ||
            i.className.toLowerCase().includes(q) ||
            (i.rollNumber && i.rollNumber.toLowerCase().includes(q)) ||
            (i.guardianName && i.guardianName.toLowerCase().includes(q)) ||
            (i.guardianPhone && i.guardianPhone.toLowerCase().includes(q))
        );
      }

      // Sorting
      items.sort((a, b) => {
        let valA: any = a[sortBy as keyof FeeDueStudentItem];
        let valB: any = b[sortBy as keyof FeeDueStudentItem];

        if (sortBy === 'daysOverdue') {
          valA = a.daysOverdue;
          valB = b.daysOverdue;
        } else if (sortBy === 'dueAmount') {
          valA = a.dueAmount;
          valB = b.dueAmount;
        } else if (sortBy === 'dueDate') {
          valA = new Date(a.dueDate).getTime();
          valB = new Date(b.dueDate).getTime();
        } else if (typeof valA === 'string') {
          return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }

        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });

      // Aggregated summary on matched items
      let totalReceivable = 0;
      let totalCollected = 0;
      let totalDue = 0;
      let totalOverdue = 0;
      let overdueInvoicesCount = 0;
      let dueSoonCount = 0;
      const studentsWithDueSet = new Set<string>();

      for (const item of items) {
        totalReceivable += item.netPayableAmount;
        totalCollected += item.paidAmount;
        totalDue += item.dueAmount;

        if (item.dueAmount > 0) {
          studentsWithDueSet.add(item.studentId);
          if (item.daysOverdue > 0) {
            totalOverdue += item.dueAmount;
            overdueInvoicesCount++;
          }
          if (item.isDueSoon) {
            dueSoonCount++;
          }
        }
      }

      // Pagination
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 15));
      const total = items.length;
      const totalPages = Math.ceil(total / limitNum);
      const startIndex = (pageNum - 1) * limitNum;
      const paginatedData = items.slice(startIndex, startIndex + limitNum);

      res.json({
        success: true,
        data: paginatedData,
        total,
        page: pageNum,
        limit: limitNum,
        totalPages,
        summary: {
          totalReceivable: Math.round(totalReceivable * 100) / 100,
          totalCollected: Math.round(totalCollected * 100) / 100,
          totalDue: Math.round(totalDue * 100) / 100,
          totalOverdue: Math.round(totalOverdue * 100) / 100,
          studentsWithDueCount: studentsWithDueSet.size,
          overdueInvoicesCount,
          dueSoonCount
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to fetch due student records',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/due-management/reminders
 * Send fee due reminders to student/guardian accounts and log dispatch history
 */
feeDueRouter.post(
  '/due-management/reminders',
  requirePermission('fees.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { feeRecordIds, channel = 'IN_APP_NOTIFICATION', reminderType = 'GENERAL_REMINDER', customTitle, customMessage, notes } =
        req.body as SendFeeReminderPayload;

      if (!Array.isArray(feeRecordIds) || feeRecordIds.length === 0) {
        res.status(400).json({
          success: false,
          error: 'At least one feeRecordId is required to dispatch reminders.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      ensureReminderLogs();

      const timestamp = new Date().toISOString();
      const newLogs: FeeReminderLog[] = [];

      for (const recId of feeRecordIds) {
        const record = (database.feeRecords || []).find((r) => r.id === recId || r.invoiceNumber === recId);
        if (!record) continue;

        const normalized = normalizeRecord(record);
        if (normalized.dueAmount <= 0) continue; // Skip fully paid invoices

        const { daysOverdue } = computeAgingDetails(normalized.dueDate, normalized.dueAmount);

        // Find student & guardian details
        const student = (database.studentProfiles || []).find((s) => s.id === normalized.studentId);
        const guardian = (database.guardians || []).find((g) => g.studentIds && g.studentIds.includes(normalized.studentId));

        const recipientContact =
          channel === 'EMAIL_PREVIEW'
            ? guardian?.email || student?.guardianEmail || 'guardian@school.edu'
            : guardian?.phone || student?.guardianPhone || '+1 (555) 000-0000';

        const defaultTitle =
          reminderType === 'OVERDUE_FIRST_NOTICE' || daysOverdue > 0
            ? `URGENT: Outstanding Fee Overdue Notice - ${normalized.invoiceNumber}`
            : reminderType === 'DUE_SOON'
            ? `Upcoming Fee Payment Reminder - ${normalized.invoiceNumber}`
            : `Fee Payment Statement & Due Reminder - ${normalized.invoiceNumber}`;

        const defaultMsg =
          daysOverdue > 0
            ? `Dear ${guardian ? guardian.name : 'Parent/Guardian'}, this is a reminder that fee invoice #${normalized.invoiceNumber} for ${normalized.studentName} ($${normalized.dueAmount.toFixed(2)}) is overdue by ${daysOverdue} day(s). Due Date: ${normalized.dueDate}. Please remit balance via the portal.`
            : `Dear ${guardian ? guardian.name : 'Parent/Guardian'}, please note that fee invoice #${normalized.invoiceNumber} for ${normalized.studentName} ($${normalized.dueAmount.toFixed(2)}) is due on ${normalized.dueDate}.`;

        const title = customTitle && customTitle.trim() ? customTitle.trim() : defaultTitle;
        const message = customMessage && customMessage.trim() ? customMessage.trim() : defaultMsg;

        const logEntry: FeeReminderLog = {
          id: `rem-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
          feeRecordId: normalized.id,
          invoiceNumber: normalized.invoiceNumber,
          studentId: normalized.studentId,
          studentName: normalized.studentName,
          admissionNumber: normalized.admissionNumber,
          className: normalized.className,
          guardianId: guardian?.id,
          guardianName: guardian?.name || student?.guardianName,
          recipientContact,
          channel: channel as ReminderChannel,
          reminderType: reminderType as ReminderType,
          title,
          message,
          dueAmountAtSend: normalized.dueAmount,
          dueDate: normalized.dueDate,
          daysOverdueAtSend: daysOverdue,
          sentAt: timestamp,
          sentById: req.user!.id,
          sentByName: req.user!.name,
          sentByRole: req.user!.role,
          status: 'DELIVERED',
          notes: notes || `Dispatched via ${channel} by ${req.user!.name}`
        };

        ((database as any).feeReminderLogs as FeeReminderLog[]).unshift(logEntry);
        newLogs.push(logEntry);

        // Push In-App Notification to Guardian user if available
        if (guardian) {
          database.notifications.unshift({
            id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            userId: guardian.userId,
            title,
            message,
            type: daysOverdue > 0 ? 'warning' : 'info',
            category: 'fee',
            isRead: false,
            createdAt: timestamp,
            link: '/guardian/fees'
          });
        }
      }

      // Audit Log
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'SEND_FEE_DUE_REMINDERS',
        entityType: 'FeeReminderLog',
        entityId: newLogs.map((l) => l.id).join(','),
        details: `Dispatched ${newLogs.length} fee due reminder(s) via ${channel} (${reminderType}). Total outstanding referenced: $${newLogs.reduce((acc, l) => acc + l.dueAmountAtSend, 0).toFixed(2)}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Successfully dispatched and recorded ${newLogs.length} fee due reminder(s).`,
        sentCount: newLogs.length,
        logs: newLogs
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to send fee reminders',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/due-management/reminders/history
 * View fee reminder dispatch history and audit logs
 */
feeDueRouter.get(
  '/due-management/reminders/history',
  requirePermission('fees.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { search, feeRecordId, studentId, channel, page = '1', limit = '20' } = req.query as {
        search?: string;
        feeRecordId?: string;
        studentId?: string;
        channel?: string;
        page?: string;
        limit?: string;
      };

      ensureReminderLogs();

      let logs: FeeReminderLog[] = [...((database as any).feeReminderLogs as FeeReminderLog[])];

      if (feeRecordId) {
        logs = logs.filter((l) => l.feeRecordId === feeRecordId || l.invoiceNumber === feeRecordId);
      }
      if (studentId) {
        logs = logs.filter((l) => l.studentId === studentId);
      }
      if (channel && channel !== 'ALL') {
        logs = logs.filter((l) => l.channel === channel);
      }
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        logs = logs.filter(
          (l) =>
            l.studentName.toLowerCase().includes(q) ||
            l.invoiceNumber.toLowerCase().includes(q) ||
            (l.guardianName && l.guardianName.toLowerCase().includes(q)) ||
            l.title.toLowerCase().includes(q) ||
            l.message.toLowerCase().includes(q)
        );
      }

      logs.sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());

      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 20));
      const total = logs.length;
      const paginatedLogs = logs.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginatedLogs,
        total,
        page: pageNum,
        limit: limitNum
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to fetch reminder logs',
        code: 'SERVER_ERROR'
      });
    }
  }
);
