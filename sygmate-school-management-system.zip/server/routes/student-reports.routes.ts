import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';

export const studentReportsRouter = Router();

/**
 * Helper: Determine user's student access scope based on RBAC
 */
function getAuthorizedStudents(req: AuthenticatedRequest) {
  const user = req.user;
  if (!user) return [];

  // Super Admin and Admin have access to all student records
  if (user.role === 'SUPER_ADMIN') {
    return database.studentProfiles;
  }

  // Teacher: strictly scoped to assigned classes and sections
  if (user.role === 'TEACHER') {
    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
    if (!teacherProfile) return [];

    const assignedClassIds = teacherProfile.assignedClassIds || [];

    // Also include sections from database.sections where classTeacherId matches
    const classTeacherSections = database.sections
      .filter((s) => s.classTeacherId === teacherProfile.id)
      .map((s) => s.id);

    const classTeacherSectionClassIds = database.sections
      .filter((s) => s.classTeacherId === teacherProfile.id)
      .map((s) => s.classId);

    const allClasses = Array.from(new Set([...assignedClassIds, ...classTeacherSectionClassIds]));
    const allSections = Array.from(new Set(classTeacherSections));

    return database.studentProfiles.filter((s) =>
      allClasses.includes(s.classId) || allSections.includes(s.sectionId)
    );
  }

  // Guardian: strictly scoped to linked children
  if (user.role === 'GUARDIAN') {
    const guardian = database.guardians.find((g) => g.userId === user.id);
    if (!guardian) return [];
    const linkedIds = guardian.studentIds || [];
    return database.studentProfiles.filter((s) => linkedIds.includes(s.id));
  }

  // Student: strictly scoped to own record
  if (user.role === 'STUDENT') {
    return database.studentProfiles.filter((s) => s.userId === user.id);
  }

  return [];
}

/**
 * Helper: Enrich a student profile with related entities
 */
function enrichStudent(profile: any, currentSessionId?: string) {
  const user = database.users.find((u) => u.id === profile.userId);
  const cls = database.classes.find((c) => c.id === profile.classId);
  const sec = database.sections.find((s) => s.id === profile.sectionId);
  const sess = database.academicSessions.find((s) => s.id === profile.academicSessionId);
  const guardian = database.guardians.find((g) => g.id === profile.guardianId || g.studentIds?.includes(profile.id));

  // Documents status
  const studentDocs = (database.studentProfiles.find(p => p.id === profile.id) as any)?.documents || [];
  const hasDocs = studentDocs.length > 0;
  const verifiedDocs = studentDocs.filter((d: any) => d.status === 'verified').length;
  const documentStatus = !hasDocs
    ? 'incomplete'
    : verifiedDocs === studentDocs.length
    ? 'verified'
    : 'pending_verification';

  // ID Card status
  const idCard = database.studentIdCards?.find((c) => c.studentId === profile.id);
  const idCardStatus = idCard ? idCard.status : 'not_issued';
  const idCardNumber = idCard ? idCard.cardNumber : undefined;

  // Academic Enrollments (historical vs current)
  const enrollments = (database.academicEnrollments || []).filter((e) => e.studentId === profile.id);

  // Name construction
  const nameParts = (user?.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim()).split(' ');
  const firstName = profile.firstName || nameParts[0] || 'Student';
  const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Scholar';
  const middleName = profile.middleName || '';
  const fullName = profile.fullName || `${firstName} ${middleName ? middleName + ' ' : ''}${lastName}`.trim();

  return {
    id: profile.id,
    userId: profile.userId,
    admissionNumber: profile.admissionNumber,
    rollNumber: profile.rollNumber || 'N/A',
    firstName,
    middleName,
    lastName,
    fullName,
    avatarUrl: profile.avatarUrl || user?.avatarUrl || '',
    email: profile.email || user?.email || '',
    phone: profile.phone || user?.phoneNumber || '',
    gender: profile.gender || 'unspecified',
    bloodGroup: profile.bloodGroup || 'N/A',
    dateOfBirth: profile.dateOfBirth,
    address: profile.address || '',
    admissionDate: profile.admissionDate || profile.enrollmentDate || '',
    enrollmentDate: profile.enrollmentDate || '',
    status: profile.status || 'active',
    enrollmentStatus: profile.enrollmentStatus || profile.status || 'active',

    // Academic details
    academicSessionId: profile.academicSessionId,
    academicSessionName: sess?.sessionName || 'Current Session',
    classId: profile.classId,
    className: cls?.name || 'Class',
    sectionId: profile.sectionId,
    sectionName: sec?.name || 'Section',

    // Guardian details
    guardianId: guardian?.id || profile.guardianId,
    guardianName: guardian?.name || profile.guardianName || 'N/A',
    guardianRelation: guardian?.relationship || profile.guardianRelation || 'Guardian',
    guardianPhone: guardian?.phone || profile.guardianPhone || '',
    guardianEmail: guardian?.email || profile.guardianEmail || '',

    // Compliance & Lifecycle
    documentStatus,
    documentCount: studentDocs.length,
    verifiedDocumentCount: verifiedDocs,
    idCardStatus,
    idCardNumber,
    totalEnrollmentsCount: enrollments.length
  };
}

/**
 * 1. GET /api/student-reports/search
 * Server-side search & filtering with pagination, sorting & RBAC protection
 */
studentReportsRouter.get('/search', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    let list = authorizedProfiles.map((p) => enrichStudent(p));

    const {
      search,
      q,
      academicSessionId,
      classId,
      sectionId,
      status,
      enrollmentStatus,
      gender,
      bloodGroup,
      admissionDateFrom,
      admissionDateTo,
      enrollmentDateFrom,
      enrollmentDateTo,
      documentStatus,
      idCardStatus,
      page = '1',
      limit = '15',
      sortBy = 'admissionNumber',
      sortOrder = 'asc'
    } = req.query as Record<string, string | undefined>;

    const searchQuery = (search || q || '').trim().toLowerCase();

    // 1. Text Search (multi-field matching)
    if (searchQuery) {
      list = list.filter((s) =>
        s.fullName.toLowerCase().includes(searchQuery) ||
        s.firstName.toLowerCase().includes(searchQuery) ||
        s.lastName.toLowerCase().includes(searchQuery) ||
        (s.middleName && s.middleName.toLowerCase().includes(searchQuery)) ||
        s.admissionNumber.toLowerCase().includes(searchQuery) ||
        (s.rollNumber && s.rollNumber.toLowerCase().includes(searchQuery)) ||
        (s.phone && s.phone.toLowerCase().includes(searchQuery)) ||
        (s.email && s.email.toLowerCase().includes(searchQuery)) ||
        (s.guardianName && s.guardianName.toLowerCase().includes(searchQuery)) ||
        (s.guardianPhone && s.guardianPhone.toLowerCase().includes(searchQuery)) ||
        (s.className && s.className.toLowerCase().includes(searchQuery)) ||
        (s.sectionName && s.sectionName.toLowerCase().includes(searchQuery)) ||
        s.id.toLowerCase().includes(searchQuery)
      );
    }

    // 2. Academic Session Filter
    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }

    // 3. Class Filter
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }

    // 4. Section Filter
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((s) => s.sectionId === sectionId);
    }

    // 5. Student Status Filter
    if (status && status !== 'ALL') {
      list = list.filter((s) => s.status.toLowerCase() === status.toLowerCase());
    }

    // 6. Enrollment Status Filter
    if (enrollmentStatus && enrollmentStatus !== 'ALL') {
      list = list.filter((s) => s.enrollmentStatus.toLowerCase() === enrollmentStatus.toLowerCase());
    }

    // 7. Gender Filter
    if (gender && gender !== 'ALL') {
      list = list.filter((s) => s.gender.toLowerCase() === gender.toLowerCase());
    }

    // 8. Blood Group Filter
    if (bloodGroup && bloodGroup !== 'ALL') {
      list = list.filter((s) => s.bloodGroup.toUpperCase() === bloodGroup.toUpperCase());
    }

    // 9. Date Ranges
    if (admissionDateFrom) {
      list = list.filter((s) => s.admissionDate && s.admissionDate >= admissionDateFrom);
    }
    if (admissionDateTo) {
      list = list.filter((s) => s.admissionDate && s.admissionDate <= admissionDateTo);
    }
    if (enrollmentDateFrom) {
      list = list.filter((s) => s.enrollmentDate && s.enrollmentDate >= enrollmentDateFrom);
    }
    if (enrollmentDateTo) {
      list = list.filter((s) => s.enrollmentDate && s.enrollmentDate <= enrollmentDateTo);
    }

    // 10. Document Status Filter
    if (documentStatus && documentStatus !== 'ALL') {
      list = list.filter((s) => s.documentStatus === documentStatus);
    }

    // 11. ID Card Status Filter
    if (idCardStatus && idCardStatus !== 'ALL') {
      list = list.filter((s) => s.idCardStatus === idCardStatus);
    }

    // 12. Sorting
    list.sort((a: any, b: any) => {
      let fieldA = a[sortBy] ?? '';
      let fieldB = b[sortBy] ?? '';

      if (sortBy === 'name' || sortBy === 'fullName') {
        fieldA = a.fullName || `${a.firstName} ${a.lastName}`;
        fieldB = b.fullName || `${b.firstName} ${b.lastName}`;
      }

      if (typeof fieldA === 'string') {
        const cmp = fieldA.localeCompare(fieldB);
        return sortOrder === 'desc' ? -cmp : cmp;
      }
      return sortOrder === 'desc' ? (fieldB as number) - (fieldA as number) : (fieldA as number) - (fieldB as number);
    });

    // 13. Pagination
    const total = list.length;
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 15);
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedData = list.slice(startIndex, startIndex + limitNum);
    const totalPages = Math.ceil(total / limitNum) || 1;

    res.json({
      success: true,
      data: paginatedData,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      },
      activeFilters: {
        search: searchQuery,
        academicSessionId: academicSessionId || 'ALL',
        classId: classId || 'ALL',
        sectionId: sectionId || 'ALL',
        status: status || 'ALL',
        enrollmentStatus: enrollmentStatus || 'ALL',
        gender: gender || 'ALL',
        bloodGroup: bloodGroup || 'ALL',
        documentStatus: documentStatus || 'ALL',
        idCardStatus: idCardStatus || 'ALL'
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to search students' });
  }
});

/**
 * 2. GET /api/student-reports/summary
 * Computed real database statistics across the authorized student body
 */
studentReportsRouter.get('/summary', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    let list = authorizedProfiles.map((p) => enrichStudent(p));

    const { academicSessionId, classId, sectionId } = req.query as Record<string, string | undefined>;

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((s) => s.sectionId === sectionId);
    }

    const totalStudents = list.length;
    const activeStudents = list.filter((s) => s.status.toLowerCase() === 'active').length;
    const inactiveStudents = list.filter((s) => s.status.toLowerCase() === 'inactive').length;
    const suspendedStudents = list.filter((s) => s.status.toLowerCase() === 'suspended').length;
    const withdrawnStudents = list.filter((s) => s.status.toLowerCase() === 'withdrawn').length;
    const transferredStudents = list.filter((s) => s.status.toLowerCase() === 'transferred').length;
    const graduatedStudents = list.filter((s) => s.status.toLowerCase() === 'graduated' || s.status.toLowerCase() === 'alumni').length;

    // Gender breakdown
    const maleCount = list.filter((s) => s.gender.toLowerCase() === 'male').length;
    const femaleCount = list.filter((s) => s.gender.toLowerCase() === 'female').length;
    const otherGenderCount = totalStudents - maleCount - femaleCount;

    // Document compliance
    const verifiedDocs = list.filter((s) => s.documentStatus === 'verified').length;
    const pendingDocs = list.filter((s) => s.documentStatus === 'pending_verification').length;
    const incompleteDocs = list.filter((s) => s.documentStatus === 'incomplete').length;
    const percentDocsVerified = totalStudents > 0 ? Math.round((verifiedDocs / totalStudents) * 100) : 0;

    // ID Card issuance
    const idCardIssued = list.filter((s) => s.idCardStatus === 'issued' || s.idCardStatus === 'active').length;
    const idCardPending = totalStudents - idCardIssued;
    const percentIdCardIssued = totalStudents > 0 ? Math.round((idCardIssued / totalStudents) * 100) : 0;

    // Class-level distribution
    const classMap: Record<string, { classId: string; className: string; studentCount: number; activeCount: number }> = {};
    for (const student of list) {
      if (!classMap[student.classId]) {
        classMap[student.classId] = {
          classId: student.classId,
          className: student.className,
          studentCount: 0,
          activeCount: 0
        };
      }
      classMap[student.classId].studentCount += 1;
      if (student.status.toLowerCase() === 'active') {
        classMap[student.classId].activeCount += 1;
      }
    }

    res.json({
      success: true,
      data: {
        totalStudents,
        activeStudents,
        inactiveStudents,
        suspendedStudents,
        withdrawnStudents,
        transferredStudents,
        graduatedStudents,
        genderDistribution: {
          male: maleCount,
          female: femaleCount,
          other: otherGenderCount
        },
        documentCompliance: {
          verifiedCount: verifiedDocs,
          pendingCount: pendingDocs,
          incompleteCount: incompleteDocs,
          percentVerified: percentDocsVerified
        },
        idCardIssuance: {
          issuedCount: idCardIssued,
          pendingCount: idCardPending,
          percentIssued: percentIdCardIssued
        },
        classBreakdown: Object.values(classMap)
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to compute summary report' });
  }
});

/**
 * 3. GET /api/student-reports/class-wise
 * Class and section hierarchical report
 */
studentReportsRouter.get('/class-wise', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    let list = authorizedProfiles.map((p) => enrichStudent(p));

    const { academicSessionId, classId, sectionId, status } = req.query as Record<string, string | undefined>;

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((s) => s.sectionId === sectionId);
    }
    if (status && status !== 'ALL') {
      list = list.filter((s) => s.status.toLowerCase() === status.toLowerCase());
    }

    // Group by Class
    const allClasses = database.classes;
    const allSections = database.sections;

    const classReports = allClasses
      .filter((cls) => (!classId || classId === 'ALL' || cls.id === classId))
      .map((cls) => {
        const classStudents = list.filter((s) => s.classId === cls.id);
        const relatedSections = allSections.filter((sec) => sec.classId === cls.id);

        const sectionsData = relatedSections
          .filter((sec) => (!sectionId || sectionId === 'ALL' || sec.id === sectionId))
          .map((sec) => {
            const secStudents = classStudents.filter((s) => s.sectionId === sec.id);
            return {
              sectionId: sec.id,
              sectionName: sec.name,
              capacity: sec.capacity || 40,
              studentCount: secStudents.length,
              activeCount: secStudents.filter((s) => s.status === 'active').length,
              students: secStudents.sort((a, b) => (a.rollNumber || '').localeCompare(b.rollNumber || ''))
            };
          });

        return {
          classId: cls.id,
          className: cls.name,
          gradeLevel: cls.numericGrade || 0,
          totalStudents: classStudents.length,
          activeStudents: classStudents.filter((s) => s.status === 'active').length,
          maleCount: classStudents.filter((s) => s.gender === 'male').length,
          femaleCount: classStudents.filter((s) => s.gender === 'female').length,
          sections: sectionsData
        };
      })
      .filter((c) => c.sections.length > 0 || c.totalStudents > 0);

    res.json({
      success: true,
      data: classReports,
      totalStudentsCount: list.length
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to generate class-wise report' });
  }
});

/**
 * 4. GET /api/student-reports/status-report
 * Segmented status audit report with last status change history
 */
studentReportsRouter.get('/status-report', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    let list = authorizedProfiles.map((p) => enrichStudent(p));

    const { academicSessionId, classId, status } = req.query as Record<string, string | undefined>;

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }
    if (status && status !== 'ALL') {
      list = list.filter((s) => s.status.toLowerCase() === status.toLowerCase());
    }

    const history = database.studentStatusHistory || [];

    const enrichedStatusList = list.map((student) => {
      // Find latest status transition in history
      const studentHistory = history.filter((h) => h.studentId === student.id);
      const latestHistory = studentHistory.length > 0 ? studentHistory[studentHistory.length - 1] : null;

      return {
        ...student,
        lastStatusChangeDate: latestHistory?.effectiveDate || student.enrollmentDate,
        lastStatusReason: latestHistory?.reason || 'Initial Enrollment',
        changedBy: latestHistory?.changedByName || latestHistory?.changedBy || 'System Registrar',
        previousStatus: latestHistory?.fromStatus || 'N/A'
      };
    });

    // Group by status
    const statusGroups: Record<string, typeof enrichedStatusList> = {
      active: [],
      inactive: [],
      suspended: [],
      withdrawn: [],
      transferred: [],
      graduated: []
    };

    for (const item of enrichedStatusList) {
      const st = item.status.toLowerCase();
      if (!statusGroups[st]) {
        statusGroups[st] = [];
      }
      statusGroups[st].push(item);
    }

    res.json({
      success: true,
      data: {
        all: enrichedStatusList,
        grouped: statusGroups,
        counts: {
          active: statusGroups.active.length,
          inactive: statusGroups.inactive.length,
          suspended: statusGroups.suspended.length,
          withdrawn: statusGroups.withdrawn.length,
          transferred: statusGroups.transferred.length,
          graduated: statusGroups.graduated.length,
          total: enrichedStatusList.length
        }
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to generate status report' });
  }
});

/**
 * 5. GET /api/student-reports/admissions
 * Admission & Enrollment ledger report
 */
studentReportsRouter.get('/admissions', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    let list = authorizedProfiles.map((p) => enrichStudent(p));

    const {
      academicSessionId,
      classId,
      sectionId,
      dateFrom,
      dateTo,
      enrollmentStatus
    } = req.query as Record<string, string | undefined>;

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((s) => s.sectionId === sectionId);
    }
    if (enrollmentStatus && enrollmentStatus !== 'ALL') {
      list = list.filter((s) => s.enrollmentStatus.toLowerCase() === enrollmentStatus.toLowerCase());
    }
    if (dateFrom) {
      list = list.filter((s) => s.admissionDate >= dateFrom);
    }
    if (dateTo) {
      list = list.filter((s) => s.admissionDate <= dateTo);
    }

    list.sort((a, b) => b.admissionDate.localeCompare(a.admissionDate));

    res.json({
      success: true,
      data: list,
      totalCount: list.length
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to generate admissions report' });
  }
});

/**
 * 6. GET /api/student-reports/academic-assignments
 * Accurate current vs historical academic assignments report
 */
studentReportsRouter.get('/academic-assignments', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId, classId, sectionId } = req.query as Record<string, string | undefined>;
    const authorizedProfiles = getAuthorizedStudents(req);
    const authorizedIds = new Set(authorizedProfiles.map((p) => p.id));

    const enrollments = (database.academicEnrollments || []).filter((e) => authorizedIds.has(e.studentId));

    let filtered = enrollments;

    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((e) => e.academicSessionId === academicSessionId);
    }
    if (classId && classId !== 'ALL') {
      filtered = filtered.filter((e) => e.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      filtered = filtered.filter((e) => e.sectionId === sectionId);
    }

    const currentSession = database.academicSessions.find((s) => s.isCurrent) || database.academicSessions[0];

    const result = filtered.map((e) => {
      const student = database.studentProfiles.find((p) => p.id === e.studentId);
      const user = database.users.find((u) => u.id === student?.userId);
      const sess = database.academicSessions.find((s) => s.id === e.academicSessionId);
      const cls = database.classes.find((c) => c.id === e.classId);
      const sec = database.sections.find((s) => s.id === e.sectionId);

      const isCurrentAssignment = e.academicSessionId === currentSession?.id;

      return {
        enrollmentId: e.id,
        studentId: e.studentId,
        studentName: user?.name || `${student?.firstName || ''} ${student?.lastName || ''}`.trim() || 'Student',
        admissionNumber: student?.admissionNumber || 'N/A',
        rollNumber: e.rollNumber || student?.rollNumber || 'N/A',
        academicSessionId: e.academicSessionId,
        academicSessionName: sess?.sessionName || 'Session',
        classId: e.classId,
        className: cls?.name || 'Class',
        sectionId: e.sectionId,
        sectionName: sec?.name || 'Section',
        enrollmentDate: e.enrollmentDate || student?.enrollmentDate || '',
        status: e.status || student?.status || 'active',
        isCurrentAssignment
      };
    });

    res.json({
      success: true,
      data: result,
      totalCount: result.length
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch academic assignments report' });
  }
});

/**
 * 7. GET /api/student-reports/promotions
 * Real promotion records report from Part 9E
 */
studentReportsRouter.get('/promotions', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    const authorizedIds = new Set(authorizedProfiles.map((p) => p.id));

    const records = (database.studentPromotionRecords || []).filter((r) => authorizedIds.has(r.studentId));

    const { sourceSessionId, targetSessionId, status } = req.query as Record<string, string | undefined>;

    let list = records;
    if (sourceSessionId && sourceSessionId !== 'ALL') {
      list = list.filter((r) => r.fromSessionId === sourceSessionId);
    }
    if (targetSessionId && targetSessionId !== 'ALL') {
      list = list.filter((r) => r.toSessionId === targetSessionId);
    }
    if (status && status !== 'ALL') {
      list = list.filter((r) => r.status === status);
    }

    res.json({
      success: true,
      data: list,
      totalCount: list.length
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch promotion records' });
  }
});

/**
 * 8. GET /api/student-reports/transfers
 * Real transfer and certificate records report from Part 9E
 */
studentReportsRouter.get('/transfers', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const authorizedProfiles = getAuthorizedStudents(req);
    const authorizedIds = new Set(authorizedProfiles.map((p) => p.id));

    const records = (database.studentTransferRecords || []).filter((r) => authorizedIds.has(r.studentId));

    const { transferType, status } = req.query as Record<string, string | undefined>;

    let list = records;
    if (transferType && transferType !== 'ALL') {
      list = list.filter((r) => r.transferType === transferType);
    }
    if (status && status !== 'ALL') {
      list = list.filter((r) => r.status === status);
    }

    res.json({
      success: true,
      data: list,
      totalCount: list.length
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch transfer records' });
  }
});

/**
 * 9. POST /api/student-reports/bulk-action
 * High-safety bulk operations: status updates, section reassignments, ID card triggers
 */
studentReportsRouter.post('/bulk-action', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { action, studentIds, targetStatus, targetClassId, targetSectionId, reason } = req.body;

    if (!action || !Array.isArray(studentIds) || studentIds.length === 0) {
      res.status(400).json({ success: false, error: 'Action and a non-empty array of studentIds are required' });
      return;
    }

    if (!reason || !reason.trim()) {
      res.status(400).json({ success: false, error: 'A valid audit reason is required for bulk operations' });
      return;
    }

    const user = req.user!;
    const affectedStudents: any[] = [];
    const failures: { studentId: string; reason: string }[] = [];

    // Verify all target students exist
    for (const sid of studentIds) {
      const student = database.studentProfiles.find((s) => s.id === sid);
      if (!student) {
        failures.push({ studentId: sid, reason: 'Student record not found' });
      } else {
        affectedStudents.push(student);
      }
    }

    if (affectedStudents.length === 0) {
      res.status(400).json({
        success: false,
        error: 'No valid students found to execute operation',
        failures
      });
      return;
    }

    const timestamp = new Date().toISOString();

    // Execute based on action
    switch (action) {
      case 'STATUS_UPDATE':
      case 'ARCHIVE': {
        const newStatus = action === 'ARCHIVE' ? 'inactive' : targetStatus;
        if (!newStatus || !['active', 'inactive', 'suspended', 'withdrawn', 'graduated'].includes(newStatus.toLowerCase())) {
          res.status(400).json({ success: false, error: `Invalid target status: ${newStatus}` });
          return;
        }

        affectedStudents.forEach((student) => {
          const oldStatus = student.status;
          student.status = newStatus;
          student.enrollmentStatus = newStatus;

          // Record in student status history
          if (!database.studentStatusHistory) database.studentStatusHistory = [];
          database.studentStatusHistory.push({
            id: `stat-hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            studentId: student.id,
            admissionNumber: student.admissionNumber,
            studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student',
            fromStatus: oldStatus as any,
            toStatus: newStatus as any,
            effectiveDate: timestamp.split('T')[0],
            reason: reason.trim(),
            changedBy: user.id,
            changedByName: user.name || 'Administrator',
            changedAt: timestamp,
            remarks: `Bulk status change execution`
          });
        });

        // Audit Log
        logAudit({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: 'UPDATE',
          entity: 'STUDENT',
          details: `Bulk status update performed on ${affectedStudents.length} students to '${newStatus}'. Reason: ${reason}`
        });

        res.json({
          success: true,
          message: `Successfully updated status for ${affectedStudents.length} students to '${newStatus}'`,
          affectedCount: affectedStudents.length,
          failures
        });
        return;
      }

      case 'SECTION_REASSIGN': {
        if (!targetSectionId) {
          res.status(400).json({ success: false, error: 'Target section ID is required for section reassignment' });
          return;
        }

        const targetSec = database.sections.find((s) => s.id === targetSectionId);
        if (!targetSec) {
          res.status(400).json({ success: false, error: 'Target section does not exist' });
          return;
        }

        const targetClsId = targetClassId || targetSec.classId;
        const targetCls = database.classes.find((c) => c.id === targetClsId);

        affectedStudents.forEach((student) => {
          const oldSectionId = student.sectionId;
          student.sectionId = targetSectionId;
          if (targetClassId) student.classId = targetClassId;

          // Also update or add academicEnrollment
          const existingEnrollment = (database.academicEnrollments || []).find(
            (e) => e.studentId === student.id && e.academicSessionId === student.academicSessionId
          );
          if (existingEnrollment) {
            existingEnrollment.sectionId = targetSectionId;
            if (targetClassId) existingEnrollment.classId = targetClassId;
          }
        });

        // Audit Log
        logAudit({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: 'UPDATE',
          entity: 'STUDENT',
          details: `Bulk section reassigned ${affectedStudents.length} students to ${targetCls?.name || ''} - ${targetSec.name}. Reason: ${reason}`
        });

        res.json({
          success: true,
          message: `Successfully reassigned ${affectedStudents.length} students to Section ${targetSec.name}`,
          affectedCount: affectedStudents.length,
          failures
        });
        return;
      }

      case 'GENERATE_ID_CARDS': {
        if (!database.studentIdCards) database.studentIdCards = [];

        let generatedCount = 0;
        let alreadyExistedCount = 0;

        affectedStudents.forEach((student) => {
          const existingCard = database.studentIdCards.find((c) => c.studentId === student.id);
          if (existingCard) {
            alreadyExistedCount++;
            existingCard.status = 'ISSUED';
            existingCard.updatedAt = timestamp;
          } else {
            generatedCount++;
            const cardNumber = `IDC-${new Date().getFullYear()}-${student.admissionNumber.replace(/[^0-9]/g, '').slice(-4) || Math.floor(1000 + Math.random() * 9000)}`;
            database.studentIdCards.push({
              id: `idc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              studentId: student.id,
              cardNumber,
              templateId: 'template-default-1',
              status: 'ISSUED',
              issueDate: timestamp.split('T')[0],
              expiryDate: `${new Date().getFullYear() + 1}-06-30`,
              qrCodeData: `SYGMATE:STU:${student.id}:${student.admissionNumber}`,
              barcodeData: student.admissionNumber,
              createdAt: timestamp,
              updatedAt: timestamp
            } as any);
          }
        });

        logAudit({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: 'CREATE',
          entity: 'DOCUMENT',
          details: `Bulk ID Card generation invoked for ${affectedStudents.length} students (${generatedCount} created, ${alreadyExistedCount} refreshed). Reason: ${reason}`
        });

        res.json({
          success: true,
          message: `Processed ID cards for ${affectedStudents.length} students (${generatedCount} newly issued, ${alreadyExistedCount} active)`,
          affectedCount: affectedStudents.length,
          failures
        });
        return;
      }

      default:
        res.status(400).json({ success: false, error: `Unsupported bulk action: ${action}` });
        return;
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to execute bulk operation' });
  }
});

/**
 * 10. POST /api/student-reports/export-audit
 * Audit log recording for reporting exports and data downloads
 */
studentReportsRouter.post('/export-audit', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { reportType, format, filterContext, recordCount } = req.body;
    const user = req.user!;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'EXPORT',
      entity: 'REPORT',
      details: `Exported ${recordCount || 0} student records from '${reportType || 'Student Report'}' as ${format || 'CSV'}. Filters: ${JSON.stringify(filterContext || {})}`
    });

    res.json({ success: true, message: 'Export audit logged successfully' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to log export audit' });
  }
});
