import { Router, Response } from 'express';
import { database, StoredUser } from '../db/database.js';
import { AuthenticatedRequest, requireAuth, requirePermission } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import { hashPassword } from '../security/auth.js';
import {
  AdmissionEnquiry,
  AdmissionApplication,
  AcademicEnrollment,
  AdmissionNumberConfig,
  DuplicateStudentCheckResult,
  DuplicateStudentMatch,
  AdmissionStatusHistory,
  AdmissionApplicationStatus,
  User,
  StudentProfile,
  Guardian,
  StudentFeeRecord,
  FeePaymentTransaction
} from '../../src/types/index.js';

export const admissionsRouter = Router();

// Apply authentication to all admission routes
admissionsRouter.use(requireAuth);

// Helper to ensure collections are defined
function ensureCollections() {
  if (!database.admissionEnquiries) database.admissionEnquiries = [];
  if (!database.admissionApplications) database.admissionApplications = [];
  if (!database.academicEnrollments) database.academicEnrollments = [];
  if (!database.admissionNumberConfig) {
    database.admissionNumberConfig = {
      prefix: 'ADM',
      includeYear: true,
      sequencePadding: 4,
      currentSequence: 850,
      autoAssignRoll: true
    };
  }
}

// Helper: Concurrency-safe admission number generator
function generateAdmissionNumber(): string {
  ensureCollections();
  database.admissionNumberConfig.currentSequence += 1;
  const seq = database.admissionNumberConfig.currentSequence;
  const currentYear = new Date().getFullYear();
  const pad = database.admissionNumberConfig.sequencePadding || 4;
  const prefix = database.admissionNumberConfig.prefix || 'ADM';

  if (database.admissionNumberConfig.includeYear) {
    return `${prefix}-${currentYear}-${String(seq).padStart(pad, '0')}`;
  }
  return `${prefix}-${String(seq).padStart(pad, '0')}`;
}

// Helper: Application number generator
function generateApplicationNumber(): string {
  ensureCollections();
  const year = new Date().getFullYear();
  const count = database.admissionApplications.length + 1;
  return `APP-${year}-${String(count).padStart(4, '0')}`;
}

// Helper: Enquiry number generator
function generateEnquiryNumber(): string {
  ensureCollections();
  const year = new Date().getFullYear();
  const count = database.admissionEnquiries.length + 1;
  return `ENQ-${year}-${String(count).padStart(4, '0')}`;
}

// Helper: Enrollment number generator
function generateEnrollmentNumber(): string {
  ensureCollections();
  const year = new Date().getFullYear();
  const count = database.academicEnrollments.length + 1;
  return `ENR-${year}-${String(count).padStart(4, '0')}`;
}

// Helper: Compute next available roll number in a section
function computeNextRollNumber(academicSessionId: string, classId: string, sectionId: string): string {
  ensureCollections();
  const studentsInSection = database.studentProfiles.filter(
    s => s.classId === classId && s.sectionId === sectionId && s.academicSessionId === academicSessionId
  );

  const existingRolls = new Set(studentsInSection.map(s => s.rollNumber).filter(Boolean));
  for (let i = 1; i <= 200; i++) {
    const candidateR = `R-${String(i).padStart(2, '0')}`;
    const candidateNum = String(i);
    if (!existingRolls.has(candidateR) && !existingRolls.has(candidateNum)) {
      return candidateR;
    }
  }
  return `R-${studentsInSection.length + 1}`;
}

// Helper: Duplicate check engine
function runDuplicateStudentCheck(payload: {
  admissionNumber?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  phone?: string;
  guardianPhone?: string;
  guardianEmail?: string;
  transferCertificateNumber?: string;
  excludeApplicationId?: string;
  excludeStudentId?: string;
}): DuplicateStudentCheckResult {
  ensureCollections();
  const matches: DuplicateStudentMatch[] = [];

  const norm = (str?: string) => (str ? str.trim().toLowerCase() : '');
  const emailNorm = norm(payload.email);
  const admNorm = norm(payload.admissionNumber);
  const fullNameNorm = `${norm(payload.firstName)} ${norm(payload.lastName)}`.trim();
  const dobNorm = norm(payload.dateOfBirth);
  const parentPhoneNorm = norm(payload.guardianPhone || payload.phone);
  const tcNorm = norm(payload.transferCertificateNumber);

  // 1. Check against active StudentProfiles
  for (const s of database.studentProfiles) {
    if (payload.excludeStudentId && s.id === payload.excludeStudentId) continue;

    const sFullName = `${norm(s.firstName)} ${norm(s.lastName)}`.trim();
    const sDob = norm(s.dateOfBirth);
    const sAdm = norm(s.admissionNumber);

    // Admission Number check
    if (admNorm && sAdm === admNorm) {
      matches.push({
        type: 'ADMISSION_NUMBER',
        matchedEntity: 'STUDENT',
        entityId: s.id,
        name: `${s.firstName || ''} ${s.lastName || ''}`.trim(),
        identifier: s.admissionNumber,
        className: s.className,
        details: `Active student profile already has admission number ${s.admissionNumber}.`
      });
    }

    // Name + DOB match
    if (fullNameNorm && sFullName === fullNameNorm && dobNorm && sDob === dobNorm) {
      matches.push({
        type: 'NAME_DOB',
        matchedEntity: 'STUDENT',
        entityId: s.id,
        name: `${s.firstName || ''} ${s.lastName || ''}`.trim(),
        identifier: s.admissionNumber,
        className: s.className,
        details: `Active student with identical name (${s.firstName} ${s.lastName}) and Date of Birth (${s.dateOfBirth}) already exists.`
      });
    }

    // Previous TC check
    if (tcNorm && s.previousSchool && norm(s.previousSchool) === tcNorm) {
      matches.push({
        type: 'PREVIOUS_TC',
        matchedEntity: 'STUDENT',
        entityId: s.id,
        name: `${s.firstName || ''} ${s.lastName || ''}`.trim(),
        identifier: s.admissionNumber,
        className: s.className,
        details: `Student with matching transfer certificate record found.`
      });
    }
  }

  // 2. Check against existing Users (for email)
  if (emailNorm) {
    const existingUser = database.users.find(u => norm(u.email) === emailNorm);
    if (existingUser) {
      matches.push({
        type: 'EMAIL',
        matchedEntity: 'STUDENT',
        entityId: existingUser.id,
        name: existingUser.name,
        identifier: existingUser.email,
        details: `System user account with email ${existingUser.email} already exists.`
      });
    }
  }

  // 3. Check against other active admission applications
  for (const app of database.admissionApplications) {
    if (payload.excludeApplicationId && app.id === payload.excludeApplicationId) continue;
    if (app.status === 'REJECTED' || app.status === 'CANCELLED') continue;

    const appFullName = norm(app.fullName || `${app.firstName} ${app.lastName}`);
    const appDob = norm(app.dateOfBirth);
    const appEmail = norm(app.email);

    if (emailNorm && appEmail === emailNorm) {
      matches.push({
        type: 'EMAIL',
        matchedEntity: 'APPLICATION',
        entityId: app.id,
        name: app.fullName,
        identifier: app.applicationNumber,
        className: app.className,
        details: `Another pending application (${app.applicationNumber}) already registered with email ${app.email}.`
      });
    }

    if (fullNameNorm && appFullName === fullNameNorm && dobNorm && appDob === dobNorm) {
      matches.push({
        type: 'NAME_DOB',
        matchedEntity: 'APPLICATION',
        entityId: app.id,
        name: app.fullName,
        identifier: app.applicationNumber,
        className: app.className,
        details: `Active application (${app.applicationNumber}) exists for applicant with identical name and DOB.`
      });
    }
  }

  return {
    isDuplicate: matches.length > 0,
    matches
  };
}

// =========================================================================
// STATS & CONFIGURATION ENDPOINTS
// =========================================================================

/**
 * GET /api/admissions/stats
 * Overview dashboard metrics
 */
admissionsRouter.get(
  '/stats',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const apps = database.admissionApplications;
      const enquiries = database.admissionEnquiries;
      const enrollments = database.academicEnrollments;

      const totalApplications = apps.length;
      const pendingReview = apps.filter(a => a.status === 'SUBMITTED' || a.status === 'UNDER_REVIEW').length;
      const approved = apps.filter(a => a.status === 'APPROVED').length;
      const enrolled = apps.filter(a => a.status === 'ENROLLED').length;
      const rejected = apps.filter(a => a.status === 'REJECTED').length;
      const drafts = apps.filter(a => a.status === 'DRAFT').length;

      const totalEnquiries = enquiries.length;
      const convertedEnquiries = enquiries.filter(e => e.status === 'CONVERTED').length;
      const conversionRate = totalEnquiries > 0 ? Math.round((convertedEnquiries / totalEnquiries) * 100) : 0;

      res.json({
        success: true,
        data: {
          applications: {
            total: totalApplications,
            pendingReview,
            approved,
            enrolled,
            rejected,
            drafts
          },
          enquiries: {
            total: totalEnquiries,
            converted: convertedEnquiries,
            conversionRate
          },
          enrollments: {
            total: enrollments.length,
            active: enrollments.filter(e => e.status === 'active').length
          }
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/admissions/config
 * Admission number configuration
 */
admissionsRouter.get(
  '/config',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      res.json({ success: true, data: database.admissionNumberConfig });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/admissions/config
 * Update admission number format configuration
 */
admissionsRouter.put(
  '/config',
  requirePermission('settings.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const { prefix, includeYear, sequencePadding, autoAssignRoll } = req.body;

      if (prefix !== undefined) database.admissionNumberConfig.prefix = String(prefix).trim().toUpperCase();
      if (includeYear !== undefined) database.admissionNumberConfig.includeYear = Boolean(includeYear);
      if (sequencePadding !== undefined) database.admissionNumberConfig.sequencePadding = Math.max(2, Math.min(8, Number(sequencePadding)));
      if (autoAssignRoll !== undefined) database.admissionNumberConfig.autoAssignRoll = Boolean(autoAssignRoll);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionConfig',
        entityId: 'config',
        details: `Updated admission number format configuration.`
      });

      res.json({ success: true, data: database.admissionNumberConfig });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/admissions/next-number
 * Preview next sequential admission number
 */
admissionsRouter.get(
  '/next-number',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const nextSeq = database.admissionNumberConfig.currentSequence + 1;
      const year = new Date().getFullYear();
      const pad = database.admissionNumberConfig.sequencePadding || 4;
      const prefix = database.admissionNumberConfig.prefix || 'ADM';

      const previewNumber = database.admissionNumberConfig.includeYear
        ? `${prefix}-${year}-${String(nextSeq).padStart(pad, '0')}`
        : `${prefix}-${String(nextSeq).padStart(pad, '0')}`;

      res.json({ success: true, data: { nextAdmissionNumber: previewNumber, nextSequence: nextSeq } });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// FRONT OFFICE: ADMISSION ENQUIRIES ENDPOINTS
// =========================================================================

/**
 * GET /api/admissions/enquiries
 * List enquiries with query filtering
 */
admissionsRouter.get(
  '/enquiries',
  requirePermission('admissions.enquiry'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const { status, classId, sessionId, source, search, limit = 50, page = 1 } = req.query;

      let list = [...database.admissionEnquiries];

      if (status) {
        list = list.filter(e => e.status === status);
      }
      if (classId) {
        list = list.filter(e => e.applyingClassId === classId);
      }
      if (sessionId) {
        list = list.filter(e => e.academicSessionId === sessionId);
      }
      if (source) {
        list = list.filter(e => e.source === source);
      }
      if (search) {
        const q = String(search).toLowerCase();
        list = list.filter(
          e =>
            e.studentName.toLowerCase().includes(q) ||
            e.parentName.toLowerCase().includes(q) ||
            e.enquiryNumber.toLowerCase().includes(q) ||
            e.phone.toLowerCase().includes(q) ||
            e.email.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/admissions/enquiries/:id
 */
admissionsRouter.get(
  '/enquiries/:id',
  requirePermission('admissions.enquiry'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Enquiry not found.' });
        return;
      }
      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/admissions/enquiries
 * Log new front office admission enquiry
 */
admissionsRouter.post(
  '/enquiries',
  requirePermission('admissions.enquiry'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const {
        studentName,
        dateOfBirth,
        gender,
        applyingClassId,
        academicSessionId,
        parentName,
        relationship,
        phone,
        email,
        address,
        source,
        followUpDate,
        notes
      } = req.body;

      if (!studentName || !parentName || !phone || !applyingClassId) {
        res.status(400).json({
          success: false,
          error: 'Student Name, Parent Name, Phone, and Applying Class are required.'
        });
        return;
      }

      const targetClass = database.classes.find(c => c.id === applyingClassId);
      const targetSession = academicSessionId
        ? database.academicSessions.find(s => s.id === academicSessionId)
        : database.academicSessions.find(s => s.status === 'active') || database.academicSessions[0];

      const newEnquiry: AdmissionEnquiry = {
        id: `enq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        enquiryNumber: generateEnquiryNumber(),
        studentName: String(studentName).trim(),
        dateOfBirth: dateOfBirth || '',
        gender: gender || 'male',
        applyingClassId,
        applyingClassName: targetClass ? targetClass.name : 'Unknown Class',
        academicSessionId: targetSession ? targetSession.id : '',
        academicSessionName: targetSession ? targetSession.name : '',
        parentName: String(parentName).trim(),
        relationship: relationship || 'Parent',
        phone: String(phone).trim(),
        email: String(email || '').trim(),
        address: String(address || '').trim(),
        source: source || 'WALK_IN',
        assignedStaffId: req.user!.id,
        assignedStaffName: req.user!.name,
        status: 'NEW',
        followUpDate: followUpDate || '',
        notes: notes || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.admissionEnquiries.push(newEnquiry);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'AdmissionEnquiry',
        entityId: newEnquiry.id,
        details: `Logged admission enquiry ${newEnquiry.enquiryNumber} for student ${newEnquiry.studentName}.`
      });

      res.status(201).json({ success: true, data: newEnquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/admissions/enquiries/:id
 */
admissionsRouter.put(
  '/enquiries/:id',
  requirePermission('admissions.enquiry'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Enquiry not found.' });
        return;
      }

      const updates = req.body;
      if (updates.studentName) enquiry.studentName = String(updates.studentName).trim();
      if (updates.parentName) enquiry.parentName = String(updates.parentName).trim();
      if (updates.phone) enquiry.phone = String(updates.phone).trim();
      if (updates.email !== undefined) enquiry.email = String(updates.email).trim();
      if (updates.status) enquiry.status = updates.status;
      if (updates.followUpDate !== undefined) enquiry.followUpDate = updates.followUpDate;
      if (updates.notes !== undefined) enquiry.notes = updates.notes;
      if (updates.source) enquiry.source = updates.source;

      if (updates.applyingClassId) {
        const cls = database.classes.find(c => c.id === updates.applyingClassId);
        if (cls) {
          enquiry.applyingClassId = cls.id;
          enquiry.applyingClassName = cls.name;
        }
      }

      enquiry.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Updated enquiry ${enquiry.enquiryNumber} (status: ${enquiry.status}).`
      });

      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * DELETE /api/admissions/enquiries/:id
 */
admissionsRouter.delete(
  '/enquiries/:id',
  requirePermission('admissions.create'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const idx = database.admissionEnquiries.findIndex(e => e.id === req.params.id);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Enquiry not found.' });
        return;
      }

      const [removed] = database.admissionEnquiries.splice(idx, 1);
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'AdmissionEnquiry',
        entityId: removed.id,
        details: `Deleted admission enquiry ${removed.enquiryNumber}.`
      });

      res.json({ success: true, message: 'Enquiry deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/admissions/enquiries/:id/convert
 * Convert enquiry to pre-filled Admission Application
 */
admissionsRouter.post(
  '/enquiries/:id/convert',
  requirePermission('admissions.create'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Enquiry not found.' });
        return;
      }

      const targetClass = database.classes.find(c => c.id === enquiry.applyingClassId) || database.classes[0];
      const targetSection = database.sections.find(s => s.classId === targetClass.id) || database.sections[0];
      const targetSession = enquiry.academicSessionId
        ? database.academicSessions.find(s => s.id === enquiry.academicSessionId)
        : database.academicSessions.find(s => s.status === 'active') || database.academicSessions[0];

      // Parse first & last name
      const nameParts = enquiry.studentName.trim().split(' ');
      const firstName = nameParts[0] || 'Applicant';
      const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : 'Student';

      const newApplication: AdmissionApplication = {
        id: `adm-app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        applicationNumber: generateApplicationNumber(),
        enquiryId: enquiry.id,
        enquiryNumber: enquiry.enquiryNumber,
        firstName,
        lastName,
        fullName: enquiry.studentName,
        dateOfBirth: enquiry.dateOfBirth || '',
        gender: enquiry.gender || 'male',
        nationality: 'United States',
        email: enquiry.email || '',
        phone: enquiry.phone || '',
        address: enquiry.address || '',
        guardianMode: 'new',
        guardianName: enquiry.parentName,
        guardianRelation: enquiry.relationship || 'Parent',
        guardianPhone: enquiry.phone,
        guardianEmail: enquiry.email || '',
        guardianAddress: enquiry.address || '',
        emergencyContact: enquiry.phone,
        academicSessionId: targetSession.id,
        academicSessionName: targetSession.name,
        classId: targetClass.id,
        className: targetClass.name,
        sectionId: targetSection ? targetSection.id : '',
        sectionName: targetSection ? targetSection.name : '',
        applicationDate: new Date().toISOString().split('T')[0],
        admissionDate: new Date().toISOString().split('T')[0],
        assignAdmissionFee: true,
        documents: [],
        status: 'DRAFT',
        statusHistory: [
          {
            fromStatus: 'ENQUIRY',
            toStatus: 'DRAFT',
            changedBy: req.user!.name,
            changedAt: new Date().toISOString(),
            reason: `Converted from front office enquiry ${enquiry.enquiryNumber}`
          }
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.admissionApplications.push(newApplication);

      // Update enquiry status
      enquiry.status = 'CONVERTED';
      enquiry.convertedAdmissionId = newApplication.id;
      enquiry.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CONVERT',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Converted enquiry ${enquiry.enquiryNumber} to application ${newApplication.applicationNumber}.`
      });

      res.status(201).json({ success: true, data: newApplication });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// ADMISSION APPLICATION & WORKFLOW LIFECYCLE ENDPOINTS
// =========================================================================

/**
 * POST /api/admissions/applications/check-duplicates
 * Standalone duplicate check API
 */
admissionsRouter.post(
  '/applications/check-duplicates',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const result = runDuplicateStudentCheck(req.body);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/admissions/applications
 * List applications with filters and pagination
 */
admissionsRouter.get(
  '/applications',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const { status, classId, sessionId, search, limit = 50, page = 1 } = req.query;

      let list = [...database.admissionApplications];

      if (status) {
        list = list.filter(a => a.status === status);
      }
      if (classId) {
        list = list.filter(a => a.classId === classId);
      }
      if (sessionId) {
        list = list.filter(a => a.academicSessionId === sessionId);
      }
      if (search) {
        const q = String(search).toLowerCase();
        list = list.filter(
          a =>
            a.fullName.toLowerCase().includes(q) ||
            a.applicationNumber.toLowerCase().includes(q) ||
            (a.email && a.email.toLowerCase().includes(q)) ||
            (a.admittedAdmissionNumber && a.admittedAdmissionNumber.toLowerCase().includes(q)) ||
            a.guardianName.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/admissions/applications/:id
 * Full application dossier
 */
admissionsRouter.get(
  '/applications/:id',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const app = database.admissionApplications.find(a => a.id === req.params.id);
      if (!app) {
        res.status(404).json({ success: false, error: 'Admission application not found.' });
        return;
      }
      res.json({ success: true, data: app });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/admissions/applications
 * Create application (DRAFT or SUBMITTED)
 */
admissionsRouter.post(
  '/applications',
  requirePermission('admissions.create'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const payload = req.body;

      if (!payload.firstName || !payload.lastName) {
        res.status(400).json({ success: false, error: 'First name and Last name are required.' });
        return;
      }

      if (!payload.academicSessionId || !payload.classId) {
        res.status(400).json({ success: false, error: 'Academic Session and Class must be selected.' });
        return;
      }

      const targetClass = database.classes.find(c => c.id === payload.classId);
      if (!targetClass) {
        res.status(400).json({ success: false, error: 'Selected class does not exist.' });
        return;
      }

      const targetSession = database.academicSessions.find(s => s.id === payload.academicSessionId);
      if (!targetSession) {
        res.status(400).json({ success: false, error: 'Selected academic session does not exist.' });
        return;
      }

      const targetSection = payload.sectionId
        ? database.sections.find(s => s.id === payload.sectionId && s.classId === targetClass.id)
        : database.sections.find(s => s.classId === targetClass.id);

      const fullName = `${payload.firstName} ${payload.middleName ? payload.middleName + ' ' : ''}${payload.lastName}`.trim();

      // Check duplicates
      const dupCheck = runDuplicateStudentCheck({
        email: payload.email,
        firstName: payload.firstName,
        lastName: payload.lastName,
        dateOfBirth: payload.dateOfBirth,
        guardianPhone: payload.guardianPhone,
        transferCertificateNumber: payload.transferCertificateNumber
      });

      // If submitted and strict duplicate found with active student admission number or existing email, warn or reject
      const strictDuplicate = dupCheck.matches.find(m => m.type === 'EMAIL' || m.type === 'ADMISSION_NUMBER');
      if (strictDuplicate && payload.status === 'SUBMITTED' && !payload.bypassDuplicateWarning) {
        res.status(409).json({
          success: false,
          error: `Duplicate conflict detected: ${strictDuplicate.details}`,
          duplicates: dupCheck.matches,
          code: 'DUPLICATE_STUDENT_DETECTED'
        });
        return;
      }

      const status: AdmissionApplicationStatus = payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED';

      const newApp: AdmissionApplication = {
        id: `adm-app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        applicationNumber: generateApplicationNumber(),
        enquiryId: payload.enquiryId,
        enquiryNumber: payload.enquiryNumber,

        firstName: String(payload.firstName).trim(),
        middleName: payload.middleName ? String(payload.middleName).trim() : undefined,
        lastName: String(payload.lastName).trim(),
        fullName,
        dateOfBirth: payload.dateOfBirth || '',
        gender: payload.gender || 'male',
        bloodGroup: payload.bloodGroup,
        nationality: payload.nationality || 'United States',
        religion: payload.religion,
        category: payload.category,
        email: payload.email ? String(payload.email).trim() : undefined,
        phone: payload.phone ? String(payload.phone).trim() : undefined,
        address: payload.address || '',
        presentAddress: payload.presentAddress || payload.address || '',
        permanentAddress: payload.permanentAddress || payload.address || '',
        city: payload.city || '',
        postalCode: payload.postalCode || '',
        avatarUrl: payload.avatarUrl,

        previousSchoolName: payload.previousSchoolName,
        previousClass: payload.previousClass,
        previousMarksPercentage: payload.previousMarksPercentage ? Number(payload.previousMarksPercentage) : undefined,
        previousSchoolBoard: payload.previousSchoolBoard,
        transferCertificateNumber: payload.transferCertificateNumber,

        guardianMode: payload.guardianMode || 'new',
        guardianId: payload.guardianId,
        guardianName: payload.guardianName || 'Guardian',
        guardianRelation: payload.guardianRelation || 'Parent',
        guardianPhone: payload.guardianPhone || '',
        guardianEmail: payload.guardianEmail || '',
        guardianAddress: payload.guardianAddress || payload.address || '',
        guardianOccupation: payload.guardianOccupation,
        emergencyContact: payload.emergencyContact || payload.guardianPhone || '',
        fatherName: payload.fatherName,
        fatherPhone: payload.fatherPhone,
        fatherEmail: payload.fatherEmail,
        fatherOccupation: payload.fatherOccupation,
        motherName: payload.motherName,
        motherPhone: payload.motherPhone,
        motherEmail: payload.motherEmail,
        motherOccupation: payload.motherOccupation,

        academicSessionId: targetSession.id,
        academicSessionName: targetSession.name,
        classId: targetClass.id,
        className: targetClass.name,
        sectionId: targetSection ? targetSection.id : '',
        sectionName: targetSection ? targetSection.name : '',
        preferredRollNumber: payload.preferredRollNumber,
        applicationDate: payload.applicationDate || new Date().toISOString().split('T')[0],
        admissionDate: payload.admissionDate || new Date().toISOString().split('T')[0],
        admissionFeeStructureId: payload.admissionFeeStructureId,
        assignAdmissionFee: payload.assignAdmissionFee !== false,

        documents: Array.isArray(payload.documents) ? payload.documents : [],

        status,
        statusHistory: [
          {
            fromStatus: 'NONE',
            toStatus: status,
            changedBy: req.user!.name,
            changedAt: new Date().toISOString(),
            reason: status === 'DRAFT' ? 'Saved initial application draft' : 'Submitted online admission application'
          }
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.admissionApplications.push(newApp);

      // If converted from an enquiry, link and mark enquiry
      if (payload.enquiryId) {
        const enq = database.admissionEnquiries.find(e => e.id === payload.enquiryId);
        if (enq) {
          enq.status = 'CONVERTED';
          enq.convertedAdmissionId = newApp.id;
          enq.updatedAt = new Date().toISOString();
        }
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'AdmissionApplication',
        entityId: newApp.id,
        details: `Created admission application ${newApp.applicationNumber} for ${newApp.fullName} (status: ${newApp.status}).`
      });

      res.status(201).json({ success: true, data: newApp, duplicateMatches: dupCheck.matches });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/admissions/applications/:id
 * Update an existing application (while in DRAFT, SUBMITTED, or UNDER_REVIEW)
 */
admissionsRouter.put(
  '/applications/:id',
  requirePermission('admissions.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const app = database.admissionApplications.find(a => a.id === req.params.id);
      if (!app) {
        res.status(404).json({ success: false, error: 'Admission application not found.' });
        return;
      }

      if (app.status === 'ENROLLED' || app.status === 'ACTIVE') {
        res.status(400).json({
          success: false,
          error: 'Cannot modify application after enrollment is completed. Please edit student profile directly.'
        });
        return;
      }

      const updates = req.body;

      // Copy allowed fields
      const allowedFields = [
        'firstName',
        'middleName',
        'lastName',
        'dateOfBirth',
        'gender',
        'bloodGroup',
        'nationality',
        'religion',
        'category',
        'email',
        'phone',
        'address',
        'presentAddress',
        'permanentAddress',
        'city',
        'postalCode',
        'avatarUrl',
        'previousSchoolName',
        'previousClass',
        'previousMarksPercentage',
        'previousSchoolBoard',
        'transferCertificateNumber',
        'guardianMode',
        'guardianId',
        'guardianName',
        'guardianRelation',
        'guardianPhone',
        'guardianEmail',
        'guardianAddress',
        'guardianOccupation',
        'emergencyContact',
        'fatherName',
        'fatherPhone',
        'fatherEmail',
        'fatherOccupation',
        'motherName',
        'motherPhone',
        'motherEmail',
        'motherOccupation',
        'preferredRollNumber',
        'applicationDate',
        'admissionDate',
        'admissionFeeStructureId',
        'assignAdmissionFee',
        'documents'
      ];

      for (const key of allowedFields) {
        if (updates[key] !== undefined) {
          (app as any)[key] = updates[key];
        }
      }

      if (updates.firstName || updates.lastName) {
        app.fullName = `${app.firstName} ${app.middleName ? app.middleName + ' ' : ''}${app.lastName}`.trim();
      }

      if (updates.classId) {
        const cls = database.classes.find(c => c.id === updates.classId);
        if (cls) {
          app.classId = cls.id;
          app.className = cls.name;
        }
      }

      if (updates.sectionId) {
        const sec = database.sections.find(s => s.id === updates.sectionId);
        if (sec) {
          app.sectionId = sec.id;
          app.sectionName = sec.name;
        }
      }

      if (updates.academicSessionId) {
        const sess = database.academicSessions.find(s => s.id === updates.academicSessionId);
        if (sess) {
          app.academicSessionId = sess.id;
          app.academicSessionName = sess.name;
        }
      }

      app.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionApplication',
        entityId: app.id,
        details: `Updated details for application ${app.applicationNumber}.`
      });

      res.json({ success: true, data: app });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/admissions/applications/:id/status
 * Transition application lifecycle status
 */
admissionsRouter.post(
  '/applications/:id/status',
  requirePermission('admissions.review'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const app = database.admissionApplications.find(a => a.id === req.params.id);
      if (!app) {
        res.status(404).json({ success: false, error: 'Application not found.' });
        return;
      }

      const { targetStatus, reason, reviewRemarks } = req.body;
      const validStatuses: AdmissionApplicationStatus[] = [
        'DRAFT',
        'SUBMITTED',
        'UNDER_REVIEW',
        'APPROVED',
        'REJECTED',
        'CANCELLED'
      ];

      if (!validStatuses.includes(targetStatus)) {
        res.status(400).json({
          success: false,
          error: `Invalid target status '${targetStatus}'. For enrollment use /approve-and-enroll.`
        });
        return;
      }

      // Enforce rejection reason
      if (targetStatus === 'REJECTED' && (!reason || String(reason).trim().length < 5)) {
        res.status(400).json({
          success: false,
          error: 'A specific rejection reason (at least 5 characters) is required when rejecting an application.'
        });
        return;
      }

      const prevStatus = app.status;
      app.status = targetStatus;
      if (reviewRemarks) app.reviewRemarks = reviewRemarks;
      if (targetStatus === 'REJECTED') app.rejectionReason = reason;

      if (targetStatus === 'UNDER_REVIEW') {
        app.reviewedBy = req.user!.id;
        app.reviewedAt = new Date().toISOString();
      } else if (targetStatus === 'APPROVED') {
        app.approvedBy = req.user!.id;
        app.approvedAt = new Date().toISOString();
      }

      app.statusHistory.push({
        fromStatus: prevStatus,
        toStatus: targetStatus,
        changedBy: req.user!.name,
        changedAt: new Date().toISOString(),
        reason: reason || reviewRemarks || `Status moved to ${targetStatus}`
      });

      app.updatedAt = new Date().toISOString();

      // Dispatch notification
      database.notifications.push({
        id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        title: `Admission Application ${app.applicationNumber}: ${targetStatus}`,
        message: `Application for ${app.fullName} is now ${targetStatus}. ${reason ? 'Note: ' + reason : ''}`,
        category: 'academic',
        isRead: false,
        createdAt: new Date().toISOString()
      });

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'STATUS_CHANGE',
        entity: 'AdmissionApplication',
        entityId: app.id,
        details: `Transitioned application ${app.applicationNumber} from ${prevStatus} to ${targetStatus}.`
      });

      res.json({ success: true, data: app });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/admissions/applications/:id/approve-and-enroll
 * AUTHORITATIVE TRANSACTIONAL ADMISSION & ACADEMIC ENROLLMENT
 */
admissionsRouter.post(
  '/applications/:id/approve-and-enroll',
  requirePermission('admissions.enroll'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const app = database.admissionApplications.find(a => a.id === req.params.id);
      if (!app) {
        res.status(404).json({ success: false, error: 'Admission application not found.' });
        return;
      }

      // Check if already enrolled
      if (app.status === 'ENROLLED' || app.admittedStudentId) {
        res.status(400).json({
          success: false,
          error: `Application ${app.applicationNumber} is already enrolled with Student ID ${app.admittedStudentId} (${app.admittedAdmissionNumber}).`
        });
        return;
      }

      // Validate Academic Session
      const session = database.academicSessions.find(s => s.id === app.academicSessionId);
      if (!session) {
        res.status(400).json({ success: false, error: 'Selected Academic Session is invalid or no longer exists.' });
        return;
      }

      // Validate Class & Section
      const cls = database.classes.find(c => c.id === app.classId);
      if (!cls) {
        res.status(400).json({ success: false, error: 'Selected Class is invalid or no longer exists.' });
        return;
      }

      let sec = database.sections.find(s => s.id === app.sectionId && s.classId === cls.id);
      if (!sec) {
        // Fallback to first section of class
        sec = database.sections.find(s => s.classId === cls.id);
        if (!sec) {
          res.status(400).json({ success: false, error: `Class ${cls.name} has no valid sections configured.` });
          return;
        }
      }

      // 1. Generate sequential, concurrency-safe Admission Number
      const admissionNumber = generateAdmissionNumber();

      // 2. Assign unique Roll Number in this section
      let rollNumber = app.preferredRollNumber ? String(app.preferredRollNumber).trim() : '';
      if (!rollNumber || database.admissionNumberConfig.autoAssignRoll) {
        rollNumber = computeNextRollNumber(session.id, cls.id, sec.id);
      } else {
        // Verify preferred roll isn't duplicate in section
        const rollConflict = database.studentProfiles.find(
          s => s.classId === cls.id && s.sectionId === sec.id && s.academicSessionId === session.id && s.rollNumber === rollNumber
        );
        if (rollConflict) {
          rollNumber = computeNextRollNumber(session.id, cls.id, sec.id);
        }
      }

      // 3. Resolve or Create Parent / Guardian
      let guardianId = app.guardianId;
      let guardianRecord: Guardian | undefined;

      if (app.guardianMode === 'existing' && guardianId) {
        guardianRecord = database.guardians.find(g => g.id === guardianId);
      }

      if (!guardianRecord) {
        // Look up by email
        if (app.guardianEmail) {
          guardianRecord = database.guardians.find(
            g => g.email.toLowerCase() === app.guardianEmail.toLowerCase()
          );
        }
      }

      // If still not found, create new Guardian user & profile
      if (!guardianRecord) {
        const guardianSalt = 'e5f2a1b8c9d0e7f4a3b2c1d0e9f8a7b6';
        const guardianEmail = app.guardianEmail || `guardian.${Date.now()}@sygmate.edu`;
        const guardianUser: StoredUser = {
          id: `usr-guard-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          email: guardianEmail,
          username: guardianEmail.split('@')[0],
          passwordHash: hashPassword('Guardian@123', guardianSalt).hash,
          passwordSalt: guardianSalt,
          name: app.guardianName || `${app.lastName} Guardian`,
          role: 'GUARDIAN',
          status: 'ACTIVE',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.users.push(guardianUser);

        guardianRecord = {
          id: `guard-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          userId: guardianUser.id,
          name: app.guardianName || `${app.lastName} Guardian`,
          relationship: app.guardianRelation || 'Parent',
          email: guardianEmail,
          phone: app.guardianPhone || '',
          address: app.guardianAddress || app.address,
          occupation: app.guardianOccupation || '',
          studentIds: [],
          status: 'active',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.guardians.push(guardianRecord);
      }

      // 4. Create Student User Account
      const studentSalt = 'e5f2a1b8c9d0e7f4a3b2c1d0e9f8a7b6';
      const cleanAdmTag = admissionNumber.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const studentEmail = app.email || `student.${cleanAdmTag}@sygmate.edu`;

      // Check if user already exists
      let studentUser = database.users.find(u => u.email.toLowerCase() === studentEmail.toLowerCase());
      if (!studentUser) {
        studentUser = {
          id: `usr-stud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          email: studentEmail,
          username: `student.${cleanAdmTag}`,
          passwordHash: hashPassword('Student@123', studentSalt).hash,
          passwordSalt: studentSalt,
          name: app.fullName,
          role: 'STUDENT',
          status: 'ACTIVE',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.users.push(studentUser);
      }

      // 5. Create StudentProfile Master Record
      const newStudentProfileId = `stud-prof-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newStudentProfile: StudentProfile = {
        id: newStudentProfileId,
        userId: studentUser.id,
        admissionNumber,
        rollNumber,
        firstName: app.firstName,
        middleName: app.middleName,
        lastName: app.lastName,
        email: studentEmail,
        phone: app.phone,
        dateOfBirth: app.dateOfBirth,
        gender: (app.gender as any) || 'male',
        bloodGroup: app.bloodGroup,
        nationality: app.nationality,
        religion: app.religion,
        category: app.category,
        address: app.address,
        presentAddress: app.presentAddress || app.address,
        permanentAddress: app.permanentAddress || app.address,
        city: app.city,
        postalCode: app.postalCode,
        avatarUrl: app.avatarUrl,

        academicSessionId: session.id,
        academicSessionName: session.name,
        classId: cls.id,
        className: cls.name,
        sectionId: sec.id,
        sectionName: sec.name,
        enrollmentDate: app.admissionDate || new Date().toISOString().split('T')[0],
        enrollmentStatus: 'active',
        status: 'active',

        previousSchool: app.previousSchoolName,
        previousClass: app.previousClass,
        previousMarksPercentage: app.previousMarksPercentage,
        transferCertificateNumber: app.transferCertificateNumber,

        guardianId: guardianRecord.id,
        guardianName: guardianRecord.name,
        guardianRelation: guardianRecord.relationship,
        guardianPhone: guardianRecord.phone,
        guardianEmail: guardianRecord.email,
        guardianAddress: guardianRecord.address,
        guardianOccupation: guardianRecord.occupation,
        emergencyContact: app.emergencyContact || guardianRecord.phone,
        fatherName: app.fatherName,
        fatherPhone: app.fatherPhone,
        fatherEmail: app.fatherEmail,
        fatherOccupation: app.fatherOccupation,
        motherName: app.motherName,
        motherPhone: app.motherPhone,
        motherEmail: app.motherEmail,
        motherOccupation: app.motherOccupation,

        documents: app.documents.map(d => ({
          id: d.id,
          name: d.name,
          type: d.type,
          url: d.url,
          size: d.size,
          category: d.category as any,
          uploadedAt: d.uploadedAt
        })),

        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.studentProfiles.push(newStudentProfile);

      // Link student to guardian's studentIds
      if (!guardianRecord.studentIds.includes(newStudentProfile.id)) {
        guardianRecord.studentIds.push(newStudentProfile.id);
      }

      // 6. Create Academic Enrollment Record
      const newEnrollment: AcademicEnrollment = {
        id: `enr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        enrollmentNumber: generateEnrollmentNumber(),
        studentId: newStudentProfile.id,
        studentAdmissionNumber: admissionNumber,
        studentName: app.fullName,
        academicSessionId: session.id,
        academicSessionName: session.name,
        classId: cls.id,
        className: cls.name,
        sectionId: sec.id,
        sectionName: sec.name,
        rollNumber,
        enrollmentDate: app.admissionDate || new Date().toISOString().split('T')[0],
        status: 'active',
        admissionApplicationId: app.id,
        remarks: `Enrolled via Admission Application ${app.applicationNumber}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      database.academicEnrollments.push(newEnrollment);

      // 7. Optional Fee Invoice Generation
      if (app.assignAdmissionFee) {
        // Find admission fee structure or generic fee structure for this class
        let targetFeeStructure = database.feeStructures.find(
          f => f.feeTypeId === 'feetype-admission' && f.classId === cls.id
        );
        if (!targetFeeStructure) {
          targetFeeStructure = database.feeStructures.find(f => f.classId === cls.id);
        }

        if (targetFeeStructure) {
          const feeAmount = targetFeeStructure.amount || 500;
          const newFeeRecord: StudentFeeRecord = {
            id: `fee-rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            studentId: newStudentProfile.id,
            admissionNumber: admissionNumber,
            studentName: app.fullName,
            academicSessionId: session.id,
            academicSessionName: session.name,
            classId: cls.id,
            className: cls.name,
            sectionId: sec.id,
            sectionName: sec.name,
            feeStructureId: targetFeeStructure.id,
            feeTypeId: targetFeeStructure.feeTypeId,
            feeType: targetFeeStructure.feeTypeName || 'Admission',
            title: targetFeeStructure.name,
            description: targetFeeStructure.description || 'Admission Enrollment Fee',
            term: 'First Term',
            currency: 'USD',
            totalAmount: feeAmount,
            discountAmount: 0,
            netPayableAmount: feeAmount,
            paidAmount: 0,
            dueAmount: feeAmount,
            status: 'UNPAID',
            invoiceNumber: `INV-${new Date().getFullYear()}-${String(database.feeRecords.length + 1).padStart(5, '0')}`,
            dueDate: targetFeeStructure.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          database.feeRecords.push(newFeeRecord);
        }
      }

      // 8. Update Application Status to ENROLLED
      const prevStatus = app.status;
      app.status = 'ENROLLED';
      app.admittedStudentId = newStudentProfile.id;
      app.admittedAdmissionNumber = admissionNumber;
      app.assignedRollNumber = rollNumber;
      app.enrollmentId = newEnrollment.id;
      app.approvedBy = req.user!.id;
      app.approvedAt = new Date().toISOString();

      app.statusHistory.push({
        fromStatus: prevStatus,
        toStatus: 'ENROLLED',
        changedBy: req.user!.name,
        changedAt: new Date().toISOString(),
        reason: `Admitted and enrolled as student ${admissionNumber}, Roll: ${rollNumber}`
      });
      app.updatedAt = new Date().toISOString();

      // If converted from enquiry, mark enquiry with converted student ID
      if (app.enquiryId) {
        const enq = database.admissionEnquiries.find(e => e.id === app.enquiryId);
        if (enq) {
          enq.convertedStudentId = newStudentProfile.id;
          enq.updatedAt = new Date().toISOString();
        }
      }

      // 9. Dispatch Notifications
      database.notifications.push({
        id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        title: `Student Enrolled: ${app.fullName}`,
        message: `Student ${app.fullName} has been officially enrolled in ${cls.name} - ${sec.name} with Admission No: ${admissionNumber}.`,
        category: 'academic',
        isRead: false,
        studentId: newStudentProfile.id,
        createdAt: new Date().toISOString()
      });

      // 10. Audit Log
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'ENROLL',
        entity: 'StudentProfile',
        entityId: newStudentProfile.id,
        details: `Successfully admitted and enrolled student ${app.fullName} (${admissionNumber}) in Class ${cls.name} / Section ${sec.name}. Application: ${app.applicationNumber}.`
      });

      res.status(200).json({
        success: true,
        message: `Student ${app.fullName} successfully admitted and enrolled.`,
        data: {
          application: app,
          studentProfile: newStudentProfile,
          enrollment: newEnrollment,
          admissionNumber,
          rollNumber
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// ACADEMIC ENROLLMENT MANAGEMENT ENDPOINTS
// =========================================================================

/**
 * GET /api/admissions/enrollments
 * Filter academic enrollments
 */
admissionsRouter.get(
  '/enrollments',
  requirePermission('admissions.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const { classId, sectionId, sessionId, status, search, limit = 50, page = 1 } = req.query;

      let list = [...database.academicEnrollments];

      if (classId) {
        list = list.filter(e => e.classId === classId);
      }
      if (sectionId) {
        list = list.filter(e => e.sectionId === sectionId);
      }
      if (sessionId) {
        list = list.filter(e => e.academicSessionId === sessionId);
      }
      if (status) {
        list = list.filter(e => e.status === status);
      }
      if (search) {
        const q = String(search).toLowerCase();
        list = list.filter(
          e =>
            e.studentName.toLowerCase().includes(q) ||
            e.studentAdmissionNumber.toLowerCase().includes(q) ||
            e.enrollmentNumber.toLowerCase().includes(q) ||
            e.rollNumber.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => a.rollNumber.localeCompare(b.rollNumber, undefined, { numeric: true }));

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/admissions/enrollments/:id/roll-number
 * Reassign roll number with duplicate check
 */
admissionsRouter.put(
  '/enrollments/:id/roll-number',
  requirePermission('admissions.enroll'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const enrollment = database.academicEnrollments.find(e => e.id === req.params.id);
      if (!enrollment) {
        res.status(404).json({ success: false, error: 'Enrollment not found.' });
        return;
      }

      const { newRollNumber } = req.body;
      if (!newRollNumber || String(newRollNumber).trim() === '') {
        res.status(400).json({ success: false, error: 'Valid roll number is required.' });
        return;
      }

      const cleanRoll = String(newRollNumber).trim();

      // Check section conflict
      const conflict = database.academicEnrollments.find(
        e =>
          e.id !== enrollment.id &&
          e.classId === enrollment.classId &&
          e.sectionId === enrollment.sectionId &&
          e.academicSessionId === enrollment.academicSessionId &&
          e.rollNumber.toLowerCase() === cleanRoll.toLowerCase() &&
          e.status === 'active'
      );

      if (conflict) {
        res.status(409).json({
          success: false,
          error: `Roll number '${cleanRoll}' is already assigned to active student ${conflict.studentName} (${conflict.studentAdmissionNumber}) in this section.`
        });
        return;
      }

      const oldRoll = enrollment.rollNumber;
      enrollment.rollNumber = cleanRoll;
      enrollment.updatedAt = new Date().toISOString();

      // Sync with student profile
      const prof = database.studentProfiles.find(s => s.id === enrollment.studentId);
      if (prof) {
        prof.rollNumber = cleanRoll;
        prof.updatedAt = new Date().toISOString();
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE_ROLL',
        entity: 'AcademicEnrollment',
        entityId: enrollment.id,
        details: `Reassigned roll number for ${enrollment.studentName} from ${oldRoll} to ${cleanRoll}.`
      });

      res.json({ success: true, data: enrollment });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/admissions/enrollments/:id/status
 * Update enrollment status (active, transferred, suspended, etc.)
 */
admissionsRouter.put(
  '/enrollments/:id/status',
  requirePermission('admissions.enroll'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureCollections();
      const enrollment = database.academicEnrollments.find(e => e.id === req.params.id);
      if (!enrollment) {
        res.status(404).json({ success: false, error: 'Enrollment not found.' });
        return;
      }

      const { status, remarks } = req.body;
      const validStatuses = ['active', 'transferred', 'suspended', 'withdrawn', 'graduated', 'promoted'];
      if (!validStatuses.includes(status)) {
        res.status(400).json({ success: false, error: 'Invalid enrollment status.' });
        return;
      }

      const prevStatus = enrollment.status;
      enrollment.status = status;
      if (remarks) enrollment.remarks = remarks;
      enrollment.updatedAt = new Date().toISOString();

      // Sync with student profile status
      const prof = database.studentProfiles.find(s => s.id === enrollment.studentId);
      if (prof) {
        prof.enrollmentStatus = status as any;
        if (status === 'active') prof.status = 'active';
        else if (status === 'suspended') prof.status = 'inactive';
        prof.updatedAt = new Date().toISOString();
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE_ENROLLMENT_STATUS',
        entity: 'AcademicEnrollment',
        entityId: enrollment.id,
        details: `Updated enrollment status for ${enrollment.studentName} from ${prevStatus} to ${status}.`
      });

      res.json({ success: true, data: enrollment });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);
