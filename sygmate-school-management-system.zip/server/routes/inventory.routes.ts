/**
 * Inventory & Asset Management Routes (Part 14A)
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import { database } from '../db/database.js';
import {
  InventoryItem,
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  Supplier,
  Asset,
  AssetCategory,
  AssetDocument,
  AssetHistoryEntry,
  AssetStatus,
  ItemType,
  InventoryItemStatus,
  InventoryDashboardStats
} from '../../src/types/index.js';

import { stockRouter } from './stock.routes.js';
import { procurementRouter } from './procurement.routes.js';
import { issueAllocationRouter } from './issue-allocation.routes.js';
import { AssetService } from '../services/asset.service.js';
import { InventoryAnalyticsService } from '../services/inventory-analytics.service.js';

export const inventoryRouter = Router();

// Mount Part 14B Stock Management Sub-Router
inventoryRouter.use('/stock', stockRouter);

// Mount Part 14D Procurement & Purchasing Sub-Router
inventoryRouter.use('/procurement', procurementRouter);

// Mount Part 14E Issue, Return, Allocation & Department Sub-Router
inventoryRouter.use('/', issueAllocationRouter);

// ============================================================================
// DEFENSIVE INITIALIZATION & TENANT CONTEXT
// ============================================================================

export function ensureInventoryCollections(): void {
  if (!database.inventoryItems) database.inventoryItems = [];
  if (!database.inventoryCategories) database.inventoryCategories = [];
  if (!database.inventoryUnits) database.inventoryUnits = [];
  if (!database.inventoryLocations) database.inventoryLocations = [];
  if (!database.suppliers) database.suppliers = [];
  if (!database.assets) database.assets = [];
  if (!database.assetCategories) database.assetCategories = [];
  if (!database.stockBalances) database.stockBalances = [];
  if (!database.stockMovements) database.stockMovements = [];
  if (!database.stockTransactions) database.stockTransactions = [];
  if (!database.assetAssignments) database.assetAssignments = [];
  if (!database.assetTransfers) database.assetTransfers = [];
  if (!database.assetReturns) database.assetReturns = [];
  if (!database.assetTimelineEvents) database.assetTimelineEvents = [];
  if (!database.purchaseRequests) database.purchaseRequests = [];
  if (!database.purchaseOrders) database.purchaseOrders = [];
  if (!database.goodsReceipts) database.goodsReceipts = [];
  if (!database.issueRequests) database.issueRequests = [];
  if (!database.stockIssues) database.stockIssues = [];
  if (!database.inventoryReturns) database.inventoryReturns = [];
}

/**
 * Authoritatively resolves the school/tenant context from the server/session.
 * Never trusts schoolId or tenantId supplied in request body or query parameters.
 */
function resolveSchoolId(req: AuthenticatedRequest): string {
  if (req?.tenant?.schoolId) return req.tenant.schoolId;
  if (req?.user?.schoolId) return req.user.schoolId;
  return database.schoolSettings?.id || 'school-main';
}

// ============================================================================
// CONCURRENCY-SAFE CODE GENERATORS
// ============================================================================

function generateNextSKU(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let counter = database.inventoryItems.filter(i => i.schoolId === schoolId).length + 1;
  let code = `SKU-${year}-${String(counter).padStart(4, '0')}`;
  while (database.inventoryItems.some(i => i.schoolId === schoolId && i.itemCode.toUpperCase() === code.toUpperCase())) {
    counter++;
    code = `SKU-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

function generateNextAssetTag(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let counter = database.assets.filter(a => a.schoolId === schoolId).length + 1;
  let tag = `AST-${year}-${String(counter).padStart(4, '0')}`;
  while (database.assets.some(a => a.schoolId === schoolId && a.assetTag.toUpperCase() === tag.toUpperCase())) {
    counter++;
    tag = `AST-${year}-${String(counter).padStart(4, '0')}`;
  }
  return tag;
}

function generateNextSupplierCode(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let counter = database.suppliers.filter(s => s.schoolId === schoolId).length + 1;
  let code = `SUP-${year}-${String(counter).padStart(3, '0')}`;
  while (database.suppliers.some(s => s.schoolId === schoolId && s.supplierCode.toUpperCase() === code.toUpperCase())) {
    counter++;
    code = `SUP-${year}-${String(counter).padStart(3, '0')}`;
  }
  return code;
}

// ============================================================================
// 1. DASHBOARD & OVERVIEW
// ============================================================================

/**
 * GET /api/inventory/dashboard
 * Aggregates summary analytics across items, assets, locations, and suppliers
 */
inventoryRouter.get(
  '/dashboard',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);

      const items = database.inventoryItems.filter(i => i.schoolId === schoolId);
      const assets = database.assets.filter(a => a.schoolId === schoolId);
      const locations = database.inventoryLocations.filter(l => l.schoolId === schoolId);
      const suppliers = database.suppliers.filter(s => s.schoolId === schoolId);

      const totalItems = items.length;
      const activeItems = items.filter(i => i.status === 'ACTIVE').length;
      const totalAssets = assets.length;
      const activeAssets = assets.filter(a => a.status === 'ACTIVE' || a.status === 'AVAILABLE' || a.status === 'ASSIGNED').length;
      const totalLocations = locations.length;
      const totalSuppliers = suppliers.length;

      const totalAssetValuation = assets.reduce((sum, a) => sum + (Number(a.purchaseCost) || 0), 0);
      const lowStockThresholdItems = items.filter(i => i.status === 'ACTIVE' && i.reorderLevel > 0).length;
      const outOfStockConfiguredItems = items.filter(i => i.minStockLevel > 0).length;

      // Recent entries
      const recentItems = [...items]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);

      const recentAssets = [...assets]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);

      const stats: InventoryDashboardStats = {
        totalItems,
        activeItems,
        totalAssets,
        activeAssets,
        totalLocations,
        totalSuppliers,
        totalAssetValuation: Math.round(totalAssetValuation * 100) / 100,
        lowStockThresholdItems,
        outOfStockConfiguredItems,
        recentItems,
        recentAssets
      };

      res.json({
        success: true,
        data: stats
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to load inventory dashboard statistics' });
    }
  }
);

/**
 * GET /api/inventory/analytics/comprehensive
 * Master multi-module analytical aggregation: Stock ledger, movements, assets,
 * procurement, issues/returns, department allocations, and 100% data reconciliation
 */
inventoryRouter.get(
  '/analytics/comprehensive',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const {
        datePreset,
        startDate,
        endDate,
        departmentId,
        locationId,
        categoryId,
        slowMovingThresholdDays
      } = req.query;

      const analytics = InventoryAnalyticsService.getComprehensiveAnalytics(schoolId, {
        datePreset: datePreset as any,
        startDate: startDate as string,
        endDate: endDate as string,
        departmentId: departmentId as string,
        locationId: locationId as string,
        categoryId: categoryId as string,
        slowMovingThresholdDays: slowMovingThresholdDays ? Number(slowMovingThresholdDays) : undefined
      });

      res.json({
        success: true,
        data: analytics
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to generate comprehensive inventory analytics' });
    }
  }
);

/**
 * GET /api/inventory/analytics/reconciliation
 * Explicit cross-module reconciliation test endpoint
 */
inventoryRouter.get(
  '/analytics/reconciliation',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const analytics = InventoryAnalyticsService.getComprehensiveAnalytics(schoolId, { datePreset: 'ALL_TIME' });
      res.json({
        success: true,
        data: analytics.reconciliation
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to verify data reconciliation' });
    }
  }
);

/**
 * GET /api/inventory/global-search
 * Searches across items, assets, locations, suppliers, POs, and issues simultaneously
 */
inventoryRouter.get(
  '/global-search',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const q = ((req.query.q as string) || '').trim();

      const results = InventoryAnalyticsService.searchGlobalInventory(schoolId, q);

      res.json({
        success: true,
        data: results
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Global search failed' });
    }
  }
);

// ============================================================================
// 2. INVENTORY ITEM MASTER
// ============================================================================

/**
 * GET /api/inventory/items
 * List items with filtering, pagination, and sorting
 */
inventoryRouter.get(
  '/items',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);

      const {
        search,
        categoryId,
        itemType,
        status,
        locationId,
        page = '1',
        limit = '20',
        sortBy = 'name',
        sortOrder = 'asc'
      } = req.query as Record<string, string>;

      let items = database.inventoryItems.filter(i => i.schoolId === schoolId);

      // Search filter
      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        items = items.filter(i =>
          i.name.toLowerCase().includes(query) ||
          i.itemCode.toLowerCase().includes(query) ||
          (i.brand && i.brand.toLowerCase().includes(query)) ||
          (i.model && i.model.toLowerCase().includes(query)) ||
          (i.barcode && i.barcode.toLowerCase().includes(query)) ||
          (i.categoryName && i.categoryName.toLowerCase().includes(query))
        );
      }

      // Category filter
      if (categoryId && categoryId !== 'ALL') {
        items = items.filter(i => i.categoryId === categoryId);
      }

      // Item Type filter
      if (itemType && itemType !== 'ALL') {
        items = items.filter(i => i.itemType === itemType);
      }

      // Status filter
      if (status && status !== 'ALL') {
        items = items.filter(i => i.status === status);
      }

      // Location filter
      if (locationId && locationId !== 'ALL') {
        items = items.filter(i => i.locationId === locationId);
      }

      // Sorting
      items.sort((a, b) => {
        let fieldA: any = (a as any)[sortBy] || '';
        let fieldB: any = (b as any)[sortBy] || '';

        if (typeof fieldA === 'string') fieldA = fieldA.toLowerCase();
        if (typeof fieldB === 'string') fieldB = fieldB.toLowerCase();

        if (fieldA < fieldB) return sortOrder === 'desc' ? 1 : -1;
        if (fieldA > fieldB) return sortOrder === 'desc' ? -1 : 1;
        return 0;
      });

      // Pagination
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 20));
      const total = items.length;
      const totalPages = Math.ceil(total / limitNum) || 1;
      const paginatedItems = items.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginatedItems,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list inventory items' });
    }
  }
);

/**
 * GET /api/inventory/items/:id
 * Retrieve a specific inventory item
 */
inventoryRouter.get(
  '/items/:id',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const item = database.inventoryItems.find(i => i.id === req.params.id && i.schoolId === schoolId);

      if (!item) {
        res.status(404).json({ success: false, error: 'Inventory item not found' });
        return;
      }

      res.json({
        success: true,
        data: item
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve item' });
    }
  }
);

/**
 * POST /api/inventory/items
 * Create a new inventory item
 */
inventoryRouter.post(
  '/items',
  requireAuth,
  requirePermission('inventory.items.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const {
        itemCode,
        name,
        description,
        categoryId,
        subcategoryId,
        subcategoryName,
        unitId,
        itemType = 'CONSUMABLE',
        brand,
        model,
        barcode,
        imageUrl,
        minStockLevel = 0,
        reorderLevel = 0,
        maxStockLevel,
        status = 'ACTIVE',
        locationId,
        unitPrice = 0
      } = req.body;

      // Validation
      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Item name is required' });
        return;
      }

      if (!categoryId) {
        res.status(400).json({ success: false, error: 'Item category is required' });
        return;
      }

      const category = database.inventoryCategories.find(c => c.id === categoryId && c.schoolId === schoolId);
      if (!category) {
        res.status(400).json({ success: false, error: 'Invalid category specified' });
        return;
      }

      if (!unitId) {
        res.status(400).json({ success: false, error: 'Unit of measurement is required' });
        return;
      }

      const unit = database.inventoryUnits.find(u => u.id === unitId && u.schoolId === schoolId);
      if (!unit) {
        res.status(400).json({ success: false, error: 'Invalid unit of measurement specified' });
        return;
      }

      const validItemTypes: ItemType[] = ['CONSUMABLE', 'NON_CONSUMABLE', 'STOCK_ITEM', 'SERVICE'];
      if (!validItemTypes.includes(itemType)) {
        res.status(400).json({ success: false, error: `Invalid itemType. Must be one of: ${validItemTypes.join(', ')}` });
        return;
      }

      // SKU handling
      let finalSKU = itemCode ? itemCode.trim().toUpperCase() : '';
      if (finalSKU) {
        const skuExists = database.inventoryItems.some(
          i => i.schoolId === schoolId && i.itemCode.toUpperCase() === finalSKU
        );
        if (skuExists) {
          res.status(409).json({ success: false, error: `Item SKU '${finalSKU}' already exists in this school context.` });
          return;
        }
      } else {
        finalSKU = generateNextSKU(schoolId);
      }

      // Location resolution
      let locationName = '';
      if (locationId) {
        const loc = database.inventoryLocations.find(l => l.id === locationId && l.schoolId === schoolId);
        if (loc) locationName = loc.name;
      }

      const now = new Date().toISOString();
      const newItem: InventoryItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        schoolId,
        itemCode: finalSKU,
        name: name.trim(),
        description: description ? description.trim() : undefined,
        categoryId: category.id,
        categoryName: category.name,
        subcategoryId: subcategoryId || undefined,
        subcategoryName: subcategoryName || undefined,
        unitId: unit.id,
        unitName: unit.name,
        unitShortCode: unit.shortCode,
        itemType,
        brand: brand ? brand.trim() : undefined,
        model: model ? model.trim() : undefined,
        barcode: barcode ? barcode.trim() : undefined,
        imageUrl: imageUrl ? imageUrl.trim() : undefined,
        minStockLevel: Math.max(0, Number(minStockLevel) || 0),
        reorderLevel: Math.max(0, Number(reorderLevel) || 0),
        maxStockLevel: maxStockLevel !== undefined ? Math.max(0, Number(maxStockLevel)) : undefined,
        status: (status as InventoryItemStatus) || 'ACTIVE',
        isActive: status === 'ACTIVE',
        locationId: locationId || undefined,
        locationName: locationName || undefined,
        unitPrice: Math.max(0, Number(unitPrice) || 0),
        createdBy: req.user?.id || 'usr-admin-1',
        createdByName: req.user?.name || 'Administrator',
        createdAt: now,
        updatedAt: now
      };

      database.inventoryItems.unshift(newItem);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryItem',
        entityId: newItem.id,
        details: `Created inventory item '${newItem.name}' with SKU '${newItem.itemCode}' in category '${newItem.categoryName}'`,
        metadata: { itemCode: newItem.itemCode, categoryId: newItem.categoryId, itemType: newItem.itemType }
      });

      res.status(201).json({
        success: true,
        data: newItem,
        message: 'Inventory item created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create inventory item' });
    }
  }
);

/**
 * PUT /api/inventory/items/:id
 * Update an existing inventory item
 */
inventoryRouter.put(
  '/items/:id',
  requireAuth,
  requirePermission('inventory.items.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const item = database.inventoryItems.find(i => i.id === req.params.id && i.schoolId === schoolId);

      if (!item) {
        res.status(404).json({ success: false, error: 'Inventory item not found' });
        return;
      }

      const {
        itemCode,
        name,
        description,
        categoryId,
        subcategoryId,
        subcategoryName,
        unitId,
        itemType,
        brand,
        model,
        barcode,
        imageUrl,
        minStockLevel,
        reorderLevel,
        maxStockLevel,
        status,
        locationId,
        unitPrice
      } = req.body;

      if (name !== undefined) {
        if (!name || !name.trim()) {
          res.status(400).json({ success: false, error: 'Item name cannot be empty' });
          return;
        }
        item.name = name.trim();
      }

      if (itemCode !== undefined) {
        const trimmedCode = itemCode.trim().toUpperCase();
        if (!trimmedCode) {
          res.status(400).json({ success: false, error: 'Item SKU cannot be empty' });
          return;
        }
        if (trimmedCode !== item.itemCode.toUpperCase()) {
          const skuExists = database.inventoryItems.some(
            i => i.schoolId === schoolId && i.id !== item.id && i.itemCode.toUpperCase() === trimmedCode
          );
          if (skuExists) {
            res.status(409).json({ success: false, error: `SKU '${trimmedCode}' is already used by another item.` });
            return;
          }
          item.itemCode = trimmedCode;
        }
      }

      if (categoryId !== undefined) {
        const cat = database.inventoryCategories.find(c => c.id === categoryId && c.schoolId === schoolId);
        if (!cat) {
          res.status(400).json({ success: false, error: 'Category not found' });
          return;
        }
        item.categoryId = cat.id;
        item.categoryName = cat.name;
      }

      if (unitId !== undefined) {
        const unit = database.inventoryUnits.find(u => u.id === unitId && u.schoolId === schoolId);
        if (!unit) {
          res.status(400).json({ success: false, error: 'Unit not found' });
          return;
        }
        item.unitId = unit.id;
        item.unitName = unit.name;
        item.unitShortCode = unit.shortCode;
      }

      if (locationId !== undefined) {
        if (locationId) {
          const loc = database.inventoryLocations.find(l => l.id === locationId && l.schoolId === schoolId);
          item.locationId = loc ? loc.id : undefined;
          item.locationName = loc ? loc.name : undefined;
        } else {
          item.locationId = undefined;
          item.locationName = undefined;
        }
      }

      if (itemType !== undefined) item.itemType = itemType;
      if (description !== undefined) item.description = description ? description.trim() : undefined;
      if (subcategoryId !== undefined) item.subcategoryId = subcategoryId || undefined;
      if (subcategoryName !== undefined) item.subcategoryName = subcategoryName || undefined;
      if (brand !== undefined) item.brand = brand ? brand.trim() : undefined;
      if (model !== undefined) item.model = model ? model.trim() : undefined;
      if (barcode !== undefined) item.barcode = barcode ? barcode.trim() : undefined;
      if (imageUrl !== undefined) item.imageUrl = imageUrl ? imageUrl.trim() : undefined;
      if (minStockLevel !== undefined) item.minStockLevel = Math.max(0, Number(minStockLevel) || 0);
      if (reorderLevel !== undefined) item.reorderLevel = Math.max(0, Number(reorderLevel) || 0);
      if (maxStockLevel !== undefined) item.maxStockLevel = Math.max(0, Number(maxStockLevel) || 0);
      if (unitPrice !== undefined) item.unitPrice = Math.max(0, Number(unitPrice) || 0);

      if (status !== undefined) {
        item.status = status;
        item.isActive = status === 'ACTIVE';
      }

      item.updatedBy = req.user?.id || 'usr-admin-1';
      item.updatedByName = req.user?.name || 'Administrator';
      item.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'InventoryItem',
        entityId: item.id,
        details: `Updated inventory item '${item.name}' (${item.itemCode})`,
        metadata: { itemCode: item.itemCode, status: item.status }
      });

      res.json({
        success: true,
        data: item,
        message: 'Inventory item updated successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update item' });
    }
  }
);

/**
 * PATCH /api/inventory/items/:id/status
 * Toggle or update item status
 */
inventoryRouter.patch(
  '/items/:id/status',
  requireAuth,
  requirePermission('inventory.items.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const item = database.inventoryItems.find(i => i.id === req.params.id && i.schoolId === schoolId);

      if (!item) {
        res.status(404).json({ success: false, error: 'Inventory item not found' });
        return;
      }

      const { status } = req.body;
      const validStatuses: InventoryItemStatus[] = ['ACTIVE', 'INACTIVE', 'DISCONTINUED'];
      if (!validStatuses.includes(status)) {
        res.status(400).json({ success: false, error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
        return;
      }

      const oldStatus = item.status;
      item.status = status;
      item.isActive = status === 'ACTIVE';
      item.updatedBy = req.user?.id || 'usr-admin-1';
      item.updatedByName = req.user?.name || 'Administrator';
      item.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'InventoryItem',
        entityId: item.id,
        details: `Changed item '${item.name}' status from ${oldStatus} to ${status}`,
        metadata: { oldStatus, newStatus: status }
      });

      res.json({
        success: true,
        data: item,
        message: `Item status updated to ${status}`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update item status' });
    }
  }
);

/**
 * DELETE /api/inventory/items/:id
 * Delete an inventory item
 */
inventoryRouter.delete(
  '/items/:id',
  requireAuth,
  requirePermission('inventory.items.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const index = database.inventoryItems.findIndex(i => i.id === req.params.id && i.schoolId === schoolId);

      if (index === -1) {
        res.status(404).json({ success: false, error: 'Inventory item not found' });
        return;
      }

      const removed = database.inventoryItems.splice(index, 1)[0];

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'DELETE',
        entity: 'OTHER',
        entityType: 'InventoryItem',
        entityId: removed.id,
        details: `Deleted inventory item '${removed.name}' (${removed.itemCode})`,
        metadata: { itemCode: removed.itemCode }
      });

      res.json({
        success: true,
        message: `Inventory item '${removed.name}' deleted successfully`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete item' });
    }
  }
);

// ============================================================================
// 3. CATEGORY MANAGEMENT
// ============================================================================

/**
 * GET /api/inventory/categories
 * List inventory categories
 */
inventoryRouter.get(
  '/categories',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { search, status } = req.query as Record<string, string>;

      let categories = database.inventoryCategories.filter(c => c.schoolId === schoolId);

      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        categories = categories.filter(c =>
          c.name.toLowerCase().includes(query) ||
          c.code.toLowerCase().includes(query) ||
          (c.description && c.description.toLowerCase().includes(query))
        );
      }

      if (status && status !== 'ALL') {
        categories = categories.filter(c => c.status === status);
      }

      // Add item count to each category
      const categoriesWithCount = categories.map(cat => ({
        ...cat,
        itemCount: database.inventoryItems.filter(i => i.schoolId === schoolId && i.categoryId === cat.id).length
      }));

      res.json({
        success: true,
        data: categoriesWithCount
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list categories' });
    }
  }
);

/**
 * POST /api/inventory/categories
 * Create an inventory category
 */
inventoryRouter.post(
  '/categories',
  requireAuth,
  requirePermission('inventory.categories.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { name, code, description, parentCategoryId, status = 'ACTIVE' } = req.body;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Category name is required' });
        return;
      }

      const generatedCode = code && code.trim()
        ? code.trim().toUpperCase()
        : `CAT-${name.trim().substring(0, 4).toUpperCase()}-${Date.now().toString(36).substring(3, 6).toUpperCase()}`;

      // Check duplicate code
      const duplicateCode = database.inventoryCategories.some(
        c => c.schoolId === schoolId && c.code.toUpperCase() === generatedCode
      );
      if (duplicateCode) {
        res.status(409).json({ success: false, error: `Category code '${generatedCode}' already exists.` });
        return;
      }

      let parentCategoryName: string | undefined;
      if (parentCategoryId) {
        const parent = database.inventoryCategories.find(c => c.id === parentCategoryId && c.schoolId === schoolId);
        if (parent) parentCategoryName = parent.name;
      }

      const now = new Date().toISOString();
      const newCategory: InventoryCategory = {
        id: `cat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        name: name.trim(),
        code: generatedCode,
        description: description ? description.trim() : undefined,
        parentCategoryId: parentCategoryId || undefined,
        parentCategoryName,
        status: status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        createdBy: req.user?.id || 'usr-admin-1',
        createdAt: now,
        updatedAt: now
      };

      database.inventoryCategories.push(newCategory);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryCategory',
        entityId: newCategory.id,
        details: `Created inventory category '${newCategory.name}' (${newCategory.code})`
      });

      res.status(201).json({
        success: true,
        data: newCategory,
        message: 'Category created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create category' });
    }
  }
);

/**
 * PUT /api/inventory/categories/:id
 * Update an inventory category
 */
inventoryRouter.put(
  '/categories/:id',
  requireAuth,
  requirePermission('inventory.categories.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const category = database.inventoryCategories.find(c => c.id === req.params.id && c.schoolId === schoolId);

      if (!category) {
        res.status(404).json({ success: false, error: 'Category not found' });
        return;
      }

      const { name, code, description, parentCategoryId, status } = req.body;

      if (name !== undefined) {
        if (!name || !name.trim()) {
          res.status(400).json({ success: false, error: 'Category name cannot be empty' });
          return;
        }
        category.name = name.trim();

        // Propagate name change to items in this category
        database.inventoryItems.forEach(i => {
          if (i.categoryId === category.id) {
            i.categoryName = category.name;
          }
        });
      }

      if (code !== undefined) {
        const trimmedCode = code.trim().toUpperCase();
        if (trimmedCode !== category.code.toUpperCase()) {
          const duplicate = database.inventoryCategories.some(
            c => c.schoolId === schoolId && c.id !== category.id && c.code.toUpperCase() === trimmedCode
          );
          if (duplicate) {
            res.status(409).json({ success: false, error: `Category code '${trimmedCode}' is already taken.` });
            return;
          }
          category.code = trimmedCode;
        }
      }

      if (description !== undefined) category.description = description ? description.trim() : undefined;
      if (parentCategoryId !== undefined) category.parentCategoryId = parentCategoryId || undefined;
      if (status !== undefined) category.status = status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';

      category.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'InventoryCategory',
        entityId: category.id,
        details: `Updated inventory category '${category.name}'`
      });

      res.json({
        success: true,
        data: category,
        message: 'Category updated successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update category' });
    }
  }
);

/**
 * DELETE /api/inventory/categories/:id
 * Delete category (blocked if items are assigned)
 */
inventoryRouter.delete(
  '/categories/:id',
  requireAuth,
  requirePermission('inventory.categories.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const index = database.inventoryCategories.findIndex(c => c.id === req.params.id && c.schoolId === schoolId);

      if (index === -1) {
        res.status(404).json({ success: false, error: 'Category not found' });
        return;
      }

      const assignedCount = database.inventoryItems.filter(
        i => i.schoolId === schoolId && i.categoryId === req.params.id
      ).length;

      if (assignedCount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete category. There are ${assignedCount} active inventory items assigned to this category.`
        });
        return;
      }

      const removed = database.inventoryCategories.splice(index, 1)[0];

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'DELETE',
        entity: 'OTHER',
        entityType: 'InventoryCategory',
        entityId: removed.id,
        details: `Deleted inventory category '${removed.name}' (${removed.code})`
      });

      res.json({
        success: true,
        message: `Category '${removed.name}' deleted successfully`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete category' });
    }
  }
);

// ============================================================================
// 4. UNIT OF MEASUREMENT
// ============================================================================

/**
 * GET /api/inventory/units
 * List units of measurement
 */
inventoryRouter.get(
  '/units',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { search, status } = req.query as Record<string, string>;

      let units = database.inventoryUnits.filter(u => u.schoolId === schoolId);

      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        units = units.filter(u =>
          u.name.toLowerCase().includes(query) ||
          u.shortCode.toLowerCase().includes(query)
        );
      }

      if (status && status !== 'ALL') {
        units = units.filter(u => u.status === status);
      }

      res.json({
        success: true,
        data: units
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list units' });
    }
  }
);

/**
 * POST /api/inventory/units
 * Create a new unit of measurement
 */
inventoryRouter.post(
  '/units',
  requireAuth,
  requirePermission('inventory.units.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { name, shortCode, description, status = 'ACTIVE' } = req.body;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Unit name is required' });
        return;
      }

      if (!shortCode || !shortCode.trim()) {
        res.status(400).json({ success: false, error: 'Unit short code is required (e.g. PCS, BOX)' });
        return;
      }

      const trimmedCode = shortCode.trim().toUpperCase();
      const duplicate = database.inventoryUnits.some(
        u => u.schoolId === schoolId && u.shortCode.toUpperCase() === trimmedCode
      );
      if (duplicate) {
        res.status(409).json({ success: false, error: `Unit code '${trimmedCode}' already exists.` });
        return;
      }

      const now = new Date().toISOString();
      const newUnit: InventoryUnit = {
        id: `unit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        name: name.trim(),
        shortCode: trimmedCode,
        description: description ? description.trim() : undefined,
        status: status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        createdAt: now,
        updatedAt: now
      };

      database.inventoryUnits.push(newUnit);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryUnit',
        entityId: newUnit.id,
        details: `Created unit of measurement '${newUnit.name}' (${newUnit.shortCode})`
      });

      res.status(201).json({
        success: true,
        data: newUnit,
        message: 'Unit of measurement created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create unit' });
    }
  }
);

/**
 * PUT /api/inventory/units/:id
 * Update an existing unit of measurement
 */
inventoryRouter.put(
  '/units/:id',
  requireAuth,
  requirePermission('inventory.units.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const unit = database.inventoryUnits.find(u => u.id === req.params.id && u.schoolId === schoolId);

      if (!unit) {
        res.status(404).json({ success: false, error: 'Unit not found' });
        return;
      }

      const { name, shortCode, description, status } = req.body;

      if (name !== undefined) {
        if (!name || !name.trim()) {
          res.status(400).json({ success: false, error: 'Unit name cannot be empty' });
          return;
        }
        unit.name = name.trim();
        // Propagate to items
        database.inventoryItems.forEach(i => {
          if (i.unitId === unit.id) i.unitName = unit.name;
        });
      }

      if (shortCode !== undefined) {
        const trimmedCode = shortCode.trim().toUpperCase();
        if (trimmedCode !== unit.shortCode.toUpperCase()) {
          const duplicate = database.inventoryUnits.some(
            u => u.schoolId === schoolId && u.id !== unit.id && u.shortCode.toUpperCase() === trimmedCode
          );
          if (duplicate) {
            res.status(409).json({ success: false, error: `Unit code '${trimmedCode}' is already taken.` });
            return;
          }
          unit.shortCode = trimmedCode;
          database.inventoryItems.forEach(i => {
            if (i.unitId === unit.id) i.unitShortCode = unit.shortCode;
          });
        }
      }

      if (description !== undefined) unit.description = description ? description.trim() : undefined;
      if (status !== undefined) unit.status = status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';

      unit.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'InventoryUnit',
        entityId: unit.id,
        details: `Updated unit of measurement '${unit.name}' (${unit.shortCode})`
      });

      res.json({
        success: true,
        data: unit,
        message: 'Unit updated successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update unit' });
    }
  }
);

/**
 * DELETE /api/inventory/units/:id
 * Delete unit (blocked if items are using it)
 */
inventoryRouter.delete(
  '/units/:id',
  requireAuth,
  requirePermission('inventory.units.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const index = database.inventoryUnits.findIndex(u => u.id === req.params.id && u.schoolId === schoolId);

      if (index === -1) {
        res.status(404).json({ success: false, error: 'Unit not found' });
        return;
      }

      const assignedCount = database.inventoryItems.filter(
        i => i.schoolId === schoolId && i.unitId === req.params.id
      ).length;

      if (assignedCount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete unit. There are ${assignedCount} inventory items using this unit.`
        });
        return;
      }

      const removed = database.inventoryUnits.splice(index, 1)[0];

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'DELETE',
        entity: 'OTHER',
        entityType: 'InventoryUnit',
        entityId: removed.id,
        details: `Deleted unit of measurement '${removed.name}' (${removed.shortCode})`
      });

      res.json({
        success: true,
        message: `Unit '${removed.name}' deleted successfully`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete unit' });
    }
  }
);

// ============================================================================
// 5. STORE / LOCATION FOUNDATION
// ============================================================================

/**
 * GET /api/inventory/locations
 * List locations / store facilities
 */
inventoryRouter.get(
  '/locations',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { search, status, department } = req.query as Record<string, string>;

      let locations = database.inventoryLocations.filter(l => l.schoolId === schoolId);

      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        locations = locations.filter(l =>
          l.name.toLowerCase().includes(query) ||
          l.code.toLowerCase().includes(query) ||
          (l.department && l.department.toLowerCase().includes(query)) ||
          (l.responsibleStaffName && l.responsibleStaffName.toLowerCase().includes(query))
        );
      }

      if (status && status !== 'ALL') {
        locations = locations.filter(l => l.status === status);
      }

      if (department && department !== 'ALL') {
        locations = locations.filter(l => l.department === department);
      }

      // Compute item count & asset count at each location
      const locationsWithMetrics = locations.map(loc => ({
        ...loc,
        itemCount: database.inventoryItems.filter(i => i.schoolId === schoolId && i.locationId === loc.id).length,
        assetCount: database.assets.filter(a => a.schoolId === schoolId && a.locationId === loc.id).length
      }));

      res.json({
        success: true,
        data: locationsWithMetrics
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list locations' });
    }
  }
);

/**
 * POST /api/inventory/locations
 * Create a new store / location
 */
inventoryRouter.post(
  '/locations',
  requireAuth,
  requirePermission('inventory.locations.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { name, code, description, department, departmentId, responsibleStaffId, responsibleStaffName, status = 'ACTIVE' } = req.body;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Location name is required' });
        return;
      }

      const generatedCode = code && code.trim()
        ? code.trim().toUpperCase()
        : `LOC-${name.trim().substring(0, 4).toUpperCase()}-${Date.now().toString(36).substring(3, 6).toUpperCase()}`;

      const duplicate = database.inventoryLocations.some(
        l => l.schoolId === schoolId && l.code.toUpperCase() === generatedCode
      );
      if (duplicate) {
        res.status(409).json({ success: false, error: `Location code '${generatedCode}' already exists.` });
        return;
      }

      const now = new Date().toISOString();
      const newLoc: InventoryLocation = {
        id: `loc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        name: name.trim(),
        code: generatedCode,
        description: description ? description.trim() : undefined,
        department: department ? department.trim() : undefined,
        departmentId: departmentId || undefined,
        responsibleStaffId: responsibleStaffId || undefined,
        responsibleStaffName: responsibleStaffName ? responsibleStaffName.trim() : undefined,
        status: status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        createdAt: now,
        updatedAt: now
      };

      database.inventoryLocations.push(newLoc);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryLocation',
        entityId: newLoc.id,
        details: `Created inventory location '${newLoc.name}' (${newLoc.code})`
      });

      res.status(201).json({
        success: true,
        data: newLoc,
        message: 'Location created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create location' });
    }
  }
);

/**
 * PUT /api/inventory/locations/:id
 * Update an existing store / location
 */
inventoryRouter.put(
  '/locations/:id',
  requireAuth,
  requirePermission('inventory.locations.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const loc = database.inventoryLocations.find(l => l.id === req.params.id && l.schoolId === schoolId);

      if (!loc) {
        res.status(404).json({ success: false, error: 'Location not found' });
        return;
      }

      const { name, code, description, department, departmentId, responsibleStaffId, responsibleStaffName, status } = req.body;

      if (name !== undefined) {
        if (!name || !name.trim()) {
          res.status(400).json({ success: false, error: 'Location name cannot be empty' });
          return;
        }
        loc.name = name.trim();
        // Propagate to items & assets
        database.inventoryItems.forEach(i => {
          if (i.locationId === loc.id) i.locationName = loc.name;
        });
        database.assets.forEach(a => {
          if (a.locationId === loc.id) a.locationName = loc.name;
        });
      }

      if (code !== undefined) {
        const trimmedCode = code.trim().toUpperCase();
        if (trimmedCode !== loc.code.toUpperCase()) {
          const duplicate = database.inventoryLocations.some(
            l => l.schoolId === schoolId && l.id !== loc.id && l.code.toUpperCase() === trimmedCode
          );
          if (duplicate) {
            res.status(409).json({ success: false, error: `Location code '${trimmedCode}' is already taken.` });
            return;
          }
          loc.code = trimmedCode;
        }
      }

      if (description !== undefined) loc.description = description ? description.trim() : undefined;
      if (department !== undefined) loc.department = department ? department.trim() : undefined;
      if (departmentId !== undefined) loc.departmentId = departmentId || undefined;
      if (responsibleStaffId !== undefined) loc.responsibleStaffId = responsibleStaffId || undefined;
      if (responsibleStaffName !== undefined) loc.responsibleStaffName = responsibleStaffName ? responsibleStaffName.trim() : undefined;
      if (status !== undefined) loc.status = status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';

      loc.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'InventoryLocation',
        entityId: loc.id,
        details: `Updated inventory location '${loc.name}' (${loc.code})`
      });

      res.json({
        success: true,
        data: loc,
        message: 'Location updated successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update location' });
    }
  }
);

/**
 * DELETE /api/inventory/locations/:id
 * Delete location (blocked if items or assets are stationed there)
 */
inventoryRouter.delete(
  '/locations/:id',
  requireAuth,
  requirePermission('inventory.locations.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const index = database.inventoryLocations.findIndex(l => l.id === req.params.id && l.schoolId === schoolId);

      if (index === -1) {
        res.status(404).json({ success: false, error: 'Location not found' });
        return;
      }

      const assignedItems = database.inventoryItems.filter(i => i.schoolId === schoolId && i.locationId === req.params.id).length;
      const assignedAssets = database.assets.filter(a => a.schoolId === schoolId && a.locationId === req.params.id).length;

      if (assignedItems > 0 || assignedAssets > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete location. There are ${assignedItems} item(s) and ${assignedAssets} asset(s) stationed at this location.`
        });
        return;
      }

      const removed = database.inventoryLocations.splice(index, 1)[0];

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'DELETE',
        entity: 'OTHER',
        entityType: 'InventoryLocation',
        entityId: removed.id,
        details: `Deleted inventory location '${removed.name}' (${removed.code})`
      });

      res.json({
        success: true,
        message: `Location '${removed.name}' deleted successfully`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete location' });
    }
  }
);

// ============================================================================
// 6. SUPPLIER FOUNDATION
// ============================================================================

/**
 * GET /api/inventory/suppliers
 * List suppliers with search, status, and pagination
 */
inventoryRouter.get(
  '/suppliers',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { search, status, page = '1', limit = '20' } = req.query as Record<string, string>;

      let suppliers = database.suppliers.filter(s => s.schoolId === schoolId);

      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        suppliers = suppliers.filter(s =>
          s.name.toLowerCase().includes(query) ||
          s.supplierCode.toLowerCase().includes(query) ||
          s.contactPerson.toLowerCase().includes(query) ||
          s.email.toLowerCase().includes(query) ||
          s.phone.toLowerCase().includes(query) ||
          (s.city && s.city.toLowerCase().includes(query))
        );
      }

      if (status && status !== 'ALL') {
        suppliers = suppliers.filter(s => s.status === status);
      }

      // Metrics: number of assets supplied
      const enrichedSuppliers = suppliers.map(sup => ({
        ...sup,
        assetCount: database.assets.filter(a => a.schoolId === schoolId && a.supplierId === sup.id).length
      }));

      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 20));
      const total = enrichedSuppliers.length;
      const totalPages = Math.ceil(total / limitNum) || 1;
      const paginated = enrichedSuppliers.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: pageNum,
          limit: limitNum,
          totalPages
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list suppliers' });
    }
  }
);

/**
 * GET /api/inventory/suppliers/:id
 * Retrieve a specific supplier with supplied assets
 */
inventoryRouter.get(
  '/suppliers/:id',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const supplier = database.suppliers.find(s => s.id === req.params.id && s.schoolId === schoolId);

      if (!supplier) {
        res.status(404).json({ success: false, error: 'Supplier not found' });
        return;
      }

      const suppliedAssets = database.assets.filter(a => a.schoolId === schoolId && a.supplierId === supplier.id);

      res.json({
        success: true,
        data: {
          ...supplier,
          assets: suppliedAssets
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve supplier' });
    }
  }
);

/**
 * POST /api/inventory/suppliers
 * Create a new supplier
 */
inventoryRouter.post(
  '/suppliers',
  requireAuth,
  requirePermission('inventory.suppliers.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const {
        supplierCode,
        name,
        contactPerson,
        phone,
        email,
        address,
        city,
        taxNumber,
        status = 'ACTIVE',
        notes
      } = req.body;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Supplier company name is required' });
        return;
      }

      if (!contactPerson || !contactPerson.trim()) {
        res.status(400).json({ success: false, error: 'Contact person name is required' });
        return;
      }

      if (!phone || !phone.trim()) {
        res.status(400).json({ success: false, error: 'Phone number is required' });
        return;
      }

      if (!email || !email.trim()) {
        res.status(400).json({ success: false, error: 'Email address is required' });
        return;
      }

      let finalCode = supplierCode ? supplierCode.trim().toUpperCase() : '';
      if (finalCode) {
        const duplicate = database.suppliers.some(
          s => s.schoolId === schoolId && s.supplierCode.toUpperCase() === finalCode
        );
        if (duplicate) {
          res.status(409).json({ success: false, error: `Supplier code '${finalCode}' already exists.` });
          return;
        }
      } else {
        finalCode = generateNextSupplierCode(schoolId);
      }

      const now = new Date().toISOString();
      const newSupplier: Supplier = {
        id: `sup-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        supplierCode: finalCode,
        name: name.trim(),
        contactPerson: contactPerson.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address ? address.trim() : '',
        city: city ? city.trim() : undefined,
        taxNumber: taxNumber ? taxNumber.trim() : undefined,
        status: status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        notes: notes ? notes.trim() : undefined,
        createdAt: now,
        updatedAt: now
      };

      database.suppliers.unshift(newSupplier);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'Supplier',
        entityId: newSupplier.id,
        details: `Created supplier '${newSupplier.name}' (${newSupplier.supplierCode})`
      });

      res.status(201).json({
        success: true,
        data: newSupplier,
        message: 'Supplier created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create supplier' });
    }
  }
);

/**
 * PUT /api/inventory/suppliers/:id
 * Update an existing supplier
 */
inventoryRouter.put(
  '/suppliers/:id',
  requireAuth,
  requirePermission('inventory.suppliers.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const supplier = database.suppliers.find(s => s.id === req.params.id && s.schoolId === schoolId);

      if (!supplier) {
        res.status(404).json({ success: false, error: 'Supplier not found' });
        return;
      }

      const { supplierCode, name, contactPerson, phone, email, address, city, taxNumber, status, notes } = req.body;

      if (name !== undefined) {
        if (!name || !name.trim()) {
          res.status(400).json({ success: false, error: 'Supplier name cannot be empty' });
          return;
        }
        supplier.name = name.trim();
        // Propagate to assets
        database.assets.forEach(a => {
          if (a.supplierId === supplier.id) a.supplierName = supplier.name;
        });
      }

      if (supplierCode !== undefined) {
        const trimmedCode = supplierCode.trim().toUpperCase();
        if (trimmedCode !== supplier.supplierCode.toUpperCase()) {
          const duplicate = database.suppliers.some(
            s => s.schoolId === schoolId && s.id !== supplier.id && s.supplierCode.toUpperCase() === trimmedCode
          );
          if (duplicate) {
            res.status(409).json({ success: false, error: `Supplier code '${trimmedCode}' already exists.` });
            return;
          }
          supplier.supplierCode = trimmedCode;
        }
      }

      if (contactPerson !== undefined) supplier.contactPerson = contactPerson ? contactPerson.trim() : supplier.contactPerson;
      if (phone !== undefined) supplier.phone = phone ? phone.trim() : supplier.phone;
      if (email !== undefined) supplier.email = email ? email.trim() : supplier.email;
      if (address !== undefined) supplier.address = address ? address.trim() : supplier.address;
      if (city !== undefined) supplier.city = city ? city.trim() : undefined;
      if (taxNumber !== undefined) supplier.taxNumber = taxNumber ? taxNumber.trim() : undefined;
      if (notes !== undefined) supplier.notes = notes ? notes.trim() : undefined;
      if (status !== undefined) supplier.status = status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';

      supplier.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'Supplier',
        entityId: supplier.id,
        details: `Updated supplier '${supplier.name}' (${supplier.supplierCode})`
      });

      res.json({
        success: true,
        data: supplier,
        message: 'Supplier updated successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update supplier' });
    }
  }
);

/**
 * DELETE /api/inventory/suppliers/:id
 * Delete supplier (blocked if assets are linked)
 */
inventoryRouter.delete(
  '/suppliers/:id',
  requireAuth,
  requirePermission('inventory.suppliers.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const index = database.suppliers.findIndex(s => s.id === req.params.id && s.schoolId === schoolId);

      if (index === -1) {
        res.status(404).json({ success: false, error: 'Supplier not found' });
        return;
      }

      const linkedAssets = database.assets.filter(a => a.schoolId === schoolId && a.supplierId === req.params.id).length;
      if (linkedAssets > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete supplier. There are ${linkedAssets} registered asset(s) linked to this vendor.`
        });
        return;
      }

      const linkedPOs = (database.purchaseOrders || []).filter(po => po.schoolId === schoolId && po.supplierId === req.params.id).length;
      if (linkedPOs > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete supplier. There are ${linkedPOs} Purchase Order(s) associated with this supplier.`
        });
        return;
      }

      const linkedGRNs = (database.goodsReceipts || []).filter(gr => gr.schoolId === schoolId && gr.supplierId === req.params.id).length;
      if (linkedGRNs > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete supplier. There are ${linkedGRNs} Goods Receipt(s) recorded from this supplier.`
        });
        return;
      }

      const removed = database.suppliers.splice(index, 1)[0];

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'DELETE',
        entity: 'OTHER',
        entityType: 'Supplier',
        entityId: removed.id,
        details: `Deleted supplier '${removed.name}' (${removed.supplierCode})`
      });

      res.json({
        success: true,
        message: `Supplier '${removed.name}' deleted successfully`
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete supplier' });
    }
  }
);

// ============================================================================
// 7. ASSET FOUNDATION & REGISTER
// ============================================================================

/**
 * GET /api/inventory/assets/categories
 * List asset categories
 */
inventoryRouter.get(
  '/assets/categories',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const categories = database.assetCategories.filter(c => c.schoolId === schoolId);

      const withCount = categories.map(cat => ({
        ...cat,
        assetCount: database.assets.filter(a => a.schoolId === schoolId && a.categoryId === cat.id).length
      }));

      res.json({
        success: true,
        data: withCount
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list asset categories' });
    }
  }
);

/**
 * POST /api/inventory/assets/categories
 * Create an asset category
 */
inventoryRouter.post(
  '/assets/categories',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureInventoryCollections();
      const schoolId = resolveSchoolId(req);
      const { name, code, description, status = 'ACTIVE' } = req.body;

      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Asset category name is required' });
        return;
      }

      const generatedCode = code && code.trim()
        ? code.trim().toUpperCase()
        : `ACAT-${name.trim().substring(0, 4).toUpperCase()}-${Date.now().toString(36).substring(3, 6).toUpperCase()}`;

      const duplicate = database.assetCategories.some(
        c => c.schoolId === schoolId && c.code.toUpperCase() === generatedCode
      );
      if (duplicate) {
        res.status(409).json({ success: false, error: `Asset category code '${generatedCode}' already exists.` });
        return;
      }

      const now = new Date().toISOString();
      const newCategory: AssetCategory = {
        id: `acat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        name: name.trim(),
        code: generatedCode,
        description: description ? description.trim() : undefined,
        status: status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        createdAt: now,
        updatedAt: now
      };

      database.assetCategories.push(newCategory);

      logAudit({
        userId: req.user?.id || 'usr-admin-1',
        userName: req.user?.name || 'Administrator',
        userRole: req.user?.role || 'SUPER_ADMIN',
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'AssetCategory',
        entityId: newCategory.id,
        details: `Created asset category '${newCategory.name}' (${newCategory.code})`
      });

      res.status(201).json({
        success: true,
        data: newCategory,
        message: 'Asset category created successfully'
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to create asset category' });
    }
  }
);

/**
 * GET /api/inventory/assets/summary
 * Asset Lifecycle KPIs, status counts, and warranty metrics
 */
inventoryRouter.get(
  '/assets/summary',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summary = AssetService.getAssetLifecycleSummary(schoolId);
      res.json({ success: true, data: summary });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch asset summary' });
    }
  }
);

/**
 * GET /api/inventory/assets/tag/:tag
 * Quick lookup by asset tag / barcode / QR code
 */
inventoryRouter.get(
  '/assets/tag/:tag',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = AssetService.getAssetByTag(schoolId, req.params.tag);
      res.json({ success: true, data: asset });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Asset not found by tag' });
    }
  }
);

/**
 * GET /api/inventory/assets
 * List assets with multifaceted filtering, sorting, and pagination
 */
inventoryRouter.get(
  '/assets',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const {
        search,
        categoryId,
        status,
        condition,
        locationId,
        supplierId,
        assigneeId,
        assigneeType,
        warrantyStatus,
        page,
        limit,
        sortBy,
        sortOrder
      } = req.query as Record<string, string>;

      const result = AssetService.getAssets(schoolId, {
        search,
        categoryId,
        status: status as any,
        condition: condition as any,
        locationId,
        supplierId,
        assigneeId,
        assigneeType: assigneeType as any,
        warrantyStatus: warrantyStatus as any,
        page: page ? parseInt(page, 10) : undefined,
        limit: limit ? parseInt(limit, 10) : undefined,
        sortBy,
        sortOrder: sortOrder as any
      });

      res.json({
        success: true,
        data: result.data,
        pagination: result.pagination
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list assets' });
    }
  }
);

/**
 * GET /api/inventory/assets/:id
 * Retrieve single asset with active assignment, recent history, and timeline
 */
inventoryRouter.get(
  '/assets/:id',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const details = AssetService.getAssetById(schoolId, req.params.id);
      res.json({
        success: true,
        data: details.asset,
        activeAssignment: details.activeAssignment,
        recentAssignments: details.recentAssignments,
        timeline: details.timeline
      });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Asset not found' });
    }
  }
);

/**
 * POST /api/inventory/assets
 * Register a new asset in the institutional register
 */
inventoryRouter.post(
  '/assets',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = AssetService.createAsset(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: asset,
        message: 'Asset registered successfully'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to register asset' });
    }
  }
);

/**
 * PUT /api/inventory/assets/:id
 * Update asset master specifications
 */
inventoryRouter.put(
  '/assets/:id',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = AssetService.updateAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset updated successfully'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to update asset' });
    }
  }
);

/**
 * DELETE /api/inventory/assets/:id
 * Safely delete an asset (guarded against active assignments)
 */
inventoryRouter.delete(
  '/assets/:id',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = AssetService.deleteAsset(schoolId, req.params.id, req.user);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to delete asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/assign
 * Assign an asset to a staff, teacher, department, location, or student
 * Serialized via withAssetLock
 */
inventoryRouter.post(
  '/assets/:id/assign',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await AssetService.assignAsset(schoolId, req.params.id, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result.asset,
        assignment: result.assignment,
        message: `Asset successfully assigned to ${result.assignment.assigneeName}`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to assign asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/return
 * Return an assigned asset back to institutional inventory
 * Serialized via withAssetLock
 */
inventoryRouter.post(
  '/assets/:id/return',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await AssetService.returnAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: result.asset,
        returnRecord: result.returnRecord,
        message: `Asset return processed successfully. Current status: ${result.asset.status}`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to return asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/transfer
 * Transfer custody directly from current custodian to a new custodian
 * Serialized via withAssetLock
 */
inventoryRouter.post(
  '/assets/:id/transfer',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await AssetService.transferAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: result.asset,
        transferRecord: result.transferRecord,
        newAssignment: result.newAssignment,
        message: `Asset successfully transferred to ${result.newAssignment.assigneeName}`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to transfer asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/send-repair
 * Send asset for maintenance/repair
 */
inventoryRouter.post(
  '/assets/:id/send-repair',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.sendForRepair(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset sent for maintenance/repair'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to send asset for repair' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/complete-repair
 * Mark repair completed and restore asset to AVAILABLE status
 */
inventoryRouter.post(
  '/assets/:id/complete-repair',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.completeRepair(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Repair marked complete. Asset is now available.'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to complete repair' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/mark-damaged
 * Mark asset as DAMAGED
 */
inventoryRouter.post(
  '/assets/:id/mark-damaged',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.markDamaged(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset marked as DAMAGED'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to mark asset as damaged' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/mark-lost
 * Report asset as LOST
 */
inventoryRouter.post(
  '/assets/:id/mark-lost',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.markLost(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset reported as LOST'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to report asset as lost' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/recover
 * Recover previously LOST asset
 */
inventoryRouter.post(
  '/assets/:id/recover',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.recoverAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset successfully recovered and restored to inventory'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to recover asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/retire
 * Decommission/retire asset
 */
inventoryRouter.post(
  '/assets/:id/retire',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.retireAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset decommissioned and retired'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to retire asset' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/dispose
 * Dispose asset (permanent terminal state)
 */
inventoryRouter.post(
  '/assets/:id/dispose',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = await AssetService.disposeAsset(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: asset,
        message: 'Asset recorded as DISPOSED'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to dispose asset' });
    }
  }
);

/**
 * PATCH /api/inventory/assets/:id/status
 * Generic status transition with validation
 */
inventoryRouter.patch(
  '/assets/:id/status',
  requireAuth,
  requirePermission('assets.status.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const { status, remarks = '' } = req.body;
      if (!status) {
        res.status(400).json({ success: false, error: 'Status is required' });
        return;
      }
      const asset = await AssetService.updateStatus(schoolId, req.params.id, status, remarks, req.user);
      res.json({
        success: true,
        data: asset,
        message: `Asset status transitioned to ${status}`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to update asset status' });
    }
  }
);

/**
 * GET /api/inventory/assets/:id/timeline
 * Complete chronological timeline of lifecycle events
 */
inventoryRouter.get(
  '/assets/:id/timeline',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const timeline = AssetService.getAssetTimeline(schoolId, req.params.id);
      res.json({ success: true, data: timeline });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch timeline' });
    }
  }
);

/**
 * GET /api/inventory/assets/:id/assignments
 * List assignment history
 */
inventoryRouter.get(
  '/assets/:id/assignments',
  requireAuth,
  requirePermission('assets.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const assignments = AssetService.getAssetAssignments(schoolId, req.params.id);
      res.json({ success: true, data: assignments });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch assignments' });
    }
  }
);

/**
 * POST /api/inventory/assets/:id/documents
 * Attach a document/warranty/invoice to an asset
 */
inventoryRouter.post(
  '/assets/:id/documents',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = AssetService.attachDocument(schoolId, req.params.id, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result.document,
        asset: result.asset,
        message: 'Document attached successfully'
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to attach document' });
    }
  }
);

/**
 * DELETE /api/inventory/assets/:id/documents/:docId
 * Remove a document from an asset
 */
inventoryRouter.delete(
  '/assets/:id/documents/:docId',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = AssetService.deleteDocument(schoolId, req.params.id, req.params.docId, req.user);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to remove document' });
    }
  }
);
