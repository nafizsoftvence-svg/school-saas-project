import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, AuthenticatedRequest } from '../security/auth.js';

export const notificationsRouter = Router();

// Get notifications for current user/role
notificationsRouter.get('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const relevant = database.notifications
    .filter((n) => n.userId === user.id || n.roleTarget === 'ALL' || n.roleTarget === user.role)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const unreadCount = relevant.filter((n) => !n.isRead).length;

  res.json({
    success: true,
    unreadCount,
    data: relevant
  });
});

// Mark single notification as read with authorization check (IDOR protection)
notificationsRouter.post('/:id/read', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { id } = req.params;
  const notif = database.notifications.find((n) => n.id === id);

  if (!notif) {
    res.status(404).json({ success: false, error: 'Notification not found.' });
    return;
  }

  // IDOR Protection: Verify notification belongs to user or their role
  const isAuthorized =
    notif.userId === user.id ||
    notif.roleTarget === 'ALL' ||
    notif.roleTarget === user.role ||
    user.role === 'SUPER_ADMIN';

  if (!isAuthorized) {
    res.status(403).json({ success: false, error: 'Forbidden. You cannot modify notifications belonging to another user.' });
    return;
  }

  notif.isRead = true;

  res.json({
    success: true,
    message: 'Notification marked as read.'
  });
});

// Mark all as read
notificationsRouter.post('/read-all', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  database.notifications.forEach((n) => {
    if (n.userId === user.id || n.roleTarget === 'ALL' || n.roleTarget === user.role) {
      n.isRead = true;
    }
  });

  res.json({
    success: true,
    message: 'All notifications marked as read.'
  });
});
