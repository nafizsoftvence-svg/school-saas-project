/**
 * Part 15A — Certificate & Document Management Foundation Routes
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { AuthenticatedRequest, requireAuth, requirePermission } from '../security/auth.js';
import { DocumentService } from '../services/document.service.js';
import { database } from '../db/database.js';

export const documentsRouter = Router();

// ==============================================================
// DASHBOARD METRICS & TYPES
// ==============================================================

/**
 * GET /api/documents/metrics
 * Returns comprehensive dashboard metrics for Document Management
 */
documentsRouter.get('/metrics', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const metrics = DocumentService.getDashboardMetrics(schoolId, req.user!);
    res.json({
      success: true,
      data: metrics
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve document metrics.'
    });
  }
});

/**
 * GET /api/documents/types
 * List configurable document categories & types
 */
documentsRouter.get('/types', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const { entityType, isActive } = req.query as Record<string, string>;
    const types = DocumentService.listDocumentTypes(
      schoolId,
      entityType as any,
      isActive !== undefined ? isActive === 'true' : undefined
    );
    res.json({
      success: true,
      data: types
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to list document types.'
    });
  }
});

/**
 * POST /api/documents/types
 * Create a new configurable document type
 */
documentsRouter.post(
  '/types',
  requireAuth,
  requirePermission('documents.types.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const created = DocumentService.createDocumentType(schoolId, req.body, req.user!);
      res.status(201).json({
        success: true,
        message: `Document type "${created.name}" created successfully.`,
        data: created
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to create document type.'
      });
    }
  }
);

/**
 * PUT /api/documents/types/:id
 * Update an existing document type
 */
documentsRouter.put(
  '/types/:id',
  requireAuth,
  requirePermission('documents.types.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = DocumentService.updateDocumentType(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `Document type "${updated.name}" updated successfully.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to update document type.'
      });
    }
  }
);

// ==============================================================
// CERTIFICATE TEMPLATES FOUNDATION
// ==============================================================

/**
 * GET /api/documents/certificate-templates
 * List certificate templates
 */
documentsRouter.get(
  '/certificate-templates',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { entityType, status } = req.query as Record<string, string>;
      const templates = DocumentService.listCertificateTemplates(schoolId, entityType as any, status as any);
      res.json({
        success: true,
        data: templates
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to retrieve certificate templates.'
      });
    }
  }
);

/**
 * GET /api/documents/certificate-templates/:id
 * Get certificate template detail
 */
documentsRouter.get(
  '/certificate-templates/:id',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const template = DocumentService.getCertificateTemplateById(schoolId, req.params.id);
      res.json({
        success: true,
        data: template
      });
    } catch (error: any) {
      res.status(404).json({
        success: false,
        error: error.message || 'Certificate template not found.'
      });
    }
  }
);

/**
 * POST /api/documents/certificate-templates
 * Create a new certificate template
 */
documentsRouter.post(
  '/certificate-templates',
  requireAuth,
  requirePermission('certificates.templates.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const template = DocumentService.createCertificateTemplate(schoolId, req.body, req.user!);
      res.status(201).json({
        success: true,
        message: `Certificate template "${template.name}" created successfully.`,
        data: template
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to create certificate template.'
      });
    }
  }
);

/**
 * PUT /api/documents/certificate-templates/:id
 * Update certificate template
 */
documentsRouter.put(
  '/certificate-templates/:id',
  requireAuth,
  requirePermission('certificates.templates.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const template = DocumentService.updateCertificateTemplate(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `Certificate template "${template.name}" updated successfully.`,
        data: template
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to update certificate template.'
      });
    }
  }
);

// ==============================================================
// MANAGED DOCUMENTS ENDPOINTS
// ==============================================================

/**
 * GET /api/documents
 * Central repository view with pagination, search, and multi-faceted filtering
 */
documentsRouter.get('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const result = DocumentService.listDocuments(schoolId, req.query as any, req.user!);
    res.json({
      success: true,
      data: result.items,
      pagination: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: result.totalPages
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch documents.'
    });
  }
});

// ==============================================================
// PART 15E — DOCUMENT REQUIREMENTS & CHECKLIST ENDPOINTS
// ==============================================================

/**
 * GET /api/documents/requirements
 * List configurable document requirements
 */
documentsRouter.get('/requirements', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const { entityType, isActive } = req.query as Record<string, string>;
    const reqs = DocumentService.listDocumentRequirements(
      schoolId,
      entityType as any,
      isActive !== undefined ? isActive === 'true' : undefined
    );
    res.json({
      success: true,
      data: reqs
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to list document requirements.'
    });
  }
});

/**
 * POST /api/documents/requirements
 * Create a new document requirement
 */
documentsRouter.post(
  '/requirements',
  requireAuth,
  requirePermission('documents.requirements.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const created = DocumentService.createDocumentRequirement(schoolId, req.body, req.user!);
      res.status(201).json({
        success: true,
        message: `Document requirement for "${created.documentTypeName}" created successfully.`,
        data: created
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to create document requirement.'
      });
    }
  }
);

/**
 * PUT /api/documents/requirements/:id
 * Update an existing document requirement
 */
documentsRouter.put(
  '/requirements/:id',
  requireAuth,
  requirePermission('documents.requirements.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = DocumentService.updateDocumentRequirement(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `Document requirement for "${updated.documentTypeName}" updated successfully.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to update document requirement.'
      });
    }
  }
);

/**
 * DELETE /api/documents/requirements/:id
 * Delete a document requirement
 */
documentsRouter.delete(
  '/requirements/:id',
  requireAuth,
  requirePermission('documents.requirements.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      DocumentService.deleteDocumentRequirement(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        message: 'Document requirement deleted successfully.'
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to delete document requirement.'
      });
    }
  }
);

/**
 * GET /api/documents/checklist/:entityType/:entityId
 * Authoritative compliance checklist summary for teacher, staff, guardian, student, or school
 */
documentsRouter.get('/checklist/:entityType/:entityId', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const { entityType, entityId } = req.params;
    const summary = DocumentService.getEntityDocumentChecklist(
      schoolId,
      entityType.toUpperCase() as any,
      entityId,
      req.user!
    );
    res.json({
      success: true,
      data: summary
    });
  } catch (error: any) {
    const status = error.message.includes('Access denied') ? 403 : error.message.includes('not found') ? 404 : 500;
    res.status(status).json({
      success: false,
      error: error.message || 'Failed to generate document checklist.'
    });
  }
});

/**
 * GET /api/documents/expiring
 * Track expiring and expired documents across staff, teachers, school, and other entities
 */
documentsRouter.get('/expiring', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const { entityType, daysThreshold, isExpired } = req.query as Record<string, string>;
    const expiring = DocumentService.getExpiringDocuments(
      schoolId,
      {
        entityType: entityType as any,
        daysThreshold: daysThreshold ? Number(daysThreshold) : 30,
        isExpired: isExpired !== undefined ? isExpired === 'true' : undefined
      },
      req.user!
    );
    res.json({
      success: true,
      data: expiring
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve expiring documents.'
    });
  }
});

/**
 * GET /api/documents/:id
 * Document detail with version history & metadata
 */
documentsRouter.get('/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const document = DocumentService.getDocumentById(schoolId, req.params.id, req.user!);
    res.json({
      success: true,
      data: document
    });
  } catch (error: any) {
    const status = error.message.includes('Access denied') ? 403 : 404;
    res.status(status).json({
      success: false,
      error: error.message || 'Document not found.'
    });
  }
});

/**
 * POST /api/documents
 * Upload / Register a new document with initial Version 1
 */
documentsRouter.post('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const document = DocumentService.createDocument(schoolId, req.body, req.user!);
    res.status(201).json({
      success: true,
      message: `Document "${document.documentTitle}" uploaded and registered successfully.`,
      data: document
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      error: error.message || 'Failed to upload document.'
    });
  }
});

/**
 * POST /api/documents/:id/version
 * Upload a replacement version/revision for an existing document record
 */
documentsRouter.post('/:id/version', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const updated = DocumentService.uploadNewVersion(schoolId, req.params.id, req.body, req.user!);
    res.json({
      success: true,
      message: `Version ${updated.version} uploaded successfully.`,
      data: updated
    });
  } catch (error: any) {
    const status = error.message.includes('Access denied') ? 403 : 400;
    res.status(status).json({
      success: false,
      error: error.message || 'Failed to upload new version.'
    });
  }
});

/**
 * POST /api/documents/:id/verify
 * Verification & Review endpoint (Admin / Reviewer only)
 */
documentsRouter.post(
  '/:id/verify',
  requireAuth,
  requirePermission('documents.verify'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = DocumentService.verifyDocument(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `Document status marked as ${updated.verificationStatus}.`,
        data: updated
      });
    } catch (error: any) {
      const status = error.message.includes('Access denied') ? 403 : 400;
      res.status(status).json({
        success: false,
        error: error.message || 'Failed to verify document.'
      });
    }
  }
);

/**
 * PUT /api/documents/:id
 * Edit document metadata (title, ref number, dates, notes, tags)
 */
documentsRouter.put('/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const updated = DocumentService.updateDocumentMetadata(schoolId, req.params.id, req.body, req.user!);
    res.json({
      success: true,
      message: 'Document metadata updated successfully.',
      data: updated
    });
  } catch (error: any) {
    const status = error.message.includes('Access denied') ? 403 : 400;
    res.status(status).json({
      success: false,
      error: error.message || 'Failed to update document metadata.'
    });
  }
});

/**
 * DELETE /api/documents/:id
 * Delete or archive document
 */
documentsRouter.delete('/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const { permanent } = req.query as Record<string, string>;

    if (permanent === 'true') {
      DocumentService.deleteDocument(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        message: 'Document removed permanently.'
      });
    } else {
      const archived = DocumentService.archiveDocument(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        message: `Document "${archived.documentTitle}" archived successfully.`,
        data: archived
      });
    }
  } catch (error: any) {
    const status = error.message.includes('Access denied') ? 403 : 400;
    res.status(status).json({
      success: false,
      error: error.message || 'Failed to delete/archive document.'
    });
  }
});

/**
 * GET /api/documents/:id/download
 * Secure download endpoint verifying authorization
 */
documentsRouter.get('/:id/download', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const schoolId = (req.user as any)?.schoolId || 'school-main';
    const doc = DocumentService.getDocumentById(schoolId, req.params.id, req.user!);
    res.json({
      success: true,
      data: {
        id: doc.id,
        fileName: doc.fileName,
        fileUrl: doc.fileUrl,
        fileType: doc.fileType,
        fileSize: doc.fileSize,
        version: doc.version
      }
    });
  } catch (error: any) {
    res.status(403).json({
      success: false,
      error: error.message || 'Access denied.'
    });
  }
});
