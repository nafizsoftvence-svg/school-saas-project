/**
 * Sygmate School Management System
 * Staff Attendance, Work Schedule & Leave Integration (Part 12B)
 * Express Router: /api/staff/attendance, /api/staff/schedules, /api/staff/leaves
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffAttendanceService } from '../services/staff-attendance.service.js';
import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { calculateLeaveWorkingDates } from './attendance.routes.js';
import {
  MarkStaffAttendancePayload,
  BulkMarkStaffAttendancePayload,
  CorrectStaffAttendancePayload,
  CreateStaffSchedulePayload,
  UpdateStaffSchedulePayload,
  StaffLeaveApplicationPayload,
  ReviewStaffLeavePayload
} from '../../src/types/index.js';

// Sub-routers
export const staffAttendanceRouter = Router();
export const staffScheduleRouter = Router();
export const staffLeaveRouter = Router();

// =========================================================================
// A. STAFF ATTENDANCE ENDPOINTS (/api/staff/attendance)
// =========================================================================

/**
 * GET /api/staff/attendance/daily
 * Daily staff attendance roster with effective work schedules and live stats
 */
staffAttendanceRouter.get(
  '/daily',
  requireAuth,
  requirePermission('staff.attendance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const date = (req.query.date as string) || todayStr;
      const departmentId = req.query.departmentId as string;
      const staffType = req.query.staffType as string;
      const status = req.query.status as string;
      const search = req.query.search as string;
      const academicSessionId = req.query.academicSessionId as string;

      const result = staffAttendanceService.getStaffDailyRoster(date, {
        departmentId,
        staffType,
        status,
        search,
        academicSessionId
      });

      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      console.error('[Staff Daily Attendance API Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve daily staff attendance roster.',
        code: 'STAFF_ATTENDANCE_DAILY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/attendance/monthly
 * Monthly attendance matrix with calendar working day statuses and aggregates
 */
staffAttendanceRouter.get(
  '/monthly',
  requireAuth,
  requirePermission('staff.attendance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const now = new Date();
      const year = req.query.year ? Number(req.query.year) : now.getFullYear();
      const month = req.query.month ? Number(req.query.month) : now.getMonth() + 1;
      const departmentId = req.query.departmentId as string;
      const staffType = req.query.staffType as string;
      const search = req.query.search as string;
      const academicSessionId = req.query.academicSessionId as string;

      const result = staffAttendanceService.getStaffMonthlyMatrix(year, month, {
        departmentId,
        staffType,
        search,
        academicSessionId
      });

      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      console.error('[Staff Monthly Attendance API Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to generate monthly staff attendance matrix.',
        code: 'STAFF_ATTENDANCE_MONTHLY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/attendance/stats
 * Aggregate institution attendance statistics and breakdowns
 */
staffAttendanceRouter.get(
  '/stats',
  requireAuth,
  requirePermission('staff.attendance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const date = req.query.date as string;
      const stats = staffAttendanceService.getStaffAttendanceStats(date);
      res.json({
        success: true,
        data: stats
      });
    } catch (err: any) {
      console.error('[Staff Attendance Stats API Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to calculate staff attendance statistics.',
        code: 'STAFF_ATTENDANCE_STATS_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/attendance/mark
 * Mark individual staff attendance with calendar verification and teacher-sync
 */
staffAttendanceRouter.post(
  '/mark',
  requireAuth,
  requirePermission('staff.attendance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as MarkStaffAttendancePayload;
      if (!payload.staffId || !payload.date || !payload.status) {
        res.status(400).json({
          success: false,
          error: 'staffId, date, and status are mandatory.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const record = staffAttendanceService.markStaffAttendance(payload, req.user!, req.ip);
      res.json({
        success: true,
        data: record,
        message: `Attendance marked as ${record.status} for ${record.staffName}.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to mark staff attendance.',
        code: 'STAFF_MARK_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/attendance/bulk
 * Bulk mark attendance for whole department or multiple staff
 */
staffAttendanceRouter.post(
  '/bulk',
  requireAuth,
  requirePermission('staff.attendance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as BulkMarkStaffAttendancePayload;
      const result = staffAttendanceService.bulkMarkStaffAttendance(payload, req.user!, req.ip);
      res.json({
        success: true,
        data: result,
        message: `Successfully recorded attendance for ${result.savedCount} staff members.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to bulk mark staff attendance.',
        code: 'STAFF_BULK_MARK_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/attendance/:id/correct
 * Correct an existing attendance record with reason and history logging
 */
staffAttendanceRouter.put(
  '/:id/correct',
  requireAuth,
  requirePermission('staff.attendance.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CorrectStaffAttendancePayload;
      if (!payload.reason || payload.reason.trim().length < 3) {
        res.status(400).json({
          success: false,
          error: 'A detailed correction reason is required for audit trail purposes.',
          code: 'REASON_REQUIRED'
        });
        return;
      }

      const record = staffAttendanceService.correctStaffAttendance(req.params.id, payload, req.user!, req.ip);
      res.json({
        success: true,
        data: record,
        message: `Attendance record updated with correction note recorded in audit trail.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to correct staff attendance record.',
        code: 'STAFF_CORRECTION_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/attendance/export
 * Export staff attendance to CSV format
 */
staffAttendanceRouter.get(
  '/export',
  requireAuth,
  requirePermission('staff.attendance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const date = (req.query.date as string) || new Date().toISOString().split('T')[0];
      const departmentId = req.query.departmentId as string;
      const staffType = req.query.staffType as string;

      const data = staffAttendanceService.getStaffDailyRoster(date, { departmentId, staffType });

      const headers = [
        'Staff ID',
        'Employee Code',
        'Staff Name',
        'Category',
        'Department',
        'Designation',
        'Date',
        'Schedule',
        'Expected Start',
        'Expected End',
        'Status',
        'Check-In',
        'Check-Out',
        'Remarks'
      ];

      const rows = data.roster.map((r) => [
        `"${r.staffId}"`,
        `"${r.employeeCode}"`,
        `"${r.staffName.replace(/"/g, '""')}"`,
        `"${r.staffType}"`,
        `"${(r.departmentName || '').replace(/"/g, '""')}"`,
        `"${(r.designation || '').replace(/"/g, '""')}"`,
        `"${r.effectiveSchedule.date}"`,
        `"${r.effectiveSchedule.scheduleName}"`,
        `"${r.effectiveSchedule.startTime}"`,
        `"${r.effectiveSchedule.endTime}"`,
        `"${r.status || 'UNMARKED'}"`,
        `"${r.checkInTime || ''}"`,
        `"${r.checkOutTime || ''}"`,
        `"${(r.remarks || '').replace(/"/g, '""')}"`
      ]);

      const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="staff-attendance-${date}.csv"`);
      res.send(csvContent);
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to export attendance records.',
        code: 'EXPORT_ERROR'
      });
    }
  }
);

// =========================================================================
// B. WORK SCHEDULE ENDPOINTS (/api/staff/schedules)
// =========================================================================

/**
 * GET /api/staff/schedules
 * List work schedules with filters
 */
staffScheduleRouter.get(
  '/',
  requireAuth,
  requirePermission('staff.schedules.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const scope = req.query.scope as string;
      const isActive = req.query.isActive !== undefined ? req.query.isActive === 'true' : undefined;
      const departmentId = req.query.departmentId as string;
      const designationId = req.query.designationId as string;
      const search = req.query.search as string;

      const schedules = staffAttendanceService.getWorkSchedules({
        scope,
        isActive,
        departmentId,
        designationId,
        search
      });

      res.json({
        success: true,
        data: schedules
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve work schedules.',
        code: 'SCHEDULES_QUERY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/schedules/effective/:staffId
 * Resolve effective schedule for specific staff on a given date
 */
staffScheduleRouter.get(
  '/effective/:staffId',
  requireAuth,
  requirePermission('staff.schedules.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const date = (req.query.date as string) || todayStr;
      const effective = staffAttendanceService.resolveEffectiveSchedule(req.params.staffId, date);

      res.json({
        success: true,
        data: effective
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to resolve effective schedule.',
        code: 'SCHEDULE_RESOLUTION_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/schedules/:id
 * Get single schedule details
 */
staffScheduleRouter.get(
  '/:id',
  requireAuth,
  requirePermission('staff.schedules.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schedule = staffAttendanceService.getWorkScheduleById(req.params.id);
      if (!schedule) {
        res.status(404).json({
          success: false,
          error: `Work schedule '${req.params.id}' not found.`,
          code: 'SCHEDULE_NOT_FOUND'
        });
        return;
      }
      res.json({
        success: true,
        data: schedule
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve schedule.',
        code: 'SCHEDULE_FETCH_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/schedules
 * Create a new work schedule
 */
staffScheduleRouter.post(
  '/',
  requireAuth,
  requirePermission('staff.schedules.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreateStaffSchedulePayload;
      const created = staffAttendanceService.createWorkSchedule(payload, req.user!, req.ip);
      res.status(201).json({
        success: true,
        data: created,
        message: `Work schedule '${created.name}' created successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to create work schedule.',
        code: 'SCHEDULE_CREATE_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/schedules/:id
 * Update an existing work schedule
 */
staffScheduleRouter.put(
  '/:id',
  requireAuth,
  requirePermission('staff.schedules.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as UpdateStaffSchedulePayload;
      const updated = staffAttendanceService.updateWorkSchedule(req.params.id, payload, req.user!, req.ip);
      res.json({
        success: true,
        data: updated,
        message: `Work schedule '${updated.name}' updated successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update work schedule.',
        code: 'SCHEDULE_UPDATE_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/staff/schedules/:id
 * Delete a work schedule (School default is protected)
 */
staffScheduleRouter.delete(
  '/:id',
  requireAuth,
  requirePermission('staff.schedules.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      staffAttendanceService.deleteWorkSchedule(req.params.id, req.user!, req.ip);
      res.json({
        success: true,
        message: 'Work schedule deleted successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to delete work schedule.',
        code: 'SCHEDULE_DELETE_ERROR'
      });
    }
  }
);

// =========================================================================
// C. STAFF LEAVE ENDPOINTS (/api/staff/leaves)
// =========================================================================

/**
 * GET /api/staff/leaves
 * List staff leave applications (RBAC: regular staff only see their own)
 */
staffLeaveRouter.get(
  '/',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const isSuperAdmin = user.role === 'SUPER_ADMIN';
      const staffProfile = (database.staffProfiles || []).find((s) => s.userId === user.id);

      let applications = (database.leaveApplications || []).filter(
        (l) => l.applicantType === 'STAFF' || l.applicantType === 'TEACHER'
      );

      // Enrich with staff directory data if missing
      applications = applications.map((app) => {
        const staff = (database.staffProfiles || []).find(
          (s) => s.id === app.staffId || s.id === app.applicantId || s.teacherProfileId === app.applicantId || s.userId === app.userId
        );
        const dept = staff?.departmentId
          ? (database.departments || []).find((d) => d.id === staff.departmentId)
          : undefined;

        return {
          ...app,
          staffId: app.staffId || staff?.id || app.applicantId,
          staffName: app.staffName || staff?.displayName || app.applicantName,
          applicantName: app.applicantName || staff?.displayName || 'Staff Member',
          employeeCode: app.employeeCode || staff?.employeeCode || 'N/A',
          departmentId: app.departmentId || staff?.departmentId,
          departmentName: app.departmentName || dept?.name || staff?.departmentName || 'General',
          staffType: app.staffType || staff?.staffType || (app.applicantType === 'TEACHER' ? 'teaching' : 'administrative')
        };
      });

      // Ownership enforcement for non-administrators
      if (!isSuperAdmin) {
        applications = applications.filter(
          (l) => l.userId === user.id || (staffProfile && l.staffId === staffProfile.id)
        );
      }

      // Filter by status
      if (req.query.status && req.query.status !== 'ALL') {
        const targetStatus = (req.query.status as string).toUpperCase();
        applications = applications.filter((l) => l.status === targetStatus);
      }

      // Filter by department
      if (req.query.departmentId && req.query.departmentId !== 'ALL') {
        applications = applications.filter((l) => l.departmentId === req.query.departmentId);
      }

      // Filter by staff type
      if (req.query.staffType && req.query.staffType !== 'ALL') {
        applications = applications.filter((l) => l.staffType === req.query.staffType);
      }

      // Search
      if (req.query.search) {
        const q = (req.query.search as string).toLowerCase().trim();
        applications = applications.filter(
          (l) =>
            l.applicantName.toLowerCase().includes(q) ||
            (l.employeeCode || '').toLowerCase().includes(q) ||
            (l.leaveTypeName || '').toLowerCase().includes(q) ||
            (l.reason || '').toLowerCase().includes(q)
        );
      }

      // Sort descending by applied date
      applications.sort((a, b) => (b.submittedAt || b.startDate).localeCompare(a.submittedAt || a.startDate));

      res.json({
        success: true,
        data: applications
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff leave applications.',
        code: 'STAFF_LEAVE_QUERY_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves
 * Submit staff leave application
 */
staffLeaveRouter.post(
  '/',
  requireAuth,
  requirePermission('staff.leaves.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as StaffLeaveApplicationPayload;
      if (!payload.startDate || !payload.leaveTypeId || !payload.reason) {
        res.status(400).json({
          success: false,
          error: 'Start Date, Leave Type, and Reason are mandatory fields.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const leave = staffAttendanceService.applyStaffLeave(payload, req.user!, req.ip);
      res.status(201).json({
        success: true,
        data: leave,
        message: 'Leave application submitted successfully for administrative review.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to submit staff leave application.',
        code: 'STAFF_LEAVE_SUBMIT_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/leaves/:id/review
 * Approve or reject staff leave application and auto-update attendance
 */
staffLeaveRouter.put(
  '/:id/review',
  requireAuth,
  requirePermission('staff.leaves.review'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { id } = req.params;
      const { status, adminRemarks, rejectionReason } = req.body as ReviewStaffLeavePayload;

      if (!['APPROVED', 'REJECTED'].includes(status)) {
        res.status(400).json({
          success: false,
          error: "Review status must be either 'APPROVED' or 'REJECTED'.",
          code: 'INVALID_STATUS'
        });
        return;
      }

      if (status === 'REJECTED' && (!rejectionReason || rejectionReason.trim().length === 0)) {
        res.status(400).json({
          success: false,
          error: 'A rejection reason is required when rejecting a leave application.',
          code: 'REJECTION_REASON_REQUIRED'
        });
        return;
      }

      const appIndex = (database.leaveApplications || []).findIndex((l) => l.id === id);
      if (appIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Leave application '${id}' not found.`,
          code: 'LEAVE_NOT_FOUND'
        });
        return;
      }

      const application = database.leaveApplications[appIndex];
      const now = new Date().toISOString();

      // If approving, apply leave to staff attendance on working days
      if (status === 'APPROVED') {
        const workingBreakdown = calculateLeaveWorkingDates(application.startDate, application.endDate || application.startDate);

        // Reuse markStaffAttendance for each working date
        for (const wDate of workingBreakdown.workingDates || [application.startDate]) {
          try {
            staffAttendanceService.markStaffAttendance(
              {
                staffId: application.staffId || application.applicantId,
                date: wDate,
                status: 'LEAVE',
                remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
                allowOverride: true,
                overrideReason: `Approved Leave Application: ${application.id}`
              },
              user,
              req.ip
            );
          } catch (e: any) {
            console.error('[Leave Approval Sync Warning]:', e.message);
          }
        }
      }

      application.status = status as any;
      application.reviewedByUserId = user.id;
      application.reviewedByName = user.name;
      application.reviewedAt = now;
      application.adminRemarks = adminRemarks;
      application.rejectionReason = rejectionReason;
      application.updatedAt = now;

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'LEAVE_APPLICATION',
        entityType: 'LEAVE_APPLICATION',
        entityId: id,
        details: `${status} staff leave application for ${application.applicantName}.`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        data: application,
        message: `Leave application has been ${status.toLowerCase()}.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to review leave application.',
        code: 'STAFF_LEAVE_REVIEW_ERROR'
      });
    }
  }
);
