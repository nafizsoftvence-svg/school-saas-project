/**
 * Multi-Tenant SaaS Security & Tenant Context Service (Phase 1)
 * Enforces server-side tenant isolation, identity validation, and role authorization.
 */

import { Request, Response, NextFunction } from 'express';
import { database } from '../db/database.js';
import { User, School, SchoolMembership, TenantContext, UserRole } from '../../src/types/index.js';
import { AuthenticatedRequest } from './auth.js';

export interface ExtendedTenantRequest extends AuthenticatedRequest {
  tenant?: TenantContext;
}

/**
 * Retrieve all active school memberships for a given user
 */
export function getUserMemberships(userId: string): SchoolMembership[] {
  return database.schoolMemberships.filter(
    (m) => m.userId === userId && m.status === 'active'
  );
}

/**
 * Retrieve all schools associated with a user
 */
export function getUserSchools(userId: string): School[] {
  const user = database.users.find((u) => u.id === userId);
  if (!user) return [];

  // Platform Super Admins have access to all schools across the platform
  if (user.role === 'SUPER_ADMIN') {
    return [...database.schools];
  }

  const membershipSchoolIds = getUserMemberships(userId).map((m) => m.schoolId);
  return database.schools.filter((s) => membershipSchoolIds.includes(s.id));
}

/**
 * Verify whether a user is authorized to access a specific school context
 */
export function verifySchoolAccess(user: User, schoolId: string): boolean {
  if (!user || !schoolId) return false;

  // Platform Super Admins have global authority over all school tenants
  if (user.role === 'SUPER_ADMIN') {
    return true;
  }

  // School Admins, Teachers, Students, and Guardians must possess an active membership
  return database.schoolMemberships.some(
    (m) => m.userId === user.id && m.schoolId === schoolId && m.status === 'active'
  );
}

/**
 * Extract candidate school ID from incoming request without trusting it blindly.
 * Checks header (X-School-Id), query param (?schoolId=), body (schoolId), or fallback to user default.
 */
export function extractCandidateSchoolId(req: Request): string | undefined {
  const headerSchoolId = req.headers['x-school-id'] as string;
  if (headerSchoolId && typeof headerSchoolId === 'string' && headerSchoolId.trim()) {
    return headerSchoolId.trim();
  }

  const querySchoolId = req.query.schoolId as string;
  if (querySchoolId && typeof querySchoolId === 'string' && querySchoolId.trim()) {
    return querySchoolId.trim();
  }

  if (req.body && typeof req.body === 'object' && typeof req.body.schoolId === 'string' && req.body.schoolId.trim()) {
    return req.body.schoolId.trim();
  }

  return undefined;
}

/**
 * Resolve validated Tenant Context for an authenticated request.
 * Returns null if user is unauthorized for the target tenant or tenant does not exist.
 */
export function resolveTenantContext(req: AuthenticatedRequest): {
  context: TenantContext | null;
  error?: string;
  code?: string;
  status?: number;
} {
  const user = req.user;
  if (!user) {
    return {
      context: null,
      error: 'Authentication required. No user session detected.',
      code: 'UNAUTHORIZED',
      status: 401
    };
  }

  const candidateSchoolId = extractCandidateSchoolId(req);

  // If client did not provide a school ID, determine user's active/default school
  let targetSchoolId = candidateSchoolId;
  if (!targetSchoolId) {
    if (user.schoolId) {
      targetSchoolId = user.schoolId;
    } else {
      const userMems = getUserMemberships(user.id);
      targetSchoolId = userMems.find((m) => m.isDefault)?.schoolId || userMems[0]?.schoolId || 'school-main';
    }
  }

  // Verify school exists in database
  const school = database.schools.find((s) => s.id === targetSchoolId);
  if (!school) {
    return {
      context: null,
      error: `Requested school tenant '${targetSchoolId}' does not exist on this platform.`,
      code: 'SCHOOL_NOT_FOUND',
      status: 404
    };
  }

  // Enforce Tenant Authorization: Super Admin has global access; other roles must possess active membership
  const isPlatformAdmin = user.role === 'SUPER_ADMIN';
  const membership = database.schoolMemberships.find(
    (m) => m.userId === user.id && m.schoolId === targetSchoolId && m.status === 'active'
  );

  if (!isPlatformAdmin && !membership) {
    return {
      context: null,
      error: `Forbidden. You do not have an authorized active membership for school '${school.name}' (${school.id}).`,
      code: 'FORBIDDEN_TENANT_ACCESS',
      status: 403
    };
  }

  // Check school operational status (suspended/inactive)
  if (school.status === 'suspended' && !isPlatformAdmin) {
    return {
      context: null,
      error: `Access denied. The subscription for school '${school.name}' is currently suspended. Please contact school administration.`,
      code: 'SCHOOL_SUSPENDED',
      status: 403
    };
  }

  const role: UserRole = membership ? membership.role : user.role;

  const tenantContext: TenantContext = {
    schoolId: school.id,
    school,
    membership,
    role,
    isPlatformAdmin
  };

  return { context: tenantContext };
}

/**
 * Express Middleware: Require Valid Tenant Context
 * Verifies authenticated identity, validates membership for requested school, attaches req.tenant
 */
export function requireTenant(req: ExtendedTenantRequest, res: Response, next: NextFunction): void {
  const result = resolveTenantContext(req);

  if (!result.context) {
    res.status(result.status || 403).json({
      success: false,
      error: result.error || 'Tenant access denied.',
      code: result.code || 'FORBIDDEN_TENANT_ACCESS'
    });
    return;
  }

  req.tenant = result.context;
  next();
}

/**
 * Express Middleware: Require Platform Super Administrator
 * Restricts platform-level operations (school provisioning, subscription management, platform metrics)
 */
export function requirePlatformAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({
      success: false,
      error: 'Authentication required.',
      code: 'UNAUTHORIZED'
    });
    return;
  }

  if (req.user.role !== 'SUPER_ADMIN') {
    res.status(403).json({
      success: false,
      error: 'Forbidden. Platform Super Administrator authority is required for this operation.',
      code: 'FORBIDDEN_PLATFORM_ADMIN'
    });
    return;
  }

  next();
}

/**
 * Switch a user's active school context (validates membership)
 */
export function switchUserActiveSchool(
  userId: string,
  targetSchoolId: string
): { success: boolean; school?: School; error?: string; code?: string } {
  const user = database.users.find((u) => u.id === userId);
  if (!user) {
    return { success: false, error: 'User not found.', code: 'USER_NOT_FOUND' };
  }

  const school = database.schools.find((s) => s.id === targetSchoolId);
  if (!school) {
    return { success: false, error: 'Target school not found.', code: 'SCHOOL_NOT_FOUND' };
  }

  // Authorization check
  const isPlatformAdmin = user.role === 'SUPER_ADMIN';
  const hasMembership = database.schoolMemberships.some(
    (m) => m.userId === userId && m.schoolId === targetSchoolId && m.status === 'active'
  );

  if (!isPlatformAdmin && !hasMembership) {
    return {
      success: false,
      error: 'You do not have membership in the requested school.',
      code: 'FORBIDDEN_TENANT_ACCESS'
    };
  }

  user.schoolId = targetSchoolId;
  return { success: true, school };
}

/**
 * Backward-compatible resolver for existing modules (Inventory, Documents, Attendance, etc.)
 * Inspects authenticated tenant context, fallback to header, fallback to default school settings.
 */
export function resolveSchoolId(req?: Request): string {
  if (req) {
    const extReq = req as ExtendedTenantRequest;
    if (extReq.tenant?.schoolId) {
      return extReq.tenant.schoolId;
    }

    const candidate = extractCandidateSchoolId(req);
    if (candidate) {
      // If user is authenticated, ensure they have access to this candidate
      if (extReq.user && verifySchoolAccess(extReq.user, candidate)) {
        return candidate;
      }
      if (!extReq.user) {
        // For public endpoints (e.g. public certificate verification)
        const schoolExists = database.schools.some((s) => s.id === candidate);
        if (schoolExists) return candidate;
      }
    }
  }

  return database.schoolSettings?.id || 'school-main';
}

/**
 * Helper to enforce tenant scoping on in-memory collections
 */
export function enforceTenantFilter<T extends { schoolId?: string }>(items: T[], tenantSchoolId: string): T[] {
  return items.filter((item) => !item.schoolId || item.schoolId === tenantSchoolId);
}
