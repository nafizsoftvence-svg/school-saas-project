import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { User, AuthSession, UserRole, Permission, TenantContext } from '../../src/types/index.js';
import { getRolePermissions, hasPermission } from './rbac.js';
export { hasPermission, getRolePermissions } from './rbac.js';

// Extend Express Request interface for authenticated user context
export interface AuthenticatedRequest extends Request {
  user?: User;
  session?: AuthSession;
  token?: string;
  tenant?: TenantContext;
}

// In-memory active session storage (token -> AuthSession)
const activeSessions = new Map<string, AuthSession>();

/**
 * Hash password with PBKDF2 with unique salt
 */
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.pbkdf2Sync(password, generatedSalt, 10000, 64, 'sha512');
  return {
    hash: derivedKey.toString('hex'),
    salt: generatedSalt
  };
}

/**
 * Verify plaintext password against stored hash and salt
 */
export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  try {
    const derivedKey = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512');
    const hashBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
    const storedBuffer = Buffer.from(storedHash, 'hex');
    if (hashBuffer.length !== storedBuffer.length) {
      return false;
    }
    return crypto.timingSafeEqual(hashBuffer, storedBuffer);
  } catch {
    return false;
  }
}

/**
 * Generate a cryptographically secure session token
 */
export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Register a new session
 */
export function createSession(
  user: User,
  additionalData?: {
    teacherProfile?: any;
    studentProfile?: any;
    guardianProfile?: any;
    schoolContext?: any;
    availableSchools?: any;
  }
): AuthSession {
  const token = generateSessionToken();
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(); // 24 hours
  const permissions = getRolePermissions(user.role);

  const session: AuthSession = {
    token,
    user,
    teacherProfile: additionalData?.teacherProfile,
    studentProfile: additionalData?.studentProfile,
    guardianProfile: additionalData?.guardianProfile,
    schoolContext: additionalData?.schoolContext,
    availableSchools: additionalData?.availableSchools,
    permissions,
    expiresAt
  };

  activeSessions.set(token, session);
  return session;
}

/**
 * Get active session
 */
export function getSession(token: string): AuthSession | undefined {
  const session = activeSessions.get(token);
  if (!session) return undefined;

  // Check expiration
  if (new Date(session.expiresAt) < new Date()) {
    activeSessions.delete(token);
    return undefined;
  }

  return session;
}

/**
 * Terminate session
 */
export function destroySession(token: string): boolean {
  return activeSessions.delete(token);
}

/**
 * Invalidate all active sessions belonging to a specific user (e.g. on password change or account disable)
 */
export function invalidateUserSessions(userId: string): number {
  let count = 0;
  for (const [token, session] of activeSessions.entries()) {
    if (session.user.id === userId) {
      activeSessions.delete(token);
      count++;
    }
  }
  return count;
}

/**
 * User status lookup callback to prevent circular dependencies with database
 */
type UserLookupFn = (userId: string) => { status: string; [key: string]: any } | undefined;
let userLookupFn: UserLookupFn | null = null;

export function registerUserLookup(fn: UserLookupFn): void {
  userLookupFn = fn;
}

/**
 * Generate cryptographically secure random token (e.g. for activations and password resets)
 */
export function generateSecureToken(bytes: number = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Validate password complexity
 */
export function validatePasswordStrength(password: string): { valid: boolean; message?: string } {
  if (!password || typeof password !== 'string') {
    return { valid: false, message: 'Password is required.' };
  }
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long.' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter (A-Z).' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter (a-z).' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one numerical digit (0-9).' };
  }
  return { valid: true };
}

/**
 * Express Middleware: Authenticate Request via Bearer Token
 */
export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: 'Authentication required. Missing or malformed authorization token.',
      code: 'UNAUTHORIZED'
    });
    return;
  }

  const token = authHeader.substring(7).trim();
  const session = getSession(token);

  if (!session) {
    res.status(401).json({
      success: false,
      error: 'Invalid or expired session. Please log in again.',
      code: 'SESSION_EXPIRED'
    });
    return;
  }

  // Live account lifecycle verification: check if account was disabled, suspended, or locked
  if (userLookupFn) {
    const liveUser = userLookupFn(session.user.id);
    if (!liveUser) {
      destroySession(token);
      res.status(401).json({
        success: false,
        error: 'User account no longer exists. Session terminated.',
        code: 'USER_NOT_FOUND'
      });
      return;
    }

    const inactiveStatuses = ['disabled', 'suspended', 'locked', 'DISABLED', 'SUSPENDED', 'LOCKED'];
    if (inactiveStatuses.includes(liveUser.status)) {
      destroySession(token);
      res.status(403).json({
        success: false,
        error: `Your account is currently ${liveUser.status.toLowerCase()}. Access has been revoked. Please contact school administration.`,
        code: 'ACCOUNT_INACTIVE'
      });
      return;
    }

    // Refresh user object in session
    session.user = {
      ...session.user,
      ...liveUser
    } as User;
  }

  req.token = token;
  req.session = session;
  req.user = session.user;
  next();
}

/**
 * Express Middleware: Require specific Role(s)
 */
export function requireRole(...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        success: false,
        error: 'Authentication required.',
        code: 'UNAUTHORIZED'
      });
      return;
    }

    const userRole = req.user.role;
    // SUPER_ADMIN has platform-wide authority and can access school-admin resources, but ADMIN cannot access SUPER_ADMIN exclusive resources
    const isAuthorized =
      allowedRoles.includes(userRole) ||
      (userRole === 'SUPER_ADMIN' && allowedRoles.includes('ADMIN'));

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: `Forbidden. Role '${req.user.role}' is not authorized to access this resource.`,
        code: 'FORBIDDEN_ROLE'
      });
      return;
    }

    next();
  };
}

/**
 * Express Middleware: Require specific Permission
 */
export function requirePermission(requiredPermission: Permission) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        success: false,
        error: 'Authentication required.',
        code: 'UNAUTHORIZED'
      });
      return;
    }

    if (!hasPermission(req.user.role, requiredPermission)) {
      res.status(403).json({
        success: false,
        error: `Forbidden. Missing required permission: '${requiredPermission}'.`,
        code: 'FORBIDDEN_PERMISSION'
      });
      return;
    }

    next();
  };
}
