import { AuditLog, UserRole } from '../../src/types/index.js';
import { database } from '../db/database.js';

export interface LogAuditParams {
  userId: string;
  userName?: string;
  userRole: UserRole;
  action: AuditLog['action'];
  entity?: AuditLog['entity'];
  entityType?: string;
  entityId?: string;
  details: string;
  ipAddress?: string;
  metadata?: any;
}

export function logAudit(params: LogAuditParams): AuditLog {
  const auditEntry: AuditLog = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userId: params.userId,
    userName: params.userName || 'System Administrator',
    userRole: params.userRole,
    action: params.action,
    entity: params.entity || params.entityType,
    entityType: params.entityType || params.entity,
    entityId: params.entityId,
    details: params.details,
    ipAddress: params.ipAddress || '127.0.0.1',
    timestamp: new Date().toISOString(),
    metadata: params.metadata
  };

  database.auditLogs.unshift(auditEntry);
  // Keep last 500 records
  if (database.auditLogs.length > 500) {
    database.auditLogs.pop();
  }

  return auditEntry;
}

export function getAuditLogs(limit: number = 50): AuditLog[] {
  return database.auditLogs.slice(0, limit);
}
