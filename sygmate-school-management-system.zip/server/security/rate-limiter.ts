/**
 * Rate Limiting & Brute-Force Protection Service
 * Tracks failed authentication attempts, enforces exponential backoff / lockouts,
 * and guards sensitive endpoints (login, forgot-password, activation).
 */

interface AttemptRecord {
  count: number;
  firstAttemptAt: number;
  lastAttemptAt: number;
  lockedUntil?: number;
}

// In-memory sliding windows (key -> AttemptRecord)
const loginAttempts = new Map<string, AttemptRecord>();
const resetAttempts = new Map<string, AttemptRecord>();

const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes temporary lockout

const MAX_RESET_REQUESTS = 3;
const RESET_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

function normalizeKey(identifier: string, ip: string): string {
  return `${identifier.toLowerCase().trim()}:${ip.trim()}`;
}

/**
 * Check if a login attempt is currently locked out
 */
export function checkLoginLockout(
  identifier: string,
  ip: string
): { isLocked: boolean; remainingSeconds: number } {
  const key = normalizeKey(identifier, ip);
  const record = loginAttempts.get(key);

  if (!record) {
    return { isLocked: false, remainingSeconds: 0 };
  }

  const now = Date.now();

  // Check if locked
  if (record.lockedUntil && record.lockedUntil > now) {
    const remainingSeconds = Math.ceil((record.lockedUntil - now) / 1000);
    return { isLocked: true, remainingSeconds };
  }

  // If window expired, clean up
  if (now - record.firstAttemptAt > LOGIN_WINDOW_MS) {
    loginAttempts.delete(key);
    return { isLocked: false, remainingSeconds: 0 };
  }

  return { isLocked: false, remainingSeconds: 0 };
}

/**
 * Record a failed login attempt
 */
export function recordLoginFailure(
  identifier: string,
  ip: string
): { isLocked: boolean; attemptsLeft: number; remainingSeconds: number } {
  const key = normalizeKey(identifier, ip);
  const now = Date.now();
  let record = loginAttempts.get(key);

  if (!record || now - record.firstAttemptAt > LOGIN_WINDOW_MS) {
    record = {
      count: 1,
      firstAttemptAt: now,
      lastAttemptAt: now
    };
  } else {
    record.count += 1;
    record.lastAttemptAt = now;
  }

  if (record.count >= MAX_LOGIN_ATTEMPTS) {
    record.lockedUntil = now + LOCKOUT_DURATION_MS;
    loginAttempts.set(key, record);
    return {
      isLocked: true,
      attemptsLeft: 0,
      remainingSeconds: Math.ceil(LOCKOUT_DURATION_MS / 1000)
    };
  }

  loginAttempts.set(key, record);
  return {
    isLocked: false,
    attemptsLeft: MAX_LOGIN_ATTEMPTS - record.count,
    remainingSeconds: 0
  };
}

/**
 * Clear failed login attempts on successful authentication
 */
export function clearLoginFailures(identifier: string, ip: string): void {
  const key = normalizeKey(identifier, ip);
  loginAttempts.delete(key);
}

/**
 * Check password reset request rate limit
 */
export function checkResetRateLimit(
  identifier: string,
  ip: string
): { isLimited: boolean; remainingSeconds: number } {
  const key = normalizeKey(identifier, ip);
  const record = resetAttempts.get(key);

  if (!record) {
    return { isLimited: false, remainingSeconds: 0 };
  }

  const now = Date.now();
  if (now - record.firstAttemptAt > RESET_WINDOW_MS) {
    resetAttempts.delete(key);
    return { isLimited: false, remainingSeconds: 0 };
  }

  if (record.count >= MAX_RESET_REQUESTS) {
    const remainingSeconds = Math.ceil((record.firstAttemptAt + RESET_WINDOW_MS - now) / 1000);
    return { isLimited: true, remainingSeconds };
  }

  return { isLimited: false, remainingSeconds: 0 };
}

/**
 * Record a password reset request
 */
export function recordResetRequest(identifier: string, ip: string): void {
  const key = normalizeKey(identifier, ip);
  const now = Date.now();
  let record = resetAttempts.get(key);

  if (!record || now - record.firstAttemptAt > RESET_WINDOW_MS) {
    record = {
      count: 1,
      firstAttemptAt: now,
      lastAttemptAt: now
    };
  } else {
    record.count += 1;
    record.lastAttemptAt = now;
  }

  resetAttempts.set(key, record);
}
