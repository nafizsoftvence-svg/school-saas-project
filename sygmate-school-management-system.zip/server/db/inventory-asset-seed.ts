/**
 * Inventory Asset Lifecycle Seed Data (Part 14C)
 * Sygmate School Management System
 */

import {
  AssetAssignment,
  AssetTransfer,
  AssetReturn,
  AssetTimelineEvent
} from '../../src/types/index.js';

export const INITIAL_ASSET_ASSIGNMENTS: AssetAssignment[] = [
  {
    id: 'asgn-1',
    schoolId: 'school-main',
    assetId: 'ast-1',
    assetTag: 'AST-2026-0001',
    assetName: 'Dell OptiPlex 7090 Micro Desktop Workstation',
    assigneeType: 'TEACHER',
    assigneeId: 'usr-teacher-1',
    assigneeName: 'Marcus Vance',
    department: 'Information Technology',
    locationId: 'loc-comp',
    locationName: 'Primary Technology & Computer Lab',
    assignedDate: '2025-08-20T09:00:00.000Z',
    expectedReturnDate: '2026-06-30T17:00:00.000Z',
    conditionAtHandover: 'EXCELLENT',
    status: 'ACTIVE',
    handoverNotes: 'Issued with power adapter, HDMI cable, wired USB mouse and keyboard for instructor desk.',
    assignedBy: 'usr-admin-1',
    assignedByName: 'Dr. Evelyn Montgomery',
    accessories: ['AC Power Brick 65W', 'HDMI Cable', 'Dell USB Keyboard', 'Dell Optical Mouse'],
    createdAt: '2025-08-20T09:00:00.000Z',
    updatedAt: '2025-08-20T09:00:00.000Z'
  },
  {
    id: 'asgn-2',
    schoolId: 'school-main',
    assetId: 'ast-4',
    assetTag: 'AST-2026-0004',
    assetName: 'Nikon Eclipse E100 LED Clinical Microscope',
    assigneeType: 'DEPARTMENT',
    assigneeId: 'dept-sci',
    assigneeName: 'Science Department',
    department: 'Science',
    locationId: 'loc-chem',
    locationName: 'Senior Science Chemistry Lab',
    assignedDate: '2025-10-15T10:30:00.000Z',
    expectedReturnDate: '2026-06-30T17:00:00.000Z',
    conditionAtHandover: 'NEW',
    status: 'ACTIVE',
    handoverNotes: 'Dedicated station unit for advanced AP biology and chemistry practical examinations.',
    assignedBy: 'usr-admin-1',
    assignedByName: 'Dr. Evelyn Montgomery',
    accessories: ['Immersion Oil Bottle', 'Vinyl Dust Cover', 'Eyepiece Micrometer'],
    createdAt: '2025-10-15T10:30:00.000Z',
    updatedAt: '2025-10-15T10:30:00.000Z'
  },
  {
    id: 'asgn-3',
    schoolId: 'school-main',
    assetId: 'ast-2',
    assetTag: 'AST-2026-0002',
    assetName: 'Epson PowerLite L520U High-Lumen Laser Projector',
    assigneeType: 'TEACHER',
    assigneeId: 'usr-teacher-2',
    assigneeName: 'Sarah Jenkins',
    department: 'Arts & Humanities',
    locationId: 'loc-main',
    locationName: 'Main Central Warehouse',
    assignedDate: '2025-09-10T08:30:00.000Z',
    expectedReturnDate: '2025-12-18T17:00:00.000Z',
    actualReturnDate: '2025-12-18T15:30:00.000Z',
    conditionAtHandover: 'NEW',
    conditionAtReturn: 'GOOD',
    status: 'RETURNED',
    handoverNotes: 'Temporary loan for Semester 1 visual arts exhibitions and multimedia presentations.',
    returnNotes: 'Returned in fully operational condition with clean lens and all original cables verified.',
    assignedBy: 'usr-admin-1',
    assignedByName: 'Dr. Evelyn Montgomery',
    receivedBy: 'usr-admin-1',
    receivedByName: 'Dr. Evelyn Montgomery',
    accessories: ['Power Cable', 'HDMI Cable', 'IR Remote Control', 'Padded Carry Case'],
    createdAt: '2025-09-10T08:30:00.000Z',
    updatedAt: '2025-12-18T15:30:00.000Z'
  },
  {
    id: 'asgn-4',
    schoolId: 'school-main',
    assetId: 'ast-6',
    assetTag: 'AST-2026-0006',
    assetName: 'Yamaha StagePas 600BT Portable PA Sound System',
    assigneeType: 'DEPARTMENT',
    assigneeId: 'dept-pe',
    assigneeName: 'Physical Education',
    department: 'Physical Education',
    locationId: 'loc-gym',
    locationName: 'Athletics Complex & Gymnasium',
    assignedDate: '2025-08-28T13:00:00.000Z',
    expectedReturnDate: '2026-06-30T17:00:00.000Z',
    conditionAtHandover: 'EXCELLENT',
    status: 'ACTIVE',
    handoverNotes: 'Portable PA audio system assigned to Physical Education department for assemblies and sports.',
    assignedBy: 'usr-admin-1',
    assignedByName: 'Dr. Evelyn Montgomery',
    accessories: ['Speaker Cables (x2)', 'Power Cable', 'Microphone with Cable'],
    createdAt: '2025-08-28T13:00:00.000Z',
    updatedAt: '2025-08-28T13:00:00.000Z'
  }
];

export const INITIAL_ASSET_TRANSFERS: AssetTransfer[] = [];

export const INITIAL_ASSET_RETURNS: AssetReturn[] = [
  {
    id: 'ret-1',
    schoolId: 'school-main',
    assetId: 'ast-2',
    assignmentId: 'asgn-3',
    returnDate: '2025-12-18T15:30:00.000Z',
    returnCondition: 'GOOD',
    resultingStatus: 'AVAILABLE',
    locationId: 'loc-main',
    locationName: 'Main Central Warehouse',
    returnedByAssigneeId: 'usr-teacher-2',
    returnedByAssigneeName: 'Sarah Jenkins',
    receivedByUserId: 'usr-admin-1',
    receivedByUserName: 'Dr. Evelyn Montgomery',
    remarks: 'Loan ended following conclusion of Semester 1 Arts festival. Laser hour count: 48 hrs.',
    createdAt: '2025-12-18T15:30:00.000Z'
  }
];

export const INITIAL_ASSET_TIMELINE_EVENTS: AssetTimelineEvent[] = [
  {
    id: 'tl-1',
    schoolId: 'school-main',
    assetId: 'ast-1',
    eventType: 'REGISTERED',
    title: 'Asset Commissioned & Tagged',
    description: 'Procured and assigned asset tag AST-2026-0001 with 3-year ProSupport warranty.',
    toStatus: 'AVAILABLE',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-08-15T14:30:00.000Z'
  },
  {
    id: 'tl-2',
    schoolId: 'school-main',
    assetId: 'ast-1',
    eventType: 'ASSIGNED',
    title: 'Custody Assigned to Marcus Vance',
    description: 'Hardware issued to faculty instructor Marcus Vance for Computer Lab #1 podium.',
    fromStatus: 'AVAILABLE',
    toStatus: 'ASSIGNED',
    toAssigneeName: 'Marcus Vance',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-08-20T09:00:00.000Z'
  },
  {
    id: 'tl-3',
    schoolId: 'school-main',
    assetId: 'ast-2',
    eventType: 'REGISTERED',
    title: 'Asset Commissioned & Tagged',
    description: 'Procured and verified for Auditorium & campus events.',
    toStatus: 'AVAILABLE',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-09-01T11:00:00.000Z'
  },
  {
    id: 'tl-4',
    schoolId: 'school-main',
    assetId: 'ast-2',
    eventType: 'ASSIGNED',
    title: 'Loan Assigned to Sarah Jenkins',
    description: 'Temporary loan for Semester 1 Arts & Humanities multimedia exhibitions.',
    fromStatus: 'AVAILABLE',
    toStatus: 'ASSIGNED',
    toAssigneeName: 'Sarah Jenkins',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-09-10T08:30:00.000Z'
  },
  {
    id: 'tl-5',
    schoolId: 'school-main',
    assetId: 'ast-2',
    eventType: 'RETURNED',
    title: 'Returned to Warehouse',
    description: 'Completed loan return in GOOD condition; placed back into available stock.',
    fromStatus: 'ASSIGNED',
    toStatus: 'AVAILABLE',
    fromAssigneeName: 'Sarah Jenkins',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-12-18T15:30:00.000Z'
  },
  {
    id: 'tl-6',
    schoolId: 'school-main',
    assetId: 'ast-4',
    eventType: 'REGISTERED',
    title: 'Asset Commissioned & Tagged',
    description: 'Calibrated laboratory microscope tagged and entered into science register.',
    toStatus: 'AVAILABLE',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-10-10T11:00:00.000Z'
  },
  {
    id: 'tl-7',
    schoolId: 'school-main',
    assetId: 'ast-4',
    eventType: 'ASSIGNED',
    title: 'Assigned to Science Department',
    description: 'Allocated for senior chemistry and biology practical workstation bench #1.',
    fromStatus: 'AVAILABLE',
    toStatus: 'ASSIGNED',
    toAssigneeName: 'Science Department',
    performedBy: 'usr-admin-1',
    performedByName: 'Dr. Evelyn Montgomery',
    timestamp: '2025-10-15T10:30:00.000Z'
  }
];
