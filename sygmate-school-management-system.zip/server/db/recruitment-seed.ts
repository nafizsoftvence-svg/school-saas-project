/**
 * Sygmate School Management System
 * Staff Recruitment & Onboarding (Part 12D) Seed Data
 */

import {
  JobOpening,
  CandidateProfile,
  JobApplication,
  JobInterview,
  JobOffer,
  OnboardingTemplate,
  OnboardingRecord
} from '../../src/types/index.js';

export const INITIAL_ONBOARDING_TEMPLATES: OnboardingTemplate[] = [
  {
    id: 'onb-tmpl-teaching',
    name: 'Teaching Faculty Onboarding Protocol',
    staffType: 'teaching',
    description: 'Comprehensive onboarding protocol for academic teachers, subject educators, and department faculty.',
    isDefault: true,
    createdAt: '2026-01-10T08:00:00.000Z',
    updatedAt: '2026-01-10T08:00:00.000Z',
    tasks: [
      {
        title: 'Complete 360° Staff Profile & Personal Dossier',
        description: 'Ensure all emergency contacts, address proof, and biographical fields are submitted.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Submit Identity & Work Authorization Proof',
        description: 'National ID card, passport copy, work permit or citizenship documentation.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Verify Academic Degrees & Teaching Certificates',
        description: 'Original degree certificates, transcripts, and verified state/national educator license.',
        category: 'CREDENTIALS',
        isMandatory: true,
        daysFromJoiningDue: 5
      },
      {
        title: 'Sign Institutional Employment Agreement & Terms',
        description: 'Countersigned service agreement, confidentiality agreement, and remuneration terms.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Assign Department & Academic Designation',
        description: 'Confirm formal academic department placement and job designation tier in HR registry.',
        category: 'WORK_SETUP',
        isMandatory: true,
        daysFromJoiningDue: 1
      },
      {
        title: 'Configure Teacher Portal Account & Security Roles',
        description: 'Provision portal login credentials with TEACHER role and 2FA settings.',
        category: 'SYSTEM_ACCESS',
        isMandatory: true,
        daysFromJoiningDue: 1
      },
      {
        title: 'Assign Weekly Teaching Work Schedule & Shift',
        description: 'Assign standard academic working shift and configure automated attendance tracking.',
        category: 'WORK_SETUP',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Academic Curriculum Orientation & LMS Onboarding',
        description: 'Orientation on syllabus, examination guidelines, homework tools, and classroom management.',
        category: 'ORIENTATION',
        isMandatory: true,
        daysFromJoiningDue: 7
      },
      {
        title: 'Assign Department Mentor / Head of Department',
        description: 'Formal introduction and mentor pairing with senior faculty member.',
        category: 'ORIENTATION',
        isMandatory: false,
        daysFromJoiningDue: 7
      },
      {
        title: 'Acknowledge Child Safeguarding & Code of Conduct Policies',
        description: 'Mandatory sign-off on institutional student protection and ethical policies.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 4
      },
      {
        title: 'Issue RFID Staff ID Card & Campus Access Pass',
        description: 'Print staff badge and program door access for academic wings and staff lounge.',
        category: 'FACILITY',
        isMandatory: true,
        daysFromJoiningDue: 5
      },
      {
        title: 'Final Joining Review & HR Confirmation',
        description: 'HR executive sign-off verifying all milestones are fulfilled and record activated.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 14
      }
    ]
  },
  {
    id: 'onb-tmpl-admin',
    name: 'Administrative Staff Onboarding Protocol',
    staffType: 'administrative',
    description: 'Structured onboarding checklist for administrative, registrar, and finance personnel.',
    isDefault: true,
    createdAt: '2026-01-10T08:00:00.000Z',
    updatedAt: '2026-01-10T08:00:00.000Z',
    tasks: [
      {
        title: 'Complete Staff Profile & Contact Information',
        description: 'Submit verified contact information and emergency phone numbers.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Submit Identity & Background Verification Documents',
        description: 'Government photo ID, background check clearance, and address verification.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Sign Employment Agreement & Non-Disclosure Agreement',
        description: 'Countersigned administrative terms and institutional data privacy compliance.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Provision Admin Portal Account & Security Permissions',
        description: 'Setup administrative user account with precise RBAC scopes.',
        category: 'SYSTEM_ACCESS',
        isMandatory: true,
        daysFromJoiningDue: 1
      },
      {
        title: 'Workstation & IT Hardware Allocation',
        description: 'Provision laptop, enterprise email account, and telephony credentials.',
        category: 'WORK_SETUP',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Assign Administrative Work Shift',
        description: 'Configure standard office hours (08:00 - 16:30) in HR schedule system.',
        category: 'WORK_SETUP',
        isMandatory: true,
        daysFromJoiningDue: 1
      },
      {
        title: 'Administrative Systems & Records Procedure Training',
        description: 'Training on student admissions, fee handling, records filing, and school procedures.',
        category: 'ORIENTATION',
        isMandatory: true,
        daysFromJoiningDue: 7
      },
      {
        title: 'Acknowledge Data Protection & Confidentiality Policy',
        description: 'Compliance acknowledgment covering student records confidentiality.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 5
      },
      {
        title: 'Issue Official Staff ID Badge & Keys',
        description: 'Deliver photo ID card, office keys, and secure cabinet access keys.',
        category: 'FACILITY',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Final HR Onboarding Sign-off',
        description: 'Final review by Head of Administration upon 14-day completion.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 14
      }
    ]
  },
  {
    id: 'onb-tmpl-support',
    name: 'Support & Operations Staff Protocol',
    staffType: 'support',
    description: 'Protocol for lab technicians, facility technicians, maintenance, and logistics staff.',
    isDefault: true,
    createdAt: '2026-01-10T08:00:00.000Z',
    updatedAt: '2026-01-10T08:00:00.000Z',
    tasks: [
      {
        title: 'Staff Profile & Emergency Information',
        description: 'Submit basic personal info and emergency contacts.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Identity Proof & Physical Health Clearance',
        description: 'Government ID verification and certified occupational medical report.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        daysFromJoiningDue: 4
      },
      {
        title: 'Work Contract & Safety Acknowledgment',
        description: 'Signed service contract, workplace safety rules, and hazard protocols.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Assign Operational Shift & Schedule',
        description: 'Set daily rotational operational schedule in attendance system.',
        category: 'WORK_SETUP',
        isMandatory: true,
        daysFromJoiningDue: 1
      },
      {
        title: 'Uniform, Tools & Protective Equipment Issue',
        description: 'Issue institutional uniform, safety equipment, and operational equipment.',
        category: 'FACILITY',
        isMandatory: true,
        daysFromJoiningDue: 2
      },
      {
        title: 'Campus Facility Tour & Emergency Response Briefing',
        description: 'Briefing on evacuation zones, fire extinguisher stations, and maintenance reporting.',
        category: 'ORIENTATION',
        isMandatory: true,
        daysFromJoiningDue: 5
      },
      {
        title: 'Issue Staff ID & Gate Entry Pass',
        description: 'Issue access card and campus gate entry credentials.',
        category: 'FACILITY',
        isMandatory: true,
        daysFromJoiningDue: 3
      },
      {
        title: 'Final Supervisor Operational Sign-off',
        description: 'Facility Supervisor verification and probation commencement.',
        category: 'COMPLIANCE',
        isMandatory: true,
        daysFromJoiningDue: 14
      }
    ]
  }
];

export const INITIAL_JOB_OPENINGS: JobOpening[] = [
  {
    id: 'job-op-2026-01',
    title: 'Senior Mathematics & Statistics Faculty',
    code: 'JOB-2026-MTH-01',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    designationId: 'des-snr-tch',
    designationTitle: 'Senior Teacher',
    staffType: 'teaching',
    employmentType: 'full_time',
    vacancies: 2,
    filledVacancies: 1,
    jobDescription: 'Seeking an accomplished Mathematics educator to teach Advanced Calculus, Algebra, and Statistics for Grades 10–12.',
    responsibilities: [
      'Design curriculum and lesson plans for Advanced Mathematics and Statistics',
      'Prepare students for national and international board examinations',
      'Mentor junior faculty and contribute to student STEM competitions',
      'Conduct regular formative assessments and provide individualized academic feedback'
    ],
    qualifications: [
      "Master's Degree in Mathematics, Applied Statistics, or Mathematics Education",
      'Valid Professional Teacher Certification / B.Ed'
    ],
    experienceYears: 4,
    requiredSkills: ['Calculus', 'Advanced Algebra', 'Pedagogy', 'Interactive Learning', 'LMS Proficiency'],
    salaryRange: '$48,000 - $58,000 / year (Commensurate with experience)',
    workLocation: 'Main Campus, Senior High Academic Wing',
    applicationStartDate: '2026-07-01',
    applicationClosingDate: '2026-10-31',
    status: 'APPLICATIONS_OPEN',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Pendelton',
    createdAt: '2026-07-01T09:00:00.000Z',
    updatedAt: '2026-08-15T14:30:00.000Z',
    notes: 'Urgent replacement vacancy for upcoming academic term.',
    applicationCount: 4
  },
  {
    id: 'job-op-2026-02',
    title: 'Head of Department — Natural & Biological Sciences',
    code: 'JOB-2026-SCI-01',
    departmentId: 'dept-sci',
    departmentName: 'Department of Natural Sciences',
    designationId: 'des-hod',
    designationTitle: 'Head of Department',
    staffType: 'teaching',
    employmentType: 'full_time',
    vacancies: 1,
    filledVacancies: 0,
    jobDescription: 'Lead the faculty of Biology, Chemistry, and Physics. Oversee state-of-the-art laboratory safety, academic standards, and interdisciplinary research.',
    responsibilities: [
      'Provide academic and pedagogical leadership across all science disciplines',
      'Oversee laboratory safety compliance, inventory, and experimental facilities',
      'Conduct teacher performance evaluations and departmental pedagogical seminars',
      'Represent the Natural Sciences department in the Academic Council'
    ],
    qualifications: [
      'Ph.D. or Master of Science in Biology, Chemistry, Physics, or Science Education',
      'Recognized Leadership or Department Management Certification'
    ],
    experienceYears: 8,
    requiredSkills: ['Curriculum Leadership', 'Lab Safety Protocols', 'Faculty Mentorship', 'Budget Planning', 'Research Oversight'],
    salaryRange: '$62,000 - $75,000 / year + Department Head Allowance',
    workLocation: 'Main Campus, Science Complex Building',
    applicationStartDate: '2026-07-15',
    applicationClosingDate: '2026-11-15',
    status: 'APPLICATIONS_OPEN',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Pendelton',
    createdAt: '2026-07-15T10:00:00.000Z',
    updatedAt: '2026-08-20T11:00:00.000Z',
    notes: 'Executive appointment requires Academic Council review.',
    applicationCount: 3
  },
  {
    id: 'job-op-2026-03',
    title: 'Assistant Registrar — Academic Records & Admissions',
    code: 'JOB-2026-REG-01',
    departmentId: 'dept-adm',
    departmentName: 'Department of Administration & Operations',
    designationId: 'des-reg-off',
    designationTitle: 'Registrar & Records Officer',
    staffType: 'administrative',
    employmentType: 'full_time',
    vacancies: 1,
    filledVacancies: 0,
    jobDescription: 'Manage student academic records, transcript issuance, enrollment verifications, and compliance with statutory educational guidelines.',
    responsibilities: [
      'Maintain official student registry, transcripts, and archived files',
      'Coordinate graduation auditing and academic certificate preparation',
      'Enforce institutional policies regarding student data privacy and integrity'
    ],
    qualifications: [
      "Bachelor's or Master's Degree in Public Administration, Education Administration, or related field",
      'Proficiency with School ERP and Student Information Systems'
    ],
    experienceYears: 3,
    requiredSkills: ['Records Management', 'Database Administration', 'Compliance Auditing', 'Student Communication'],
    salaryRange: '$40,000 - $48,000 / year',
    workLocation: 'Administration Building, Central Registry',
    applicationStartDate: '2026-08-01',
    applicationClosingDate: '2026-10-15',
    status: 'APPLICATIONS_OPEN',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Pendelton',
    createdAt: '2026-08-01T08:30:00.000Z',
    updatedAt: '2026-08-25T09:00:00.000Z',
    applicationCount: 2
  },
  {
    id: 'job-op-2026-04',
    title: 'IT Network & Systems Administrator',
    code: 'JOB-2026-IT-01',
    departmentId: 'dept-it',
    departmentName: 'Department of Information Technology',
    designationId: 'des-it-admin',
    designationTitle: 'IT Administrator & Systems Engineer',
    staffType: 'support',
    employmentType: 'full_time',
    vacancies: 1,
    filledVacancies: 0,
    jobDescription: 'Oversee campus enterprise network infrastructure, cloud backups, firewalls, and staff/student endpoint hardware.',
    responsibilities: [
      'Manage school server infrastructure, VPN, and campus-wide Wi-Fi networks',
      'Monitor cyber-security compliance, firewalls, and scheduled data backups',
      'Provide escalation support for classroom smartboards and lab workstations'
    ],
    qualifications: [
      "Bachelor's Degree in Computer Science, Information Technology, or relevant certifications (CCNA, Network+, CompTIA Security+)"
    ],
    experienceYears: 3,
    requiredSkills: ['Network Architecture', 'Linux & Windows Server', 'Cybersecurity', 'Disaster Recovery', 'Hardware Troubleshooting'],
    salaryRange: '$45,000 - $54,000 / year',
    workLocation: 'IT Operations Center, Tech Pavilion',
    applicationStartDate: '2026-08-10',
    applicationClosingDate: '2026-11-30',
    status: 'APPLICATIONS_OPEN',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Pendelton',
    createdAt: '2026-08-10T11:00:00.000Z',
    updatedAt: '2026-08-10T11:00:00.000Z',
    applicationCount: 2
  },
  {
    id: 'job-op-2026-05',
    title: 'Primary Homeroom Teacher — Grade 3 & 4',
    code: 'JOB-2026-PRI-01',
    departmentId: 'dept-eng',
    departmentName: 'Department of Languages & Literature',
    designationId: 'des-asst-tch',
    designationTitle: 'Assistant Teacher',
    staffType: 'teaching',
    employmentType: 'full_time',
    vacancies: 2,
    filledVacancies: 0,
    jobDescription: 'Dynamic primary educator responsible for literacy, elementary numeracy, and social-emotional development.',
    responsibilities: [
      'Deliver engaging foundational lessons in reading, phonics, and basic math',
      'Foster an inclusive, nurturing, and safe classroom atmosphere',
      'Maintain continuous communication with parents on student progress'
    ],
    qualifications: [
      "Bachelor's Degree in Primary Education, Early Childhood Development, or English Literature",
      'Teaching license or PGCE'
    ],
    experienceYears: 2,
    requiredSkills: ['Early Childhood Pedagogy', 'Phonics Instruction', 'Classroom Management', 'Parent Communication'],
    salaryRange: '$38,000 - $46,000 / year',
    workLocation: 'Junior School Campus, East Wing',
    applicationStartDate: '2026-08-15',
    applicationClosingDate: '2026-10-31',
    status: 'APPLICATIONS_OPEN',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Pendelton',
    createdAt: '2026-08-15T09:30:00.000Z',
    updatedAt: '2026-08-15T09:30:00.000Z',
    applicationCount: 2
  }
];

export const INITIAL_CANDIDATES: CandidateProfile[] = [
  {
    id: 'cand-2026-001',
    candidateNumber: 'CND-2026-001',
    fullName: 'Dr. Lawrence Vance',
    firstName: 'Lawrence',
    lastName: 'Vance',
    email: 'lawrence.vance.candidate@example.com',
    phone: '+1 (555) 432-1101',
    address: '448 Birchwood Way, Apt 3A',
    city: 'Springfield',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1987-04-18',
    gender: 'male',
    emergencyContactName: 'Clara Vance',
    emergencyContactPhone: '+1 (555) 432-1102',
    currentOccupation: 'Senior Mathematics Lecturer, St. Jude Prep',
    highestQualification: 'Ph.D. in Applied Mathematics',
    institution: 'University of Michigan',
    yearsOfExperience: 6,
    previousEmployment: 'St. Jude Preparatory Academy (2020–2026)',
    skills: ['Calculus', 'Linear Algebra', 'AP Statistics', 'Mathematical Olympiad Coaching', 'Python for Math'],
    certifications: ['State Advanced Educator License #IL-9921', 'AP Calculus BC Certified Instructor'],
    specialization: 'Higher Mathematics & Mathematical Modeling',
    references: [
      {
        name: 'Dr. Miriam O’Connor',
        designation: 'Dean of Faculty',
        organization: 'St. Jude Preparatory Academy',
        email: 'm.oconnor@stjude.org',
        phone: '+1 (555) 234-5678',
        relationship: 'Former Academic Supervisor'
      }
    ],
    appliedPositionTitle: 'Senior Mathematics & Statistics Faculty',
    appliedDepartmentId: 'dept-mth',
    appliedDepartmentName: 'Department of Mathematics',
    source: 'SCHOOL_WEBSITE',
    currentStage: 'SELECTED',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Outstanding interview scores. Exceptional student engagement during mock teaching demonstration.',
    createdAt: '2026-07-05T10:15:00.000Z',
    updatedAt: '2026-08-20T16:00:00.000Z'
  },
  {
    id: 'cand-2026-002',
    candidateNumber: 'CND-2026-002',
    fullName: 'Elena Vasquez-Moreno',
    firstName: 'Elena',
    lastName: 'Vasquez-Moreno',
    email: 'elena.moreno.candidate@example.com',
    phone: '+1 (555) 345-6789',
    address: '120 Horizon Boulevard',
    city: 'Springfield',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1991-09-22',
    gender: 'female',
    emergencyContactName: 'Mateo Moreno',
    emergencyContactPhone: '+1 (555) 345-6780',
    currentOccupation: 'High School Mathematics Teacher',
    highestQualification: "Master of Science in Mathematics Education",
    institution: 'Northwestern University',
    yearsOfExperience: 5,
    previousEmployment: 'Oakridge International High School (2021–2026)',
    skills: ['Geometry', 'Pre-Calculus', 'Formative Assessment', 'STEM Integration'],
    certifications: ['National Board Certified Teacher (NBCT)', 'Secondary Mathematics Certificate'],
    specialization: 'Secondary Mathematics & Inquiry Learning',
    references: [
      {
        name: 'Robert Hastings',
        designation: 'Principal',
        organization: 'Oakridge High School',
        email: 'rhastings@oakridge.edu',
        phone: '+1 (555) 987-6543',
        relationship: 'Direct Supervisor'
      }
    ],
    appliedPositionTitle: 'Senior Mathematics & Statistics Faculty',
    appliedDepartmentId: 'dept-mth',
    appliedDepartmentName: 'Department of Mathematics',
    source: 'REFERRAL',
    currentStage: 'INTERVIEW',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Passed initial screening; round 2 panel interview scheduled.',
    createdAt: '2026-07-12T14:20:00.000Z',
    updatedAt: '2026-08-18T10:00:00.000Z'
  },
  {
    id: 'cand-2026-003',
    candidateNumber: 'CND-2026-003',
    fullName: 'Dr. Fiona Gallagher',
    firstName: 'Fiona',
    lastName: 'Gallagher',
    email: 'fiona.gallagher.candidate@example.com',
    phone: '+1 (555) 567-8901',
    address: '89 Willow Creek Lane',
    city: 'Chicago',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1984-11-03',
    gender: 'female',
    emergencyContactName: 'Sean Gallagher',
    emergencyContactPhone: '+1 (555) 567-8902',
    currentOccupation: 'Department Chair & Senior Biology Faculty',
    highestQualification: 'Ph.D. in Molecular Biology & Educational Leadership',
    institution: 'University of Chicago',
    yearsOfExperience: 10,
    previousEmployment: 'Lakeview Collegiate Institute (2016–2026)',
    skills: ['Science Curriculum Oversight', 'Biotechnology Lab Management', 'Staff Development', 'Grant Writing'],
    certifications: ['OSHA Laboratory Safety Compliance Officer', 'Advanced Leadership in Education'],
    specialization: 'Molecular Biology & Departmental Administration',
    references: [
      {
        name: 'Prof. Donald Sterling',
        designation: 'Superintendent',
        organization: 'Lakeview Academic District',
        email: 'd.sterling@lakeview.org',
        phone: '+1 (555) 678-1234',
        relationship: 'Former District Superintendent'
      }
    ],
    appliedPositionTitle: 'Head of Department — Natural & Biological Sciences',
    appliedDepartmentId: 'dept-sci',
    appliedDepartmentName: 'Department of Natural Sciences',
    source: 'JOB_BOARD',
    currentStage: 'OFFER',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Offer letter drafted with department head allowance; awaiting candidate formal acceptance.',
    createdAt: '2026-07-20T11:00:00.000Z',
    updatedAt: '2026-08-25T15:00:00.000Z'
  },
  {
    id: 'cand-2026-004',
    candidateNumber: 'CND-2026-004',
    fullName: 'Julian Mercer',
    firstName: 'Julian',
    lastName: 'Mercer',
    email: 'julian.mercer.candidate@example.com',
    phone: '+1 (555) 678-2345',
    address: '702 Maplewood Avenue',
    city: 'Springfield',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1993-02-14',
    gender: 'male',
    emergencyContactName: 'Hannah Mercer',
    emergencyContactPhone: '+1 (555) 678-2346',
    currentOccupation: 'Records Coordinator',
    highestQualification: "Bachelor of Arts in Information & Records Management",
    institution: 'Illinois State University',
    yearsOfExperience: 4,
    previousEmployment: 'Midwest Community College Registrar Office (2022–2026)',
    skills: ['FERPA Compliance', 'SIS Administration', 'Transcripts Verification', 'Data Auditing'],
    certifications: ['Certified Records Manager (CRM) Part 1', 'Student Information System Specialist'],
    specialization: 'Academic Records Integrity & Admissions Workflow',
    appliedPositionTitle: 'Assistant Registrar — Academic Records & Admissions',
    appliedDepartmentId: 'dept-adm',
    appliedDepartmentName: 'Department of Administration & Operations',
    source: 'DIRECT_APPLICATION',
    currentStage: 'SHORTLISTED',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Strong knowledge of student privacy laws and data archival standards.',
    createdAt: '2026-08-05T13:45:00.000Z',
    updatedAt: '2026-08-22T14:10:00.000Z'
  },
  {
    id: 'cand-2026-005',
    candidateNumber: 'CND-2026-005',
    fullName: 'Devon Bradley',
    firstName: 'Devon',
    lastName: 'Bradley',
    email: 'devon.bradley.candidate@example.com',
    phone: '+1 (555) 789-3456',
    address: '15 Southridge Terrace',
    city: 'Peoria',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1995-07-29',
    gender: 'male',
    emergencyContactName: 'Tanya Bradley',
    emergencyContactPhone: '+1 (555) 789-3457',
    currentOccupation: 'Network Systems Support Specialist',
    highestQualification: "Bachelor of Science in Computer Networking & Cyber Security",
    institution: 'Purdue University',
    yearsOfExperience: 4,
    previousEmployment: 'Tri-County Educational Service Center (2022–2026)',
    skills: ['Cisco Routing & Switching', 'Firewall Management', 'Active Directory', 'Google Workspace for Education'],
    certifications: ['Cisco CCNA', 'CompTIA Security+', 'Microsoft Certified: Azure Fundamentals'],
    specialization: 'Educational Campus Networks & Infrastructure',
    appliedPositionTitle: 'IT Network & Systems Administrator',
    appliedDepartmentId: 'dept-it',
    appliedDepartmentName: 'Department of Information Technology',
    source: 'JOB_BOARD',
    currentStage: 'SCREENING',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Resume under screening. Holds relevant networking credentials.',
    createdAt: '2026-08-14T09:00:00.000Z',
    updatedAt: '2026-08-14T09:00:00.000Z'
  },
  {
    id: 'cand-2026-006',
    candidateNumber: 'CND-2026-006',
    fullName: 'Sophia Linnea Berg',
    firstName: 'Sophia Linnea',
    lastName: 'Berg',
    email: 'sophia.berg.candidate@example.com',
    phone: '+1 (555) 890-4567',
    address: '33 Gardenia Court',
    city: 'Springfield',
    state: 'Illinois',
    country: 'United States',
    dateOfBirth: '1994-06-12',
    gender: 'female',
    emergencyContactName: 'Astrid Berg',
    emergencyContactPhone: '+1 (555) 890-4568',
    currentOccupation: 'Primary Educator (Grade 3)',
    highestQualification: "Master of Arts in Elementary Education",
    institution: 'Vanderbilt University Peabody College',
    yearsOfExperience: 4,
    previousEmployment: 'St. Paul Country Day School (2022–2026)',
    skills: ['Guided Reading', 'Differentiated Instruction', 'Classroom Culture', 'Child Psychology'],
    certifications: ['State Elementary Teaching License (K–6)', 'Orton-Gillingham Literacy Certified'],
    specialization: 'Early Literacy & Experiential Elementary Learning',
    appliedPositionTitle: 'Primary Homeroom Teacher — Grade 3 & 4',
    appliedDepartmentId: 'dept-eng',
    appliedDepartmentName: 'Department of Languages & Literature',
    source: 'SCHOOL_WEBSITE',
    currentStage: 'ACCEPTED',
    status: 'ACTIVE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    notes: 'Accepted offer terms. Ready for candidate-to-staff conversion and onboarding initialization.',
    createdAt: '2026-08-16T10:30:00.000Z',
    updatedAt: '2026-08-28T16:45:00.000Z'
  }
];

export const INITIAL_JOB_APPLICATIONS: JobApplication[] = [
  {
    id: 'app-2026-001',
    applicationNumber: 'APP-2026-001',
    candidateId: 'cand-2026-001',
    candidateName: 'Dr. Lawrence Vance',
    candidateEmail: 'lawrence.vance.candidate@example.com',
    candidatePhone: '+1 (555) 432-1101',
    candidateQualification: 'Ph.D. in Applied Mathematics',
    candidateExperienceYears: 6,
    jobOpeningId: 'job-op-2026-01',
    jobTitle: 'Senior Mathematics & Statistics Faculty',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    applicationDate: '2026-07-05',
    stage: 'SELECTED',
    status: 'SELECTED',
    resumeUrl: '/documents/candidates/lawrence_vance_cv.pdf',
    resumeFileName: 'Dr_Lawrence_Vance_Curriculum_Vitae.pdf',
    coverLetter: 'I am writing to express my enthusiasm for the Senior Mathematics position at Sygmate School. With a Ph.D. in Applied Mathematics and 6 years preparing students for national Olympiads, I look forward to inspiring rigorous mathematical inquiry.',
    supportingDocuments: [
      {
        id: 'doc-cand-1-deg',
        name: 'Doctorate_Degree_Certificate.pdf',
        fileUrl: '/documents/candidates/doc-cand-1-deg.pdf',
        fileType: 'application/pdf',
        fileSize: '1.8 MB',
        uploadedAt: '2026-07-05T10:20:00.000Z'
      }
    ],
    source: 'SCHOOL_WEBSITE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    screeningNotes: 'Impeccable academic credentials. Prior Olympiad coaching matches institutional strategic goals.',
    screeningDecision: 'SHORTLISTED',
    screenedBy: 'usr-admin-1',
    screenedByName: 'Dr. Arthur Pendelton',
    screenedAt: '2026-07-08T11:00:00.000Z',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-001',
        changedByName: 'Dr. Lawrence Vance',
        timestamp: '2026-07-05T10:15:00.000Z',
        notes: 'Application submitted via school portal.'
      },
      {
        stage: 'SCREENING',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-07-07T09:00:00.000Z',
        notes: 'Profile placed under HR credential verification.'
      },
      {
        stage: 'SHORTLISTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-07-08T11:00:00.000Z',
        notes: 'Passed screening with top score; moved to interview panel.'
      },
      {
        stage: 'INTERVIEW',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-07-15T14:00:00.000Z',
        notes: 'Interview round 1 and 2 completed.'
      },
      {
        stage: 'SELECTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-20T16:00:00.000Z',
        notes: 'Unanimous selection by Math faculty panel and Principal.'
      }
    ],
    internalNotes: 'Top candidate for Senior Mathematics chair.',
    createdAt: '2026-07-05T10:15:00.000Z',
    updatedAt: '2026-08-20T16:00:00.000Z'
  },
  {
    id: 'app-2026-002',
    applicationNumber: 'APP-2026-002',
    candidateId: 'cand-2026-002',
    candidateName: 'Elena Vasquez-Moreno',
    candidateEmail: 'elena.moreno.candidate@example.com',
    candidatePhone: '+1 (555) 345-6789',
    candidateQualification: "Master of Science in Mathematics Education",
    candidateExperienceYears: 5,
    jobOpeningId: 'job-op-2026-01',
    jobTitle: 'Senior Mathematics & Statistics Faculty',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    applicationDate: '2026-07-12',
    stage: 'INTERVIEW',
    status: 'INTERVIEWING',
    resumeUrl: '/documents/candidates/elena_moreno_cv.pdf',
    resumeFileName: 'Elena_Moreno_Resume.pdf',
    coverLetter: 'Dedicated to fostering mathematical curiosity through active problem-solving and modern pedagogy.',
    source: 'REFERRAL',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    screeningNotes: 'Strong classroom credentials and NBCT certification.',
    screeningDecision: 'SHORTLISTED',
    screenedBy: 'usr-admin-1',
    screenedByName: 'Dr. Arthur Pendelton',
    screenedAt: '2026-07-16T15:00:00.000Z',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-002',
        changedByName: 'Elena Vasquez-Moreno',
        timestamp: '2026-07-12T14:20:00.000Z',
        notes: 'Submitted application.'
      },
      {
        stage: 'SHORTLISTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-07-16T15:00:00.000Z',
        notes: 'Shortlisted for academic demonstration round.'
      },
      {
        stage: 'INTERVIEW',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-18T10:00:00.000Z',
        notes: 'Round 1 interview completed.'
      }
    ],
    createdAt: '2026-07-12T14:20:00.000Z',
    updatedAt: '2026-08-18T10:00:00.000Z'
  },
  {
    id: 'app-2026-003',
    applicationNumber: 'APP-2026-003',
    candidateId: 'cand-2026-003',
    candidateName: 'Dr. Fiona Gallagher',
    candidateEmail: 'fiona.gallagher.candidate@example.com',
    candidatePhone: '+1 (555) 567-8901',
    candidateQualification: 'Ph.D. in Molecular Biology & Educational Leadership',
    candidateExperienceYears: 10,
    jobOpeningId: 'job-op-2026-02',
    jobTitle: 'Head of Department — Natural & Biological Sciences',
    departmentId: 'dept-sci',
    departmentName: 'Department of Natural Sciences',
    applicationDate: '2026-07-20',
    stage: 'OFFER',
    status: 'OFFERED',
    resumeUrl: '/documents/candidates/fiona_gallagher_cv.pdf',
    resumeFileName: 'Dr_Fiona_Gallagher_Executive_Dossier.pdf',
    coverLetter: 'Over 10 years guiding secondary science curricula and biotechnology laboratory safety.',
    source: 'JOB_BOARD',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    screeningNotes: 'Top-tier executive candidate. Verified supervisory credentials.',
    screeningDecision: 'SHORTLISTED',
    screenedBy: 'usr-admin-1',
    screenedByName: 'Dr. Arthur Pendelton',
    screenedAt: '2026-07-25T10:00:00.000Z',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-003',
        changedByName: 'Dr. Fiona Gallagher',
        timestamp: '2026-07-20T11:00:00.000Z',
        notes: 'Executive application filed.'
      },
      {
        stage: 'SHORTLISTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-07-25T10:00:00.000Z',
        notes: 'Passed screening.'
      },
      {
        stage: 'INTERVIEW',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-05T14:00:00.000Z',
        notes: 'Comprehensive interview rounds completed.'
      },
      {
        stage: 'SELECTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-15T11:00:00.000Z',
        notes: 'Selected for department head position.'
      },
      {
        stage: 'OFFER',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-25T15:00:00.000Z',
        notes: 'Formal offer generated and delivered.'
      }
    ],
    createdAt: '2026-07-20T11:00:00.000Z',
    updatedAt: '2026-08-25T15:00:00.000Z'
  },
  {
    id: 'app-2026-004',
    applicationNumber: 'APP-2026-004',
    candidateId: 'cand-2026-004',
    candidateName: 'Julian Mercer',
    candidateEmail: 'julian.mercer.candidate@example.com',
    candidatePhone: '+1 (555) 678-2345',
    candidateQualification: "Bachelor of Arts in Information & Records Management",
    candidateExperienceYears: 4,
    jobOpeningId: 'job-op-2026-03',
    jobTitle: 'Assistant Registrar — Academic Records & Admissions',
    departmentId: 'dept-adm',
    departmentName: 'Department of Administration & Operations',
    applicationDate: '2026-08-05',
    stage: 'SHORTLISTED',
    status: 'SHORTLISTED',
    resumeUrl: '/documents/candidates/julian_mercer_cv.pdf',
    resumeFileName: 'Julian_Mercer_Registrar_CV.pdf',
    source: 'DIRECT_APPLICATION',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    screeningNotes: 'Solid background in collegiate registrar management.',
    screeningDecision: 'SHORTLISTED',
    screenedBy: 'usr-admin-1',
    screenedByName: 'Dr. Arthur Pendelton',
    screenedAt: '2026-08-22T14:10:00.000Z',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-004',
        changedByName: 'Julian Mercer',
        timestamp: '2026-08-05T13:45:00.000Z',
        notes: 'Application registered.'
      },
      {
        stage: 'SHORTLISTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-22T14:10:00.000Z',
        notes: 'Approved for interview scheduling.'
      }
    ],
    createdAt: '2026-08-05T13:45:00.000Z',
    updatedAt: '2026-08-22T14:10:00.000Z'
  },
  {
    id: 'app-2026-005',
    applicationNumber: 'APP-2026-005',
    candidateId: 'cand-2026-005',
    candidateName: 'Devon Bradley',
    candidateEmail: 'devon.bradley.candidate@example.com',
    candidatePhone: '+1 (555) 789-3456',
    candidateQualification: "Bachelor of Science in Computer Networking & Cyber Security",
    candidateExperienceYears: 4,
    jobOpeningId: 'job-op-2026-04',
    jobTitle: 'IT Network & Systems Administrator',
    departmentId: 'dept-it',
    departmentName: 'Department of Information Technology',
    applicationDate: '2026-08-14',
    stage: 'SCREENING',
    status: 'UNDER_REVIEW',
    resumeUrl: '/documents/candidates/devon_bradley_resume.pdf',
    resumeFileName: 'Devon_Bradley_IT_Systems.pdf',
    source: 'JOB_BOARD',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-005',
        changedByName: 'Devon Bradley',
        timestamp: '2026-08-14T09:00:00.000Z',
        notes: 'Submitted resume via online job board.'
      },
      {
        stage: 'SCREENING',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-16T11:30:00.000Z',
        notes: 'Assigned to IT Director for technical qualification review.'
      }
    ],
    createdAt: '2026-08-14T09:00:00.000Z',
    updatedAt: '2026-08-16T11:30:00.000Z'
  },
  {
    id: 'app-2026-006',
    applicationNumber: 'APP-2026-006',
    candidateId: 'cand-2026-006',
    candidateName: 'Sophia Linnea Berg',
    candidateEmail: 'sophia.berg.candidate@example.com',
    candidatePhone: '+1 (555) 890-4567',
    candidateQualification: "Master of Arts in Elementary Education",
    candidateExperienceYears: 4,
    jobOpeningId: 'job-op-2026-05',
    jobTitle: 'Primary Homeroom Teacher — Grade 3 & 4',
    departmentId: 'dept-eng',
    departmentName: 'Department of Languages & Literature',
    applicationDate: '2026-08-16',
    stage: 'ACCEPTED',
    status: 'ACCEPTED',
    resumeUrl: '/documents/candidates/sophia_berg_cv.pdf',
    resumeFileName: 'Sophia_Berg_Elementary_Educator.pdf',
    source: 'SCHOOL_WEBSITE',
    assignedRecruiterId: 'usr-admin-1',
    assignedRecruiterName: 'Dr. Arthur Pendelton',
    screeningNotes: 'Passionate and patient educator. High parent engagement praise from prior institution.',
    screeningDecision: 'SHORTLISTED',
    screenedBy: 'usr-admin-1',
    screenedByName: 'Dr. Arthur Pendelton',
    screenedAt: '2026-08-18T10:00:00.000Z',
    stageHistory: [
      {
        stage: 'APPLIED',
        changedBy: 'cand-2026-006',
        changedByName: 'Sophia Linnea Berg',
        timestamp: '2026-08-16T10:30:00.000Z',
        notes: 'Application filed.'
      },
      {
        stage: 'SHORTLISTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-18T10:00:00.000Z',
        notes: 'Passed screening.'
      },
      {
        stage: 'INTERVIEW',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-22T13:00:00.000Z',
        notes: 'Completed teaching demo.'
      },
      {
        stage: 'SELECTED',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-24T15:00:00.000Z',
        notes: 'Selected for appointment.'
      },
      {
        stage: 'OFFER',
        changedBy: 'usr-admin-1',
        changedByName: 'Dr. Arthur Pendelton',
        timestamp: '2026-08-26T09:00:00.000Z',
        notes: 'Delivered formal contract.'
      },
      {
        stage: 'ACCEPTED',
        changedBy: 'cand-2026-006',
        changedByName: 'Sophia Linnea Berg',
        timestamp: '2026-08-28T16:45:00.000Z',
        notes: 'Candidate accepted offer. Ready for staff conversion.'
      }
    ],
    createdAt: '2026-08-16T10:30:00.000Z',
    updatedAt: '2026-08-28T16:45:00.000Z'
  }
];

export const INITIAL_INTERVIEWS: JobInterview[] = [
  {
    id: 'intv-2026-001',
    interviewNumber: 'INT-2026-001',
    applicationId: 'app-2026-001',
    candidateId: 'cand-2026-001',
    candidateName: 'Dr. Lawrence Vance',
    candidateEmail: 'lawrence.vance.candidate@example.com',
    jobOpeningId: 'job-op-2026-01',
    jobTitle: 'Senior Mathematics & Statistics Faculty',
    interviewRound: 1,
    roundName: 'Academic Panel & Pedagogy Evaluation',
    interviewType: 'IN_PERSON',
    interviewDate: '2026-07-15',
    startTime: '10:00',
    endTime: '11:30',
    location: 'Conference Room 204, Academic Center',
    meetingLink: undefined,
    panelMembers: [
      {
        userId: 'usr-admin-1',
        staffId: 'staff-prof-1',
        name: 'Dr. Arthur Pendelton',
        role: 'SUPER_ADMIN',
        email: 'admin@sygmate.edu'
      },
      {
        userId: 'usr-teacher-1',
        staffId: 'staff-prof-2',
        name: 'Prof. Sarah Jenkins',
        role: 'TEACHER',
        email: 'sarah.jenkins@sygmate.edu'
      }
    ],
    status: 'COMPLETED',
    evaluations: [
      {
        id: 'eval-1-pendelton',
        interviewerId: 'usr-admin-1',
        interviewerName: 'Dr. Arthur Pendelton',
        interviewerRole: 'Super Administrator',
        submittedAt: '2026-07-15T12:00:00.000Z',
        technicalSkillsScore: 5,
        communicationScore: 5,
        subjectKnowledgeScore: 5,
        teachingDemonstrationScore: 5,
        experienceScore: 5,
        problemSolvingScore: 5,
        professionalismScore: 5,
        overallScore: 5,
        recommendation: 'STRONG_HIRE',
        strengthsNotes: 'Profound mastery of advanced mathematics and exemplary pedagogical presence. Seamless lesson delivery.',
        weaknessesNotes: 'None observed.',
        generalComments: 'Highest recommendation. A tremendous asset to the school.'
      },
      {
        id: 'eval-1-jenkins',
        interviewerId: 'usr-teacher-1',
        interviewerName: 'Prof. Sarah Jenkins',
        interviewerRole: 'Senior Faculty',
        submittedAt: '2026-07-15T12:15:00.000Z',
        technicalSkillsScore: 5,
        communicationScore: 4,
        subjectKnowledgeScore: 5,
        teachingDemonstrationScore: 5,
        experienceScore: 4,
        problemSolvingScore: 5,
        professionalismScore: 5,
        overallScore: 4.7,
        recommendation: 'STRONG_HIRE',
        strengthsNotes: 'Dynamic lesson plan connecting real-world financial statistics with differential equations.',
        weaknessesNotes: 'Slightly fast pacing for introductory learners, easily calibrated.',
        generalComments: 'Will elevate our AP Mathematics cohort results significantly.'
      }
    ],
    overallRecommendation: 'STRONG_HIRE',
    averageScore: 4.85,
    notes: 'Panel interview completed with top evaluation.',
    createdAt: '2026-07-09T10:00:00.000Z',
    updatedAt: '2026-07-15T12:15:00.000Z'
  },
  {
    id: 'intv-2026-002',
    interviewNumber: 'INT-2026-002',
    applicationId: 'app-2026-002',
    candidateId: 'cand-2026-002',
    candidateName: 'Elena Vasquez-Moreno',
    candidateEmail: 'elena.moreno.candidate@example.com',
    jobOpeningId: 'job-op-2026-01',
    jobTitle: 'Senior Mathematics & Statistics Faculty',
    interviewRound: 1,
    roundName: 'Initial Screening & Subject Assessment',
    interviewType: 'ONLINE_VIDEO',
    interviewDate: '2026-08-18',
    startTime: '14:00',
    endTime: '15:00',
    location: 'Google Meet Virtual Boardroom',
    meetingLink: 'https://meet.google.com/syg-math-recruitment',
    panelMembers: [
      {
        userId: 'usr-admin-1',
        staffId: 'staff-prof-1',
        name: 'Dr. Arthur Pendelton',
        role: 'SUPER_ADMIN',
        email: 'admin@sygmate.edu'
      }
    ],
    status: 'COMPLETED',
    evaluations: [
      {
        id: 'eval-2-pendelton',
        interviewerId: 'usr-admin-1',
        interviewerName: 'Dr. Arthur Pendelton',
        interviewerRole: 'Super Administrator',
        submittedAt: '2026-08-18T15:30:00.000Z',
        technicalSkillsScore: 4,
        communicationScore: 5,
        subjectKnowledgeScore: 4,
        teachingDemonstrationScore: 4,
        experienceScore: 4,
        problemSolvingScore: 4,
        professionalismScore: 5,
        overallScore: 4.3,
        recommendation: 'HIRE',
        strengthsNotes: 'Articulate, empathetic, and shows excellent familiarity with curriculum standards.',
        weaknessesNotes: 'Less familiar with Olympiad level competition coaching.',
        generalComments: 'Solid teaching practitioner for secondary mathematics.'
      }
    ],
    overallRecommendation: 'HIRE',
    averageScore: 4.3,
    notes: 'Round 1 completed with positive recommendation.',
    createdAt: '2026-08-10T11:00:00.000Z',
    updatedAt: '2026-08-18T15:30:00.000Z'
  },
  {
    id: 'intv-2026-003',
    interviewNumber: 'INT-2026-003',
    applicationId: 'app-2026-004',
    candidateId: 'cand-2026-004',
    candidateName: 'Julian Mercer',
    candidateEmail: 'julian.mercer.candidate@example.com',
    jobOpeningId: 'job-op-2026-03',
    jobTitle: 'Assistant Registrar — Academic Records & Admissions',
    interviewRound: 1,
    roundName: 'Registrar Operations & Compliance Review',
    interviewType: 'IN_PERSON',
    interviewDate: '2026-09-18',
    startTime: '11:00',
    endTime: '12:00',
    location: 'Administration Conference Suite 101',
    meetingLink: undefined,
    panelMembers: [
      {
        userId: 'usr-admin-1',
        staffId: 'staff-prof-1',
        name: 'Dr. Arthur Pendelton',
        role: 'SUPER_ADMIN',
        email: 'admin@sygmate.edu'
      }
    ],
    status: 'SCHEDULED',
    evaluations: [],
    notes: 'Scheduled for upcoming week; candidate confirmed attendance.',
    createdAt: '2026-08-25T10:00:00.000Z',
    updatedAt: '2026-08-25T10:00:00.000Z'
  }
];

export const INITIAL_JOB_OFFERS: JobOffer[] = [
  {
    id: 'off-2026-001',
    offerNumber: 'OFF-2026-001',
    applicationId: 'app-2026-003',
    candidateId: 'cand-2026-003',
    candidateName: 'Dr. Fiona Gallagher',
    candidateEmail: 'fiona.gallagher.candidate@example.com',
    jobOpeningId: 'job-op-2026-02',
    positionTitle: 'Head of Department — Natural & Biological Sciences',
    departmentId: 'dept-sci',
    departmentName: 'Department of Natural Sciences',
    designationId: 'des-hod',
    designationTitle: 'Head of Department',
    staffType: 'teaching',
    employmentType: 'full_time',
    proposedJoiningDate: '2026-10-01',
    offeredSalary: '$72,500 / annum + Comprehensive Health + Academic Leadership Stipend',
    offerExpiryDate: '2026-09-30',
    probationPeriodMonths: 6,
    termsAndConditions: 'Standard full-time administrative and teaching contract. 40 hours weekly on-campus commitment with departmental leadership purview.',
    workScheduleId: 'sched-std-teach',
    workScheduleName: 'Standard Teaching Faculty Schedule (07:45 - 15:45)',
    supervisorName: 'Dr. Arthur Pendelton (Principal & Superintendent)',
    status: 'SENT',
    approvals: [
      {
        approverId: 'usr-admin-1',
        approverName: 'Dr. Arthur Pendelton',
        approverRole: 'SUPER_ADMIN',
        decision: 'APPROVED',
        remarks: 'Approved per Academic Board compensation committee guidelines.',
        decisionDate: '2026-08-25T14:30:00.000Z'
      }
    ],
    approvedBy: 'usr-admin-1',
    approvedByName: 'Dr. Arthur Pendelton',
    approvedAt: '2026-08-25T14:30:00.000Z',
    sentAt: '2026-08-25T15:00:00.000Z',
    sentBy: 'usr-admin-1',
    generatedLetterContent: `OFFICIAL LETTER OF APPOINTMENT OFFER
Sygmate Preparatory Academy
Date: August 25, 2026

Dear Dr. Fiona Gallagher,

On behalf of the Board of Trustees and Academic Council of Sygmate Preparatory Academy, we are delighted to extend this formal offer of appointment as Head of Department — Natural & Biological Sciences.

Position: Head of Department (Faculty Level)
Department: Department of Natural Sciences
Annual Base Remuneration: $72,500 / annum
Effective Joining Date: October 1, 2026
Probationary Review: Six (6) Months

We look forward to welcoming you to our faculty leadership team.`,
    createdAt: '2026-08-24T16:00:00.000Z',
    updatedAt: '2026-08-25T15:00:00.000Z'
  },
  {
    id: 'off-2026-002',
    offerNumber: 'OFF-2026-002',
    applicationId: 'app-2026-006',
    candidateId: 'cand-2026-006',
    candidateName: 'Sophia Linnea Berg',
    candidateEmail: 'sophia.berg.candidate@example.com',
    jobOpeningId: 'job-op-2026-05',
    positionTitle: 'Primary Homeroom Teacher — Grade 3 & 4',
    departmentId: 'dept-eng',
    departmentName: 'Department of Languages & Literature',
    designationId: 'des-asst-tch',
    designationTitle: 'Assistant Teacher',
    staffType: 'teaching',
    employmentType: 'full_time',
    proposedJoiningDate: '2026-09-25',
    offeredSalary: '$44,000 / annum + Standard Medical & Dental',
    offerExpiryDate: '2026-09-10',
    probationPeriodMonths: 3,
    termsAndConditions: 'Ten-month academic year full-time teaching contract. Daily working hours 07:45 - 15:45.',
    workScheduleId: 'sched-std-teach',
    workScheduleName: 'Standard Teaching Faculty Schedule (07:45 - 15:45)',
    supervisorName: 'Mrs. Evelyn Clark (Primary Coordinator)',
    status: 'ACCEPTED',
    approvals: [
      {
        approverId: 'usr-admin-1',
        approverName: 'Dr. Arthur Pendelton',
        approverRole: 'SUPER_ADMIN',
        decision: 'APPROVED',
        remarks: 'Approved.',
        decisionDate: '2026-08-25T16:00:00.000Z'
      }
    ],
    approvedBy: 'usr-admin-1',
    approvedByName: 'Dr. Arthur Pendelton',
    approvedAt: '2026-08-25T16:00:00.000Z',
    sentAt: '2026-08-26T09:00:00.000Z',
    sentBy: 'usr-admin-1',
    acceptedAt: '2026-08-28T16:45:00.000Z',
    generatedLetterContent: `OFFICIAL LETTER OF APPOINTMENT OFFER
Sygmate Preparatory Academy

Dear Ms. Sophia Berg,

We are delighted to formally offer you the position of Primary Homeroom Teacher (Grade 3 & 4) at Sygmate Preparatory Academy.

Compensation: $44,000 / annum
Reporting Date: September 25, 2026`,
    createdAt: '2026-08-25T15:30:00.000Z',
    updatedAt: '2026-08-28T16:45:00.000Z'
  }
];

export const INITIAL_ONBOARDING_RECORDS: OnboardingRecord[] = [
  {
    id: 'onb-2026-001',
    staffId: 'staff-prof-2',
    employeeCode: 'EMP-TCH-1002',
    staffName: 'Prof. Sarah Jenkins',
    staffType: 'teaching',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    designation: 'Senior Faculty',
    joiningDate: '2026-01-15',
    templateId: 'onb-tmpl-teaching',
    templateName: 'Teaching Faculty Onboarding Protocol',
    status: 'COMPLETED',
    totalTasks: 12,
    completedTasks: 12,
    progressPercentage: 100,
    startDate: '2026-01-15',
    targetCompletionDate: '2026-01-29',
    completedAt: '2026-01-28T16:00:00.000Z',
    notes: 'Onboarding completed in full with exemplary credentials verification.',
    createdAt: '2026-01-15T08:00:00.000Z',
    updatedAt: '2026-01-28T16:00:00.000Z',
    tasks: [
      {
        id: 'onb-task-1',
        title: 'Complete 360° Staff Profile & Personal Dossier',
        description: 'Ensure emergency contacts, address proof, and biographical fields are submitted.',
        category: 'DOCUMENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-17',
        completedAt: '2026-01-16T10:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 1
      },
      {
        id: 'onb-task-2',
        title: 'Submit Identity & Work Authorization Proof',
        category: 'DOCUMENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-18',
        completedAt: '2026-01-17T11:30:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 2
      },
      {
        id: 'onb-task-3',
        title: 'Verify Academic Degrees & Teaching Certificates',
        category: 'CREDENTIALS',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-20',
        completedAt: '2026-01-18T14:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 3
      },
      {
        id: 'onb-task-4',
        title: 'Sign Institutional Employment Agreement & Terms',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-18',
        completedAt: '2026-01-18T15:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 4
      },
      {
        id: 'onb-task-5',
        title: 'Assign Department & Academic Designation',
        category: 'WORK_SETUP',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-16',
        completedAt: '2026-01-15T09:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 5
      },
      {
        id: 'onb-task-6',
        title: 'Configure Teacher Portal Account & Security Roles',
        category: 'SYSTEM_ACCESS',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-16',
        completedAt: '2026-01-15T10:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 6
      },
      {
        id: 'onb-task-7',
        title: 'Assign Weekly Teaching Work Schedule & Shift',
        category: 'WORK_SETUP',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-17',
        completedAt: '2026-01-16T14:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 7
      },
      {
        id: 'onb-task-8',
        title: 'Academic Curriculum Orientation & LMS Onboarding',
        category: 'ORIENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-22',
        completedAt: '2026-01-21T16:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 8
      },
      {
        id: 'onb-task-9',
        title: 'Assign Department Mentor / Head of Department',
        category: 'ORIENTATION',
        isMandatory: false,
        status: 'COMPLETED',
        dueDate: '2026-01-22',
        completedAt: '2026-01-20T11:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 9
      },
      {
        id: 'onb-task-10',
        title: 'Acknowledge Child Safeguarding & Code of Conduct Policies',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-19',
        completedAt: '2026-01-19T09:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 10
      },
      {
        id: 'onb-task-11',
        title: 'Issue RFID Staff ID Card & Campus Access Pass',
        category: 'FACILITY',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-20',
        completedAt: '2026-01-20T14:30:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 11
      },
      {
        id: 'onb-task-12',
        title: 'Final Joining Review & HR Confirmation',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-01-29',
        completedAt: '2026-01-28T16:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 12
      }
    ]
  },
  {
    id: 'onb-2026-002',
    staffId: 'staff-prof-9',
    employeeCode: 'EMP-LIB-1006',
    staffName: 'Miriam Vance',
    staffType: 'administrative',
    departmentId: 'dept-lib',
    departmentName: 'Department of Library & Information Services',
    designation: 'Head Librarian',
    joiningDate: '2026-07-01',
    templateId: 'onb-tmpl-admin',
    templateName: 'Administrative Staff Onboarding Protocol',
    status: 'IN_PROGRESS',
    totalTasks: 10,
    completedTasks: 8,
    progressPercentage: 80,
    startDate: '2026-07-01',
    targetCompletionDate: '2026-07-15',
    notes: '8 of 10 tasks accomplished. Awaiting final records audit.',
    createdAt: '2026-07-01T08:30:00.000Z',
    updatedAt: '2026-07-12T14:00:00.000Z',
    tasks: [
      {
        id: 'onb-m-1',
        title: 'Complete Staff Profile & Contact Information',
        category: 'DOCUMENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-03',
        completedAt: '2026-07-02T10:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 1
      },
      {
        id: 'onb-m-2',
        title: 'Submit Identity & Background Verification Documents',
        category: 'DOCUMENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-04',
        completedAt: '2026-07-03T11:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 2
      },
      {
        id: 'onb-m-3',
        title: 'Sign Employment Agreement & Non-Disclosure Agreement',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-04',
        completedAt: '2026-07-03T15:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 3
      },
      {
        id: 'onb-m-4',
        title: 'Provision Admin Portal Account & Security Permissions',
        category: 'SYSTEM_ACCESS',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-02',
        completedAt: '2026-07-01T14:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 4
      },
      {
        id: 'onb-m-5',
        title: 'Workstation & IT Hardware Allocation',
        category: 'WORK_SETUP',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-03',
        completedAt: '2026-07-02T16:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 5
      },
      {
        id: 'onb-m-6',
        title: 'Assign Administrative Work Shift',
        category: 'WORK_SETUP',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-02',
        completedAt: '2026-07-01T11:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 6
      },
      {
        id: 'onb-m-7',
        title: 'Administrative Systems & Records Procedure Training',
        category: 'ORIENTATION',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-08',
        completedAt: '2026-07-07T16:30:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 7
      },
      {
        id: 'onb-m-8',
        title: 'Acknowledge Data Protection & Confidentiality Policy',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'COMPLETED',
        dueDate: '2026-07-06',
        completedAt: '2026-07-05T10:00:00.000Z',
        completedBy: 'usr-admin-1',
        completedByName: 'Dr. Arthur Pendelton',
        order: 8
      },
      {
        id: 'onb-m-9',
        title: 'Issue Official Staff ID Badge & Keys',
        category: 'FACILITY',
        isMandatory: true,
        status: 'IN_PROGRESS',
        dueDate: '2026-07-14',
        notes: 'RFID card programmed; physical archive cabinet keys being cut.',
        order: 9
      },
      {
        id: 'onb-m-10',
        title: 'Final HR Onboarding Sign-off',
        category: 'COMPLIANCE',
        isMandatory: true,
        status: 'PENDING',
        dueDate: '2026-07-15',
        order: 10
      }
    ]
  }
];
