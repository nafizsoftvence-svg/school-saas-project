/**
 * Part 15C & 15D — Certificate Generation, Issuance, Verification & Digital Seed Data
 * Sygmate School Management System
 */

import {
  CertificateTypeConfig,
  IssuedCertificate
} from '../../src/types/index.js';
import { INITIAL_CERTIFICATE_TEMPLATES } from './document-seed.js';

export const INITIAL_CERTIFICATE_TYPES: CertificateTypeConfig[] = [
  {
    id: 'cert-type-merit',
    schoolId: 'school-main',
    name: 'Academic Excellence & Merit Certificate',
    code: 'ACADEMIC_MERIT_CERT',
    description: 'Conferred to top scholars achieving superior grades, honor rolls, and dean list academic recognition.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-academic-merit',
    requiredFields: ['student_name', 'admission_number', 'class_name', 'academic_session'],
    numberingPrefix: 'MERIT',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 3,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'cert-type-bonafide',
    schoolId: 'school-main',
    name: 'Bonafide Student Certificate',
    code: 'BONAFIDE_CERT',
    description: 'Formal institutional affirmation certifying regular active student enrollment for passport, visa, bank, or transit verification.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-academic-merit',
    requiredFields: ['student_name', 'admission_number', 'class_name', 'academic_session'],
    numberingPrefix: 'BONA',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 3,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T08:30:00.000Z',
    updatedAt: '2026-01-05T08:30:00.000Z'
  },
  {
    id: 'cert-type-conduct',
    schoolId: 'school-main',
    name: 'Character & Exemplary Conduct Certificate',
    code: 'CHARACTER_CERT',
    description: 'Official citation verifying student conduct, moral character, peer leadership, and disciplinary standing.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-conduct',
    requiredFields: ['student_name', 'admission_number', 'class_name'],
    numberingPrefix: 'CHAR',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 2,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T09:00:00.000Z',
    updatedAt: '2026-01-05T09:00:00.000Z'
  },
  {
    id: 'cert-type-tc',
    schoolId: 'school-main',
    name: 'Transfer & School Leaving Certificate',
    code: 'TRANSFER_CERT',
    description: 'Statutory certificate issued upon student relocation or completion of institutional tenure.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-conduct',
    requiredFields: ['student_name', 'admission_number', 'class_name', 'academic_session'],
    numberingPrefix: 'TC',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 2,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T09:30:00.000Z',
    updatedAt: '2026-01-05T09:30:00.000Z'
  },
  {
    id: 'cert-type-completion',
    schoolId: 'school-main',
    name: 'Course & Curriculum Completion Certificate',
    code: 'COURSE_COMPLETION_CERT',
    description: 'Awarded upon satisfying all graduation benchmarks, subject coursework, and attendance minimums.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-academic-merit',
    requiredFields: ['student_name', 'admission_number', 'class_name', 'academic_session'],
    numberingPrefix: 'COMPL',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 2,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T10:00:00.000Z',
    updatedAt: '2026-01-05T10:00:00.000Z'
  },
  {
    id: 'cert-type-study',
    schoolId: 'school-main',
    name: 'Study & Medium of Instruction Certificate',
    code: 'STUDY_MEDIUM_CERT',
    description: 'Validates primary medium of instruction (English) and duration of continuous academic residency.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-academic-merit',
    requiredFields: ['student_name', 'admission_number', 'class_name'],
    numberingPrefix: 'STUDY',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 1,
    isActive: true,
    createdBy: 'usr-admin-1',
    createdAt: '2026-01-05T10:30:00.000Z',
    updatedAt: '2026-01-05T10:30:00.000Z'
  }
];

export const INITIAL_ISSUED_CERTIFICATES: IssuedCertificate[] = [
  {
    id: 'cert-iss-001',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-merit',
    certificateTypeCode: 'ACADEMIC_MERIT_CERT',
    certificateTypeName: 'Academic Excellence & Merit Certificate',
    certificateNumber: 'MERIT/2026/000001',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        rollNumber: 'G10-A-07',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026',
        academicSessionId: 'session-2025-2026',
        dob: '2010-04-12',
        gender: 'Male',
        admissionDate: '2022-09-01',
        guardianName: 'Carlos Rivera',
        address: '742 Evergreen Terrace, Academic District'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu',
        website: 'https://academy.sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        student_id: 'stud-prof-1',
        admission_number: 'ADM-2026-0842',
        class_name: 'Grade 10',
        section_name: 'Section A',
        academic_session: '2025-2026',
        academic_year: '2025-2026',
        school_name: 'Sygmate International Academy',
        certificate_number: 'MERIT/2026/000001',
        issue_date: '2026-02-15'
      }
    },
    renderedTitle: 'CERTIFICATE OF ACADEMIC EXCELLENCE',
    renderedSubtitle: 'This is proudly presented in recognition of outstanding scholastic distinction to',
    renderedBody: 'for demonstrating exemplary intellectual curiosity, peer leadership, and attaining High Distinction in Grade 10 during Academic Session 2025-2026.',
    renderedFooter: 'Verified by Sygmate Institutional Academic Council. Official registry document.',
    issueDate: '2026-02-15',
    status: 'ISSUED',
    verificationStatus: 'VERIFIED',
    verifiedBy: 'usr-teacher-1',
    verifiedByName: 'Dr. Evelyn Montgomery',
    verifiedAt: '2026-02-14T14:30:00.000Z',
    verificationNotes: 'Verified transcript scores and GPA clearance with the examination department.',
    approvalStatus: 'APPROVED',
    approvedBy: 'usr-admin-1',
    approvedByName: 'System Administrator',
    approvedAt: '2026-02-15T09:00:00.000Z',
    approvalNotes: 'Conferred and approved for official graduation honor roll.',
    digitalVerificationReference: 'SEC-VER-A1B2-C3D4-E5F6-0001',
    verificationUrl: '/verify-certificate?ref=SEC-VER-A1B2-C3D4-E5F6-0001',
    documentId: 'doc-vault-cert-001',
    fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200',
    fileName: 'Alex_Rivera_Academic_Merit_2026.pdf',
    issuedBy: 'usr-admin-1',
    issuedByName: 'System Administrator',
    issuedAt: '2026-02-15T10:00:00.000Z',
    version: 1,
    remarks: 'Awarded with Highest Honors for First Place in STEM Quad-County Olympiad.',
    qrVerificationCode: 'QR-VERIFY-MERIT-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-001-1',
        certificateId: 'cert-iss-001',
        action: 'GENERATED',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-02-14T10:00:00.000Z',
        previousStatus: 'DRAFT',
        newStatus: 'GENERATED'
      },
      {
        id: 'wf-seed-001-2',
        certificateId: 'cert-iss-001',
        action: 'VERIFIED',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-02-14T14:30:00.000Z',
        previousStatus: 'GENERATED',
        newStatus: 'PENDING_APPROVAL',
        notes: 'Verified transcript scores and GPA clearance with the examination department.'
      },
      {
        id: 'wf-seed-001-3',
        certificateId: 'cert-iss-001',
        action: 'APPROVED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-02-15T09:00:00.000Z',
        previousStatus: 'PENDING_APPROVAL',
        newStatus: 'APPROVED'
      },
      {
        id: 'wf-seed-001-4',
        certificateId: 'cert-iss-001',
        action: 'ISSUED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-02-15T10:00:00.000Z',
        previousStatus: 'APPROVED',
        newStatus: 'ISSUED'
      }
    ],
    createdAt: '2026-02-15T09:30:00.000Z',
    updatedAt: '2026-02-15T10:00:00.000Z'
  },
  {
    id: 'cert-iss-002',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-bonafide',
    certificateTypeCode: 'BONAFIDE_CERT',
    certificateTypeName: 'Bonafide Student Certificate',
    certificateNumber: 'BONA/2026/000001',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026',
        dob: '2010-04-12'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        certificate_number: 'BONA/2026/000001',
        issue_date: '2026-02-10'
      }
    },
    renderedTitle: 'BONAFIDE ENROLLMENT CERTIFICATE',
    renderedSubtitle: 'To Whom It May Concern',
    renderedBody: 'This is to officially certify that Alex Rivera, Admission No. ADM-2026-0842, is a bonafide regular student currently enrolled in Grade 10, Section A for the Academic Session 2025-2026.',
    renderedFooter: 'Authorized institutional certificate for official consular, transit, and verification purposes.',
    issueDate: '2026-02-10',
    status: 'ISSUED',
    verificationStatus: 'VERIFIED',
    approvalStatus: 'APPROVED',
    digitalVerificationReference: 'SEC-VER-B2C3-D4E5-F6A7-0002',
    verificationUrl: '/verify-certificate?ref=SEC-VER-B2C3-D4E5-F6A7-0002',
    documentId: 'doc-vault-cert-002',
    fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200',
    fileName: 'Alex_Rivera_Bonafide_2026.pdf',
    issuedBy: 'usr-admin-1',
    issuedByName: 'System Administrator',
    issuedAt: '2026-02-10T11:00:00.000Z',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-BONA-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-002-1',
        certificateId: 'cert-iss-002',
        action: 'ISSUED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-02-10T11:00:00.000Z',
        previousStatus: 'APPROVED',
        newStatus: 'ISSUED'
      }
    ],
    createdAt: '2026-02-10T10:45:00.000Z',
    updatedAt: '2026-02-10T11:00:00.000Z'
  },
  {
    id: 'cert-iss-003',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-conduct',
    certificateTypeCode: 'CHARACTER_CERT',
    certificateTypeName: 'Character & Exemplary Conduct Certificate',
    certificateNumber: 'CHAR/2026/000001',
    studentId: 'stud-prof-2',
    studentName: 'Sarah Jenkins',
    admissionNumber: 'ADM-2026-0914',
    className: 'Grade 9',
    sectionName: 'Section B',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-conduct',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[1] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-2',
        fullName: 'Sarah Jenkins',
        admissionNumber: 'ADM-2026-0914',
        className: 'Grade 9',
        sectionName: 'Section B',
        academicSession: '2025-2026',
        dob: '2011-08-22'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Sarah Jenkins',
        certificate_number: 'CHAR/2026/000001',
        issue_date: '2026-01-30'
      }
    },
    renderedTitle: 'CERTIFICATE OF CHARACTER & CONDUCT',
    renderedSubtitle: 'Office of the Dean of Students',
    renderedBody: 'This certifies that Sarah Jenkins is known to have demonstrated exemplary ethical conduct, discipline, and outstanding community engagement.',
    renderedFooter: 'Official disciplinary and moral character affirmation.',
    issueDate: '2026-01-30',
    status: 'ISSUED',
    verificationStatus: 'VERIFIED',
    approvalStatus: 'APPROVED',
    digitalVerificationReference: 'SEC-VER-C3D4-E5F6-A7B8-0003',
    verificationUrl: '/verify-certificate?ref=SEC-VER-C3D4-E5F6-A7B8-0003',
    documentId: 'doc-vault-cert-003',
    fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200',
    fileName: 'Sarah_Jenkins_Conduct_2026.pdf',
    issuedBy: 'usr-admin-1',
    issuedByName: 'System Administrator',
    issuedAt: '2026-01-30T14:00:00.000Z',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-CHAR-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-003-1',
        certificateId: 'cert-iss-003',
        action: 'ISSUED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-01-30T14:00:00.000Z',
        previousStatus: 'APPROVED',
        newStatus: 'ISSUED'
      }
    ],
    createdAt: '2026-01-30T13:30:00.000Z',
    updatedAt: '2026-01-30T14:00:00.000Z'
  },
  {
    id: 'cert-iss-004',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-completion',
    certificateTypeCode: 'COURSE_COMPLETION_CERT',
    certificateTypeName: 'Course & Curriculum Completion Certificate',
    certificateNumber: 'COMPL/2026/000001',
    studentId: 'stud-prof-2',
    studentName: 'Sarah Jenkins',
    admissionNumber: 'ADM-2026-0914',
    className: 'Grade 9',
    sectionName: 'Section B',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-2',
        fullName: 'Sarah Jenkins',
        admissionNumber: 'ADM-2026-0914',
        className: 'Grade 9',
        sectionName: 'Section B',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Sarah Jenkins',
        certificate_number: 'COMPL/2026/000001',
        issue_date: '2026-02-12'
      }
    },
    renderedTitle: 'CERTIFICATE OF CURRICULUM COMPLETION',
    renderedSubtitle: 'Academic Board of Examiners',
    renderedBody: 'Satisfied all coursework requirements and foundational prerequisites for Advanced Science.',
    issueDate: '2026-02-12',
    status: 'ISSUED',
    verificationStatus: 'VERIFIED',
    approvalStatus: 'APPROVED',
    digitalVerificationReference: 'SEC-VER-D4E5-F6A7-B8C9-0004',
    verificationUrl: '/verify-certificate?ref=SEC-VER-D4E5-F6A7-B8C9-0004',
    documentId: 'doc-vault-cert-004',
    fileUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80&w=1200',
    fileName: 'Sarah_Jenkins_Curriculum_2026.pdf',
    issuedBy: 'usr-admin-1',
    issuedByName: 'System Administrator',
    issuedAt: '2026-02-12T15:00:00.000Z',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-COMPL-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-004-1',
        certificateId: 'cert-iss-004',
        action: 'ISSUED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-02-12T15:00:00.000Z',
        previousStatus: 'APPROVED',
        newStatus: 'ISSUED'
      }
    ],
    createdAt: '2026-02-12T14:40:00.000Z',
    updatedAt: '2026-02-12T15:00:00.000Z'
  },
  {
    id: 'cert-iss-005',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-merit',
    certificateTypeCode: 'ACADEMIC_MERIT_CERT',
    certificateTypeName: 'Academic Excellence & Merit Certificate',
    certificateNumber: 'MERIT/2026/000002',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        certificate_number: 'MERIT/2026/000002',
        issue_date: '2026-01-20'
      }
    },
    renderedTitle: 'CERTIFICATE OF ACADEMIC EXCELLENCE',
    renderedSubtitle: 'This is proudly presented to',
    renderedBody: 'for scholastic distinction in Grade 10.',
    issueDate: '2026-01-20',
    status: 'CANCELLED',
    cancellationReason: 'Issued with preliminary midterm score rather than final validated board grade.',
    cancelledBy: 'usr-admin-1',
    cancelledByName: 'System Administrator',
    cancelledAt: '2026-01-21T09:00:00.000Z',
    digitalVerificationReference: 'SEC-VER-E5F6-A7B8-C9D0-0005',
    verificationUrl: '/verify-certificate?ref=SEC-VER-E5F6-A7B8-C9D0-0005',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-MERIT-2026-000002',
    workflowHistory: [
      {
        id: 'wf-seed-005-1',
        certificateId: 'cert-iss-005',
        action: 'CANCELLED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-01-21T09:00:00.000Z',
        previousStatus: 'GENERATED',
        newStatus: 'CANCELLED',
        reason: 'Issued with preliminary midterm score rather than final validated board grade.'
      }
    ],
    createdAt: '2026-01-20T10:00:00.000Z',
    updatedAt: '2026-01-21T09:00:00.000Z'
  },
  {
    id: 'cert-iss-006',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-merit',
    certificateTypeCode: 'ACADEMIC_MERIT_CERT',
    certificateTypeName: 'Academic Excellence & Merit Certificate',
    certificateNumber: 'MERIT/2026/000003',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        certificate_number: 'MERIT/2026/000003',
        issue_date: '2026-01-15'
      }
    },
    renderedTitle: 'CERTIFICATE OF ACADEMIC EXCELLENCE',
    renderedSubtitle: 'Presented for academic honor roll',
    renderedBody: 'Scholastic excellence during fall term.',
    issueDate: '2026-01-15',
    status: 'REVOKED',
    revocationReason: 'Grade auditing revealed transcript reconciliation discrepancy.',
    revokedBy: 'usr-admin-1',
    revokedByName: 'System Administrator',
    revokedAt: '2026-01-25T11:00:00.000Z',
    digitalVerificationReference: 'SEC-VER-F6A7-B8C9-D0E1-0006',
    verificationUrl: '/verify-certificate?ref=SEC-VER-F6A7-B8C9-D0E1-0006',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-MERIT-2026-000003',
    workflowHistory: [
      {
        id: 'wf-seed-006-1',
        certificateId: 'cert-iss-006',
        action: 'ISSUED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-01-15T10:00:00.000Z',
        previousStatus: 'APPROVED',
        newStatus: 'ISSUED'
      },
      {
        id: 'wf-seed-006-2',
        certificateId: 'cert-iss-006',
        action: 'REVOKED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-01-25T11:00:00.000Z',
        previousStatus: 'ISSUED',
        newStatus: 'REVOKED',
        reason: 'Grade auditing revealed transcript reconciliation discrepancy.'
      }
    ],
    createdAt: '2026-01-15T09:00:00.000Z',
    updatedAt: '2026-01-25T11:00:00.000Z'
  },
  // Part 15D: Verification Queue Seed item
  {
    id: 'cert-iss-007',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-merit',
    certificateTypeCode: 'ACADEMIC_MERIT_CERT',
    certificateTypeName: 'Academic Excellence & Merit Certificate',
    certificateNumber: 'MERIT/2026/000004',
    studentId: 'stud-prof-2',
    studentName: 'Sarah Jenkins',
    admissionNumber: 'ADM-2026-0914',
    className: 'Grade 9',
    sectionName: 'Section B',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-2',
        fullName: 'Sarah Jenkins',
        admissionNumber: 'ADM-2026-0914',
        className: 'Grade 9',
        sectionName: 'Section B',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Sarah Jenkins',
        certificate_number: 'MERIT/2026/000004',
        issue_date: '2026-03-01',
        created_by_user_id: 'usr-teacher-1'
      }
    },
    renderedTitle: 'CERTIFICATE OF ACADEMIC EXCELLENCE',
    renderedSubtitle: 'This is proudly presented to',
    renderedBody: 'for scholastic distinction in Grade 9.',
    issueDate: '2026-03-01',
    status: 'PENDING_VERIFICATION',
    verificationStatus: 'PENDING',
    approvalStatus: 'PENDING',
    digitalVerificationReference: 'SEC-VER-1122-3344-5566-0007',
    verificationUrl: '/verify-certificate?ref=SEC-VER-1122-3344-5566-0007',
    version: 1,
    remarks: 'Candidate nominated for Math & Robotics distinction.',
    qrVerificationCode: 'QR-VERIFY-MERIT-2026-000004',
    workflowHistory: [
      {
        id: 'wf-seed-007-1',
        certificateId: 'cert-iss-007',
        action: 'GENERATED',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-03-01T08:00:00.000Z',
        previousStatus: 'DRAFT',
        newStatus: 'GENERATED'
      },
      {
        id: 'wf-seed-007-2',
        certificateId: 'cert-iss-007',
        action: 'SUBMITTED_FOR_VERIFICATION',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-03-01T08:30:00.000Z',
        previousStatus: 'GENERATED',
        newStatus: 'PENDING_VERIFICATION',
        notes: 'Submitted for prerequisite verification.'
      }
    ],
    createdAt: '2026-03-01T08:00:00.000Z',
    updatedAt: '2026-03-01T08:30:00.000Z'
  },
  // Part 15D: Approval Queue Seed item
  {
    id: 'cert-iss-008',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-study',
    certificateTypeCode: 'STUDY_MEDIUM_CERT',
    certificateTypeName: 'Study & Medium of Instruction Certificate',
    certificateNumber: 'STUDY/2026/000001',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        certificate_number: 'STUDY/2026/000001',
        issue_date: '2026-03-02',
        created_by_user_id: 'usr-teacher-1'
      }
    },
    renderedTitle: 'CERTIFICATE OF MEDIUM OF INSTRUCTION',
    renderedSubtitle: 'Academic Affairs Bureau',
    renderedBody: 'This certifies that the English language has been the sole medium of instruction throughout the student enrollment.',
    issueDate: '2026-03-02',
    status: 'PENDING_APPROVAL',
    verificationStatus: 'VERIFIED',
    verifiedBy: 'usr-teacher-1',
    verifiedByName: 'Dr. Evelyn Montgomery',
    verifiedAt: '2026-03-02T09:15:00.000Z',
    verificationNotes: 'Transcript records verified. Medium of instruction confirmed as English.',
    approvalStatus: 'PENDING',
    digitalVerificationReference: 'SEC-VER-2233-4455-6677-0008',
    verificationUrl: '/verify-certificate?ref=SEC-VER-2233-4455-6677-0008',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-STUDY-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-008-1',
        certificateId: 'cert-iss-008',
        action: 'VERIFIED',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-03-02T09:15:00.000Z',
        previousStatus: 'PENDING_VERIFICATION',
        newStatus: 'PENDING_APPROVAL',
        notes: 'Transcript records verified. Medium of instruction confirmed as English.'
      }
    ],
    createdAt: '2026-03-02T08:45:00.000Z',
    updatedAt: '2026-03-02T09:15:00.000Z'
  },
  // Part 15D: Approved & Ready for Issuance Seed item
  {
    id: 'cert-iss-009',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-bonafide',
    certificateTypeCode: 'BONAFIDE_CERT',
    certificateTypeName: 'Bonafide Student Certificate',
    certificateNumber: 'BONA/2026/000002',
    studentId: 'stud-prof-2',
    studentName: 'Sarah Jenkins',
    admissionNumber: 'ADM-2026-0914',
    className: 'Grade 9',
    sectionName: 'Section B',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-academic-merit',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[0] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-2',
        fullName: 'Sarah Jenkins',
        admissionNumber: 'ADM-2026-0914',
        className: 'Grade 9',
        sectionName: 'Section B',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Sarah Jenkins',
        certificate_number: 'BONA/2026/000002',
        issue_date: '2026-03-03'
      }
    },
    renderedTitle: 'BONAFIDE ENROLLMENT CERTIFICATE',
    renderedSubtitle: 'Official Verification',
    renderedBody: 'This certifies active enrollment in Grade 9, Section B.',
    issueDate: '2026-03-03',
    status: 'APPROVED',
    verificationStatus: 'VERIFIED',
    verifiedBy: 'usr-teacher-1',
    verifiedByName: 'Dr. Evelyn Montgomery',
    verifiedAt: '2026-03-03T10:00:00.000Z',
    approvalStatus: 'APPROVED',
    approvedBy: 'usr-admin-1',
    approvedByName: 'System Administrator',
    approvedAt: '2026-03-03T11:00:00.000Z',
    approvalNotes: 'Approved for international visa application submission.',
    digitalVerificationReference: 'SEC-VER-3344-5566-7788-0009',
    verificationUrl: '/verify-certificate?ref=SEC-VER-3344-5566-7788-0009',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-BONA-2026-000002',
    workflowHistory: [
      {
        id: 'wf-seed-009-1',
        certificateId: 'cert-iss-009',
        action: 'APPROVED',
        actorId: 'usr-admin-1',
        actorName: 'System Administrator',
        actorRole: 'SUPER_ADMIN',
        timestamp: '2026-03-03T11:00:00.000Z',
        previousStatus: 'PENDING_APPROVAL',
        newStatus: 'APPROVED',
        notes: 'Approved for international visa application submission.'
      }
    ],
    createdAt: '2026-03-03T09:30:00.000Z',
    updatedAt: '2026-03-03T11:00:00.000Z'
  },
  // Part 15D: Verification Rejected Seed item
  {
    id: 'cert-iss-010',
    schoolId: 'school-main',
    certificateTypeId: 'cert-type-tc',
    certificateTypeCode: 'TRANSFER_CERT',
    certificateTypeName: 'Transfer & School Leaving Certificate',
    certificateNumber: 'TC/2026/000001',
    studentId: 'stud-prof-1',
    studentName: 'Alex Rivera',
    admissionNumber: 'ADM-2026-0842',
    className: 'Grade 10',
    sectionName: 'Section A',
    academicSessionId: 'session-2025-2026',
    academicSessionName: '2025-2026',
    templateId: 'tmpl-cert-conduct',
    templateSnapshot: { ...INITIAL_CERTIFICATE_TEMPLATES[1] },
    dataSnapshot: {
      student: {
        id: 'stud-prof-1',
        fullName: 'Alex Rivera',
        admissionNumber: 'ADM-2026-0842',
        className: 'Grade 10',
        sectionName: 'Section A',
        academicSession: '2025-2026'
      },
      school: {
        id: 'school-main',
        name: 'Sygmate International Academy',
        address: 'Campus Boulevard, Academic City',
        contact: '(800) 555-0199',
        email: 'registrar@sygmate.edu'
      },
      variables: {
        student_name: 'Alex Rivera',
        certificate_number: 'TC/2026/000001',
        issue_date: '2026-03-04'
      }
    },
    renderedTitle: 'TRANSFER CERTIFICATE',
    renderedSubtitle: 'Leaving Certificate Document',
    renderedBody: 'Student requested transfer certificate.',
    issueDate: '2026-03-04',
    status: 'VERIFICATION_REJECTED',
    verificationStatus: 'REJECTED',
    verifiedBy: 'usr-teacher-1',
    verifiedByName: 'Dr. Evelyn Montgomery',
    verifiedAt: '2026-03-04T12:00:00.000Z',
    verificationRejectionReason: 'Library clearance incomplete and outstanding fee dues pending clearance before transfer certificate issuance.',
    approvalStatus: 'PENDING',
    digitalVerificationReference: 'SEC-VER-4455-6677-8899-0010',
    verificationUrl: '/verify-certificate?ref=SEC-VER-4455-6677-8899-0010',
    version: 1,
    qrVerificationCode: 'QR-VERIFY-TC-2026-000001',
    workflowHistory: [
      {
        id: 'wf-seed-010-1',
        certificateId: 'cert-iss-010',
        action: 'VERIFICATION_REJECTED',
        actorId: 'usr-teacher-1',
        actorName: 'Dr. Evelyn Montgomery',
        actorRole: 'TEACHER',
        timestamp: '2026-03-04T12:00:00.000Z',
        previousStatus: 'PENDING_VERIFICATION',
        newStatus: 'VERIFICATION_REJECTED',
        reason: 'Library clearance incomplete and outstanding fee dues pending clearance before transfer certificate issuance.'
      }
    ],
    createdAt: '2026-03-04T11:00:00.000Z',
    updatedAt: '2026-03-04T12:00:00.000Z'
  }
];

export const INITIAL_CERTIFICATE_SEQUENCES: Record<string, number> = {
  'school-main_MERIT_2026': 4,
  'school-main_BONA_2026': 2,
  'school-main_CHAR_2026': 1,
  'school-main_TC_2026': 1,
  'school-main_COMPL_2026': 1,
  'school-main_STUDY_2026': 1
};
