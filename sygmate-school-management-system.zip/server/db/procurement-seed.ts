/**
 * Procurement & Purchase Workflow Seed Data (Part 14D)
 * Sygmate School Management System
 */

import {
  PurchaseRequest,
  PurchaseOrder,
  GoodsReceipt
} from '../../src/types/index.js';

export const INITIAL_PURCHASE_REQUESTS: PurchaseRequest[] = [
  {
    id: 'pr-1',
    schoolId: 'school-main',
    requestNumber: 'PR-2026-0001',
    requestDate: '2026-02-01T09:30:00.000Z',
    requiredDate: '2026-02-25T17:00:00.000Z',
    priority: 'HIGH',
    status: 'CONVERTED_TO_PO',
    requestingUserId: 'usr-teacher-1',
    requestingUserName: 'Marcus Vance',
    departmentId: 'dept-it',
    departmentName: 'Information Technology',
    targetLocationId: 'loc-comp',
    targetLocationName: 'Primary Technology & Computer Lab',
    purpose: 'Quarterly replenishment of networking patches, laser toner cartridges, and backup peripherals',
    notes: 'Urgent for mid-term examination preparation lab sessions',
    totalEstimatedAmount: 1850,
    reviewedBy: 'usr-admin-1',
    reviewedByName: 'Dr. Evelyn Montgomery',
    reviewedAt: '2026-02-02T11:00:00.000Z',
    reviewNotes: 'Approved in line with Q1 STEM hardware operational budget.',
    purchaseOrderId: 'po-1',
    purchaseOrderNumber: 'PO-2026-0001',
    items: [
      {
        id: 'pri-1-1',
        itemId: 'item-2', // Cat6 UTP Patch Cable
        itemName: 'Cat6 UTP Ethernet Patch Cable (3m)',
        itemCode: 'IT-CAB-002',
        description: 'Snagless RJ45 gigabit network cables for workstation pods',
        quantity: 50,
        unitId: 'unit-pcs',
        unitShortCode: 'PCS',
        estimatedUnitCost: 6.5,
        estimatedTotal: 325,
        preferredSupplierId: 'sup-3',
        preferredSupplierName: 'New England IT Infrastructure & Hardware',
        isCapitalAsset: false
      },
      {
        id: 'pri-1-2',
        itemId: 'item-1', // A4 Paper Ream
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        description: 'High-speed printer reams for student test paper distribution',
        quantity: 200,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        estimatedUnitCost: 7.25,
        estimatedTotal: 1450,
        preferredSupplierId: 'sup-1',
        preferredSupplierName: 'Apex Educational & Office Supplies',
        isCapitalAsset: false
      }
    ],
    createdAt: '2026-02-01T09:30:00.000Z',
    updatedAt: '2026-02-03T10:15:00.000Z'
  },
  {
    id: 'pr-2',
    schoolId: 'school-main',
    requestNumber: 'PR-2026-0002',
    requestDate: '2026-02-10T14:15:00.000Z',
    requiredDate: '2026-03-15T17:00:00.000Z',
    priority: 'MEDIUM',
    status: 'APPROVED',
    requestingUserId: 'usr-teacher-2',
    requestingUserName: 'Dr. Robert Vance',
    departmentId: 'dept-sci',
    departmentName: 'Science',
    targetLocationId: 'loc-chem',
    targetLocationName: 'Senior Science Chemistry Lab',
    purpose: 'Standard laboratory reagent replenish and safety goggles for chemistry practicals',
    notes: 'Required before regional science olympiad workshops',
    totalEstimatedAmount: 640,
    reviewedBy: 'usr-admin-1',
    reviewedByName: 'Dr. Evelyn Montgomery',
    reviewedAt: '2026-02-12T09:00:00.000Z',
    reviewNotes: 'Authorized for purchase. Ready to dispatch PO to Cambridge Scientific.',
    items: [
      {
        id: 'pri-2-1',
        itemId: 'item-3', // Whiteboard Markers
        itemName: 'Chisel Tip Dry-Erase Whiteboard Markers (Assorted 4-Pack)',
        itemCode: 'OFF-MRK-003',
        description: 'Laboratory glass write-on and classroom markers',
        quantity: 40,
        unitId: 'unit-pkg',
        unitShortCode: 'PKG',
        estimatedUnitCost: 6.0,
        estimatedTotal: 240,
        preferredSupplierId: 'sup-2',
        preferredSupplierName: 'Cambridge Scientific & Lab Instruments',
        isCapitalAsset: false
      }
    ],
    createdAt: '2026-02-10T14:15:00.000Z',
    updatedAt: '2026-02-12T09:00:00.000Z'
  },
  {
    id: 'pr-3',
    schoolId: 'school-main',
    requestNumber: 'PR-2026-0003',
    requestDate: '2026-02-15T11:00:00.000Z',
    requiredDate: '2026-03-01T17:00:00.000Z',
    priority: 'URGENT',
    status: 'SUBMITTED',
    requestingUserId: 'usr-teacher-1',
    requestingUserName: 'Marcus Vance',
    departmentId: 'dept-it',
    departmentName: 'Information Technology',
    targetLocationId: 'loc-comp',
    targetLocationName: 'Primary Technology & Computer Lab',
    purpose: 'Capital acquisition of high-resolution interactive displays for robotics room',
    notes: 'Capital expenditure request for FY2026 digital campus upgrade',
    totalEstimatedAmount: 2400,
    items: [
      {
        id: 'pri-3-1',
        itemId: 'item-2',
        itemName: 'Interactive 4K Digital Smartboard Screen',
        itemCode: 'CAP-IT-009',
        description: '65-inch anti-glare interactive touch panel for robotics demonstration',
        quantity: 2,
        unitId: 'unit-pcs',
        unitShortCode: 'PCS',
        estimatedUnitCost: 1200,
        estimatedTotal: 2400,
        preferredSupplierId: 'sup-3',
        preferredSupplierName: 'New England IT Infrastructure & Hardware',
        isCapitalAsset: true
      }
    ],
    createdAt: '2026-02-15T11:00:00.000Z',
    updatedAt: '2026-02-15T11:00:00.000Z'
  }
];

export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    id: 'po-1',
    schoolId: 'school-main',
    poNumber: 'PO-2026-0001',
    poDate: '2026-02-03T10:15:00.000Z',
    supplierId: 'sup-1',
    supplierName: 'Apex Educational & Office Supplies',
    supplierCode: 'SUP-2026-001',
    purchaseRequestId: 'pr-1',
    purchaseRequestNumber: 'PR-2026-0001',
    departmentId: 'dept-it',
    departmentName: 'Information Technology',
    deliveryLocationId: 'loc-main',
    deliveryLocationName: 'Central Campus Logistics Warehouse',
    expectedDeliveryDate: '2026-02-20T17:00:00.000Z',
    paymentTerms: 'NET 30 Days upon physical receipt verification',
    supplierInvoiceNumber: 'INV-APEX-88301',
    status: 'PARTIALLY_RECEIVED',
    subtotal: 1450,
    totalDiscount: 0,
    totalTax: 72.5,
    grandTotal: 1522.5,
    notes: 'Delivery to loading bay 2 between 9am and 3pm',
    items: [
      {
        id: 'poi-1-1',
        itemId: 'item-1',
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        description: 'High-speed printer reams for student test paper distribution',
        quantityOrdered: 200,
        quantityReceived: 120,
        quantityRemaining: 80,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        unitPrice: 7.25,
        discountPercentage: 0,
        discountAmount: 0,
        taxPercentage: 5,
        taxAmount: 72.5,
        lineTotal: 1522.5,
        isCapitalAsset: false,
        expectedDeliveryDate: '2026-02-20T17:00:00.000Z'
      }
    ],
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Evelyn Montgomery',
    approvedBy: 'usr-admin-1',
    approvedByName: 'Dr. Evelyn Montgomery',
    approvedAt: '2026-02-03T11:00:00.000Z',
    sentAt: '2026-02-03T11:30:00.000Z',
    createdAt: '2026-02-03T10:15:00.000Z',
    updatedAt: '2026-02-18T14:30:00.000Z'
  },
  {
    id: 'po-2',
    schoolId: 'school-main',
    poNumber: 'PO-2026-0002',
    poDate: '2026-02-14T09:00:00.000Z',
    supplierId: 'sup-3',
    supplierName: 'New England IT Infrastructure & Hardware',
    supplierCode: 'SUP-2026-003',
    departmentId: 'dept-it',
    departmentName: 'Information Technology',
    deliveryLocationId: 'loc-comp',
    deliveryLocationName: 'Primary Technology & Computer Lab',
    expectedDeliveryDate: '2026-02-28T17:00:00.000Z',
    paymentTerms: 'NET 45 Days',
    status: 'APPROVED',
    subtotal: 950,
    totalDiscount: 50,
    totalTax: 45,
    grandTotal: 945,
    notes: 'Direct institutional purchase of patch cables and networking transceivers',
    items: [
      {
        id: 'poi-2-1',
        itemId: 'item-2',
        itemName: 'Cat6 UTP Ethernet Patch Cable (3m)',
        itemCode: 'IT-CAB-002',
        description: 'Snagless RJ45 gigabit network cables for workstation pods',
        quantityOrdered: 100,
        quantityReceived: 0,
        quantityRemaining: 100,
        unitId: 'unit-pcs',
        unitShortCode: 'PCS',
        unitPrice: 6.5,
        discountPercentage: 5,
        discountAmount: 32.5,
        taxPercentage: 5,
        taxAmount: 30.87,
        lineTotal: 648.37,
        isCapitalAsset: false
      }
    ],
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Evelyn Montgomery',
    approvedBy: 'usr-admin-1',
    approvedByName: 'Dr. Evelyn Montgomery',
    approvedAt: '2026-02-14T10:00:00.000Z',
    sentAt: '2026-02-14T10:30:00.000Z',
    createdAt: '2026-02-14T09:00:00.000Z',
    updatedAt: '2026-02-14T10:30:00.000Z'
  }
];

export const INITIAL_GOODS_RECEIPTS: GoodsReceipt[] = [
  {
    id: 'grn-1',
    schoolId: 'school-main',
    receiptNumber: 'GRN-2026-0001',
    purchaseOrderId: 'po-1',
    purchaseOrderNumber: 'PO-2026-0001',
    supplierId: 'sup-1',
    supplierName: 'Apex Educational & Office Supplies',
    supplierCode: 'SUP-2026-001',
    receivingLocationId: 'loc-main',
    receivingLocationName: 'Central Campus Logistics Warehouse',
    receiptDate: '2026-02-18T14:30:00.000Z',
    receivedBy: 'usr-admin-1',
    receivedByName: 'Dr. Evelyn Montgomery',
    referenceNumber: 'DN-APEX-9921',
    supplierInvoiceNumber: 'INV-APEX-88301',
    status: 'COMPLETED',
    totalOrderedQty: 200,
    totalReceivedQty: 120,
    totalAcceptedQty: 115,
    totalRejectedQty: 5,
    notes: 'Partial shipment batch 1 of 2. 5 boxes wet from transit water leak, returned to courier.',
    items: [
      {
        id: 'gri-1-1',
        poItemId: 'poi-1-1',
        itemId: 'item-1',
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        quantityOrdered: 200,
        previouslyReceived: 0,
        quantityReceived: 120,
        quantityAccepted: 115,
        quantityRejected: 5,
        remainingQuantity: 80,
        rejectionReason: 'Water damaged outer corrugated box during transit',
        itemCondition: 'GOOD',
        isCapitalAsset: false,
        notes: '115 boxes verified in good order and placed into Main Warehouse Rack A-2.',
        stockTransactionId: 'tx-grn-seed-1'
      }
    ],
    createdAt: '2026-02-18T14:30:00.000Z',
    updatedAt: '2026-02-18T14:30:00.000Z'
  }
];
