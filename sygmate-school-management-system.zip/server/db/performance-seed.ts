/**
 * Sygmate School Management System
 * Staff Performance Management (Part 12E) Seed Data
 */

import {
  PerformanceReviewCycle,
  PerformanceCriterion,
  PerformanceGoal,
  StaffPerformanceReview,
  PerformanceFeedbackItem,
  PerformanceImprovementPlan
} from '../../src/types/index.js';

// ====================================================
// 1. REUSABLE PERFORMANCE CRITERIA / KPIS
// ====================================================

export const INITIAL_PERFORMANCE_CRITERIA: PerformanceCriterion[] = [
  // --- Teaching Faculty Criteria (Sum of weights = 100) ---
  {
    id: 'crit-t-1',
    name: 'Lesson Preparation & Curriculum Delivery',
    code: 'TCH-PED-01',
    description: 'Systematic lesson planning, alignment with curriculum standards, and clear instructional goals.',
    category: 'PEDAGOGY',
    weight: 15,
    maxScore: 5,
    scoringRubric: [
      { score: 1, label: 'Unsatisfactory', description: 'Plans missing, lessons unstructured, no curriculum alignment.' },
      { score: 3, label: 'Meets Expectations', description: 'Consistent lesson planning following syllabi with adequate resources.' },
      { score: 5, label: 'Exceptional', description: 'Innovative, highly differentiated lesson architectures integrating multimedia and rigor.' }
    ],
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-2',
    name: 'Instructional Quality & Pedagogical Delivery',
    code: 'TCH-PED-02',
    description: 'Effectiveness of teaching methodologies, clarity of explanation, and student active engagement.',
    category: 'PEDAGOGY',
    weight: 15,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-3',
    name: 'Classroom Management & Behavioral Culture',
    code: 'TCH-ENV-01',
    description: 'Fosters an orderly, respectful, psychologically safe, and stimulating academic environment.',
    category: 'CLASSROOM_MANAGEMENT',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-4',
    name: 'Student Support, Inclusivity & Pastoral Care',
    code: 'TCH-OUT-01',
    description: 'Identifying struggling students, providing targeted remedial assistance, and nurturing growth.',
    category: 'STUDENT_OUTCOMES',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-5',
    name: 'Subject Mastery & Domain Expertise',
    code: 'TCH-PED-03',
    description: 'Depth and currency of academic subject knowledge, accuracy, and scholarly leadership.',
    category: 'PEDAGOGY',
    weight: 15,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-6',
    name: 'Assessment Quality, Grading & Timely Feedback',
    code: 'TCH-OUT-02',
    description: 'Rigorous assessment design, timely entry of exam marks, rubric adherence, and feedback.',
    category: 'PEDAGOGY',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-7',
    name: 'Parent & Guardian Communication',
    code: 'TCH-COM-01',
    description: 'Proactive engagement with parents via school communication portal, conferences, and logs.',
    category: 'COMMUNICATION',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-8',
    name: 'Institutional Duties, Governance & Committee Work',
    code: 'TCH-INS-01',
    description: 'Active contribution to school events, exam invigilation, club mentoring, and administrative duties.',
    category: 'INSTITUTIONAL_DUTIES',
    weight: 5,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-9',
    name: 'Professional Development & Pedagogical Innovation',
    code: 'TCH-PRF-01',
    description: 'Participation in faculty workshops, peer reviews, advanced certifications, and new methodologies.',
    category: 'PROFESSIONALISM',
    weight: 5,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-t-10',
    name: 'Punctuality, Schedule Adherence & Attendance',
    code: 'TCH-ATT-01',
    description: 'Consistent daily attendance, prompt arrival to assigned periods, and compliance with shifts.',
    category: 'ATTENDANCE_PUNCTUALITY',
    weight: 5,
    maxScore: 5,
    applicableStaffType: 'TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },

  // --- General & Non-Teaching Staff Criteria (Sum of weights = 100) ---
  {
    id: 'crit-g-1',
    name: 'Job Knowledge & Operational Competence',
    code: 'GEN-OPS-01',
    description: 'Mastery of departmental procedures, software tools, equipment, and statutory regulations.',
    category: 'WORK_QUALITY',
    weight: 20,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-2',
    name: 'Work Quality, Accuracy & Attention to Detail',
    code: 'GEN-OPS-02',
    description: 'Precision in record-keeping, zero-defect processing, and high standard of deliverables.',
    category: 'WORK_QUALITY',
    weight: 20,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-3',
    name: 'Productivity & Execution Speed',
    code: 'GEN-PRD-01',
    description: 'Efficiency in completing daily operational queues, meeting service deadlines, and backlog handling.',
    category: 'PRODUCTIVITY',
    weight: 15,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-4',
    name: 'Attendance, Punctuality & Shift Reliability',
    code: 'GEN-ATT-01',
    description: 'Daily attendance consistency, roster compliance, and dependable operational coverage.',
    category: 'ATTENDANCE_PUNCTUALITY',
    weight: 15,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-5',
    name: 'Communication & Interdepartmental Teamwork',
    code: 'GEN-COM-01',
    description: 'Courteous collaboration with teachers, administration, and campus stakeholders.',
    category: 'COMMUNICATION',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-6',
    name: 'Problem Solving, Resourcefulness & Initiative',
    code: 'GEN-LDR-01',
    description: 'Proactively resolving bottlenecks, suggesting process improvements, and handling emergencies.',
    category: 'LEADERSHIP',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  },
  {
    id: 'crit-g-7',
    name: 'Institutional Compliance, Safety & Ethics',
    code: 'GEN-PRF-01',
    description: 'Strict adherence to child protection guidelines, campus safety, and confidentiality.',
    category: 'PROFESSIONALISM',
    weight: 10,
    maxScore: 5,
    applicableStaffType: 'NON_TEACHING',
    isActive: true,
    createdAt: '2026-01-05T08:00:00.000Z',
    updatedAt: '2026-01-05T08:00:00.000Z'
  }
];

// ====================================================
// 2. PERFORMANCE REVIEW CYCLES
// ====================================================

export const INITIAL_REVIEW_CYCLES: PerformanceReviewCycle[] = [
  {
    id: 'prc-2025-2026-annual',
    name: 'Annual Faculty & Staff Appraisal 2025-2026',
    code: 'APP-2025-26-ANN',
    description: 'Comprehensive annual performance evaluation, goal verification, and faculty development review for all staff.',
    academicSessionId: 'session-1',
    academicSessionName: 'Academic Year 2025-2026',
    reviewPeriod: 'Jul 2025 - Jun 2026',
    startDate: '2026-06-01',
    endDate: '2026-09-30',
    selfAssessmentDeadline: '2026-08-15',
    supervisorReviewDeadline: '2026-09-10',
    reviewType: 'ANNUAL',
    frequency: 'ANNUAL',
    applicableStaffCategories: ['ALL'],
    applicableDepartmentIds: [],
    applicableDesignationIds: [],
    status: 'IN_PROGRESS',
    scoringModel: 'WEIGHTED_100',
    allowSelfAssessment: true,
    requireHODReview: true,
    requireHRFinalApproval: true,
    totalEligibleStaff: 18,
    completedReviewsCount: 3,
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Sterling',
    createdAt: '2026-05-15T09:00:00.000Z',
    updatedAt: '2026-08-20T14:30:00.000Z'
  },
  {
    id: 'prc-2025-midyear',
    name: 'Mid-Year Faculty Milestone Review 2025-2026',
    code: 'APP-2025-26-MID',
    description: 'Mid-session milestone check-in covering first-term curriculum progress and examination delivery.',
    academicSessionId: 'session-1',
    academicSessionName: 'Academic Year 2025-2026',
    reviewPeriod: 'Jul 2025 - Dec 2025',
    startDate: '2025-12-01',
    endDate: '2026-01-31',
    selfAssessmentDeadline: '2025-12-20',
    supervisorReviewDeadline: '2026-01-15',
    reviewType: 'HALF_YEARLY',
    frequency: 'HALF_YEARLY',
    applicableStaffCategories: ['TEACHING'],
    applicableDepartmentIds: [],
    applicableDesignationIds: [],
    status: 'COMPLETED',
    scoringModel: 'WEIGHTED_100',
    allowSelfAssessment: true,
    requireHODReview: true,
    requireHRFinalApproval: true,
    totalEligibleStaff: 12,
    completedReviewsCount: 12,
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Sterling',
    createdAt: '2025-11-15T09:00:00.000Z',
    updatedAt: '2026-02-01T10:00:00.000Z'
  },
  {
    id: 'prc-2026-q3-probation',
    name: 'Probationary & Induction Review Cycle Q3 2026',
    code: 'APP-2026-Q3-PROB',
    description: 'Targeted performance review for recently onboarded staff completing mandatory probationary milestones.',
    academicSessionId: 'session-1',
    academicSessionName: 'Academic Year 2025-2026',
    reviewPeriod: 'Apr 2026 - Sep 2026',
    startDate: '2026-08-01',
    endDate: '2026-10-15',
    selfAssessmentDeadline: '2026-09-01',
    supervisorReviewDeadline: '2026-09-25',
    reviewType: 'PROBATION',
    frequency: 'QUARTERLY',
    applicableStaffCategories: ['ALL'],
    applicableDepartmentIds: [],
    applicableDesignationIds: [],
    status: 'OPEN',
    scoringModel: 'WEIGHTED_100',
    allowSelfAssessment: true,
    requireHODReview: true,
    requireHRFinalApproval: true,
    totalEligibleStaff: 4,
    completedReviewsCount: 0,
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Sterling',
    createdAt: '2026-07-20T11:00:00.000Z',
    updatedAt: '2026-08-01T08:00:00.000Z'
  }
];

// ====================================================
// 3. PERFORMANCE GOALS
// ====================================================

export const INITIAL_PERFORMANCE_GOALS: PerformanceGoal[] = [
  {
    id: 'goal-101',
    staffId: 'staff-prof-2',
    staffName: 'Prof. Sarah Jenkins',
    staffEmployeeCode: 'EMP-T-1004',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    title: 'Modernize Calculus Interactive Learning Lab',
    description: 'Implement computer-assisted calculus visualization modules using dynamic graphing tools for Grade 11 & 12.',
    category: 'INNOVATION',
    target: '100% of advanced calculus sections utilizing weekly interactive digital labs',
    measurementMethod: 'Curriculum audit, student lab submissions, and term test performance',
    weight: 25,
    startDate: '2025-09-01',
    dueDate: '2026-05-30',
    progressPercentage: 100,
    status: 'ACHIEVED',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    milestones: [
      { id: 'm-1', title: 'Lab curriculum and software license review', dueDate: '2025-10-15', isCompleted: true, completedAt: '2025-10-12' },
      { id: 'm-2', title: 'Pilot with Grade 11 Calculus Honors', dueDate: '2025-12-15', isCompleted: true, completedAt: '2025-12-10' },
      { id: 'm-3', title: 'Full department rollout and faculty demonstration', dueDate: '2026-04-30', isCompleted: true, completedAt: '2026-04-25' }
    ],
    progressNotes: [
      {
        id: 'pn-1',
        note: 'Completed demonstration session for Mathematics faculty. Grade 11 average comprehension improved by 14%.',
        updatedPercentage: 100,
        authorId: 'usr-teacher-1',
        authorName: 'Prof. Sarah Jenkins',
        createdAt: '2026-05-02T10:15:00.000Z'
      }
    ],
    lastUpdatedDate: '2026-05-02',
    updatedBy: 'usr-teacher-1',
    createdAt: '2025-09-01T08:00:00.000Z'
  },
  {
    id: 'goal-102',
    staffId: 'staff-prof-2',
    staffName: 'Prof. Sarah Jenkins',
    staffEmployeeCode: 'EMP-T-1004',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    title: 'Zero-Late Examination Marks Entry Compliance',
    description: 'Ensure 100% of mathematics midterm and final examination score submissions are submitted and verified within 48 hours.',
    category: 'ACADEMIC',
    target: '100% on-time submission across all 4 assigned class sections',
    measurementMethod: 'Examination portal audit logs and registrar verification timestamps',
    weight: 20,
    startDate: '2025-09-01',
    dueDate: '2026-06-15',
    progressPercentage: 100,
    status: 'ACHIEVED',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    lastUpdatedDate: '2026-06-16',
    updatedBy: 'usr-admin-1',
    createdAt: '2025-09-01T08:00:00.000Z'
  },
  {
    id: 'goal-103',
    staffId: 'staff-prof-3',
    staffName: 'Dr. Marcus Vance',
    staffEmployeeCode: 'EMP-T-1009',
    departmentId: 'dept-sci',
    departmentName: 'Department of Natural Sciences',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    title: 'Physics Laboratory Safety & Hazardous Material Audit',
    description: 'Perform complete inventory cataloging and OSHA/School safety compliance inspection for optics and chemical storage.',
    category: 'INSTITUTIONAL_CONTRIBUTION',
    target: 'Full compliance certification by state safety inspector',
    measurementMethod: 'Safety certificate issued with zero violation notices',
    weight: 30,
    startDate: '2025-09-15',
    dueDate: '2026-04-30',
    progressPercentage: 85,
    status: 'IN_PROGRESS',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    milestones: [
      { id: 'm-301', title: 'Inventory count and disposal of expired reagents', dueDate: '2025-11-30', isCompleted: true, completedAt: '2025-11-28' },
      { id: 'm-302', title: 'Install secondary spill containment kits', dueDate: '2026-02-15', isCompleted: true, completedAt: '2026-02-14' },
      { id: 'm-303', title: 'Final inspector walkthrough', dueDate: '2026-04-30', isCompleted: false }
    ],
    lastUpdatedDate: '2026-07-10',
    updatedBy: 'usr-teacher-2',
    createdAt: '2025-09-15T09:00:00.000Z'
  },
  {
    id: 'goal-104',
    staffId: 'staff-prof-5',
    staffName: 'Jonathan Hayes',
    staffEmployeeCode: 'EMP-IT-2001',
    departmentId: 'dept-it',
    departmentName: 'IT Infrastructure & Support',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    title: 'Smart Classroom Wi-Fi 6 Migration',
    description: 'Upgrade network access points across 24 academic classrooms to enterprise Wi-Fi 6 with 99.9% uptime during instruction.',
    category: 'ADMINISTRATIVE',
    target: '24 access points deployed with <1hr total downtime',
    measurementMethod: 'Network management telemetry dashboard logs',
    weight: 35,
    startDate: '2025-10-01',
    dueDate: '2026-03-31',
    progressPercentage: 100,
    status: 'ACHIEVED',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    lastUpdatedDate: '2026-03-28',
    updatedBy: 'usr-admin-1',
    createdAt: '2025-10-01T08:00:00.000Z'
  },
  {
    id: 'goal-105',
    staffId: 'staff-prof-6',
    staffName: 'David Sterling',
    staffEmployeeCode: 'EMP-FAC-3002',
    departmentId: 'dept-fac',
    departmentName: 'Facilities & Campus Maintenance',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    title: 'HVAC Seasonal Inspection & Filter Replacement Log',
    description: 'Maintain strict bi-monthly maintenance tickets and log air filter replacements across gymnasium and auditorium.',
    category: 'ADMINISTRATIVE',
    target: '100% scheduled maintenance tickets signed off without backlog',
    measurementMethod: 'Maintenance ticketing system audits',
    weight: 30,
    startDate: '2025-09-01',
    dueDate: '2026-05-30',
    progressPercentage: 45,
    status: 'PARTIALLY_ACHIEVED',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    lastUpdatedDate: '2026-06-05',
    updatedBy: 'usr-admin-1',
    createdAt: '2025-09-01T08:00:00.000Z'
  }
];

// ====================================================
// 4. STAFF PERFORMANCE REVIEWS
// ====================================================

export const INITIAL_STAFF_PERFORMANCE_REVIEWS: StaffPerformanceReview[] = [
  // 1. Prof. Sarah Jenkins (Head of Math) - Finalized & Acknowledged
  {
    id: 'rev-2026-sarah-jenkins',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    staffId: 'staff-prof-2',
    staffName: 'Prof. Sarah Jenkins',
    staffEmployeeCode: 'EMP-T-1004',
    departmentId: 'dept-mth',
    departmentName: 'Department of Mathematics',
    designationTitle: 'Senior Faculty & Head of Mathematics',
    staffType: 'TEACHING',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    hrReviewerId: 'usr-admin-1',
    hrReviewerName: 'Dr. Arthur Sterling (Head of HR)',
    reviewPeriod: 'Jul 2025 - Jun 2026',
    academicSessionId: 'session-1',
    status: 'ACKNOWLEDGED',
    currentStage: 'Employee Acknowledged & Closed',
    history: [
      {
        stage: 'DRAFT',
        action: 'CREATED',
        actorId: 'usr-admin-1',
        actorName: 'Dr. Arthur Sterling',
        timestamp: '2026-06-01T09:00:00.000Z',
        comments: 'Annual review initiated.'
      },
      {
        stage: 'SELF_ASSESSMENT',
        action: 'SUBMITTED',
        actorId: 'usr-teacher-1',
        actorName: 'Prof. Sarah Jenkins',
        timestamp: '2026-07-20T14:22:00.000Z',
        comments: 'Submitted detailed self-assessment highlighting Calculus Lab completion and peer tutoring program.'
      },
      {
        stage: 'SUPERVISOR_REVIEW',
        action: 'EVALUATED',
        actorId: 'usr-admin-1',
        actorName: 'Dr. Arthur Sterling',
        timestamp: '2026-08-05T11:15:00.000Z',
        comments: 'Supervisor scores and pedagogical evaluation submitted with unanimous commendation.'
      },
      {
        stage: 'HR_REVIEW',
        action: 'FINALIZED',
        actorId: 'usr-admin-1',
        actorName: 'Dr. Arthur Sterling',
        timestamp: '2026-08-10T16:00:00.000Z',
        comments: 'Official rating band confirmed: EXCEPTIONAL (Score: 95.0%).'
      },
      {
        stage: 'ACKNOWLEDGED',
        action: 'ACKNOWLEDGED',
        actorId: 'usr-teacher-1',
        actorName: 'Prof. Sarah Jenkins',
        timestamp: '2026-08-12T09:30:00.000Z',
        comments: 'I am honored by the recognition and grateful for the institutional support in our digital math lab expansion.'
      }
    ],
    selfAssessment: {
      achievementSummary: 'Successfully launched the interactive calculus visualizer for Grades 11-12. Coordinated department faculty workshops resulting in 100% syllabus coverage two weeks ahead of finals. Mentored two junior mathematics teachers through their first-year induction.',
      goalProgressSummary: 'Achieved 100% on both annual key goals: Calculus lab deployment and zero-late marks submission compliance.',
      strengths: 'Curriculum architecture, rigorous mathematical pedagogy, student engagement in abstract concepts, and departmental collaboration.',
      challenges: 'Balancing administrative workload as Head of Department with high-touch remedial student tutoring.',
      trainingNeeds: 'Advanced pedagogical workshops on adaptive testing and AI-assisted STEM problem formulation.',
      comments: 'Very proud of our department students achieving top honors in the Regional Mathematics Olympiad.',
      selfRating: 5,
      submittedAt: '2026-07-20T14:22:00.000Z'
    },
    supervisorReview: {
      criteriaScores: [
        { criterionId: 'crit-t-1', criterionCode: 'TCH-PED-01', criterionName: 'Lesson Preparation & Curriculum Delivery', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 5, comments: 'Gold standard lesson architectures.' },
        { criterionId: 'crit-t-2', criterionCode: 'TCH-PED-02', criterionName: 'Instructional Quality & Pedagogical Delivery', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 5, comments: 'Dynamic, highly articulate delivery.' },
        { criterionId: 'crit-t-3', criterionCode: 'TCH-ENV-01', criterionName: 'Classroom Management & Behavioral Culture', category: 'CLASSROOM_MANAGEMENT', weight: 10, maxScore: 5, score: 5, comments: 'Exemplary classroom culture.' },
        { criterionId: 'crit-t-4', criterionCode: 'TCH-OUT-01', criterionName: 'Student Support, Inclusivity & Pastoral Care', category: 'STUDENT_OUTCOMES', weight: 10, maxScore: 5, score: 4, comments: 'Dedicated after-school tutorials.' },
        { criterionId: 'crit-t-5', criterionCode: 'TCH-PED-03', criterionName: 'Subject Mastery & Domain Expertise', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 5, comments: 'Recognized academic subject leader.' },
        { criterionId: 'crit-t-6', criterionCode: 'TCH-OUT-02', criterionName: 'Assessment Quality, Grading & Timely Feedback', category: 'PEDAGOGY', weight: 10, maxScore: 5, score: 5, comments: '100% on-time registrar marks compliance.' },
        { criterionId: 'crit-t-7', criterionCode: 'TCH-COM-01', criterionName: 'Parent & Guardian Communication', category: 'COMMUNICATION', weight: 10, maxScore: 5, score: 5, comments: 'Detailed, constructive communication logs.' },
        { criterionId: 'crit-t-8', criterionCode: 'TCH-INS-01', criterionName: 'Institutional Duties, Governance & Committee Work', category: 'INSTITUTIONAL_DUTIES', weight: 5, maxScore: 5, score: 5, comments: 'Leads Academic Senate Mathematics committee.' },
        { criterionId: 'crit-t-9', criterionCode: 'TCH-PRF-01', criterionName: 'Professional Development & Pedagogical Innovation', category: 'PROFESSIONALISM', weight: 5, maxScore: 5, score: 5, comments: 'Publishes and mentors junior faculty.' },
        { criterionId: 'crit-t-10', criterionCode: 'TCH-ATT-01', criterionName: 'Punctuality, Schedule Adherence & Attendance', category: 'ATTENDANCE_PUNCTUALITY', weight: 5, maxScore: 5, score: 5, comments: 'Pristine attendance ledger record.' }
      ],
      goalAssessments: [
        { goalId: 'goal-101', goalTitle: 'Modernize Calculus Interactive Learning Lab', weight: 25, progressPercentage: 100, achievedScore: 5, comments: 'Complete and outstanding delivery.' },
        { goalId: 'goal-102', goalTitle: 'Zero-Late Examination Marks Entry Compliance', weight: 20, progressPercentage: 100, achievedScore: 5, comments: 'Zero violations across all academic exam cycles.' }
      ],
      strengths: 'Exceptional domain command, pedagogical rigor, faculty mentorship, and reliable administrative governance.',
      areasForImprovement: 'Delegate routine administrative paperwork to assistant faculty to prevent burnout.',
      developmentRecommendations: 'Recommend appointment as Institutional Curriculum Advisor for Senior Secondary.',
      recommendedTraining: ['Advanced STEM Educational Leadership Seminar', 'Modern Learning Management Systems Masterclass'],
      calculatedScore: 98.0,
      supervisorRating: 5,
      generalComments: 'Prof. Jenkins represents the highest standard of academic excellence at Sygmate International School.',
      submittedAt: '2026-08-05T11:15:00.000Z'
    },
    hrReview: {
      hrComments: 'Unanimous executive endorsement. No score adjustment required. Exceptional rating verified against attendance, examination, and student feedback data.',
      finalCalculatedScore: 98.0,
      finalRatingBand: 'EXCEPTIONAL',
      pipRecommended: false,
      reviewedAt: '2026-08-10T16:00:00.000Z'
    },
    acknowledgement: {
      isAcknowledged: true,
      acknowledgedAt: '2026-08-12T09:30:00.000Z',
      comments: 'I am honored by the recognition and grateful for the institutional support in our digital math lab expansion.'
    },
    supportingData: {
      attendancePercentage: 98.8,
      lateArrivalsCount: 0,
      approvedLeavesCount: 3,
      workloadSummary: '4 Class Sections (11-A, 11-B, 12-A, 12-B) | 22 Teaching Periods/Week',
      marksSubmissionComplianceRate: 100,
      documentsComplianceStatus: 'All 7 Credential Documents Verified & Up to Date'
    },
    createdAt: '2026-06-01T09:00:00.000Z',
    updatedAt: '2026-08-12T09:30:00.000Z'
  },

  // 2. Dr. Marcus Vance (Physics Teacher) - In HR Review stage
  {
    id: 'rev-2026-marcus-vance',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    staffId: 'staff-prof-3',
    staffName: 'Dr. Marcus Vance',
    staffEmployeeCode: 'EMP-T-1009',
    departmentId: 'dept-sci',
    departmentName: 'Department of Natural Sciences',
    designationTitle: 'Senior Physics Educator & Lab Coordinator',
    staffType: 'TEACHING',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    reviewPeriod: 'Jul 2025 - Jun 2026',
    academicSessionId: 'session-1',
    status: 'HR_REVIEW',
    currentStage: 'Pending HR Final Approval & Rating Confirmation',
    history: [
      {
        stage: 'DRAFT',
        action: 'CREATED',
        actorId: 'usr-admin-1',
        actorName: 'Dr. Arthur Sterling',
        timestamp: '2026-06-01T09:00:00.000Z'
      },
      {
        stage: 'SELF_ASSESSMENT',
        action: 'SUBMITTED',
        actorId: 'usr-teacher-2',
        actorName: 'Dr. Marcus Vance',
        timestamp: '2026-07-28T16:00:00.000Z',
        comments: 'Completed self-assessment emphasizing lab upgrades and science fair coordination.'
      },
      {
        stage: 'SUPERVISOR_REVIEW',
        action: 'EVALUATED',
        actorId: 'usr-admin-1',
        actorName: 'Dr. Arthur Sterling',
        timestamp: '2026-08-14T10:30:00.000Z',
        comments: 'Supervisor assessment completed. Solid performance across theoretical physics and laboratory safety.'
      }
    ],
    selfAssessment: {
      achievementSummary: 'Overhauled the Senior Physics laboratory equipment. Led 3 student teams to the National Science Fair with one team receiving regional commendation.',
      goalProgressSummary: 'Physics lab safety audit is 85% complete; awaiting final state inspector inspection date.',
      strengths: 'Laboratory experiment design, hands-on physics demonstrations, student project mentoring.',
      challenges: 'Promptness in inputting weekly homework feedback on the student portal.',
      trainingNeeds: 'Classroom management for larger classes and modern digital grading rubrics.',
      comments: 'Looking forward to introducing AP Physics C next academic session.',
      selfRating: 4,
      submittedAt: '2026-07-28T16:00:00.000Z'
    },
    supervisorReview: {
      criteriaScores: [
        { criterionId: 'crit-t-1', criterionCode: 'TCH-PED-01', criterionName: 'Lesson Preparation & Curriculum Delivery', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 4, comments: 'Well prepared theoretical plans.' },
        { criterionId: 'crit-t-2', criterionCode: 'TCH-PED-02', criterionName: 'Instructional Quality & Pedagogical Delivery', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 4, comments: 'Clear lab demonstrations.' },
        { criterionId: 'crit-t-3', criterionCode: 'TCH-ENV-01', criterionName: 'Classroom Management & Behavioral Culture', category: 'CLASSROOM_MANAGEMENT', weight: 10, maxScore: 5, score: 4, comments: 'Good lab discipline.' },
        { criterionId: 'crit-t-4', criterionCode: 'TCH-OUT-01', criterionName: 'Student Support, Inclusivity & Pastoral Care', category: 'STUDENT_OUTCOMES', weight: 10, maxScore: 5, score: 5, comments: 'Superb project coaching.' },
        { criterionId: 'crit-t-5', criterionCode: 'TCH-PED-03', criterionName: 'Subject Mastery & Domain Expertise', category: 'PEDAGOGY', weight: 15, maxScore: 5, score: 5, comments: 'Exceptional knowledge of mechanics and quantum physics.' },
        { criterionId: 'crit-t-6', criterionCode: 'TCH-OUT-02', criterionName: 'Assessment Quality, Grading & Timely Feedback', category: 'PEDAGOGY', weight: 10, maxScore: 5, score: 4, comments: 'Good, occasional slight delay on homework entries.' },
        { criterionId: 'crit-t-7', criterionCode: 'TCH-COM-01', criterionName: 'Parent & Guardian Communication', category: 'COMMUNICATION', weight: 10, maxScore: 5, score: 4, comments: 'Constructive conference notes.' },
        { criterionId: 'crit-t-8', criterionCode: 'TCH-INS-01', criterionName: 'Institutional Duties, Governance & Committee Work', category: 'INSTITUTIONAL_DUTIES', weight: 5, maxScore: 5, score: 5, comments: 'Great stewardship of Science Fair.' },
        { criterionId: 'crit-t-9', criterionCode: 'TCH-PRF-01', criterionName: 'Professional Development & Pedagogical Innovation', category: 'PROFESSIONALISM', weight: 5, maxScore: 5, score: 4, comments: 'Active in science education webinars.' },
        { criterionId: 'crit-t-10', criterionCode: 'TCH-ATT-01', criterionName: 'Punctuality, Schedule Adherence & Attendance', category: 'ATTENDANCE_PUNCTUALITY', weight: 5, maxScore: 5, score: 4, comments: 'Good attendance record.' }
      ],
      goalAssessments: [
        { goalId: 'goal-103', goalTitle: 'Physics Laboratory Safety & Hazardous Material Audit', weight: 30, progressPercentage: 85, achievedScore: 4, comments: 'Good progress, pending external inspector walkthrough.' }
      ],
      strengths: 'Deep subject knowledge, inspiring laboratory sessions, dedicated science competition mentoring.',
      areasForImprovement: 'Improve turnaround time for regular homework submissions on the online portal.',
      developmentRecommendations: 'Encourage cross-disciplinary integration with the Mathematics department.',
      recommendedTraining: ['Digital Formative Assessment Tools Workshop'],
      calculatedScore: 86.0,
      supervisorRating: 4,
      generalComments: 'Strong asset to our Science faculty with great commitment to student experiential learning.',
      submittedAt: '2026-08-14T10:30:00.000Z'
    },
    supportingData: {
      attendancePercentage: 96.2,
      lateArrivalsCount: 2,
      approvedLeavesCount: 4,
      workloadSummary: '3 Class Sections (10-A, 11-A, 12-A) | 18 Teaching Periods/Week',
      marksSubmissionComplianceRate: 95.0,
      documentsComplianceStatus: 'All Credentials Verified'
    },
    createdAt: '2026-06-01T09:00:00.000Z',
    updatedAt: '2026-08-14T10:30:00.000Z'
  },

  // 3. Jonathan Hayes (IT Infrastructure Administrator) - Finalized
  {
    id: 'rev-2026-jonathan-hayes',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    staffId: 'staff-prof-5',
    staffName: 'Jonathan Hayes',
    staffEmployeeCode: 'EMP-IT-2001',
    departmentId: 'dept-it',
    departmentName: 'IT Infrastructure & Support',
    designationTitle: 'Senior Systems Administrator & IT Specialist',
    staffType: 'NON_TEACHING',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    hrReviewerId: 'usr-admin-1',
    hrReviewerName: 'Dr. Arthur Sterling',
    reviewPeriod: 'Jul 2025 - Jun 2026',
    academicSessionId: 'session-1',
    status: 'FINALIZED',
    currentStage: 'Finalized - Pending Staff Sign-off',
    history: [
      { stage: 'DRAFT', action: 'CREATED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-06-01T09:00:00.000Z' },
      { stage: 'SELF_ASSESSMENT', action: 'SUBMITTED', actorId: 'usr-admin-1', actorName: 'Jonathan Hayes', timestamp: '2026-07-15T10:00:00.000Z' },
      { stage: 'SUPERVISOR_REVIEW', action: 'EVALUATED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-07-29T15:00:00.000Z' },
      { stage: 'HR_REVIEW', action: 'FINALIZED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-08-01T12:00:00.000Z', comments: 'Final Rating Band: EXCEEDS_EXPECTATIONS (88.0%)' }
    ],
    selfAssessment: {
      achievementSummary: 'Completed full Wi-Fi 6 upgrade across 24 classrooms with zero lost instructional hours. Maintained 99.98% school server uptime.',
      goalProgressSummary: 'Wi-Fi 6 deployment achieved 100% on schedule.',
      strengths: 'Rapid response time, network security, infrastructure reliability.',
      challenges: 'High volume of peripheral device requests during exam season.',
      trainingNeeds: 'Cloud enterprise identity governance and cybersecurity threat modeling.',
      comments: 'Glad to keep campus digital systems humming smoothly.',
      selfRating: 4,
      submittedAt: '2026-07-15T10:00:00.000Z'
    },
    supervisorReview: {
      criteriaScores: [
        { criterionId: 'crit-g-1', criterionCode: 'GEN-OPS-01', criterionName: 'Job Knowledge & Operational Competence', category: 'WORK_QUALITY', weight: 20, maxScore: 5, score: 5, comments: 'High technical aptitude.' },
        { criterionId: 'crit-g-2', criterionCode: 'GEN-OPS-02', criterionName: 'Work Quality, Accuracy & Attention to Detail', category: 'WORK_QUALITY', weight: 20, maxScore: 5, score: 4, comments: 'Thorough documentation.' },
        { criterionId: 'crit-g-3', criterionCode: 'GEN-PRD-01', criterionName: 'Productivity & Execution Speed', category: 'PRODUCTIVITY', weight: 15, maxScore: 5, score: 5, comments: 'Tickets handled swiftly.' },
        { criterionId: 'crit-g-4', criterionCode: 'GEN-ATT-01', criterionName: 'Attendance, Punctuality & Shift Reliability', category: 'ATTENDANCE_PUNCTUALITY', weight: 15, maxScore: 5, score: 4, comments: 'Reliable shift coverage.' },
        { criterionId: 'crit-g-5', criterionCode: 'GEN-COM-01', criterionName: 'Communication & Interdepartmental Teamwork', category: 'COMMUNICATION', weight: 10, maxScore: 5, score: 4, comments: 'Friendly and patient with faculty.' },
        { criterionId: 'crit-g-6', criterionCode: 'GEN-LDR-01', criterionName: 'Problem Solving, Resourcefulness & Initiative', category: 'LEADERSHIP', weight: 10, maxScore: 5, score: 4, comments: 'Proactive troubleshooting.' },
        { criterionId: 'crit-g-7', criterionCode: 'GEN-PRF-01', criterionName: 'Institutional Compliance, Safety & Ethics', category: 'PROFESSIONALISM', weight: 10, maxScore: 5, score: 5, comments: 'Strict data privacy compliance.' }
      ],
      goalAssessments: [
        { goalId: 'goal-104', goalTitle: 'Smart Classroom Wi-Fi 6 Migration', weight: 35, progressPercentage: 100, achievedScore: 5, comments: 'Flawless execution.' }
      ],
      strengths: 'Exceptional network competence, dependable crisis troubleshooting, great attitude.',
      areasForImprovement: 'Develop structured user guides for new teaching staff.',
      developmentRecommendations: 'Fund IT security certification.',
      recommendedTraining: ['CompTIA Security+ Certification', 'Google Cloud Education Suite Administration'],
      calculatedScore: 88.0,
      supervisorRating: 4,
      generalComments: 'Invaluable member of the campus technology backbone.',
      submittedAt: '2026-07-29T15:00:00.000Z'
    },
    hrReview: {
      hrComments: 'Performance validated against ticket logs and infrastructure uptime. EXCEEDS_EXPECTATIONS affirmed.',
      finalCalculatedScore: 88.0,
      finalRatingBand: 'EXCEEDS_EXPECTATIONS',
      pipRecommended: false,
      reviewedAt: '2026-08-01T12:00:00.000Z'
    },
    supportingData: {
      attendancePercentage: 97.5,
      lateArrivalsCount: 1,
      approvedLeavesCount: 2,
      workloadSummary: 'IT Helpdesk & Systems Support | 148 Tickets Resolved',
      documentsComplianceStatus: 'All Verified'
    },
    createdAt: '2026-06-01T09:00:00.000Z',
    updatedAt: '2026-08-01T12:00:00.000Z'
  },

  // 4. David Sterling (Facilities & Campus Maintenance) - Needs Improvement / PIP
  {
    id: 'rev-2026-david-sterling',
    reviewCycleId: 'prc-2025-2026-annual',
    reviewCycleName: 'Annual Faculty & Staff Appraisal 2025-2026',
    staffId: 'staff-prof-6',
    staffName: 'David Sterling',
    staffEmployeeCode: 'EMP-FAC-3002',
    departmentId: 'dept-fac',
    departmentName: 'Facilities & Campus Maintenance',
    designationTitle: 'Campus Maintenance Technician',
    staffType: 'SUPPORT',
    reviewerId: 'staff-prof-1',
    reviewerName: 'Dr. Arthur Sterling',
    hrReviewerId: 'usr-admin-1',
    hrReviewerName: 'Dr. Arthur Sterling',
    reviewPeriod: 'Jul 2025 - Jun 2026',
    academicSessionId: 'session-1',
    status: 'FINALIZED',
    currentStage: 'Finalized - Active Performance Improvement Plan (PIP) Assigned',
    history: [
      { stage: 'DRAFT', action: 'CREATED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-06-01T09:00:00.000Z' },
      { stage: 'SELF_ASSESSMENT', action: 'SUBMITTED', actorId: 'usr-admin-1', actorName: 'David Sterling', timestamp: '2026-07-10T11:00:00.000Z' },
      { stage: 'SUPERVISOR_REVIEW', action: 'EVALUATED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-07-25T14:00:00.000Z' },
      { stage: 'HR_REVIEW', action: 'FINALIZED', actorId: 'usr-admin-1', actorName: 'Dr. Arthur Sterling', timestamp: '2026-08-02T10:00:00.000Z', comments: 'Score: 52.0% (NEEDS_IMPROVEMENT). Formal 60-day PIP initiated.' }
    ],
    selfAssessment: {
      achievementSummary: 'Maintained outdoor athletic turf and handled daily repairs.',
      goalProgressSummary: 'HVAC maintenance fell behind due to equipment delivery delays.',
      strengths: 'Physical repairs and lawn care.',
      challenges: 'Digital logging of maintenance work orders and multiple morning late arrivals.',
      trainingNeeds: 'Hands-on training with computerized work order system.',
      comments: 'Need clearer maintenance inventory parts.',
      selfRating: 3,
      submittedAt: '2026-07-10T11:00:00.000Z'
    },
    supervisorReview: {
      criteriaScores: [
        { criterionId: 'crit-g-1', criterionCode: 'GEN-OPS-01', criterionName: 'Job Knowledge & Operational Competence', category: 'WORK_QUALITY', weight: 20, maxScore: 5, score: 3, comments: 'Adequate physical maintenance skills.' },
        { criterionId: 'crit-g-2', criterionCode: 'GEN-OPS-02', criterionName: 'Work Quality, Accuracy & Attention to Detail', category: 'WORK_QUALITY', weight: 20, maxScore: 5, score: 2, comments: 'Recurring misses in filter replacement logs.' },
        { criterionId: 'crit-g-3', criterionCode: 'GEN-PRD-01', criterionName: 'Productivity & Execution Speed', category: 'PRODUCTIVITY', weight: 15, maxScore: 5, score: 3, comments: 'Average ticket resolution rate.' },
        { criterionId: 'crit-g-4', criterionCode: 'GEN-ATT-01', criterionName: 'Attendance, Punctuality & Shift Reliability', category: 'ATTENDANCE_PUNCTUALITY', weight: 15, maxScore: 5, score: 2, comments: '8 late clock-ins recorded during spring term.' },
        { criterionId: 'crit-g-5', criterionCode: 'GEN-COM-01', criterionName: 'Communication & Interdepartmental Teamwork', category: 'COMMUNICATION', weight: 10, maxScore: 5, score: 3, comments: 'Generally communicative when prompted.' },
        { criterionId: 'crit-g-6', criterionCode: 'GEN-LDR-01', criterionName: 'Problem Solving, Resourcefulness & Initiative', category: 'LEADERSHIP', weight: 10, maxScore: 5, score: 2, comments: 'Waits for reminders rather than taking initiative.' },
        { criterionId: 'crit-g-7', criterionCode: 'GEN-PRF-01', criterionName: 'Institutional Compliance, Safety & Ethics', category: 'PROFESSIONALISM', weight: 10, maxScore: 5, score: 3, comments: 'Follows safety goggles protocol.' }
      ],
      goalAssessments: [
        { goalId: 'goal-105', goalTitle: 'HVAC Seasonal Inspection & Filter Replacement Log', weight: 30, progressPercentage: 45, achievedScore: 2, comments: 'Substantial backlog in scheduled filter audits.' }
      ],
      strengths: 'Willingness to handle heavy physical tasks.',
      areasForImprovement: 'Punctuality compliance, routine scheduled inspection diligence, and work ticket logging.',
      developmentRecommendations: 'Enroll in 60-day Performance Improvement Plan with weekly supervisor check-ins.',
      recommendedTraining: ['Campus Preventive Maintenance Procedures', 'Time Management & Workplace Punctuality'],
      calculatedScore: 52.0,
      supervisorRating: 2,
      generalComments: 'Requires structured intervention to meet basic institutional reliability standards.',
      submittedAt: '2026-07-25T14:00:00.000Z'
    },
    hrReview: {
      hrComments: 'Score of 52.0% falls within NEEDS_IMPROVEMENT band. Enrolled into formal 60-day PIP under supervision of Campus Facilities Manager.',
      finalCalculatedScore: 52.0,
      finalRatingBand: 'NEEDS_IMPROVEMENT',
      pipRecommended: true,
      reviewedAt: '2026-08-02T10:00:00.000Z'
    },
    supportingData: {
      attendancePercentage: 86.4,
      lateArrivalsCount: 8,
      approvedLeavesCount: 6,
      workloadSummary: 'Campus Facilities Work Order Queue | 62 Tasks Completed (14 Overdue)',
      documentsComplianceStatus: 'Verified'
    },
    createdAt: '2026-06-01T09:00:00.000Z',
    updatedAt: '2026-08-02T10:00:00.000Z'
  }
];

// ====================================================
// 5. PERFORMANCE FEEDBACK REPOSITORY
// ====================================================

export const INITIAL_PERFORMANCE_FEEDBACK: PerformanceFeedbackItem[] = [
  {
    id: 'fb-201',
    reviewId: 'rev-2026-sarah-jenkins',
    staffId: 'staff-prof-2',
    staffName: 'Prof. Sarah Jenkins',
    givenBy: 'usr-admin-1',
    givenByName: 'Dr. Arthur Sterling',
    givenByRole: 'Principal & Head of Institution',
    feedbackType: 'COMMENDATION',
    strengths: 'Outstanding departmental leadership, academic rigor, and pioneering the interactive calculus visualizer.',
    improvementAreas: 'Avoid taking on excess administrative tasks that can be delegated to junior department faculty.',
    recommendations: 'Continue expanding senior math honors track and serve as guest mentor for new teachers.',
    trainingNeeds: 'Executive Academic Leadership Program',
    careerDevelopmentSuggestions: 'Prepared for institutional Academic Dean or Vice-Principal roles in the future.',
    generalComments: 'Sygmate is tremendously grateful for Prof. Jenkins commitment to instructional mastery.',
    isAcknowledged: true,
    acknowledgedAt: '2026-08-12T09:30:00.000Z',
    acknowledgementNote: 'Thank you for the wonderful commendation. I look forward to mentoring our new math educators.',
    createdAt: '2026-08-10T16:15:00.000Z'
  },
  {
    id: 'fb-202',
    reviewId: 'rev-2026-marcus-vance',
    staffId: 'staff-prof-3',
    staffName: 'Dr. Marcus Vance',
    givenBy: 'usr-admin-1',
    givenByName: 'Dr. Arthur Sterling',
    givenByRole: 'Principal & Head of Institution',
    feedbackType: 'FORMAL_APPRAISAL',
    strengths: 'Deep passion for experimental science, inspiring demonstrations, and science fair mentorship.',
    improvementAreas: 'Timeliness of online portal homework entry and gradebook updates.',
    recommendations: 'Set a dedicated 30-minute block each Friday afternoon specifically for gradebook updates.',
    trainingNeeds: 'School Portal Rapid Grading Workshop',
    careerDevelopmentSuggestions: 'Candidate for Science Department Chair upon scheduled rotation.',
    generalComments: 'Students consistently praise Dr. Vances engaging laboratory sessions.',
    isAcknowledged: false,
    createdAt: '2026-08-14T10:45:00.000Z'
  },
  {
    id: 'fb-203',
    reviewId: 'rev-2026-david-sterling',
    staffId: 'staff-prof-6',
    staffName: 'David Sterling',
    givenBy: 'usr-admin-1',
    givenByName: 'Dr. Arthur Sterling',
    givenByRole: 'Campus Operations Director',
    feedbackType: 'AREAS_TO_DEVELOP',
    strengths: 'Good mechanical skills and helpful attitude when assigned direct tasks.',
    improvementAreas: 'Morning punctuality, proactive work order logging, and preventive maintenance follow-through.',
    recommendations: 'Must strictly follow the 60-day PIP milestones and meet with supervisor every Monday morning.',
    trainingNeeds: 'Preventive Facilities Maintenance & Safety Log Protocol',
    careerDevelopmentSuggestions: 'Achieving consistent reliability will open paths to Senior Maintenance Lead.',
    generalComments: 'We believe in Davids potential and look forward to seeing significant progress under the PIP.',
    isAcknowledged: true,
    acknowledgedAt: '2026-08-04T08:30:00.000Z',
    acknowledgementNote: 'Understood. I will be on time and focus on completing the HVAC checklist daily.',
    createdAt: '2026-08-02T10:15:00.000Z'
  }
];

// ====================================================
// 6. PERFORMANCE IMPROVEMENT PLANS (PIP)
// ====================================================

export const INITIAL_PERFORMANCE_IMPROVEMENT_PLANS: PerformanceImprovementPlan[] = [
  {
    id: 'pip-2026-david-sterling',
    staffId: 'staff-prof-6',
    staffName: 'David Sterling',
    staffEmployeeCode: 'EMP-FAC-3002',
    departmentId: 'dept-fac',
    departmentName: 'Facilities & Campus Maintenance',
    designationTitle: 'Campus Maintenance Technician',
    reviewId: 'rev-2026-david-sterling',
    reason: 'Annual performance score of 52.0% (NEEDS_IMPROVEMENT), excessive late clock-ins (8 instances), and 14 overdue HVAC maintenance work orders.',
    improvementAreas: [
      'Shift Punctuality & Clock-in Consistency (Zero unexcused late arrivals)',
      '100% On-time Clearance of Bi-monthly HVAC Maintenance Checklists',
      'Daily Work Order Resolution and System Logging within 24 Hours'
    ],
    requiredActions: [
      {
        id: 'act-1',
        description: 'Achieve zero late arrivals across the entire 60-day probationary review window.',
        deadline: '2026-10-02',
        status: 'IN_PROGRESS',
        verificationNotes: 'Clock-in records verified weekly by supervisor.'
      },
      {
        id: 'act-2',
        description: 'Complete full inspection and replacement of filters in Gymnasium and Auditorium HVAC units.',
        deadline: '2026-08-25',
        status: 'COMPLETED',
        verificationNotes: 'Verified and signed off by Facilities Supervisor on 2026-08-24.'
      },
      {
        id: 'act-3',
        description: 'Attend and pass the Campus Facility Safety and Work Order Software training refresher.',
        deadline: '2026-09-10',
        status: 'PENDING'
      }
    ],
    targetDate: '2026-10-02',
    reviewDate: '2026-09-01',
    assignedSupervisorId: 'staff-prof-1',
    assignedSupervisorName: 'Dr. Arthur Sterling',
    progressNotes: [
      {
        id: 'note-1',
        note: 'First bi-weekly check-in: David was on time every day this fortnight. Completed Gymnasium HVAC filters ahead of target.',
        loggedAt: '2026-08-25T11:00:00.000Z',
        loggedBy: 'usr-admin-1',
        loggedByName: 'Dr. Arthur Sterling'
      }
    ],
    outcome: 'PENDING',
    status: 'ACTIVE',
    createdBy: 'usr-admin-1',
    createdByName: 'Dr. Arthur Sterling',
    createdAt: '2026-08-02T10:30:00.000Z',
    updatedAt: '2026-08-25T11:00:00.000Z'
  }
];
