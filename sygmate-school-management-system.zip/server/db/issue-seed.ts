/**
 * Issue, Return & Department Allocation Seed Data (Part 14E)
 * Sygmate School Management System
 */

import {
  IssueRequest,
  StockIssue,
  InventoryReturn
} from '../../src/types/index.js';

export const INITIAL_ISSUE_REQUESTS: IssueRequest[] = [
  {
    id: 'ir-1',
    schoolId: 'school-main',
    requestNumber: 'IR-2026-0001',
    requestDate: '2026-02-10T10:00:00.000Z',
    requiredDate: '2026-02-15T16:00:00.000Z',
    priority: 'MEDIUM',
    status: 'APPROVED',
    requestingUserId: 'usr-teacher-1',
    requestingUserName: 'Marcus Vance',
    recipientType: 'TEACHER',
    recipientId: 'usr-teacher-1',
    recipientName: 'Marcus Vance',
    departmentId: 'dept-sci',
    departmentName: 'Natural Sciences & Biology',
    locationId: 'loc-sci',
    locationName: 'Advanced Science & Biology Laboratory',
    sourceLocationId: 'loc-wh',
    sourceLocationName: 'Main Central Warehouse',
    purpose: 'Classroom science demonstration supplies and lab stationery',
    notes: 'Required for Grade 11 weekly experiments',
    totalEstimatedCost: 65.5,
    reviewedBy: 'usr-admin-1',
    reviewedByName: 'Dr. Evelyn Montgomery',
    reviewedAt: '2026-02-11T14:30:00.000Z',
    reviewNotes: 'Approved for science practical classes.',
    createdAt: '2026-02-10T10:00:00.000Z',
    updatedAt: '2026-02-11T14:30:00.000Z',
    items: [
      {
        id: 'iri-1-1',
        itemId: 'item-3', // Dry Erase Whiteboard Markers
        itemName: 'Dry Erase Whiteboard Markers (Pack of 12)',
        itemCode: 'OFF-MRK-003',
        quantityRequested: 5,
        quantityApproved: 5,
        quantityIssued: 0,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        unitCost: 12.5,
        estimatedTotal: 62.5,
        notes: 'Assorted colors'
      }
    ]
  },
  {
    id: 'ir-2',
    schoolId: 'school-main',
    requestNumber: 'IR-2026-0002',
    requestDate: '2026-02-12T11:15:00.000Z',
    requiredDate: '2026-02-18T17:00:00.000Z',
    priority: 'HIGH',
    status: 'PARTIALLY_ISSUED',
    requestingUserId: 'usr-admin-1',
    requestingUserName: 'Dr. Evelyn Montgomery',
    recipientType: 'DEPARTMENT',
    recipientId: 'dept-admin',
    recipientName: 'Administration & Finance',
    departmentId: 'dept-admin',
    departmentName: 'Administration & Finance',
    locationId: 'loc-adm',
    locationName: 'Administration Archive & Registry',
    sourceLocationId: 'loc-wh',
    sourceLocationName: 'Main Central Warehouse',
    purpose: 'Monthly administrative copying and printing reams',
    totalEstimatedCost: 150.0,
    reviewedBy: 'usr-admin-1',
    reviewedByName: 'Dr. Evelyn Montgomery',
    reviewedAt: '2026-02-12T13:00:00.000Z',
    reviewNotes: 'Approved full quantity.',
    createdAt: '2026-02-12T11:15:00.000Z',
    updatedAt: '2026-02-13T09:00:00.000Z',
    items: [
      {
        id: 'iri-2-1',
        itemId: 'item-1', // A4 Paper Ream
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        quantityRequested: 20,
        quantityApproved: 20,
        quantityIssued: 10,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        unitCost: 7.5,
        estimatedTotal: 150.0,
        notes: 'First batch of 10 boxes delivered'
      }
    ]
  }
];

export const INITIAL_STOCK_ISSUES: StockIssue[] = [
  {
    id: 'iss-1',
    schoolId: 'school-main',
    issueNumber: 'ISS-2026-0001',
    issueDate: '2026-02-13T09:00:00.000Z',
    issueRequestId: 'ir-2',
    issueRequestNumber: 'IR-2026-0002',
    sourceLocationId: 'loc-wh',
    sourceLocationName: 'Main Central Warehouse',
    recipientType: 'DEPARTMENT',
    recipientId: 'dept-admin',
    recipientName: 'Administration & Finance',
    departmentId: 'dept-admin',
    departmentName: 'Administration & Finance',
    locationId: 'loc-adm',
    locationName: 'Administration Archive & Registry',
    purpose: 'Monthly administrative copying and printing reams (Batch 1)',
    notes: 'Dispatched 10 boxes from Warehouse to Admin Archive',
    items: [
      {
        id: 'issi-1-1',
        itemId: 'item-1',
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        quantityIssued: 10,
        quantityReturned: 0,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        unitCost: 7.5,
        totalCost: 75.0,
        stockTransactionId: 'tx-seed-out-1'
      }
    ],
    totalItemsCount: 1,
    totalCost: 75.0,
    issuedBy: 'usr-admin-1',
    issuedByName: 'Dr. Evelyn Montgomery',
    status: 'COMPLETED',
    createdAt: '2026-02-13T09:00:00.000Z',
    updatedAt: '2026-02-13T09:00:00.000Z'
  }
];

export const INITIAL_INVENTORY_RETURNS: InventoryReturn[] = [
  {
    id: 'ret-inv-1',
    schoolId: 'school-main',
    returnNumber: 'RET-2026-0001',
    returnDate: '2026-02-14T15:00:00.000Z',
    originalIssueId: 'iss-1',
    originalIssueNumber: 'ISS-2026-0001',
    returnLocationId: 'loc-wh',
    returnLocationName: 'Main Central Warehouse',
    returnedByType: 'DEPARTMENT',
    returnedById: 'dept-admin',
    returnedByName: 'Administration & Finance',
    departmentId: 'dept-admin',
    departmentName: 'Administration & Finance',
    reason: 'Excess paper boxes returned to warehouse for secure storage',
    notes: 'Box sealed in original good condition',
    items: [
      {
        id: 'reti-1-1',
        itemId: 'item-1',
        itemName: 'Multipurpose A4 Printing & Copy Paper (80 GSM)',
        itemCode: 'OFF-PPR-001',
        quantityReturned: 2,
        unitId: 'unit-box',
        unitShortCode: 'BOX',
        condition: 'GOOD',
        stockTransactionId: 'tx-seed-ret-1'
      }
    ],
    receivedByUserId: 'usr-admin-1',
    receivedByUserName: 'Dr. Evelyn Montgomery',
    createdAt: '2026-02-14T15:00:00.000Z'
  }
];
