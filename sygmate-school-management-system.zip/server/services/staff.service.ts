/**
 * Sygmate School Management System
 * Staff & Human Resource Management Foundation (Part 12A)
 * Core Backend Service
 */

import { database, StoredUser } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { hashPassword, registerUserLookup } from '../security/auth.js';
import {
  StaffProfile,
  StaffDirectoryQuery,
  StaffDirectoryResponse,
  StaffDirectorySummary,
  StaffStatsResponse,
  CreateStaffPayload,
  UpdateStaffPayload,
  ChangeStaffStatusPayload,
  UploadStaffDocumentPayload,
  VerifyStaffDocumentPayload,
  CreateDesignationPayload,
  UpdateDesignationPayload,
  Designation,
  Department,
  StaffDocument,
  StaffStatusHistoryEntry,
  User,
  UserRole,
  TeacherProfile
} from '../../src/types/index.js';

export class StaffService {
  /**
   * High-performance Paginated Staff Directory Query
   */
  public getStaffDirectory(query: StaffDirectoryQuery = {}): StaffDirectoryResponse {
    const {
      search = '',
      staffType,
      departmentId,
      designationId,
      employmentStatus,
      employmentType,
      gender,
      page = 1,
      limit = 10,
      sortBy = 'name',
      sortOrder = 'asc'
    } = query;

    // Filter staff profiles
    let items = database.staffProfiles.filter((staff) => {
      // Search term filter
      if (search.trim()) {
        const term = search.toLowerCase().trim();
        const fullName = `${staff.firstName} ${staff.lastName}`.toLowerCase();
        const code = (staff.employeeCode || '').toLowerCase();
        const email = (staff.email || '').toLowerCase();
        const phone = (staff.phone || '').toLowerCase();
        const designation = (staff.designation || '').toLowerCase();
        const dept = (staff.departmentName || '').toLowerCase();
        const qual = (staff.qualification || '').toLowerCase();

        const matches =
          fullName.includes(term) ||
          code.includes(term) ||
          email.includes(term) ||
          phone.includes(term) ||
          designation.includes(term) ||
          dept.includes(term) ||
          qual.includes(term);

        if (!matches) return false;
      }

      // Staff type filter
      if (staffType && staffType !== 'all') {
        if (staff.staffType.toLowerCase() !== staffType.toLowerCase()) return false;
      }

      // Department filter
      if (departmentId && departmentId !== 'all') {
        if (staff.departmentId !== departmentId) return false;
      }

      // Designation filter
      if (designationId && designationId !== 'all') {
        if (staff.designationId !== designationId && staff.designation !== designationId) return false;
      }

      // Employment status filter
      if (employmentStatus && employmentStatus !== 'all') {
        if (staff.employmentStatus.toLowerCase() !== employmentStatus.toLowerCase()) return false;
      }

      // Employment type filter
      if (employmentType && employmentType !== 'all') {
        if (staff.employmentType.toLowerCase() !== employmentType.toLowerCase()) return false;
      }

      // Gender filter
      if (gender && gender !== 'all') {
        if (staff.gender.toLowerCase() !== gender.toLowerCase()) return false;
      }

      return true;
    });

    // Compute live summary before slicing
    const allStaff = database.staffProfiles;
    const summary: StaffDirectorySummary = {
      totalStaff: allStaff.length,
      teachingStaff: allStaff.filter((s) => s.staffType === 'teaching').length,
      administrativeStaff: allStaff.filter((s) => s.staffType === 'administrative').length,
      supportStaff: allStaff.filter((s) => s.staffType === 'support').length,
      managementStaff: allStaff.filter((s) => s.staffType === 'management').length,
      operationalStaff: allStaff.filter((s) => s.staffType === 'operational').length,
      activeStaff: allStaff.filter((s) => s.employmentStatus === 'active').length,
      onLeaveStaff: allStaff.filter((s) => s.employmentStatus === 'on_leave').length,
      probationStaff: allStaff.filter((s) => s.employmentStatus === 'probation').length,
      inactiveStaff: allStaff.filter((s) => ['resigned', 'retired', 'terminated', 'suspended'].includes(s.employmentStatus)).length
    };

    // Sort items
    items.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'name':
          comparison = `${a.firstName} ${a.lastName}`.localeCompare(`${b.firstName} ${b.lastName}`);
          break;
        case 'employeeCode':
          comparison = (a.employeeCode || '').localeCompare(b.employeeCode || '');
          break;
        case 'department':
          comparison = (a.departmentName || '').localeCompare(b.departmentName || '');
          break;
        case 'designation':
          comparison = (a.designation || '').localeCompare(b.designation || '');
          break;
        case 'status':
          comparison = (a.employmentStatus || '').localeCompare(b.employmentStatus || '');
          break;
        case 'joiningDate':
          comparison = new Date(a.joiningDate || 0).getTime() - new Date(b.joiningDate || 0).getTime();
          break;
        default:
          comparison = `${a.firstName} ${a.lastName}`.localeCompare(`${b.firstName} ${b.lastName}`);
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    // Pagination
    const total = items.length;
    const safePage = Math.max(1, Number(page));
    const safeLimit = Math.max(1, Math.min(100, Number(limit)));
    const totalPages = Math.ceil(total / safeLimit) || 1;
    const startIndex = (safePage - 1) * safeLimit;
    const paginatedItems = items.slice(startIndex, startIndex + safeLimit);

    // Enrich items with fresh document counts & account status
    const enrichedItems = paginatedItems.map((s) => {
      const user = s.userId ? database.users.find((u) => u.id === s.userId) : undefined;
      const docs = database.staffDocuments.filter((d) => d.staffId === s.id);
      return {
        ...s,
        hasAccount: Boolean(user),
        accountRole: user?.role,
        accountStatus: user?.status,
        username: user?.username,
        lastLoginAt: user?.lastLoginAt,
        documents: docs
      };
    });

    return {
      items: enrichedItems,
      pagination: {
        page: safePage,
        limit: safeLimit,
        total,
        totalPages
      },
      summary
    };
  }

  /**
   * Get Single Staff Dossier by ID
   */
  public getStaffById(id: string): (StaffProfile & { teacherDetails?: any }) | null {
    const staff = database.staffProfiles.find((s) => s.id === id || s.employeeCode === id);
    if (!staff) return null;

    // Refresh live documents & history
    const docs = database.staffDocuments.filter((d) => d.staffId === staff.id);
    const history = database.staffStatusHistory.filter((h) => h.staffId === staff.id);
    const user = staff.userId ? database.users.find((u) => u.id === staff.userId) : undefined;

    // Optional teacher enrichment if teaching faculty
    let teacherDetails: any = null;
    if (staff.staffType === 'teaching' || staff.teacherProfileId) {
      const tp = database.teacherProfiles.find(
        (t) => t.id === staff.teacherProfileId || (staff.userId && t.userId === staff.userId) || t.employeeCode === staff.employeeCode
      );
      if (tp) {
        const assignedClasses = database.classes.filter((c) => tp.assignedClassIds?.includes(c.id));
        const assignedSubjects = database.subjects.filter((s) => tp.assignedSubjectIds?.includes(s.id));
        teacherDetails = {
          teacherProfileId: tp.id,
          assignedClasses,
          assignedSubjects,
          roomNumber: (tp as any).roomNumber
        };
      }
    }

    return {
      ...staff,
      hasAccount: Boolean(user),
      accountRole: user?.role,
      accountStatus: user?.status,
      username: user?.username,
      lastLoginAt: user?.lastLoginAt,
      documents: docs,
      statusHistory: history,
      teacherDetails
    };
  }

  /**
   * Generate Next Employee Code based on Staff Type
   */
  public generateNextEmployeeCode(staffType: string): string {
    const prefixMap: Record<string, string> = {
      teaching: 'EMP-T',
      administrative: 'EMP-ADM',
      support: 'EMP-SUP',
      management: 'EMP-MGT',
      operational: 'EMP-OPS'
    };
    const prefix = prefixMap[staffType] || 'EMP-STF';

    // Find highest current sequence with this prefix
    const existing = database.staffProfiles
      .map((s) => s.employeeCode)
      .filter((code) => code && code.startsWith(prefix));

    let maxNumber = 1000;
    for (const code of existing) {
      const parts = code.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num) && num > maxNumber) {
        maxNumber = num;
      }
    }

    return `${prefix}-${maxNumber + 1}`;
  }

  /**
   * Create New Staff Profile
   */
  public createStaff(payload: CreateStaffPayload, createdByUser?: User): StaffProfile {
    // 1. Validate required fields
    if (!payload.firstName?.trim() || !payload.lastName?.trim()) {
      throw new Error('First name and last name are required.');
    }
    if (!payload.email?.trim()) {
      throw new Error('Email address is required.');
    }
    if (!payload.phone?.trim()) {
      throw new Error('Phone number is required.');
    }
    if (!payload.departmentId?.trim()) {
      throw new Error('Department selection is required.');
    }
    if (!payload.staffType?.trim()) {
      throw new Error('Staff classification type is required.');
    }

    const emailTrimmed = payload.email.trim().toLowerCase();
    const phoneTrimmed = payload.phone.trim();

    // 2. Check email & phone uniqueness in staffProfiles
    const emailConflict = database.staffProfiles.find((s) => s.email.toLowerCase() === emailTrimmed);
    if (emailConflict) {
      throw new Error(`Email address '${emailTrimmed}' is already assigned to employee ${emailConflict.employeeCode} (${emailConflict.firstName} ${emailConflict.lastName}).`);
    }

    if (phoneTrimmed) {
      const cleanPhone = phoneTrimmed.replace(/[^0-9]/g, '');
      if (cleanPhone.length >= 7) {
        const phoneConflict = database.staffProfiles.find(
          (s) => s.phone && s.phone.replace(/[^0-9]/g, '') === cleanPhone
        );
        if (phoneConflict) {
          throw new Error(`Phone number '${phoneTrimmed}' is already registered to employee ${phoneConflict.employeeCode} (${phoneConflict.firstName} ${phoneConflict.lastName}).`);
        }
      }
    }

    // 3. Resolve department & designation names
    const dept = database.departments.find((d) => d.id === payload.departmentId);
    if (!dept) {
      throw new Error(`Selected department '${payload.departmentId}' was not found in system.`);
    }

    let designationTitle = payload.designation || 'Staff Member';
    if (payload.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        designationTitle = des.title;
      }
    }

    // 4. Employee code resolution
    let employeeCode = payload.employeeCode?.trim();
    if (!employeeCode) {
      employeeCode = this.generateNextEmployeeCode(payload.staffType);
    } else {
      const codeConflict = database.staffProfiles.find((s) => s.employeeCode.toLowerCase() === employeeCode!.toLowerCase());
      if (codeConflict) {
        throw new Error(`Employee code '${employeeCode}' is already in use by another staff member.`);
      }
    }

    const now = new Date().toISOString();
    const staffId = `staff-prof-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    // 5. Optional User Account creation
    let createdUserId: string | undefined = undefined;
    let username: string | undefined = undefined;
    let accountRole: UserRole | undefined = undefined;

    if (payload.createAccount) {
      const accountEmail = emailTrimmed;
      const desiredUsername = (payload.username || accountEmail.split('@')[0] || `staff_${Date.now()}`).trim().toLowerCase();

      const userConflict = database.users.find(
        (u) => u.email.toLowerCase() === accountEmail || u.username.toLowerCase() === desiredUsername
      );
      if (userConflict) {
        throw new Error(`A user account with email '${accountEmail}' or username '${desiredUsername}' already exists.`);
      }

      const rawPassword = payload.password?.trim() || 'SygmateStaff@2026';
      const { hash, salt } = hashPassword(rawPassword);

      accountRole = payload.accountRole || (payload.staffType === 'teaching' ? 'TEACHER' : payload.staffType === 'management' ? 'SUPER_ADMIN' : 'STAFF' as any);
      createdUserId = `usr-staff-${Date.now()}`;
      username = desiredUsername;

      const newUser: StoredUser = {
        id: createdUserId,
        name: `${payload.firstName.trim()} ${payload.lastName.trim()}`,
        firstName: payload.firstName.trim(),
        lastName: payload.lastName.trim(),
        email: accountEmail,
        username: desiredUsername,
        role: accountRole,
        status: 'active',
        phoneNumber: phoneTrimmed,
        passwordHash: hash,
        passwordSalt: salt,
        createdAt: now,
        updatedAt: now
      };

      database.users.push(newUser as any);
      registerUserLookup((uid: string) => database.users.find((u) => u.id === uid));

      logAudit({
        userId: createdByUser?.id || 'sys-admin',
        userName: createdByUser?.name || 'System Administrator',
        userRole: createdByUser?.role || 'SUPER_ADMIN',
        action: 'USER_CREATE',
        entity: 'USER',
        entityType: 'USER',
        entityId: createdUserId,
        details: `Created user account '${desiredUsername}' for staff member ${employeeCode}`
      });
    }

    // 6. Seamless TeacherProfile integration if teaching staff
    let teacherProfileId: string | undefined = undefined;
    if (payload.staffType === 'teaching') {
      teacherProfileId = `teacher-prof-${Date.now()}`;
      const newTeacherProfile: TeacherProfile = {
        id: teacherProfileId,
        userId: createdUserId || `usr-placeholder-${teacherProfileId}`,
        employeeCode,
        firstName: payload.firstName.trim(),
        lastName: payload.lastName.trim(),
        email: emailTrimmed,
        phone: phoneTrimmed,
        contactNumber: phoneTrimmed,
        gender: payload.gender as any,
        dateOfBirth: payload.dateOfBirth,
        address: payload.currentAddress?.trim() || '',
        designation: designationTitle,
        department: dept.name,
        departmentId: dept.id,
        employmentStatus: payload.employmentType || 'full_time',
        joiningDate: payload.joiningDate || now.split('T')[0],
        qualification: payload.qualification || 'Bachelor Degree',
        specialization: payload.specialization,
        status: 'active',
        assignedClassIds: [],
        assignedSubjectIds: [],
        createdAt: now,
        updatedAt: now
      };
      database.teacherProfiles.push(newTeacherProfile);
    }

    // 7. Assemble Staff Profile
    const newStaffProfile: StaffProfile = {
      id: staffId,
      userId: createdUserId,
      teacherProfileId,
      employeeCode,
      firstName: payload.firstName.trim(),
      lastName: payload.lastName.trim(),
      displayName: `${payload.firstName.trim()} ${payload.lastName.trim()}`,
      avatarUrl: payload.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256',
      gender: payload.gender || 'other',
      dateOfBirth: payload.dateOfBirth,
      maritalStatus: payload.maritalStatus,
      nationality: payload.nationality || 'American',
      bloodGroup: payload.bloodGroup,
      nationalIdNumber: payload.nationalIdNumber,
      passportNumber: payload.passportNumber,
      email: emailTrimmed,
      phone: phoneTrimmed,
      emergencyContactName: payload.emergencyContactName,
      emergencyContactPhone: payload.emergencyContactPhone,
      emergencyContactRelation: payload.emergencyContactRelation,
      currentAddress: payload.currentAddress?.trim() || 'Main Campus',
      permanentAddress: payload.permanentAddress?.trim(),
      city: payload.city,
      state: payload.state,
      postalCode: payload.postalCode,
      country: payload.country || 'USA',
      staffType: payload.staffType,
      departmentId: dept.id,
      departmentName: dept.name,
      designationId: payload.designationId,
      designation: designationTitle,
      employmentType: payload.employmentType || 'full_time',
      employmentStatus: payload.employmentStatus || 'active',
      joiningDate: payload.joiningDate || now.split('T')[0],
      confirmationDate: payload.confirmationDate,
      contractEndDate: payload.contractEndDate,
      qualification: payload.qualification?.trim() || 'Bachelor Degree',
      specialization: payload.specialization?.trim(),
      yearsOfExperience: payload.yearsOfExperience || 0,
      workShift: payload.workShift || 'general',
      workLocation: payload.workLocation || 'Main Campus',
      hasAccount: Boolean(createdUserId),
      accountRole,
      accountStatus: 'active',
      username,
      documents: [],
      statusHistory: [
        {
          id: `hist-${Date.now()}`,
          staffId,
          previousStatus: 'none',
          newStatus: payload.employmentStatus || 'active',
          reason: 'Initial staff profile creation and onboarding',
          effectiveDate: payload.joiningDate || now.split('T')[0],
          changedBy: createdByUser?.id || 'sys-admin',
          changedByName: createdByUser?.name || 'System Administrator',
          notes: 'Standard onboarding registration in HR master registry',
          timestamp: now
        }
      ],
      createdAt: now,
      updatedAt: now
    };

    database.staffProfiles.unshift(newStaffProfile);

    // Update department staff counts
    dept.staffCount = database.staffProfiles.filter((s) => s.departmentId === dept.id).length;

    // Audit Log
    logAudit({
      userId: createdByUser?.id || 'sys-admin',
      userName: createdByUser?.name || 'System Administrator',
      userRole: createdByUser?.role || 'SUPER_ADMIN',
      action: 'USER_CREATE' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_PROFILE',
      entityId: staffId,
      details: `Created staff profile for ${newStaffProfile.firstName} ${newStaffProfile.lastName} (${employeeCode}) in ${dept.name}`,
      metadata: { employeeCode, staffType: payload.staffType, departmentId: dept.id }
    });

    return newStaffProfile;
  }

  /**
   * Update Staff Profile
   */
  public updateStaff(id: string, payload: UpdateStaffPayload, updatedByUser?: User): StaffProfile {
    const staffIndex = database.staffProfiles.findIndex((s) => s.id === id || s.employeeCode === id);
    if (staffIndex === -1) {
      throw new Error(`Staff profile with ID or Code '${id}' was not found.`);
    }

    const current = database.staffProfiles[staffIndex];
    const now = new Date().toISOString();

    // Check email conflict if updated
    if (payload.email && payload.email.trim().toLowerCase() !== current.email.toLowerCase()) {
      const newEmail = payload.email.trim().toLowerCase();
      const conflict = database.staffProfiles.find((s) => s.id !== current.id && s.email.toLowerCase() === newEmail);
      if (conflict) {
        throw new Error(`Email address '${newEmail}' is already assigned to employee ${conflict.employeeCode}.`);
      }
      current.email = newEmail;
    }

    // Resolve department
    if (payload.departmentId && payload.departmentId !== current.departmentId) {
      const dept = database.departments.find((d) => d.id === payload.departmentId);
      if (dept) {
        current.departmentId = dept.id;
        current.departmentName = dept.name;
      }
    }

    // Resolve designation
    if (payload.designationId && payload.designationId !== current.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        current.designationId = des.id;
        current.designation = des.title;
      }
    } else if (payload.designation) {
      current.designation = payload.designation;
    }

    // Update basic & contact fields
    if (payload.firstName) current.firstName = payload.firstName.trim();
    if (payload.lastName) current.lastName = payload.lastName.trim();
    current.displayName = `${current.firstName} ${current.lastName}`;
    if (payload.avatarUrl !== undefined) current.avatarUrl = payload.avatarUrl;
    if (payload.phone && payload.phone.trim() !== current.phone) {
      const newPhone = payload.phone.trim();
      const cleanPhone = newPhone.replace(/[^0-9]/g, '');
      if (cleanPhone.length >= 7) {
        const conflict = database.staffProfiles.find(
          (s) => s.id !== current.id && s.phone && s.phone.replace(/[^0-9]/g, '') === cleanPhone
        );
        if (conflict) {
          throw new Error(`Phone number '${newPhone}' is already registered to employee ${conflict.employeeCode} (${conflict.firstName} ${conflict.lastName}).`);
        }
      }
      current.phone = newPhone;
    }
    if (payload.gender) current.gender = payload.gender;
    if (payload.dateOfBirth !== undefined) current.dateOfBirth = payload.dateOfBirth;
    if (payload.maritalStatus !== undefined) current.maritalStatus = payload.maritalStatus;
    if (payload.nationality !== undefined) current.nationality = payload.nationality;
    if (payload.bloodGroup !== undefined) current.bloodGroup = payload.bloodGroup;
    if (payload.nationalIdNumber !== undefined) current.nationalIdNumber = payload.nationalIdNumber;
    if (payload.passportNumber !== undefined) current.passportNumber = payload.passportNumber;
    if (payload.emergencyContactName !== undefined) current.emergencyContactName = payload.emergencyContactName;
    if (payload.emergencyContactPhone !== undefined) current.emergencyContactPhone = payload.emergencyContactPhone;
    if (payload.emergencyContactRelation !== undefined) current.emergencyContactRelation = payload.emergencyContactRelation;
    if (payload.currentAddress !== undefined) current.currentAddress = payload.currentAddress;
    if (payload.permanentAddress !== undefined) current.permanentAddress = payload.permanentAddress;
    if (payload.city !== undefined) current.city = payload.city;
    if (payload.state !== undefined) current.state = payload.state;
    if (payload.postalCode !== undefined) current.postalCode = payload.postalCode;
    if (payload.country !== undefined) current.country = payload.country;

    // Update professional fields
    if (payload.staffType) current.staffType = payload.staffType;
    if (payload.employmentType) current.employmentType = payload.employmentType;
    if (payload.joiningDate) current.joiningDate = payload.joiningDate;
    if (payload.confirmationDate !== undefined) current.confirmationDate = payload.confirmationDate;
    if (payload.contractEndDate !== undefined) current.contractEndDate = payload.contractEndDate;
    if (payload.qualification) current.qualification = payload.qualification;
    if (payload.specialization !== undefined) current.specialization = payload.specialization;
    if (payload.yearsOfExperience !== undefined) current.yearsOfExperience = payload.yearsOfExperience;
    if (payload.workShift !== undefined) current.workShift = payload.workShift;
    if (payload.workLocation !== undefined) current.workLocation = payload.workLocation;

    current.updatedAt = now;

    // Sync to linked TeacherProfile if present
    if (current.teacherProfileId) {
      const tp = database.teacherProfiles.find((t) => t.id === current.teacherProfileId);
      if (tp) {
        tp.firstName = current.firstName;
        tp.lastName = current.lastName;
        tp.email = current.email;
        tp.phone = current.phone;
        tp.designation = current.designation;
        tp.department = current.departmentName;
        tp.departmentId = current.departmentId;
        tp.qualification = current.qualification;
        tp.specialization = current.specialization;
        tp.address = current.currentAddress;
        tp.updatedAt = now;
      }
    }

    // Sync to linked User if present
    if (current.userId) {
      const user = database.users.find((u) => u.id === current.userId);
      if (user) {
        user.name = current.displayName;
        user.firstName = current.firstName;
        user.lastName = current.lastName;
        user.email = current.email;
        user.phoneNumber = current.phone;
        user.updatedAt = now;
      }
    }

    // Audit Log
    logAudit({
      userId: updatedByUser?.id || 'sys-admin',
      userName: updatedByUser?.name || 'System Administrator',
      userRole: updatedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_PROFILE',
      entityId: current.id,
      details: `Updated staff profile for ${current.displayName} (${current.employeeCode})`
    });

    return current;
  }

  /**
   * Safe Employment Status Transition Governance
   * Note: Changing staff status does NOT corrupt or delete historical attendance, leave, or academic logs!
   */
  public changeStaffStatus(
    id: string,
    payload: ChangeStaffStatusPayload,
    changedByUser?: User
  ): StaffProfile {
    const staff = database.staffProfiles.find((s) => s.id === id || s.employeeCode === id);
    if (!staff) {
      throw new Error(`Staff profile '${id}' was not found.`);
    }

    if (!payload.newStatus) {
      throw new Error('New employment status must be specified.');
    }
    if (!payload.reason?.trim()) {
      throw new Error('A detailed operational reason is required for any employment status transition.');
    }

    const previousStatus = staff.employmentStatus;

    // Validate state machine status transition
    if (previousStatus !== payload.newStatus) {
      const VALID_TRANSITIONS: Record<string, string[]> = {
        probation: ['active', 'suspended', 'terminated', 'resigned'],
        active: ['on_leave', 'suspended', 'terminated', 'resigned', 'retired', 'probation'],
        on_leave: ['active', 'suspended', 'terminated', 'resigned', 'retired'],
        suspended: ['active', 'terminated', 'resigned'],
        terminated: ['active'], // Reinstatement / rehire only
        resigned: ['active'],   // Rehire only
        retired: ['active']     // Re-engagement as active/visiting
      };

      const allowed = VALID_TRANSITIONS[previousStatus];
      if (allowed && !allowed.includes(payload.newStatus)) {
        throw new Error(`Invalid status transition: Cannot transition employee from '${previousStatus}' to '${payload.newStatus}'.`);
      }
    }

    const now = new Date().toISOString();
    const effectiveDate = payload.effectiveDate || now.split('T')[0];

    // Update staff record
    staff.employmentStatus = payload.newStatus;
    staff.statusChangeReason = payload.reason.trim();
    staff.statusEffectiveDate = effectiveDate;
    staff.updatedAt = now;

    // Create history entry
    const historyEntry: StaffStatusHistoryEntry = {
      id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      staffId: staff.id,
      previousStatus,
      newStatus: payload.newStatus,
      reason: payload.reason.trim(),
      effectiveDate,
      changedBy: changedByUser?.id || 'sys-admin',
      changedByName: changedByUser?.name || 'System Administrator',
      notes: payload.notes?.trim(),
      timestamp: now
    };

    database.staffStatusHistory.unshift(historyEntry);
    if (!staff.statusHistory) staff.statusHistory = [];
    staff.statusHistory.unshift(historyEntry);

    // Sync status to teacher profile if present
    if (staff.teacherProfileId) {
      const tp = database.teacherProfiles.find((t) => t.id === staff.teacherProfileId);
      if (tp) {
        if (payload.newStatus === 'on_leave') {
          tp.status = 'on_leave';
        } else if (['resigned', 'retired', 'terminated', 'suspended'].includes(payload.newStatus)) {
          tp.status = 'inactive';
        } else {
          tp.status = 'active';
        }
        tp.updatedAt = now;
      }
    }

    // If deactivate account is requested (or status is terminated/suspended), update linked account
    if (staff.userId && (payload.deactivateAccount || ['terminated', 'suspended'].includes(payload.newStatus))) {
      const user = database.users.find((u) => u.id === staff.userId);
      if (user) {
        user.status = 'inactive';
        user.updatedAt = now;
        staff.accountStatus = 'inactive';
      }
    } else if (staff.userId && payload.newStatus === 'active') {
      const user = database.users.find((u) => u.id === staff.userId);
      if (user && user.status === 'inactive') {
        user.status = 'active';
        user.updatedAt = now;
        staff.accountStatus = 'active';
      }
    }

    // Audit Log
    logAudit({
      userId: changedByUser?.id || 'sys-admin',
      userName: changedByUser?.name || 'System Administrator',
      userRole: changedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_STATUS_CHANGE',
      entityId: staff.id,
      details: `Transitioned employment status of ${staff.displayName} (${staff.employeeCode}) from '${previousStatus}' to '${payload.newStatus}'. Reason: ${payload.reason}`,
      metadata: { previousStatus, newStatus: payload.newStatus, effectiveDate }
    });

    return staff;
  }

  /**
   * Upload / Attach Staff Document
   */
  public uploadStaffDocument(
    staffId: string,
    payload: UploadStaffDocumentPayload,
    uploadedByUser?: User
  ): StaffDocument {
    const staff = database.staffProfiles.find((s) => s.id === staffId || s.employeeCode === staffId);
    if (!staff) {
      throw new Error(`Staff profile '${staffId}' not found.`);
    }

    if (!payload.title?.trim()) {
      throw new Error('Document title is required.');
    }
    if (!payload.fileUrl?.trim()) {
      throw new Error('Valid document file URL or attachment is required.');
    }

    const now = new Date().toISOString();
    const docId = `doc-staff-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    const newDoc: StaffDocument = {
      id: docId,
      staffId: staff.id,
      name: payload.name || payload.title.replace(/\s+/g, '_') + '.pdf',
      title: payload.title.trim(),
      category: payload.category || 'OTHER',
      documentNumber: payload.documentNumber?.trim(),
      issuingAuthority: payload.issuingAuthority?.trim(),
      issueDate: payload.issueDate,
      expiryDate: payload.expiryDate,
      fileUrl: payload.fileUrl.trim(),
      fileSize: payload.fileSize || '1.2 MB',
      fileType: payload.fileType || 'pdf',
      verificationStatus: 'PENDING_VERIFICATION',
      uploadedAt: now
    };

    database.staffDocuments.unshift(newDoc);
    if (!staff.documents) staff.documents = [];
    staff.documents.unshift(newDoc);

    logAudit({
      userId: uploadedByUser?.id || 'sys-admin',
      userName: uploadedByUser?.name || 'System Administrator',
      userRole: uploadedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_DOCUMENT',
      entityId: docId,
      details: `Uploaded credential document '${newDoc.title}' (${newDoc.category}) for ${staff.displayName} (${staff.employeeCode})`
    });

    return newDoc;
  }

  /**
   * Delete Staff Document
   */
  public deleteStaffDocument(staffId: string, documentId: string, deletedByUser?: User): boolean {
    const docIndex = database.staffDocuments.findIndex((d) => d.id === documentId && d.staffId === staffId);
    if (docIndex === -1) {
      throw new Error(`Staff document '${documentId}' not found for staff '${staffId}'.`);
    }

    const removed = database.staffDocuments.splice(docIndex, 1)[0];

    const staff = database.staffProfiles.find((s) => s.id === staffId);
    if (staff && staff.documents) {
      staff.documents = staff.documents.filter((d) => d.id !== documentId);
    }

    logAudit({
      userId: deletedByUser?.id || 'sys-admin',
      userName: deletedByUser?.name || 'System Administrator',
      userRole: deletedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_DOCUMENT_DELETE',
      entityId: documentId,
      details: `Deleted credential document '${removed.title}' for staff member '${staff?.displayName || staffId}'`
    });

    return true;
  }

  /**
   * Verify Staff Document
   */
  public verifyStaffDocument(
    staffId: string,
    documentId: string,
    payload: VerifyStaffDocumentPayload,
    verifiedByUser?: User
  ): StaffDocument {
    const doc = database.staffDocuments.find((d) => d.id === documentId && d.staffId === staffId);
    if (!doc) {
      throw new Error(`Staff document '${documentId}' not found.`);
    }

    const now = new Date().toISOString();
    doc.verificationStatus = payload.verificationStatus || 'VERIFIED';
    doc.verifiedBy = verifiedByUser?.name || 'Institutional Auditor';
    doc.verifiedAt = now;
    if (payload.verificationRemarks !== undefined) {
      doc.verificationRemarks = payload.verificationRemarks;
    }

    const staff = database.staffProfiles.find((s) => s.id === staffId);
    if (staff && staff.documents) {
      const match = staff.documents.find((d) => d.id === documentId);
      if (match) {
        match.verificationStatus = doc.verificationStatus;
        match.verifiedBy = doc.verifiedBy;
        match.verifiedAt = doc.verifiedAt;
        match.verificationRemarks = doc.verificationRemarks;
      }
    }

    logAudit({
      userId: verifiedByUser?.id || 'sys-admin',
      userName: verifiedByUser?.name || 'System Administrator',
      userRole: verifiedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_DOCUMENT_VERIFY',
      entityId: documentId,
      details: `Updated verification status of document '${doc.title}' to '${doc.verificationStatus}' for staff member '${staff?.displayName || staffId}'`
    });

    return doc;
  }

  /**
   * Link User Account to Staff Member
   */
  public linkStaffAccount(
    staffId: string,
    payload: { userId?: string; username?: string; password?: string; role?: UserRole },
    performedByUser?: User
  ): StaffProfile {
    const staff = database.staffProfiles.find((s) => s.id === staffId || s.employeeCode === staffId);
    if (!staff) {
      throw new Error(`Staff profile '${staffId}' not found.`);
    }

    const now = new Date().toISOString();

    if (payload.userId) {
      const user = database.users.find((u) => u.id === payload.userId);
      if (!user) {
        throw new Error(`User account with ID '${payload.userId}' not found.`);
      }

      staff.userId = user.id;
      staff.hasAccount = true;
      staff.accountRole = user.role;
      staff.accountStatus = user.status;
      staff.username = user.username;
      staff.updatedAt = now;

      // Sync user email & phone if empty
      if (!user.email && staff.email) user.email = staff.email;
      if (!user.phoneNumber && staff.phone) user.phoneNumber = staff.phone;
    } else if (payload.username && payload.password) {
      // Create new user account
      const desiredUsername = payload.username.trim().toLowerCase();
      const conflict = database.users.find((u) => u.username.toLowerCase() === desiredUsername || u.email.toLowerCase() === staff.email.toLowerCase());
      if (conflict) {
        throw new Error(`A user account with username '${desiredUsername}' or email '${staff.email}' already exists.`);
      }

      const { hash, salt } = hashPassword(payload.password);
      const newUserId = `usr-staff-${Date.now()}`;
      const role = payload.role || (staff.staffType === 'teaching' ? 'TEACHER' : staff.staffType === 'management' ? 'SUPER_ADMIN' : 'STAFF' as any);

      const newUser: StoredUser = {
        id: newUserId,
        name: staff.displayName || `${staff.firstName} ${staff.lastName}`,
        firstName: staff.firstName,
        lastName: staff.lastName,
        email: staff.email,
        username: desiredUsername,
        role,
        status: 'active',
        phoneNumber: staff.phone,
        passwordHash: hash,
        passwordSalt: salt,
        createdAt: now,
        updatedAt: now
      };

      database.users.push(newUser as any);
      registerUserLookup((uid: string) => database.users.find((u) => u.id === uid));

      staff.userId = newUserId;
      staff.hasAccount = true;
      staff.accountRole = role;
      staff.accountStatus = 'active';
      staff.username = desiredUsername;
      staff.updatedAt = now;
    } else {
      throw new Error('Must provide either existing userId or new username and password.');
    }

    logAudit({
      userId: performedByUser?.id || 'sys-admin',
      userName: performedByUser?.name || 'System Administrator',
      userRole: performedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_ACCOUNT_LINK',
      entityId: staff.id,
      details: `Linked user account '${staff.username}' to staff member ${staff.displayName} (${staff.employeeCode})`
    });

    return staff;
  }

  /**
   * Unlink User Account from Staff Member
   */
  public unlinkStaffAccount(staffId: string, performedByUser?: User): StaffProfile {
    const staff = database.staffProfiles.find((s) => s.id === staffId || s.employeeCode === staffId);
    if (!staff) {
      throw new Error(`Staff profile '${staffId}' not found.`);
    }

    const previousUsername = staff.username;
    staff.userId = undefined;
    staff.hasAccount = false;
    staff.accountRole = undefined;
    staff.accountStatus = undefined;
    staff.username = undefined;
    staff.updatedAt = new Date().toISOString();

    logAudit({
      userId: performedByUser?.id || 'sys-admin',
      userName: performedByUser?.name || 'System Administrator',
      userRole: performedByUser?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'STAFF_ACCOUNT_UNLINK',
      entityId: staff.id,
      details: `Unlinked user account '${previousUsername}' from staff member ${staff.displayName} (${staff.employeeCode})`
    });

    return staff;
  }

  /**
   * Aggregate Staff Statistics & Demographics
   */
  public getStaffStats(): StaffStatsResponse {
    const staff = database.staffProfiles;
    const depts = database.departments;

    const summary: StaffDirectorySummary = {
      totalStaff: staff.length,
      teachingStaff: staff.filter((s) => s.staffType === 'teaching').length,
      administrativeStaff: staff.filter((s) => s.staffType === 'administrative').length,
      supportStaff: staff.filter((s) => s.staffType === 'support').length,
      managementStaff: staff.filter((s) => s.staffType === 'management').length,
      operationalStaff: staff.filter((s) => s.staffType === 'operational').length,
      activeStaff: staff.filter((s) => s.employmentStatus === 'active').length,
      onLeaveStaff: staff.filter((s) => s.employmentStatus === 'on_leave').length,
      probationStaff: staff.filter((s) => s.employmentStatus === 'probation').length,
      inactiveStaff: staff.filter((s) => ['resigned', 'retired', 'terminated', 'suspended'].includes(s.employmentStatus)).length
    };

    // By department
    const byDepartment = depts.map((d) => ({
      departmentId: d.id,
      departmentName: d.name,
      count: staff.filter((s) => s.departmentId === d.id).length
    })).sort((a, b) => b.count - a.count);

    // By staff type
    const types = ['teaching', 'administrative', 'support', 'management', 'operational'];
    const byStaffType = types.map((t) => ({
      type: t,
      count: staff.filter((s) => s.staffType === t).length
    }));

    // By employment status
    const statuses = ['active', 'on_leave', 'probation', 'suspended', 'resigned', 'retired', 'terminated'];
    const byEmploymentStatus = statuses.map((st) => ({
      status: st,
      count: staff.filter((s) => s.employmentStatus === st).length
    })).filter((item) => item.count > 0);

    // By gender
    const genders = ['male', 'female', 'other'];
    const byGender = genders.map((g) => ({
      gender: g,
      count: staff.filter((s) => s.gender === g).length
    }));

    // Recent joiners (last 5)
    const recentJoiners = [...staff]
      .sort((a, b) => new Date(b.joiningDate || 0).getTime() - new Date(a.joiningDate || 0).getTime())
      .slice(0, 5);

    return {
      summary,
      byDepartment,
      byStaffType,
      byEmploymentStatus,
      byGender,
      recentJoiners
    };
  }

  /**
   * Departments with Real-time Staff Counts & Metrics
   */
  public getDepartmentsWithStats(): Array<Department & { staffCount: number; teachingCount: number; nonTeachingCount: number }> {
    return database.departments.map((d) => {
      const assigned = database.staffProfiles.filter((s) => s.departmentId === d.id);
      const teachingCount = assigned.filter((s) => s.staffType === 'teaching').length;
      return {
        ...d,
        staffCount: assigned.length,
        teachingCount,
        nonTeachingCount: assigned.length - teachingCount
      };
    });
  }

  /**
   * Create Department
   */
  public createDepartment(payload: Partial<Department>, user?: User): Department {
    if (!payload.name?.trim()) {
      throw new Error('Department name is required.');
    }
    const code = (payload.code || `DEP-${payload.name.substring(0, 3).toUpperCase()}`).trim();

    const conflict = database.departments.find(
      (d) => d.name.toLowerCase() === payload.name!.trim().toLowerCase() || d.code.toLowerCase() === code.toLowerCase()
    );
    if (conflict) {
      throw new Error(`A department with name '${payload.name}' or code '${code}' already exists.`);
    }

    const now = new Date().toISOString();
    const newDept: Department = {
      id: payload.id || `dept-${Date.now()}`,
      name: payload.name.trim(),
      code,
      description: payload.description?.trim(),
      category: payload.category || 'administrative',
      location: payload.location?.trim(),
      budgetCode: payload.budgetCode?.trim(),
      headOfDepartmentId: payload.headOfDepartmentId,
      headOfDepartmentName: payload.headOfDepartmentName,
      status: 'active',
      staffCount: 0,
      createdAt: now,
      updatedAt: now
    };

    database.departments.push(newDept);

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'ACADEMIC_UPDATE' as any,
      entity: 'ACADEMIC_SESSION' as any,
      entityType: 'DEPARTMENT',
      entityId: newDept.id,
      details: `Created new department '${newDept.name}' (${newDept.code})`
    });

    return newDept;
  }

  /**
   * Update Department
   */
  public updateDepartment(id: string, payload: Partial<Department>, user?: User): Department {
    const dept = database.departments.find((d) => d.id === id);
    if (!dept) {
      throw new Error(`Department '${id}' not found.`);
    }

    if (payload.name) dept.name = payload.name.trim();
    if (payload.code) dept.code = payload.code.trim();
    if (payload.description !== undefined) dept.description = payload.description;
    if (payload.category) dept.category = payload.category;
    if (payload.location !== undefined) dept.location = payload.location;
    if (payload.budgetCode !== undefined) dept.budgetCode = payload.budgetCode;
    if (payload.headOfDepartmentId !== undefined) dept.headOfDepartmentId = payload.headOfDepartmentId;
    if (payload.headOfDepartmentName !== undefined) dept.headOfDepartmentName = payload.headOfDepartmentName;
    if (payload.status) dept.status = payload.status as any;

    dept.updatedAt = new Date().toISOString();

    // Propagate updated name to staff members
    for (const staff of database.staffProfiles) {
      if (staff.departmentId === dept.id) {
        staff.departmentName = dept.name;
      }
    }

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'ACADEMIC_UPDATE' as any,
      entity: 'ACADEMIC_SESSION' as any,
      entityType: 'DEPARTMENT',
      entityId: dept.id,
      details: `Updated department metadata for '${dept.name}'`
    });

    return dept;
  }

  /**
   * Delete / Archive Department
   */
  public deleteDepartment(id: string, user?: User): boolean {
    const assignedCount = database.staffProfiles.filter((s) => s.departmentId === id).length;
    if (assignedCount > 0) {
      throw new Error(`Cannot delete department '${id}' because ${assignedCount} active staff member(s) are assigned to it. Please reassign staff first.`);
    }

    const index = database.departments.findIndex((d) => d.id === id);
    if (index === -1) {
      throw new Error(`Department '${id}' not found.`);
    }

    const removed = database.departments.splice(index, 1)[0];

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'ACADEMIC_UPDATE' as any,
      entity: 'ACADEMIC_SESSION' as any,
      entityType: 'DEPARTMENT',
      entityId: id,
      details: `Deleted department '${removed.name}'`
    });

    return true;
  }

  /**
   * Designations Directory
   */
  public getDesignations(departmentId?: string, staffType?: string): Designation[] {
    let list = database.designations;

    if (departmentId && departmentId !== 'all') {
      list = list.filter((d) => d.departmentId === departmentId || !d.departmentId);
    }
    if (staffType && staffType !== 'all') {
      list = list.filter((d) => d.staffType.toLowerCase() === staffType.toLowerCase());
    }

    // Enrich with live staff counts
    return list.map((des) => {
      const count = database.staffProfiles.filter(
        (s) => s.designationId === des.id || s.designation.toLowerCase() === des.title.toLowerCase()
      ).length;
      return {
        ...des,
        staffCount: count
      };
    });
  }

  /**
   * Create Designation
   */
  public createDesignation(payload: CreateDesignationPayload, user?: User): Designation {
    if (!payload.title?.trim()) {
      throw new Error('Designation title is required.');
    }
    if (!payload.code?.trim()) {
      throw new Error('Designation code is required.');
    }

    const code = payload.code.trim().toUpperCase();
    const conflict = database.designations.find((d) => d.code.toUpperCase() === code);
    if (conflict) {
      throw new Error(`A designation with code '${code}' already exists.`);
    }

    let departmentName: string | undefined = undefined;
    if (payload.departmentId) {
      const dept = database.departments.find((d) => d.id === payload.departmentId);
      if (dept) departmentName = dept.name;
    }

    const now = new Date().toISOString();
    const newDes: Designation = {
      id: `des-${Date.now()}`,
      title: payload.title.trim(),
      code,
      departmentId: payload.departmentId,
      departmentName,
      staffType: payload.staffType || 'teaching',
      description: payload.description?.trim(),
      level: payload.level || 'mid',
      status: payload.status || 'active',
      staffCount: 0,
      createdAt: now,
      updatedAt: now
    };

    database.designations.push(newDes);

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'DESIGNATION',
      entityId: newDes.id,
      details: `Created new designation '${newDes.title}' (${newDes.code})`
    });

    return newDes;
  }

  /**
   * Update Designation
   */
  public updateDesignation(id: string, payload: UpdateDesignationPayload, user?: User): Designation {
    const des = database.designations.find((d) => d.id === id);
    if (!des) {
      throw new Error(`Designation '${id}' not found.`);
    }

    if (payload.title) des.title = payload.title.trim();
    if (payload.code) des.code = payload.code.trim().toUpperCase();
    if (payload.departmentId !== undefined) {
      des.departmentId = payload.departmentId;
      const dept = database.departments.find((d) => d.id === payload.departmentId);
      des.departmentName = dept?.name;
    }
    if (payload.staffType) des.staffType = payload.staffType;
    if (payload.description !== undefined) des.description = payload.description;
    if (payload.level) des.level = payload.level;
    if (payload.status) des.status = payload.status;

    des.updatedAt = new Date().toISOString();

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'DESIGNATION',
      entityId: des.id,
      details: `Updated designation '${des.title}'`
    });

    return des;
  }

  /**
   * Delete Designation
   */
  public deleteDesignation(id: string, user?: User): boolean {
    const assignedCount = database.staffProfiles.filter((s) => s.designationId === id).length;
    if (assignedCount > 0) {
      throw new Error(`Cannot delete designation '${id}' because ${assignedCount} active staff member(s) hold this title.`);
    }

    const index = database.designations.findIndex((d) => d.id === id);
    if (index === -1) {
      throw new Error(`Designation '${id}' not found.`);
    }

    const removed = database.designations.splice(index, 1)[0];

    logAudit({
      userId: user?.id || 'sys-admin',
      userName: user?.name || 'System Administrator',
      userRole: user?.role || 'SUPER_ADMIN',
      action: 'USER_EDIT' as any,
      entity: 'USER' as any,
      entityType: 'DESIGNATION',
      entityId: id,
      details: `Deleted designation '${removed.title}'`
    });

    return true;
  }

  /**
   * Export Staff Directory to CSV
   */
  public exportStaffToCsv(query: StaffDirectoryQuery = {}): string {
    const res = this.getStaffDirectory({ ...query, page: 1, limit: 10000 });
    const headers = [
      'Employee Code',
      'First Name',
      'Last Name',
      'Staff Type',
      'Department',
      'Designation',
      'Employment Type',
      'Employment Status',
      'Joining Date',
      'Email',
      'Phone',
      'Emergency Contact Name',
      'Emergency Contact Phone',
      'Gender',
      'Date of Birth',
      'Qualification',
      'Specialization',
      'Years of Experience',
      'Current Address',
      'City',
      'State',
      'Country',
      'Has User Account',
      'Username',
      'Account Role'
    ];

    const escape = (val: any) => {
      if (val === null || val === undefined) return '""';
      const s = String(val).replace(/"/g, '""');
      return `"${s}"`;
    };

    const rows = res.items.map((s) => [
      escape(s.employeeCode),
      escape(s.firstName),
      escape(s.lastName),
      escape(s.staffType),
      escape(s.departmentName),
      escape(s.designation),
      escape(s.employmentType),
      escape(s.employmentStatus),
      escape(s.joiningDate),
      escape(s.email),
      escape(s.phone),
      escape(s.emergencyContactName),
      escape(s.emergencyContactPhone),
      escape(s.gender),
      escape(s.dateOfBirth),
      escape(s.qualification),
      escape(s.specialization),
      escape(s.yearsOfExperience),
      escape(s.currentAddress),
      escape(s.city),
      escape(s.state),
      escape(s.country),
      escape(s.hasAccount ? 'Yes' : 'No'),
      escape(s.username || ''),
      escape(s.accountRole || '')
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }
}

export const staffService = new StaffService();
