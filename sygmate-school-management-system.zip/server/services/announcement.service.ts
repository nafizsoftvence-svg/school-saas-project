import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { CommunicationService } from './communication.service.js';
import { BulkCampaignService } from './bulk-campaign.service.js';
import {
  ClassAnnouncement,
  AnnouncementAudience,
  AnnouncementCategory,
  AnnouncementStatus,
  AnnouncementFilterParams,
  UserRole,
  AnnouncementAttachment
} from '../../src/types/index.js';

/**
 * Server-side HTML & Content Sanitizer to prevent XSS.
 * Strips script tags, iframes, javascript: pseudo-protocols, and inline event listeners.
 */
export function sanitizeAnnouncementContent(content: string): string {
  if (!content) return '';
  let sanitized = content;

  // Remove script tags and contents
  sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
  // Remove iframe tags and contents
  sanitized = sanitized.replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '');
  // Remove object, embed, applet tags
  sanitized = sanitized.replace(/<(object|embed|applet)\b[^<]*(?:(?!<\/(object|embed|applet)>)<[^<]*)*<\/(object|embed|applet)>/gi, '');
  // Remove javascript: URLs
  sanitized = sanitized.replace(/href\s*=\s*(['"])\s*javascript:[^'"]*(\1)/gi, 'href="#"');
  sanitized = sanitized.replace(/src\s*=\s*(['"])\s*javascript:[^'"]*(\1)/gi, 'src=""');
  // Remove event handlers (on* attributes like onerror, onload, onclick, etc.)
  sanitized = sanitized.replace(/\s+on\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');

  return sanitized.trim();
}

export class AnnouncementService {
  private static schedulerInitialized = false;

  /**
   * Initializes background scheduler to check for scheduled announcements and expirations.
   */
  public static initScheduler(): void {
    if (this.schedulerInitialized) return;
    this.schedulerInitialized = true;

    // Check once after event loop tick so all imported services are initialized
    setTimeout(() => {
      try {
        this.evaluateLifecycle();
      } catch (err) {
        console.error('[AnnouncementService] Initial lifecycle evaluation error:', err);
      }
    }, 100);

    // Check every 60 seconds
    const timer = setInterval(() => {
      try {
        this.evaluateLifecycle();
      } catch (err) {
        console.error('[AnnouncementService] Scheduler lifecycle evaluation error:', err);
      }
    }, 60000);
    if (timer.unref) timer.unref();
  }

  /**
   * Automatically publishes scheduled announcements whose time has arrived,
   * and marks published announcements as expired if expiry date has passed.
   */
  public static evaluateLifecycle(): { published: number; expired: number } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const now = new Date();
    const nowIso = now.toISOString();
    const todayStr = nowIso.split('T')[0];
    let publishedCount = 0;
    let expiredCount = 0;

    for (const ann of database.classAnnouncements) {
      // 1. Check Scheduled -> Published
      if (ann.status === 'scheduled') {
        const scheduledTime = ann.scheduledPublishAt
          ? new Date(ann.scheduledPublishAt)
          : ann.publishDate ? new Date(ann.publishDate) : null;

        if (scheduledTime && scheduledTime <= now) {
          ann.status = 'published';
          ann.publishedAt = nowIso;
          ann.publishDate = todayStr;
          ann.updatedAt = nowIso;
          publishedCount++;

          // Dispatch notifications via CommunicationService
          this.dispatchAnnouncementNotifications(ann);

          logAudit({
            userId: ann.authorUserId || 'system-scheduler',
            userName: ann.authorName || 'System Scheduler',
            userRole: (ann.authorRole as UserRole) || 'SUPER_ADMIN',
            action: 'ANNOUNCEMENT_SCHEDULE_FIRED',
            entity: 'ClassAnnouncement',
            entityType: 'ClassAnnouncement',
            entityId: ann.id,
            details: `Scheduled announcement '${ann.title}' was automatically published and dispatched.`
          });
        }
      }

      // 2. Check Published -> Expired
      if (ann.status === 'published') {
        let isExpired = false;
        if (ann.expiresAt && new Date(ann.expiresAt) <= now) {
          isExpired = true;
        } else if (ann.expiryDate && ann.expiryDate < todayStr) {
          isExpired = true;
        }

        if (isExpired) {
          ann.status = 'expired';
          ann.updatedAt = nowIso;
          expiredCount++;

          logAudit({
            userId: 'system-scheduler',
            userName: 'System Scheduler',
            userRole: 'SUPER_ADMIN',
            action: 'ANNOUNCEMENT_EXPIRED',
            entity: 'ClassAnnouncement',
            entityType: 'ClassAnnouncement',
            entityId: ann.id,
            details: `Announcement '${ann.title}' has expired automatically.`
          });
        }
      }
    }

    // Evaluate scheduled bulk campaigns
    if (typeof BulkCampaignService !== 'undefined' && BulkCampaignService?.evaluateLifecycle) {
      try {
        BulkCampaignService.evaluateLifecycle();
      } catch (err) {
        console.error('[BulkCampaignService] Error evaluating campaign lifecycle in scheduler:', err);
      }
    }

    return { published: publishedCount, expired: expiredCount };
  }

  /**
   * Resolves target recipients for an announcement and dispatches via CommunicationService
   */
  public static async dispatchAnnouncementNotifications(ann: ClassAnnouncement): Promise<void> {
    try {
      const channels = ann.channels || { inApp: true, email: true, sms: false, push: true };
      // If all channels are turned off, nothing to dispatch
      if (!channels.inApp && !channels.email && !channels.sms && !channels.push) {
        return;
      }

      const targetAudience = ann.targetAudience || (ann.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
      let targetRole: UserRole | 'ALL' = 'ALL';

      if (targetAudience === 'STUDENTS') targetRole = 'STUDENT';
      else if (targetAudience === 'PARENTS') targetRole = 'GUARDIAN';
      else if (targetAudience === 'TEACHERS') targetRole = 'TEACHER';

      const actor = {
        id: ann.authorUserId || ann.teacherUserId || 'usr-admin-1',
        name: ann.authorName || ann.teacherName || 'Administration',
        role: (ann.authorRole as UserRole) || 'SUPER_ADMIN'
      };

      await CommunicationService.dispatch({
        eventType: 'SCHOOL_ANNOUNCEMENT',
        entityId: ann.id,
        entityType: 'ANNOUNCEMENT',
        classId: ann.classId && ann.classId !== 'ALL' ? ann.classId : undefined,
        sectionId: ann.sectionId && ann.sectionId !== 'ALL' ? ann.sectionId : undefined,
        targetRole,
        customTitle: ann.title,
        customMessage: ann.message,
        variables: {
          announcement_title: ann.title,
          announcement_body: ann.message,
          author_name: ann.authorName || ann.teacherName || 'Administration',
          school_name: 'Sygmate International Academy',
          date: ann.publishDate || new Date().toISOString().split('T')[0]
        },
        actorUser: actor
      });
    } catch (err) {
      console.error('[AnnouncementService] Failed to dispatch announcement notifications:', err);
    }
  }

  /**
   * Calculate eligible recipient count for an announcement
   */
  public static calculateEligibleRecipients(ann: ClassAnnouncement): number {
    const audience = ann.targetAudience || (ann.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');

    if (audience === 'SCHOOL_WIDE') {
      return (database.users || []).filter((u) => u.status === 'active' || u.status === 'ACTIVE').length;
    }
    if (audience === 'STUDENTS') {
      return (database.studentProfiles || []).length;
    }
    if (audience === 'PARENTS') {
      return (database.guardians || []).length;
    }
    if (audience === 'TEACHERS') {
      return (database.teacherProfiles || []).length;
    }
    if (audience === 'CLASS') {
      const studentCount = (database.studentProfiles || []).filter((s) => s.classId === ann.classId).length;
      return studentCount * 2; // Students + parents
    }
    if (audience === 'SECTION') {
      const studentCount = (database.studentProfiles || []).filter(
        (s) => s.classId === ann.classId && s.sectionId === ann.sectionId
      ).length;
      return studentCount * 2;
    }
    if (audience === 'CUSTOM' && ann.targetRoles) {
      return (database.users || []).filter((u) => ann.targetRoles?.includes(u.role)).length;
    }

    return (database.studentProfiles || []).length;
  }

  /**
   * Retrieves announcements matching filters and authorization context
   */
  public static getAnnouncements(
    params: AnnouncementFilterParams,
    userContext: {
      userId: string;
      role: UserRole;
      studentProfileId?: string;
      classId?: string;
      sectionId?: string;
      guardianId?: string;
      childIds?: string[];
      teacherId?: string;
      assignedClassIds?: string[];
    }
  ): {
    data: ClassAnnouncement[];
    total: number;
    stats?: {
      total: number;
      published: number;
      scheduled: number;
      drafts: number;
      expired: number;
      archived: number;
    };
  } {
    this.evaluateLifecycle();

    if (!database.classAnnouncements) database.classAnnouncements = [];
    const list = database.classAnnouncements;
    const isAdmin = userContext.role === 'SUPER_ADMIN' || (userContext.role as string) === 'ADMIN';

    // Filter by User Authorization & Audience
    let filtered = list.filter((a) => {
      // Admins see all announcements
      if (isAdmin) {
        return true;
      }

      // Teachers see announcements they created, or published announcements for their classes / school-wide
      if (userContext.role === 'TEACHER') {
        if (a.authorUserId === userContext.userId || a.teacherUserId === userContext.userId) {
          return true;
        }
        if (a.status !== 'published') return false;

        const audience = a.targetAudience || (a.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
        if (audience === 'SCHOOL_WIDE' || audience === 'TEACHERS') return true;
        if (audience === 'CUSTOM' && a.targetRoles?.includes('TEACHER')) return true;

        if (userContext.assignedClassIds && userContext.assignedClassIds.includes(a.classId)) {
          return true;
        }
        return false;
      }

      // Students see published, non-expired announcements for their class/section or school-wide/students
      if (userContext.role === 'STUDENT') {
        if (a.status !== 'published') return false;

        const audience = a.targetAudience || (a.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
        if (audience === 'SCHOOL_WIDE' || audience === 'STUDENTS') return true;
        if (audience === 'CUSTOM' && a.targetRoles?.includes('STUDENT')) return true;

        if (a.classId === userContext.classId || a.classId === 'ALL') {
          if (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === userContext.sectionId) {
            return true;
          }
        }
        return false;
      }

      // Guardians see published, non-expired announcements for their children or school-wide/parents
      if (userContext.role === 'GUARDIAN') {
        if (a.status !== 'published') return false;

        const audience = a.targetAudience || (a.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
        if (audience === 'SCHOOL_WIDE' || audience === 'PARENTS') return true;
        if (audience === 'CUSTOM' && a.targetRoles?.includes('GUARDIAN')) return true;

        // If child-specific filter or matched by linked child
        if (userContext.classId && (a.classId === userContext.classId || a.classId === 'ALL')) {
          if (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === userContext.sectionId) {
            return true;
          }
        }

        // Check if any of guardian's children are in this class
        if (userContext.childIds && userContext.childIds.length > 0) {
          const childrenInClass = (database.studentProfiles || []).filter(
            (sp) => userContext.childIds?.includes(sp.id) && (sp.classId === a.classId || a.classId === 'ALL')
          );
          if (childrenInClass.length > 0) {
            if (!a.sectionId || a.sectionId === 'ALL') return true;
            if (childrenInClass.some((c) => c.sectionId === a.sectionId)) return true;
          }
        }

        return false;
      }

      return false;
    });

    // Compute metrics before additional param filters
    const stats = {
      total: filtered.length,
      published: filtered.filter((a) => a.status === 'published').length,
      scheduled: filtered.filter((a) => a.status === 'scheduled').length,
      drafts: filtered.filter((a) => a.status === 'draft').length,
      expired: filtered.filter((a) => a.status === 'expired').length,
      archived: filtered.filter((a) => a.status === 'archived').length
    };

    // Apply Filter Parameters
    if (params.status && params.status !== 'ALL' && params.status !== 'all') {
      filtered = filtered.filter((a) => a.status === params.status);
    } else if (!isAdmin && userContext.role !== 'TEACHER') {
      // Non-admins never see drafts, archived, or scheduled items
      filtered = filtered.filter((a) => a.status === 'published');
    }

    if (params.category && params.category !== 'ALL' && params.category !== 'all') {
      filtered = filtered.filter((a) => a.category === params.category);
    }

    if (params.priority && params.priority !== 'ALL' && params.priority !== 'all') {
      const pr = params.priority.toLowerCase();
      filtered = filtered.filter((a) => a.priority.toLowerCase() === pr);
    }

    if (params.targetAudience && params.targetAudience !== 'ALL' && params.targetAudience !== 'all') {
      filtered = filtered.filter((a) => a.targetAudience === params.targetAudience);
    }

    if (params.classId && params.classId !== 'ALL' && params.classId !== 'all') {
      filtered = filtered.filter((a) => a.classId === params.classId || a.classId === 'ALL');
    }

    if (params.sectionId && params.sectionId !== 'ALL' && params.sectionId !== 'all') {
      filtered = filtered.filter((a) => a.sectionId === params.sectionId || a.sectionId === 'ALL');
    }

    if (params.search && params.search.trim()) {
      const q = params.search.trim().toLowerCase();
      filtered = filtered.filter(
        (a) =>
          (a.title || '').toLowerCase().includes(q) ||
          (a.message || '').toLowerCase().includes(q) ||
          (a.className || '').toLowerCase().includes(q) ||
          (a.teacherName || '').toLowerCase().includes(q) ||
          (a.authorName || '').toLowerCase().includes(q) ||
          (a.category || '').toLowerCase().includes(q)
      );
    }

    // Sort: Pinned first, then date descending
    filtered.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      const dateA = a.publishDate || a.createdAt;
      const dateB = b.publishDate || b.createdAt;
      return dateB.localeCompare(dateA) || b.createdAt.localeCompare(a.createdAt);
    });

    // Decorate each announcement with read status and stats
    const decorated = filtered.map((ann) => {
      const isRead = !!(ann.readReceipts && ann.readReceipts.some((r) => r.userId === userContext.userId));
      const myReceipt = ann.readReceipts?.find((r) => r.userId === userContext.userId);
      const totalRecipients = this.calculateEligibleRecipients(ann);
      const readCount = ann.readReceipts ? ann.readReceipts.length : 0;
      const unreadCount = Math.max(0, totalRecipients - readCount);

      // Find delivered logs count
      const commLogs = CommunicationService.getLogs();
      const deliveredCount = commLogs.filter(
        (l) => (l.relatedEntityId === ann.id || l.entityId === ann.id) && (l.status === 'DELIVERED' || l.status === 'SENT')
      ).length;

      return {
        ...ann,
        isRead,
        readAt: myReceipt?.readAt,
        stats: {
          totalRecipients,
          deliveredCount,
          readCount,
          unreadCount
        }
      };
    });

    return {
      data: decorated,
      total: decorated.length,
      stats
    };
  }

  /**
   * Retrieves single announcement by ID with validation
   */
  public static getAnnouncementById(
    id: string,
    userContext: {
      userId: string;
      role: UserRole;
      classId?: string;
      sectionId?: string;
    }
  ): ClassAnnouncement | null {
    this.evaluateLifecycle();

    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);
    if (!ann) return null;

    const isAdmin = userContext.role === 'SUPER_ADMIN' || (userContext.role as string) === 'ADMIN';
    if (!isAdmin && ann.status !== 'published') {
      // Non-admins can only view published announcements
      if (ann.authorUserId !== userContext.userId) {
        return null;
      }
    }

    const isRead = !!(ann.readReceipts && ann.readReceipts.some((r) => r.userId === userContext.userId));
    const myReceipt = ann.readReceipts?.find((r) => r.userId === userContext.userId);
    const totalRecipients = this.calculateEligibleRecipients(ann);
    const readCount = ann.readReceipts ? ann.readReceipts.length : 0;
    const unreadCount = Math.max(0, totalRecipients - readCount);

    const commLogs = CommunicationService.getLogs();
    const deliveredCount = commLogs.filter(
      (l) => (l.relatedEntityId === ann.id || l.entityId === ann.id) && (l.status === 'DELIVERED' || l.status === 'SENT')
    ).length;

    return {
      ...ann,
      isRead,
      readAt: myReceipt?.readAt,
      stats: {
        totalRecipients,
        deliveredCount,
        readCount,
        unreadCount
      }
    };
  }

  /**
   * Creates a new announcement
   */
  public static async createAnnouncement(
    payload: {
      title: string;
      message: string;
      category?: AnnouncementCategory | string;
      priority?: 'normal' | 'important' | 'high' | 'urgent';
      targetAudience?: AnnouncementAudience;
      targetRoles?: UserRole[];
      targetUserIds?: string[];
      classId?: string;
      sectionId?: string;
      publishDate?: string;
      scheduledPublishAt?: string;
      expiryDate?: string;
      expiresAt?: string;
      isPinned?: boolean;
      status?: AnnouncementStatus;
      visibility?: 'ALL' | 'INTERNAL' | 'RESTRICTED';
      attachments?: AnnouncementAttachment[];
      channels?: { inApp: boolean; email: boolean; sms: boolean; push: boolean };
    },
    actor: {
      id: string;
      name: string;
      role: UserRole;
    }
  ): Promise<ClassAnnouncement> {
    if (!database.classAnnouncements) database.classAnnouncements = [];

    const now = new Date();
    const nowIso = now.toISOString();
    const todayStr = nowIso.split('T')[0];

    const sanitizedMessage = sanitizeAnnouncementContent(payload.message || '');
    const sanitizedTitle = (payload.title || '').trim();

    // Resolve target class & section names
    let className = 'All Classes';
    let sectionName = 'All Sections';

    if (payload.classId && payload.classId !== 'ALL') {
      const cls = (database.classes || []).find((c) => c.id === payload.classId);
      if (cls) className = cls.name;
    }

    if (payload.sectionId && payload.sectionId !== 'ALL') {
      const sec = (database.sections || []).find((s) => s.id === payload.sectionId);
      if (sec) sectionName = sec.name;
    }

    const activeSession = (database.academicSessions || []).find((s) => s.isActive) || (database.academicSessions || [])[0];

    // Status logic
    let status: AnnouncementStatus = payload.status || 'published';
    if (payload.scheduledPublishAt && new Date(payload.scheduledPublishAt) > now) {
      status = 'scheduled';
    }

    const newAnnouncement: ClassAnnouncement = {
      id: `ann-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      schoolId: 'school-main',
      title: sanitizedTitle,
      message: sanitizedMessage,
      content: sanitizedMessage,
      category: payload.category || 'general',
      classId: payload.classId || 'ALL',
      className,
      sectionId: payload.sectionId || 'ALL',
      sectionName,
      academicSessionId: activeSession?.id || 'session-2026-2027',
      academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
      targetAudience: payload.targetAudience || 'SCHOOL_WIDE',
      targetRoles: payload.targetRoles || [],
      targetUserIds: payload.targetUserIds || [],
      publishDate: payload.publishDate || todayStr,
      publishAt: status === 'published' ? nowIso : undefined,
      publishedAt: status === 'published' ? nowIso : undefined,
      scheduledPublishAt: payload.scheduledPublishAt,
      expiryDate: payload.expiryDate,
      expiresAt: payload.expiresAt,
      priority: payload.priority || 'normal',
      isPinned: payload.isPinned === true,
      status,
      visibility: payload.visibility || 'ALL',
      authorId: actor.id,
      authorUserId: actor.id,
      authorName: actor.name,
      authorRole: actor.role,
      teacherId: actor.role === 'TEACHER' ? actor.id : 'admin-office',
      teacherUserId: actor.id,
      teacherName: actor.name,
      attachments: Array.isArray(payload.attachments) ? payload.attachments : [],
      channels: payload.channels || { inApp: true, email: true, sms: false, push: true },
      readReceipts: [],
      createdAt: nowIso,
      updatedAt: nowIso
    };

    database.classAnnouncements.unshift(newAnnouncement);

    // If published right away, dispatch multi-channel communications
    if (newAnnouncement.status === 'published') {
      await this.dispatchAnnouncementNotifications(newAnnouncement);
    }

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_CREATE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: newAnnouncement.id,
      details: `Created announcement '${newAnnouncement.title}' (Status: ${newAnnouncement.status}, Audience: ${newAnnouncement.targetAudience}).`
    });

    return newAnnouncement;
  }

  /**
   * Updates an existing announcement
   */
  public static async updateAnnouncement(
    id: string,
    updates: Partial<ClassAnnouncement>,
    actor: {
      id: string;
      name: string;
      role: UserRole;
    }
  ): Promise<{ success: boolean; data?: ClassAnnouncement; error?: string }> {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const index = database.classAnnouncements.findIndex((a) => a.id === id);

    if (index === -1) {
      return { success: false, error: 'Announcement not found.' };
    }

    const current = database.classAnnouncements[index];
    const isAdmin = actor.role === 'SUPER_ADMIN' || (actor.role as string) === 'ADMIN';

    if (!isAdmin && current.authorUserId !== actor.id && current.teacherUserId !== actor.id) {
      return { success: false, error: 'Unauthorized: You do not have permission to modify this announcement.' };
    }

    const now = new Date();
    const nowIso = now.toISOString();

    const previousStatus = current.status;
    let newStatus = updates.status !== undefined ? updates.status : current.status;

    if (updates.scheduledPublishAt && new Date(updates.scheduledPublishAt) > now && newStatus !== 'draft') {
      newStatus = 'scheduled';
    }

    // Resolve class & section name if changed
    let className = current.className;
    let sectionName = current.sectionName;

    if (updates.classId && updates.classId !== current.classId) {
      if (updates.classId === 'ALL') {
        className = 'All Classes';
      } else {
        const cls = (database.classes || []).find((c) => c.id === updates.classId);
        if (cls) className = cls.name;
      }
    }

    if (updates.sectionId !== undefined && updates.sectionId !== current.sectionId) {
      if (updates.sectionId === 'ALL') {
        sectionName = 'All Sections';
      } else {
        const sec = (database.sections || []).find((s) => s.id === updates.sectionId);
        if (sec) sectionName = sec.name;
      }
    }

    const updatedAnnouncement: ClassAnnouncement = {
      ...current,
      title: updates.title !== undefined ? updates.title.trim() : current.title,
      message: updates.message !== undefined ? sanitizeAnnouncementContent(updates.message) : current.message,
      content: updates.message !== undefined ? sanitizeAnnouncementContent(updates.message) : current.content,
      category: updates.category !== undefined ? updates.category : current.category,
      priority: updates.priority !== undefined ? updates.priority : current.priority,
      classId: updates.classId !== undefined ? updates.classId : current.classId,
      className,
      sectionId: updates.sectionId !== undefined ? updates.sectionId : current.sectionId,
      sectionName,
      targetAudience: updates.targetAudience !== undefined ? updates.targetAudience : current.targetAudience,
      targetRoles: updates.targetRoles !== undefined ? updates.targetRoles : current.targetRoles,
      publishDate: updates.publishDate !== undefined ? updates.publishDate : current.publishDate,
      scheduledPublishAt: updates.scheduledPublishAt !== undefined ? updates.scheduledPublishAt : current.scheduledPublishAt,
      expiryDate: updates.expiryDate !== undefined ? updates.expiryDate : current.expiryDate,
      expiresAt: updates.expiresAt !== undefined ? updates.expiresAt : current.expiresAt,
      isPinned: updates.isPinned !== undefined ? updates.isPinned : current.isPinned,
      status: newStatus,
      attachments: updates.attachments !== undefined ? updates.attachments : current.attachments,
      channels: updates.channels !== undefined ? updates.channels : current.channels,
      updatedAt: nowIso
    };

    // If transitioned to published, dispatch communications
    if (previousStatus !== 'published' && newStatus === 'published') {
      updatedAnnouncement.publishedAt = nowIso;
      updatedAnnouncement.publishDate = nowIso.split('T')[0];
      await this.dispatchAnnouncementNotifications(updatedAnnouncement);
    }

    database.classAnnouncements[index] = updatedAnnouncement;

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_UPDATE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Updated announcement '${updatedAnnouncement.title}' (Status: ${updatedAnnouncement.status}).`
    });

    return { success: true, data: updatedAnnouncement };
  }

  /**
   * Publishes an announcement immediately
   */
  public static async publishAnnouncement(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): Promise<{ success: boolean; data?: ClassAnnouncement; error?: string }> {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    const nowIso = new Date().toISOString();
    ann.status = 'published';
    ann.publishedAt = nowIso;
    ann.publishDate = nowIso.split('T')[0];
    ann.scheduledPublishAt = undefined;
    ann.updatedAt = nowIso;

    await this.dispatchAnnouncementNotifications(ann);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_PUBLISH',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Published announcement '${ann.title}' to audience: ${ann.targetAudience}.`
    });

    return { success: true, data: ann };
  }

  /**
   * Cancels a scheduled announcement (transitions back to draft)
   */
  public static cancelSchedule(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): { success: boolean; data?: ClassAnnouncement; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    if (ann.status !== 'scheduled') {
      return { success: false, error: 'Only scheduled announcements can be cancelled.' };
    }

    const nowIso = new Date().toISOString();
    ann.status = 'cancelled';
    ann.cancelledAt = nowIso;
    ann.updatedAt = nowIso;

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_SCHEDULE_CANCELLED',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Cancelled schedule for announcement '${ann.title}'.`
    });

    return { success: true, data: ann };
  }

  /**
   * Archives an announcement
   */
  public static archiveAnnouncement(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): { success: boolean; data?: ClassAnnouncement; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    const nowIso = new Date().toISOString();
    ann.status = 'archived';
    ann.archivedAt = nowIso;
    ann.updatedAt = nowIso;

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_ARCHIVE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Archived announcement '${ann.title}'.`
    });

    return { success: true, data: ann };
  }

  /**
   * Unarchives an announcement (restores to published or draft)
   */
  public static unarchiveAnnouncement(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): { success: boolean; data?: ClassAnnouncement; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    const nowIso = new Date().toISOString();
    ann.status = 'published';
    ann.archivedAt = undefined;
    ann.updatedAt = nowIso;

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_UNARCHIVE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Unarchived announcement '${ann.title}'.`
    });

    return { success: true, data: ann };
  }

  /**
   * Toggles pinned status of an announcement
   */
  public static togglePin(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): { success: boolean; isPinned?: boolean; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === id);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    ann.isPinned = !ann.isPinned;
    ann.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_PIN_TOGGLE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `${ann.isPinned ? 'Pinned' : 'Unpinned'} announcement '${ann.title}'.`
    });

    return { success: true, isPinned: ann.isPinned };
  }

  /**
   * Deletes an announcement
   */
  public static deleteAnnouncement(
    id: string,
    actor: { id: string; name: string; role: UserRole }
  ): { success: boolean; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const index = database.classAnnouncements.findIndex((a) => a.id === id);

    if (index === -1) {
      return { success: false, error: 'Announcement not found.' };
    }

    const current = database.classAnnouncements[index];
    const isAdmin = actor.role === 'SUPER_ADMIN' || (actor.role as string) === 'ADMIN';

    if (!isAdmin && current.authorUserId !== actor.id && current.teacherUserId !== actor.id) {
      return { success: false, error: 'Unauthorized: You do not have permission to delete this announcement.' };
    }

    database.classAnnouncements.splice(index, 1);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'ANNOUNCEMENT_DELETE',
      entity: 'ClassAnnouncement',
      entityType: 'ClassAnnouncement',
      entityId: id,
      details: `Deleted announcement '${current.title}'.`
    });

    return { success: true };
  }

  /**
   * Marks announcement as read by a specific user (isolated per-user read receipt)
   */
  public static markAsRead(
    announcementId: string,
    user: { id: string; name: string; role: UserRole | string }
  ): { success: boolean; error?: string } {
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const ann = database.classAnnouncements.find((a) => a.id === announcementId);

    if (!ann) {
      return { success: false, error: 'Announcement not found.' };
    }

    if (!ann.readReceipts) {
      ann.readReceipts = [];
    }

    // Check if user already marked as read
    const existing = ann.readReceipts.find((r) => r.userId === user.id);
    if (!existing) {
      ann.readReceipts.push({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        readAt: new Date().toISOString()
      });
    }

    return { success: true };
  }

  /**
   * Returns system-wide announcement statistics
   */
  public static getAggregatedStats(): {
    total: number;
    published: number;
    scheduled: number;
    drafts: number;
    expired: number;
    archived: number;
    pinned: number;
    totalReads: number;
    byCategory: Record<string, number>;
    byAudience: Record<string, number>;
  } {
    this.evaluateLifecycle();
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const list = database.classAnnouncements;

    const byCategory: Record<string, number> = {};
    const byAudience: Record<string, number> = {};
    let totalReads = 0;
    let pinned = 0;

    for (const a of list) {
      const cat = a.category || 'general';
      byCategory[cat] = (byCategory[cat] || 0) + 1;

      const aud = a.targetAudience || (a.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
      byAudience[aud] = (byAudience[aud] || 0) + 1;

      if (a.isPinned) pinned++;
      if (a.readReceipts) totalReads += a.readReceipts.length;
    }

    return {
      total: list.length,
      published: list.filter((a) => a.status === 'published').length,
      scheduled: list.filter((a) => a.status === 'scheduled').length,
      drafts: list.filter((a) => a.status === 'draft').length,
      expired: list.filter((a) => a.status === 'expired').length,
      archived: list.filter((a) => a.status === 'archived').length,
      pinned,
      totalReads,
      byCategory,
      byAudience
    };
  }
}

// Automatically start scheduler
AnnouncementService.initScheduler();
