/**
 * Sygmate School Management System
 * Staff Recruitment & Onboarding Management (Part 12D)
 * Core Business Logic Service
 */

import { database } from '../db/database.js';
import {
  JobOpening,
  CreateJobOpeningPayload,
  UpdateJobOpeningPayload,
  CandidateProfile,
  CreateCandidatePayload,
  UpdateCandidatePayload,
  JobApplication,
  CreateJobApplicationPayload,
  ScreenApplicationPayload,
  TransitionApplicationStagePayload,
  JobInterview,
  ScheduleInterviewPayload,
  SubmitEvaluationPayload,
  RescheduleInterviewPayload,
  JobOffer,
  CreateJobOfferPayload,
  ReviewOfferPayload,
  CandidateOfferResponsePayload,
  ConvertCandidateToStaffPayload,
  CandidateConversionResult,
  OnboardingRecord,
  OnboardingTemplate,
  OnboardingTask,
  CreateOnboardingTaskPayload,
  UpdateOnboardingTaskPayload,
  RecruitmentDashboardMetrics,
  RecruitmentFilterQuery,
  User,
  AuditLog,
  NotificationItem,
  StaffProfile
} from '../../src/types/index.js';
import { staffService } from './staff.service.js';

export class StaffRecruitmentService {
  // ==========================================
  // HELPER METHODS
  // ==========================================

  private logAudit(
    action: string,
    entityType: string,
    entityId: string,
    actor?: User,
    details?: Record<string, any>
  ): void {
    const auditEntry: AuditLog = {
      id: `audit-rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      userId: actor?.id || 'system',
      userName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'System HR Engine',
      userRole: actor?.role || 'SUPER_ADMIN',
      action,
      entityType,
      entityId,
      details: details ? JSON.stringify(details) : undefined,
      ipAddress: '127.0.0.1'
    };
    database.auditLogs.unshift(auditEntry);
  }

  private sendNotification(
    userId: string,
    title: string,
    message: string,
    category: 'system' | 'general' = 'general',
    link?: string
  ): void {
    const notif: NotificationItem = {
      id: `notif-rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      title,
      message,
      type: 'INFO',
      category,
      isRead: false,
      createdAt: new Date().toISOString(),
      link
    };
    database.notifications.unshift(notif);
  }

  // ==========================================
  // 1. JOB OPENINGS
  // ==========================================

  public listJobOpenings(query?: RecruitmentFilterQuery): {
    items: JobOpening[];
    total: number;
    summary: {
      totalOpenings: number;
      activeOpenings: number;
      totalVacancies: number;
      filledVacancies: number;
    };
  } {
    let items = [...database.jobOpenings];

    // Calculate dynamic application counts
    items = items.map((job) => {
      const appCount = database.jobApplications.filter((a) => a.jobOpeningId === job.id).length;
      return {
        ...job,
        applicationCount: appCount
      };
    });

    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (job) =>
          job.title.toLowerCase().includes(q) ||
          job.code.toLowerCase().includes(q) ||
          job.departmentName.toLowerCase().includes(q) ||
          job.designationTitle.toLowerCase().includes(q) ||
          job.workLocation.toLowerCase().includes(q)
      );
    }

    if (query?.departmentId && query.departmentId !== 'all') {
      items = items.filter((job) => job.departmentId === query.departmentId);
    }

    if (query?.staffType && query.staffType !== 'all') {
      items = items.filter((job) => job.staffType === query.staffType);
    }

    if (query?.status && query.status !== 'all') {
      items = items.filter((job) => job.status === query.status);
    }

    const totalOpenings = database.jobOpenings.length;
    const activeOpenings = database.jobOpenings.filter((j) =>
      ['PUBLISHED', 'APPLICATIONS_OPEN'].includes(j.status)
    ).length;
    const totalVacancies = database.jobOpenings.reduce((sum, j) => sum + (j.vacancies || 0), 0);
    const filledVacancies = database.jobOpenings.reduce((sum, j) => sum + (j.filledVacancies || 0), 0);

    const total = items.length;
    const page = query?.page || 1;
    const limit = query?.limit || 50;
    const startIndex = (page - 1) * limit;
    const paginatedItems = items.slice(startIndex, startIndex + limit);

    return {
      items: paginatedItems,
      total,
      summary: {
        totalOpenings,
        activeOpenings,
        totalVacancies,
        filledVacancies
      }
    };
  }

  public getJobOpeningById(id: string): JobOpening | null {
    const job = database.jobOpenings.find((j) => j.id === id);
    if (!job) return null;
    const appCount = database.jobApplications.filter((a) => a.jobOpeningId === job.id).length;
    return {
      ...job,
      applicationCount: appCount
    };
  }

  public createJobOpening(payload: CreateJobOpeningPayload, actor?: User): JobOpening {
    if (!payload.title?.trim()) {
      throw new Error('Position title is required.');
    }
    if (!payload.departmentId?.trim()) {
      throw new Error('Department is required.');
    }
    if (!payload.vacancies || payload.vacancies < 1) {
      throw new Error('Number of vacancies must be at least 1.');
    }
    if (!payload.staffType?.trim()) {
      throw new Error('Staff classification type is required.');
    }
    if (!payload.employmentType?.trim()) {
      throw new Error('Employment type is required.');
    }
    if (!payload.applicationStartDate?.trim() || !payload.applicationClosingDate?.trim()) {
      throw new Error('Application opening and closing dates are required.');
    }

    const dept = database.departments.find((d) => d.id === payload.departmentId);
    if (!dept) {
      throw new Error(`Department with ID '${payload.departmentId}' was not found.`);
    }

    let designationTitle = payload.designationTitle?.trim() || 'Staff Faculty';
    if (payload.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        designationTitle = des.title;
      }
    }

    const code =
      payload.code?.trim() ||
      `JOB-${new Date().getFullYear()}-${dept.name.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const now = new Date().toISOString();
    const newOpening: JobOpening = {
      id: `job-op-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: payload.title.trim(),
      code,
      departmentId: dept.id,
      departmentName: dept.name,
      designationId: payload.designationId,
      designationTitle,
      staffType: payload.staffType,
      employmentType: payload.employmentType,
      vacancies: Number(payload.vacancies),
      filledVacancies: 0,
      jobDescription: payload.jobDescription?.trim() || '',
      responsibilities: payload.responsibilities || [],
      qualifications: payload.qualifications || [],
      experienceYears: Number(payload.experienceYears || 0),
      requiredSkills: payload.requiredSkills || [],
      salaryRange: payload.salaryRange?.trim(),
      workLocation: payload.workLocation?.trim() || 'Main School Campus',
      applicationStartDate: payload.applicationStartDate,
      applicationClosingDate: payload.applicationClosingDate,
      status: 'APPLICATIONS_OPEN',
      createdBy: actor?.id || 'system',
      createdByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Administrator',
      createdAt: now,
      updatedAt: now,
      notes: payload.notes?.trim(),
      applicationCount: 0
    };

    database.jobOpenings.unshift(newOpening);
    this.logAudit('CREATE_JOB_OPENING', 'JobOpening', newOpening.id, actor, {
      title: newOpening.title,
      code: newOpening.code,
      vacancies: newOpening.vacancies
    });

    return newOpening;
  }

  public updateJobOpening(id: string, payload: UpdateJobOpeningPayload, actor?: User): JobOpening {
    const jobIndex = database.jobOpenings.findIndex((j) => j.id === id);
    if (jobIndex === -1) {
      throw new Error(`Job opening with ID '${id}' not found.`);
    }

    const existing = database.jobOpenings[jobIndex];
    let departmentName = existing.departmentName;
    if (payload.departmentId && payload.departmentId !== existing.departmentId) {
      const dept = database.departments.find((d) => d.id === payload.departmentId);
      if (dept) {
        departmentName = dept.name;
      }
    }

    let designationTitle = existing.designationTitle;
    if (payload.designationId && payload.designationId !== existing.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        designationTitle = des.title;
      }
    } else if (payload.designationTitle) {
      designationTitle = payload.designationTitle;
    }

    const updated: JobOpening = {
      ...existing,
      ...payload,
      departmentName,
      designationTitle,
      updatedAt: new Date().toISOString()
    };

    database.jobOpenings[jobIndex] = updated;
    this.logAudit('UPDATE_JOB_OPENING', 'JobOpening', id, actor, {
      title: updated.title,
      status: updated.status
    });

    return updated;
  }

  public deleteJobOpening(id: string, actor?: User): boolean {
    const jobIndex = database.jobOpenings.findIndex((j) => j.id === id);
    if (jobIndex === -1) {
      throw new Error(`Job opening with ID '${id}' not found.`);
    }

    const applications = database.jobApplications.filter((a) => a.jobOpeningId === id);
    if (applications.length > 0) {
      // Instead of hard delete when applications exist, archive it
      database.jobOpenings[jobIndex].status = 'ARCHIVED';
      database.jobOpenings[jobIndex].updatedAt = new Date().toISOString();
      this.logAudit('ARCHIVE_JOB_OPENING', 'JobOpening', id, actor, {
        reason: 'Archived due to existing associated candidate applications'
      });
      return true;
    }

    database.jobOpenings.splice(jobIndex, 1);
    this.logAudit('DELETE_JOB_OPENING', 'JobOpening', id, actor);
    return true;
  }

  // ==========================================
  // 2. CANDIDATES & APPLICANTS
  // ==========================================

  public listCandidates(query?: RecruitmentFilterQuery): {
    items: CandidateProfile[];
    total: number;
  } {
    let items = [...database.candidates];

    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (cand) =>
          cand.fullName.toLowerCase().includes(q) ||
          cand.email.toLowerCase().includes(q) ||
          cand.phone.toLowerCase().includes(q) ||
          cand.candidateNumber.toLowerCase().includes(q) ||
          cand.highestQualification.toLowerCase().includes(q) ||
          cand.appliedPositionTitle?.toLowerCase().includes(q) ||
          cand.skills.some((s) => s.toLowerCase().includes(q))
      );
    }

    if (query?.status && query.status !== 'all') {
      items = items.filter((cand) => cand.currentStage === query.status || cand.status === query.status);
    }

    if (query?.departmentId && query.departmentId !== 'all') {
      items = items.filter((cand) => cand.appliedDepartmentId === query.departmentId);
    }

    const total = items.length;
    const page = query?.page || 1;
    const limit = query?.limit || 50;
    const startIndex = (page - 1) * limit;
    const paginatedItems = items.slice(startIndex, startIndex + limit);

    return {
      items: paginatedItems,
      total
    };
  }

  public getCandidateById(id: string): (CandidateProfile & {
    applications: JobApplication[];
    interviews: JobInterview[];
    offers: JobOffer[];
    staffProfile?: StaffProfile;
  }) | null {
    const cand = database.candidates.find((c) => c.id === id || c.candidateNumber === id);
    if (!cand) return null;

    const applications = database.jobApplications.filter((a) => a.candidateId === cand.id);
    const interviews = database.interviews.filter((i) => i.candidateId === cand.id);
    const offers = database.jobOffers.filter((o) => o.candidateId === cand.id);
    const staffProfile = cand.staffProfileId
      ? database.staffProfiles.find((s) => s.id === cand.staffProfileId)
      : undefined;

    return {
      ...cand,
      applications,
      interviews,
      offers,
      staffProfile
    };
  }

  public createCandidate(payload: CreateCandidatePayload, actor?: User): CandidateProfile {
    if (!payload.firstName?.trim() || !payload.lastName?.trim()) {
      throw new Error('First name and last name are required.');
    }
    if (!payload.email?.trim()) {
      throw new Error('Email address is required.');
    }
    if (!payload.phone?.trim()) {
      throw new Error('Phone number is required.');
    }
    if (!payload.highestQualification?.trim()) {
      throw new Error('Highest academic qualification is required.');
    }

    const emailTrimmed = payload.email.trim().toLowerCase();

    // Check duplicate among active candidates
    const duplicate = database.candidates.find(
      (c) => c.email.toLowerCase() === emailTrimmed && c.status === 'ACTIVE'
    );
    if (duplicate) {
      throw new Error(
        `An active candidate record with email '${emailTrimmed}' already exists (${duplicate.candidateNumber} - ${duplicate.fullName}).`
      );
    }

    const fullName = `${payload.firstName.trim()} ${payload.lastName.trim()}`;
    const candidateNumber = `CND-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    let appliedPositionTitle: string | undefined = undefined;
    let appliedDepartmentId: string | undefined = undefined;
    let appliedDepartmentName: string | undefined = undefined;

    if (payload.applyForJobOpeningId) {
      const opening = database.jobOpenings.find((j) => j.id === payload.applyForJobOpeningId);
      if (opening) {
        appliedPositionTitle = opening.title;
        appliedDepartmentId = opening.departmentId;
        appliedDepartmentName = opening.departmentName;
      }
    }

    const newCandidate: CandidateProfile = {
      id: `cand-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      candidateNumber,
      fullName,
      firstName: payload.firstName.trim(),
      lastName: payload.lastName.trim(),
      email: emailTrimmed,
      phone: payload.phone.trim(),
      photoUrl: payload.photoUrl,
      address: payload.address?.trim(),
      city: payload.city?.trim(),
      state: payload.state?.trim(),
      country: payload.country?.trim() || 'United States',
      dateOfBirth: payload.dateOfBirth,
      gender: payload.gender,
      emergencyContactName: payload.emergencyContactName?.trim(),
      emergencyContactPhone: payload.emergencyContactPhone?.trim(),
      currentOccupation: payload.currentOccupation?.trim(),
      highestQualification: payload.highestQualification.trim(),
      institution: payload.institution?.trim(),
      yearsOfExperience: Number(payload.yearsOfExperience || 0),
      previousEmployment: payload.previousEmployment?.trim(),
      skills: payload.skills || [],
      certifications: payload.certifications || [],
      specialization: payload.specialization?.trim(),
      references: payload.references || [],
      appliedPositionTitle,
      appliedDepartmentId,
      appliedDepartmentName,
      source: payload.source || 'DIRECT_APPLICATION',
      currentStage: 'APPLIED',
      status: 'ACTIVE',
      assignedRecruiterId: actor?.id,
      assignedRecruiterName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : undefined,
      notes: payload.notes?.trim(),
      createdAt: now,
      updatedAt: now
    };

    database.candidates.unshift(newCandidate);
    this.logAudit('CREATE_CANDIDATE', 'CandidateProfile', newCandidate.id, actor, {
      candidateNumber: newCandidate.candidateNumber,
      fullName: newCandidate.fullName,
      email: newCandidate.email
    });

    // Auto-create application if applyForJobOpeningId is supplied
    if (payload.applyForJobOpeningId) {
      this.createApplication(
        {
          candidateId: newCandidate.id,
          jobOpeningId: payload.applyForJobOpeningId,
          coverLetter: payload.coverLetter,
          resumeUrl: payload.resumeUrl,
          source: payload.source
        },
        actor
      );
    }

    return newCandidate;
  }

  public updateCandidate(id: string, payload: UpdateCandidatePayload, actor?: User): CandidateProfile {
    const candIndex = database.candidates.findIndex((c) => c.id === id);
    if (candIndex === -1) {
      throw new Error(`Candidate with ID '${id}' was not found.`);
    }

    const existing = database.candidates[candIndex];
    let fullName = existing.fullName;
    if (payload.firstName || payload.lastName) {
      const fName = payload.firstName?.trim() || existing.firstName;
      const lName = payload.lastName?.trim() || existing.lastName;
      fullName = `${fName} ${lName}`;
    }

    const updated: CandidateProfile = {
      ...existing,
      ...payload,
      fullName,
      updatedAt: new Date().toISOString()
    };

    database.candidates[candIndex] = updated;
    this.logAudit('UPDATE_CANDIDATE', 'CandidateProfile', id, actor, {
      fullName: updated.fullName,
      currentStage: updated.currentStage
    });

    return updated;
  }

  // ==========================================
  // 3. JOB APPLICATIONS
  // ==========================================

  public listApplications(query?: RecruitmentFilterQuery & {
    candidateId?: string;
    jobOpeningId?: string;
    stage?: string;
  }): {
    items: JobApplication[];
    total: number;
  } {
    let items = [...database.jobApplications];

    if (query?.candidateId) {
      items = items.filter((a) => a.candidateId === query.candidateId);
    }

    if (query?.jobOpeningId) {
      items = items.filter((a) => a.jobOpeningId === query.jobOpeningId);
    }

    if (query?.departmentId && query.departmentId !== 'all') {
      items = items.filter((a) => a.departmentId === query.departmentId);
    }

    if (query?.stage && query.stage !== 'all') {
      items = items.filter((a) => a.stage === query.stage);
    }

    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (a) =>
          a.applicationNumber.toLowerCase().includes(q) ||
          a.candidateName.toLowerCase().includes(q) ||
          a.candidateEmail.toLowerCase().includes(q) ||
          a.jobTitle.toLowerCase().includes(q) ||
          a.departmentName.toLowerCase().includes(q)
      );
    }

    const total = items.length;
    const page = query?.page || 1;
    const limit = query?.limit || 50;
    const startIndex = (page - 1) * limit;
    const paginatedItems = items.slice(startIndex, startIndex + limit);

    return {
      items: paginatedItems,
      total
    };
  }

  public getApplicationById(id: string): (JobApplication & {
    interviews: JobInterview[];
    offers: JobOffer[];
    candidate?: CandidateProfile;
    jobOpening?: JobOpening;
  }) | null {
    const app = database.jobApplications.find((a) => a.id === id || a.applicationNumber === id);
    if (!app) return null;

    const interviews = database.interviews.filter((i) => i.applicationId === app.id);
    const offers = database.jobOffers.filter((o) => o.applicationId === app.id);
    const candidate = database.candidates.find((c) => c.id === app.candidateId);
    const jobOpening = database.jobOpenings.find((j) => j.id === app.jobOpeningId);

    return {
      ...app,
      interviews,
      offers,
      candidate,
      jobOpening
    };
  }

  public createApplication(payload: CreateJobApplicationPayload, actor?: User): JobApplication {
    const candidate = database.candidates.find((c) => c.id === payload.candidateId);
    if (!candidate) {
      throw new Error(`Candidate with ID '${payload.candidateId}' not found.`);
    }

    const job = database.jobOpenings.find((j) => j.id === payload.jobOpeningId);
    if (!job) {
      throw new Error(`Job opening with ID '${payload.jobOpeningId}' not found.`);
    }

    // CONCURRENCY / DUPLICATE RULE: Prevent candidate from applying multiple times to same job opening
    const existingActiveApp = database.jobApplications.find(
      (a) =>
        a.candidateId === candidate.id &&
        a.jobOpeningId === job.id &&
        !['REJECTED', 'WITHDRAWN', 'CANCELLED'].includes(a.stage)
    );
    if (existingActiveApp) {
      throw new Error(
        `Candidate ${candidate.fullName} already has an active application (${existingActiveApp.applicationNumber}) for position '${job.title}'.`
      );
    }

    const now = new Date().toISOString();
    const today = now.split('T')[0];
    const applicationNumber = `APP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const actorName = actor
      ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim()
      : candidate.fullName;

    const newApp: JobApplication = {
      id: `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      applicationNumber,
      candidateId: candidate.id,
      candidateName: candidate.fullName,
      candidateEmail: candidate.email,
      candidatePhone: candidate.phone,
      candidateQualification: candidate.highestQualification,
      candidateExperienceYears: candidate.yearsOfExperience,
      jobOpeningId: job.id,
      jobTitle: job.title,
      departmentId: job.departmentId,
      departmentName: job.departmentName,
      applicationDate: today,
      stage: 'APPLIED',
      status: 'SUBMITTED',
      resumeUrl: payload.resumeUrl,
      resumeFileName: payload.resumeFileName || 'Resume.pdf',
      coverLetter: payload.coverLetter?.trim(),
      supportingDocuments: payload.supportingDocuments || [],
      source: payload.source || candidate.source,
      stageHistory: [
        {
          stage: 'APPLIED',
          changedBy: actor?.id || candidate.id,
          changedByName: actorName,
          timestamp: now,
          notes: 'Application created and submitted.'
        }
      ],
      internalNotes: payload.internalNotes?.trim(),
      createdAt: now,
      updatedAt: now
    };

    database.jobApplications.unshift(newApp);

    // Update candidate's applied position info if not already set
    candidate.appliedPositionTitle = job.title;
    candidate.appliedDepartmentId = job.departmentId;
    candidate.appliedDepartmentName = job.departmentName;
    candidate.updatedAt = now;

    this.logAudit('CREATE_APPLICATION', 'JobApplication', newApp.id, actor, {
      applicationNumber: newApp.applicationNumber,
      candidateName: newApp.candidateName,
      jobTitle: newApp.jobTitle
    });

    return newApp;
  }

  public screenApplication(id: string, payload: ScreenApplicationPayload, actor?: User): JobApplication {
    const appIndex = database.jobApplications.findIndex((a) => a.id === id);
    if (appIndex === -1) {
      throw new Error(`Job application with ID '${id}' not found.`);
    }

    const app = database.jobApplications[appIndex];
    const now = new Date().toISOString();
    const actorName = actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Reviewer';

    let nextStage = app.stage;
    let nextStatus = app.status;

    if (payload.decision === 'SHORTLISTED') {
      nextStage = 'SHORTLISTED';
      nextStatus = 'SHORTLISTED';
    } else if (payload.decision === 'REJECTED') {
      nextStage = 'REJECTED';
      nextStatus = 'REJECTED';
    } else if (payload.decision === 'HOLD') {
      nextStage = 'ON_HOLD';
      nextStatus = 'UNDER_REVIEW';
    }

    const updated: JobApplication = {
      ...app,
      stage: nextStage,
      status: nextStatus,
      screeningNotes: payload.notes.trim(),
      screeningDecision: payload.decision,
      screenedBy: actor?.id || 'system',
      screenedByName: actorName,
      screenedAt: now,
      rejectionReason: payload.decision === 'REJECTED' ? payload.rejectionReason || payload.notes : undefined,
      stageHistory: [
        ...app.stageHistory,
        {
          stage: nextStage,
          changedBy: actor?.id || 'system',
          changedByName: actorName,
          timestamp: now,
          notes: `Screening outcome: ${payload.decision}. ${payload.notes}`
        }
      ],
      updatedAt: now
    };

    database.jobApplications[appIndex] = updated;

    // Synchronize candidate currentStage
    const cand = database.candidates.find((c) => c.id === app.candidateId);
    if (cand) {
      cand.currentStage = nextStage;
      cand.updatedAt = now;
    }

    this.logAudit('SCREEN_APPLICATION', 'JobApplication', id, actor, {
      decision: payload.decision,
      notes: payload.notes
    });

    return updated;
  }

  public transitionApplicationStage(
    id: string,
    payload: TransitionApplicationStagePayload,
    actor?: User
  ): JobApplication {
    const appIndex = database.jobApplications.findIndex((a) => a.id === id);
    if (appIndex === -1) {
      throw new Error(`Job application with ID '${id}' not found.`);
    }

    const app = database.jobApplications[appIndex];
    const now = new Date().toISOString();
    const actorName = actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Recruiter';

    let status = app.status;
    switch (payload.newStage) {
      case 'APPLIED':
        status = 'SUBMITTED';
        break;
      case 'SCREENING':
        status = 'UNDER_REVIEW';
        break;
      case 'SHORTLISTED':
        status = 'SHORTLISTED';
        break;
      case 'INTERVIEW':
        status = 'INTERVIEWING';
        break;
      case 'SELECTED':
        status = 'SELECTED';
        break;
      case 'OFFER':
        status = 'OFFERED';
        break;
      case 'ACCEPTED':
        status = 'ACCEPTED';
        break;
      case 'ONBOARDING':
        status = 'ONBOARDING';
        break;
      case 'HIRED':
        status = 'HIRED';
        break;
      case 'REJECTED':
        status = 'REJECTED';
        break;
      case 'WITHDRAWN':
        status = 'WITHDRAWN';
        break;
      case 'CANCELLED':
        status = 'CANCELLED';
        break;
    }

    const updated: JobApplication = {
      ...app,
      stage: payload.newStage,
      status,
      rejectionReason: payload.newStage === 'REJECTED' ? payload.rejectionReason || payload.notes : app.rejectionReason,
      stageHistory: [
        ...app.stageHistory,
        {
          stage: payload.newStage,
          changedBy: actor?.id || 'system',
          changedByName: actorName,
          timestamp: now,
          notes: payload.notes || `Moved to ${payload.newStage} stage`
        }
      ],
      updatedAt: now
    };

    database.jobApplications[appIndex] = updated;

    // Update candidate current stage
    const cand = database.candidates.find((c) => c.id === app.candidateId);
    if (cand) {
      cand.currentStage = payload.newStage;
      cand.updatedAt = now;
    }

    this.logAudit('TRANSITION_APPLICATION_STAGE', 'JobApplication', id, actor, {
      fromStage: app.stage,
      toStage: payload.newStage,
      notes: payload.notes
    });

    return updated;
  }

  // ==========================================
  // 4. INTERVIEWS & EVALUATIONS
  // ==========================================

  public listInterviews(query?: {
    applicationId?: string;
    candidateId?: string;
    jobOpeningId?: string;
    status?: string;
    date?: string;
  }): JobInterview[] {
    let items = [...database.interviews];

    if (query?.applicationId) {
      items = items.filter((i) => i.applicationId === query.applicationId);
    }
    if (query?.candidateId) {
      items = items.filter((i) => i.candidateId === query.candidateId);
    }
    if (query?.jobOpeningId) {
      items = items.filter((i) => i.jobOpeningId === query.jobOpeningId);
    }
    if (query?.status && query.status !== 'all') {
      items = items.filter((i) => i.status === query.status);
    }
    if (query?.date) {
      items = items.filter((i) => i.interviewDate === query.date);
    }

    // Sort by interviewDate and startTime ascending
    items.sort((a, b) => `${a.interviewDate} ${a.startTime}`.localeCompare(`${b.interviewDate} ${b.startTime}`));

    return items;
  }

  public getInterviewById(id: string): JobInterview | null {
    return database.interviews.find((i) => i.id === id || i.interviewNumber === id) || null;
  }

  public scheduleInterview(payload: ScheduleInterviewPayload, actor?: User): JobInterview {
    const app = database.jobApplications.find((a) => a.id === payload.applicationId);
    if (!app) {
      throw new Error(`Job application with ID '${payload.applicationId}' not found.`);
    }

    if (!payload.interviewDate || !payload.startTime || !payload.endTime) {
      throw new Error('Interview date, start time, and end time are required.');
    }

    if (!payload.panelUserIds || payload.panelUserIds.length === 0) {
      throw new Error('At least one panel member must be assigned.');
    }

    // Resolve panel members
    const panelMembers = payload.panelUserIds
      .map((userId) => {
        const u = database.users.find((user) => user.id === userId);
        if (!u) return null;
        const staff = database.staffProfiles.find((s) => s.userId === u.id);
        return {
          userId: u.id,
          staffId: staff?.id,
          name: `${u.firstName || ''} ${u.lastName || u.name || ''}`.trim(),
          role: u.role,
          email: u.email
        };
      })
      .filter((m): m is NonNullable<typeof m> => m !== null);

    if (panelMembers.length === 0) {
      throw new Error('Valid panel members must be selected from registered staff users.');
    }

    // CONFLICT DETECTION: Check if candidate or panel members already have an overlapping scheduled interview
    const requestedDate = payload.interviewDate;
    const requestedStart = payload.startTime;
    const requestedEnd = payload.endTime;

    const existingInterviewsOnDate = database.interviews.filter(
      (i) => i.interviewDate === requestedDate && ['SCHEDULED', 'CONFIRMED'].includes(i.status)
    );

    for (const existing of existingInterviewsOnDate) {
      // Overlap condition: start < existing.endTime && end > existing.startTime
      const isOverlap = requestedStart < existing.endTime && requestedEnd > existing.startTime;
      if (isOverlap) {
        if (existing.candidateId === app.candidateId) {
          throw new Error(
            `Scheduling conflict: Candidate ${app.candidateName} is already scheduled for an interview (${existing.roundName}) from ${existing.startTime} to ${existing.endTime} on ${requestedDate}.`
          );
        }

        for (const member of panelMembers) {
          if (existing.panelMembers.some((pm) => pm.userId === member.userId)) {
            throw new Error(
              `Scheduling conflict: Panel member ${member.name} is already scheduled for an interview (${existing.interviewNumber}) from ${existing.startTime} to ${existing.endTime} on ${requestedDate}.`
            );
          }
        }
      }
    }

    const now = new Date().toISOString();
    const interviewNumber = `INT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newInterview: JobInterview = {
      id: `intv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      interviewNumber,
      applicationId: app.id,
      candidateId: app.candidateId,
      candidateName: app.candidateName,
      candidateEmail: app.candidateEmail,
      jobOpeningId: app.jobOpeningId,
      jobTitle: app.jobTitle,
      interviewRound: payload.interviewRound || 1,
      roundName: payload.roundName?.trim() || `Round ${payload.interviewRound || 1}`,
      interviewType: payload.interviewType,
      interviewDate: payload.interviewDate,
      startTime: payload.startTime,
      endTime: payload.endTime,
      location: payload.location?.trim() || 'School Conference Room',
      meetingLink: payload.meetingLink?.trim(),
      panelMembers,
      status: 'SCHEDULED',
      evaluations: [],
      notes: payload.notes?.trim(),
      createdAt: now,
      updatedAt: now
    };

    database.interviews.unshift(newInterview);

    // Update application stage if needed
    if (!['INTERVIEW', 'SELECTED', 'OFFER', 'ACCEPTED', 'HIRED'].includes(app.stage)) {
      this.transitionApplicationStage(
        app.id,
        {
          newStage: 'INTERVIEW',
          notes: `Scheduled ${newInterview.roundName} on ${payload.interviewDate} at ${payload.startTime}`
        },
        actor
      );
    }

    // Send notifications to panel members
    for (const member of panelMembers) {
      this.sendNotification(
        member.userId,
        `New Interview Scheduled: ${app.candidateName}`,
        `You are assigned to the interview panel for ${app.candidateName} (${app.jobTitle}) on ${payload.interviewDate} from ${payload.startTime} to ${payload.endTime}.`,
        'general'
      );
    }

    this.logAudit('SCHEDULE_INTERVIEW', 'JobInterview', newInterview.id, actor, {
      interviewNumber: newInterview.interviewNumber,
      candidateName: newInterview.candidateName,
      date: newInterview.interviewDate,
      time: `${newInterview.startTime} - ${newInterview.endTime}`
    });

    return newInterview;
  }

  public submitInterviewEvaluation(
    interviewId: string,
    payload: SubmitEvaluationPayload,
    actor?: User
  ): JobInterview {
    const intvIndex = database.interviews.findIndex((i) => i.id === interviewId);
    if (intvIndex === -1) {
      throw new Error(`Interview with ID '${interviewId}' not found.`);
    }

    const interview = database.interviews[intvIndex];

    // Institutional Conflict-of-Interest Guard: Candidate cannot evaluate their own interview
    const candidate = database.candidates.find((c) => c.id === interview.candidateId);
    if (candidate && actor?.email && candidate.email) {
      if (candidate.email.toLowerCase() === actor.email.toLowerCase()) {
        throw new Error('Institutional Policy Violation: Candidates are strictly prohibited from evaluating their own interviews.');
      }
    }

    const interviewerId = actor?.id || 'usr-admin-1';
    const interviewerName = actor
      ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim()
      : 'Evaluator';
    const interviewerRole = actor?.role || 'Interviewer';

    // Validate scores between 1 and 5
    const scores = [
      payload.technicalSkillsScore,
      payload.communicationScore,
      payload.subjectKnowledgeScore,
      payload.experienceScore,
      payload.problemSolvingScore,
      payload.professionalismScore
    ];

    if (payload.teachingDemonstrationScore !== undefined) {
      scores.push(payload.teachingDemonstrationScore);
    }

    for (const score of scores) {
      if (typeof score !== 'number' || score < 1 || score > 5) {
        throw new Error('All evaluation metric scores must be between 1 and 5.');
      }
    }

    const sum = scores.reduce((a, b) => a + b, 0);
    const overallScore = Math.round((sum / scores.length) * 10) / 10;

    const newEvaluation = {
      id: `eval-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      interviewerId,
      interviewerName,
      interviewerRole,
      submittedAt: new Date().toISOString(),
      technicalSkillsScore: payload.technicalSkillsScore,
      communicationScore: payload.communicationScore,
      subjectKnowledgeScore: payload.subjectKnowledgeScore,
      teachingDemonstrationScore: payload.teachingDemonstrationScore,
      experienceScore: payload.experienceScore,
      problemSolvingScore: payload.problemSolvingScore,
      professionalismScore: payload.professionalismScore,
      overallScore,
      recommendation: payload.recommendation,
      strengthsNotes: payload.strengthsNotes?.trim() || '',
      weaknessesNotes: payload.weaknessesNotes?.trim() || '',
      generalComments: payload.generalComments?.trim() || ''
    };

    // Upsert evaluation for this interviewer
    const existingEvalIndex = interview.evaluations.findIndex((e) => e.interviewerId === interviewerId);
    if (existingEvalIndex >= 0) {
      interview.evaluations[existingEvalIndex] = newEvaluation;
    } else {
      interview.evaluations.push(newEvaluation);
    }

    // Recompute interview-level averages
    const allScores = interview.evaluations.map((e) => e.overallScore);
    const avgScore = Math.round((allScores.reduce((a, b) => a + b, 0) / allScores.length) * 10) / 10;

    // Derive overall recommendation: if all STRONG_HIRE -> STRONG_HIRE; if any DO_NOT_HIRE -> DO_NOT_HIRE; else HIRE
    let overallRec = interview.evaluations[0]?.recommendation;
    if (interview.evaluations.some((e) => e.recommendation === 'DO_NOT_HIRE')) {
      overallRec = 'DO_NOT_HIRE';
    } else if (interview.evaluations.every((e) => e.recommendation === 'STRONG_HIRE')) {
      overallRec = 'STRONG_HIRE';
    } else if (interview.evaluations.some((e) => e.recommendation === 'HIRE')) {
      overallRec = 'HIRE';
    }

    interview.averageScore = avgScore;
    interview.overallRecommendation = overallRec;
    interview.status = 'COMPLETED';
    interview.updatedAt = new Date().toISOString();

    database.interviews[intvIndex] = interview;

    this.logAudit('SUBMIT_EVALUATION', 'JobInterview', interviewId, actor, {
      interviewerName,
      overallScore,
      recommendation: payload.recommendation
    });

    return interview;
  }

  public rescheduleInterview(
    interviewId: string,
    payload: RescheduleInterviewPayload,
    actor?: User
  ): JobInterview {
    const intvIndex = database.interviews.findIndex((i) => i.id === interviewId);
    if (intvIndex === -1) {
      throw new Error(`Interview with ID '${interviewId}' not found.`);
    }

    const interview = database.interviews[intvIndex];

    const rescheduledFrom = {
      date: interview.interviewDate,
      startTime: interview.startTime,
      endTime: interview.endTime
    };

    interview.rescheduledFrom = rescheduledFrom;
    interview.interviewDate = payload.newDate;
    interview.startTime = payload.newStartTime;
    interview.endTime = payload.newEndTime;
    interview.status = 'RESCHEDULED';
    interview.statusReason = payload.reason;
    if (payload.location) interview.location = payload.location;
    if (payload.meetingLink) interview.meetingLink = payload.meetingLink;
    interview.updatedAt = new Date().toISOString();

    database.interviews[intvIndex] = interview;

    for (const member of interview.panelMembers) {
      this.sendNotification(
        member.userId,
        `Interview Rescheduled: ${interview.candidateName}`,
        `The interview for ${interview.candidateName} has been rescheduled to ${payload.newDate} (${payload.newStartTime} - ${payload.newEndTime}). Reason: ${payload.reason}`,
        'general'
      );
    }

    this.logAudit('RESCHEDULE_INTERVIEW', 'JobInterview', interviewId, actor, {
      from: rescheduledFrom,
      to: { date: payload.newDate, start: payload.newStartTime, end: payload.newEndTime },
      reason: payload.reason
    });

    return interview;
  }

  // ==========================================
  // 5. SELECTION MANAGEMENT
  // ==========================================

  public selectCandidate(applicationId: string, actor?: User): JobApplication {
    const app = database.jobApplications.find((a) => a.id === applicationId);
    if (!app) {
      throw new Error(`Job application with ID '${applicationId}' not found.`);
    }

    if (['REJECTED', 'WITHDRAWN', 'CANCELLED'].includes(app.stage)) {
      throw new Error(`Cannot select candidate whose application is currently ${app.stage}.`);
    }

    const job = database.jobOpenings.find((j) => j.id === app.jobOpeningId);
    if (!job) {
      throw new Error(`Associated job opening '${app.jobOpeningId}' not found.`);
    }

    // VACANCY VALIDATION: Ensure there is at least one remaining vacancy
    if (job.filledVacancies >= job.vacancies) {
      throw new Error(
        `All ${job.vacancies} vacancies for position '${job.title}' have already been filled.`
      );
    }

    return this.transitionApplicationStage(
      app.id,
      {
        newStage: 'SELECTED',
        notes: `Candidate marked as Selected for appointment to ${job.title}.`
      },
      actor
    );
  }

  // ==========================================
  // 6. OFFER MANAGEMENT & APPROVAL WORKFLOW
  // ==========================================

  public listOffers(query?: {
    applicationId?: string;
    candidateId?: string;
    jobOpeningId?: string;
    status?: string;
  }): JobOffer[] {
    let items = [...database.jobOffers];

    if (query?.applicationId) {
      items = items.filter((o) => o.applicationId === query.applicationId);
    }
    if (query?.candidateId) {
      items = items.filter((o) => o.candidateId === query.candidateId);
    }
    if (query?.jobOpeningId) {
      items = items.filter((o) => o.jobOpeningId === query.jobOpeningId);
    }
    if (query?.status && query.status !== 'all') {
      items = items.filter((o) => o.status === query.status);
    }

    return items;
  }

  public getOfferById(id: string): JobOffer | null {
    return database.jobOffers.find((o) => o.id === id || o.offerNumber === id) || null;
  }

  public createOffer(payload: CreateJobOfferPayload, actor?: User): JobOffer {
    const app = database.jobApplications.find((a) => a.id === payload.applicationId);
    if (!app) {
      throw new Error(`Job application with ID '${payload.applicationId}' not found.`);
    }

    const job = database.jobOpenings.find((j) => j.id === app.jobOpeningId);
    if (!job) {
      throw new Error(`Associated job opening not found.`);
    }

    if (!payload.proposedJoiningDate?.trim()) {
      throw new Error('Proposed joining date is required.');
    }
    if (!payload.offeredSalary?.trim()) {
      throw new Error('Compensation and salary terms are required.');
    }
    if (!payload.offerExpiryDate?.trim()) {
      throw new Error('Offer acceptance expiry date is required.');
    }

    let designationTitle = payload.designationTitle?.trim() || job.designationTitle || 'Staff Member';
    if (payload.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        designationTitle = des.title;
      }
    }

    const offerNumber = `OFF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString();

    const letterContent = `OFFICIAL LETTER OF APPOINTMENT OFFER
Sygmate Preparatory Academy
Ref: ${offerNumber}
Date: ${now.split('T')[0]}

Dear ${app.candidateName},

We are delighted to extend to you this formal offer of appointment at Sygmate Preparatory Academy.

Position: ${job.title}
Designation: ${designationTitle}
Department: ${job.departmentName}
Staff Classification: ${job.staffType.toUpperCase()}
Employment Type: ${job.employmentType.toUpperCase()}

Compensation & Benefits: ${payload.offeredSalary}
Proposed Joining Date: ${payload.proposedJoiningDate}
Probationary Period: ${payload.probationPeriodMonths || 3} months
Offer Valid Until: ${payload.offerExpiryDate}

Terms & Conditions:
${payload.termsAndConditions}

Please indicate your acceptance by countersigning or confirming in the school portal by the expiry date.`;

    const newOffer: JobOffer = {
      id: `off-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      offerNumber,
      applicationId: app.id,
      candidateId: app.candidateId,
      candidateName: app.candidateName,
      candidateEmail: app.candidateEmail,
      jobOpeningId: job.id,
      positionTitle: job.title,
      departmentId: job.departmentId,
      departmentName: job.departmentName,
      designationId: payload.designationId || job.designationId,
      designationTitle,
      staffType: job.staffType,
      employmentType: job.employmentType,
      proposedJoiningDate: payload.proposedJoiningDate,
      offeredSalary: payload.offeredSalary,
      offerExpiryDate: payload.offerExpiryDate,
      probationPeriodMonths: payload.probationPeriodMonths || 3,
      termsAndConditions: payload.termsAndConditions,
      workScheduleId: payload.workScheduleId,
      supervisorName: payload.supervisorName,
      status: 'PENDING_APPROVAL',
      approvals: [],
      generatedLetterContent: letterContent,
      createdAt: now,
      updatedAt: now
    };

    database.jobOffers.unshift(newOffer);

    // Update application stage to OFFER
    this.transitionApplicationStage(
      app.id,
      {
        newStage: 'OFFER',
        notes: `Formal job offer ${newOffer.offerNumber} drafted and pending administrative approval.`
      },
      actor
    );

    this.logAudit('CREATE_OFFER', 'JobOffer', newOffer.id, actor, {
      offerNumber: newOffer.offerNumber,
      candidateName: newOffer.candidateName,
      position: newOffer.positionTitle
    });

    return newOffer;
  }

  public reviewOffer(offerId: string, payload: ReviewOfferPayload, actor?: User): JobOffer {
    const offerIndex = database.jobOffers.findIndex((o) => o.id === offerId);
    if (offerIndex === -1) {
      throw new Error(`Job offer with ID '${offerId}' not found.`);
    }

    const offer = database.jobOffers[offerIndex];

    // Institutional Conflict-of-Interest Guard: Candidate cannot approve their own offer
    const candidate = database.candidates.find((c) => c.id === offer.candidateId);
    if (candidate && actor?.email && candidate.email) {
      if (candidate.email.toLowerCase() === actor.email.toLowerCase()) {
        throw new Error('Institutional Policy Violation: Candidates are strictly prohibited from approving their own job offers.');
      }
    }

    const now = new Date().toISOString();
    const actorName = actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Super Admin';

    const approvalEntry = {
      approverId: actor?.id || 'usr-admin-1',
      approverName: actorName,
      approverRole: actor?.role || 'SUPER_ADMIN',
      decision: payload.decision,
      remarks: payload.remarks?.trim(),
      decisionDate: now
    };

    offer.approvals.push(approvalEntry);

    if (payload.decision === 'APPROVED') {
      offer.status = 'APPROVED';
      offer.approvedBy = actor?.id;
      offer.approvedByName = actorName;
      offer.approvedAt = now;
    } else {
      offer.status = 'REJECTED';
      offer.rejectionReason = payload.remarks;
      offer.rejectedAt = now;
    }

    offer.updatedAt = now;
    database.jobOffers[offerIndex] = offer;

    this.logAudit('REVIEW_OFFER', 'JobOffer', offerId, actor, {
      decision: payload.decision,
      remarks: payload.remarks
    });

    return offer;
  }

  public sendOffer(offerId: string, actor?: User): JobOffer {
    const offerIndex = database.jobOffers.findIndex((o) => o.id === offerId);
    if (offerIndex === -1) {
      throw new Error(`Job offer with ID '${offerId}' not found.`);
    }

    const offer = database.jobOffers[offerIndex];
    if (offer.status !== 'APPROVED') {
      throw new Error(`Only approved job offers can be formally dispatched (current status: ${offer.status}).`);
    }

    const now = new Date().toISOString();
    offer.status = 'SENT';
    offer.sentAt = now;
    offer.sentBy = actor?.id;
    offer.updatedAt = now;

    database.jobOffers[offerIndex] = offer;

    this.logAudit('SEND_OFFER', 'JobOffer', offerId, actor, {
      candidateEmail: offer.candidateEmail
    });

    return offer;
  }

  public recordCandidateOfferResponse(
    offerId: string,
    payload: CandidateOfferResponsePayload,
    actor?: User
  ): JobOffer {
    const offerIndex = database.jobOffers.findIndex((o) => o.id === offerId);
    if (offerIndex === -1) {
      throw new Error(`Job offer with ID '${offerId}' not found.`);
    }

    const offer = database.jobOffers[offerIndex];
    const now = new Date().toISOString();

    if (payload.response === 'ACCEPTED') {
      offer.status = 'ACCEPTED';
      offer.acceptedAt = now;

      // Update application stage to ACCEPTED
      const app = database.jobApplications.find((a) => a.id === offer.applicationId);
      if (app) {
        this.transitionApplicationStage(
          app.id,
          {
            newStage: 'ACCEPTED',
            notes: `Offer ${offer.offerNumber} accepted by candidate.`
          },
          actor
        );
      }
    } else {
      offer.status = 'REJECTED';
      offer.rejectedAt = now;
      offer.rejectionReason = payload.reason;

      const app = database.jobApplications.find((a) => a.id === offer.applicationId);
      if (app) {
        this.transitionApplicationStage(
          app.id,
          {
            newStage: 'WITHDRAWN',
            notes: `Candidate declined offer: ${payload.reason || 'No specific reason provided.'}`
          },
          actor
        );
      }
    }

    offer.updatedAt = now;
    database.jobOffers[offerIndex] = offer;

    this.logAudit('RECORD_OFFER_RESPONSE', 'JobOffer', offerId, actor, {
      response: payload.response,
      reason: payload.reason
    });

    return offer;
  }

  // ==========================================
  // 7. CANDIDATE -> STAFF CONVERSION (THE CORE MILESTONE)
  // ==========================================

  public convertCandidateToStaff(
    payload: ConvertCandidateToStaffPayload,
    actor?: User
  ): CandidateConversionResult {
    const candidate = database.candidates.find((c) => c.id === payload.candidateId);
    if (!candidate) {
      throw new Error(`Candidate with ID '${payload.candidateId}' not found.`);
    }

    // Verify candidate is not already converted
    if (candidate.status === 'CONVERTED_TO_STAFF') {
      throw new Error(
        `Candidate ${candidate.fullName} has already been converted to staff profile (${candidate.employeeCode}).`
      );
    }

    // Resolve department
    const dept = database.departments.find((d) => d.id === payload.departmentId);
    if (!dept) {
      throw new Error(`Department with ID '${payload.departmentId}' not found.`);
    }

    // Resolve designation
    let designationTitle = payload.designationTitle?.trim() || 'Staff Member';
    if (payload.designationId) {
      const des = database.designations.find((d) => d.id === payload.designationId);
      if (des) {
        designationTitle = des.title;
      }
    }

    // ATOMIC TRANSACTION: Call existing StaffService.createStaff
    // This handles validation, employee code generation, user account creation, and teacher profile synchronization!
    const staffPayload = {
      firstName: candidate.firstName,
      lastName: candidate.lastName,
      email: candidate.email,
      phone: candidate.phone,
      departmentId: dept.id,
      designationId: payload.designationId,
      designation: designationTitle,
      staffType: payload.staffType,
      employmentType: payload.employmentType,
      employmentStatus: payload.employmentStatus || 'active',
      joiningDate: payload.joiningDate,
      employeeCode: payload.employeeCode,
      gender: candidate.gender || 'other',
      dateOfBirth: candidate.dateOfBirth,
      address: candidate.address,
      currentAddress: candidate.address || 'Address on record',
      qualification: candidate.highestQualification,
      experienceYears: candidate.yearsOfExperience,
      emergencyContactName: candidate.emergencyContactName,
      emergencyContactPhone: candidate.emergencyContactPhone,
      workScheduleId: payload.workScheduleId,
      createAccount: Boolean(payload.createAccount),
      username: payload.username,
      password: payload.password,
      accountRole: payload.accountRole
    };

    const newStaff = staffService.createStaff(staffPayload, actor);

    const now = new Date().toISOString();

    // 1. Update Candidate record
    candidate.status = 'CONVERTED_TO_STAFF';
    candidate.currentStage = 'HIRED';
    candidate.staffProfileId = newStaff.id;
    candidate.employeeCode = newStaff.employeeCode;
    candidate.updatedAt = now;

    // 2. Update Application record if provided or found
    const app = payload.applicationId
      ? database.jobApplications.find((a) => a.id === payload.applicationId)
      : database.jobApplications.find(
          (a) => a.candidateId === candidate.id && ['ACCEPTED', 'SELECTED', 'OFFER'].includes(a.stage)
        );

    if (app) {
      app.stage = 'HIRED';
      app.status = 'HIRED';
      app.stageHistory.push({
        stage: 'HIRED',
        changedBy: actor?.id || 'system',
        changedByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'System',
        timestamp: now,
        notes: `Converted to staff member. Employee Code: ${newStaff.employeeCode}`
      });
      app.updatedAt = now;

      // Increment filled vacancies on job opening
      const opening = database.jobOpenings.find((j) => j.id === app.jobOpeningId);
      if (opening) {
        opening.filledVacancies = (opening.filledVacancies || 0) + 1;
        if (opening.filledVacancies >= opening.vacancies) {
          opening.status = 'FILLED';
        }
        opening.updatedAt = now;
      }
    }

    // 3. Automatically Initialize Onboarding Record
    let onboardingId: string | undefined = undefined;
    try {
      const templateId = payload.onboardingTemplateId || (
        payload.staffType === 'teaching'
          ? 'onb-tmpl-teaching'
          : payload.staffType === 'administrative'
          ? 'onb-tmpl-admin'
          : 'onb-tmpl-support'
      );

      const onboardingRecord = this.initializeOnboarding(
        newStaff.id,
        templateId,
        actor,
        candidate.id,
        app?.id
      );
      onboardingId = onboardingRecord.id;
    } catch (onbErr) {
      console.warn('Auto-onboarding initialization skipped:', onbErr);
    }

    this.logAudit('CONVERT_CANDIDATE_TO_STAFF', 'CandidateProfile', candidate.id, actor, {
      candidateId: candidate.id,
      staffId: newStaff.id,
      employeeCode: newStaff.employeeCode,
      staffName: `${newStaff.firstName} ${newStaff.lastName}`
    });

    return {
      candidateId: candidate.id,
      staffId: newStaff.id,
      employeeCode: newStaff.employeeCode,
      staffName: `${newStaff.firstName} ${newStaff.lastName}`,
      departmentName: dept.name,
      designation: designationTitle,
      hasAccount: Boolean(newStaff.userId),
      username: newStaff.username,
      onboardingId
    };
  }

  // ==========================================
  // 8. ONBOARDING & CHECKLISTS
  // ==========================================

  public listOnboardingRecords(query?: {
    status?: string;
    departmentId?: string;
    staffType?: string;
    search?: string;
  }): OnboardingRecord[] {
    let items = [...database.onboardingRecords];

    if (query?.status && query.status !== 'all') {
      items = items.filter((o) => o.status === query.status);
    }
    if (query?.departmentId && query.departmentId !== 'all') {
      items = items.filter((o) => o.departmentId === query.departmentId);
    }
    if (query?.staffType && query.staffType !== 'all') {
      items = items.filter((o) => o.staffType === query.staffType);
    }
    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (o) =>
          o.staffName.toLowerCase().includes(q) ||
          o.employeeCode.toLowerCase().includes(q) ||
          o.departmentName.toLowerCase().includes(q) ||
          o.designation.toLowerCase().includes(q)
      );
    }

    return items;
  }

  public getOnboardingRecordById(id: string): OnboardingRecord | null {
    return database.onboardingRecords.find((o) => o.id === id) || null;
  }

  public getOnboardingRecordByStaffId(staffId: string): OnboardingRecord | null {
    return database.onboardingRecords.find((o) => o.staffId === staffId) || null;
  }

  public listOnboardingTemplates(): OnboardingTemplate[] {
    return [...database.onboardingTemplates];
  }

  public getOnboardingTemplateById(id: string): OnboardingTemplate | null {
    return database.onboardingTemplates.find((t) => t.id === id) || null;
  }

  public initializeOnboarding(
    staffId: string,
    templateId: string,
    actor?: User,
    candidateId?: string,
    applicationId?: string
  ): OnboardingRecord {
    const staff = database.staffProfiles.find((s) => s.id === staffId);
    if (!staff) {
      throw new Error(`Staff profile with ID '${staffId}' not found.`);
    }

    // Check if onboarding already exists
    const existing = database.onboardingRecords.find((o) => o.staffId === staff.id);
    if (existing) {
      return existing;
    }

    const template = database.onboardingTemplates.find((t) => t.id === templateId) || database.onboardingTemplates[0];

    const now = new Date().toISOString();
    const joiningDate = staff.joiningDate || now.split('T')[0];

    // Compute target completion date (14 days from joining)
    const targetDate = new Date(joiningDate);
    targetDate.setDate(targetDate.getDate() + 14);
    const targetCompletionDate = targetDate.toISOString().split('T')[0];

    const tasks: OnboardingTask[] = template.tasks.map((tmplTask, index) => {
      const dueDateObj = new Date(joiningDate);
      dueDateObj.setDate(dueDateObj.getDate() + (tmplTask.daysFromJoiningDue || 7));
      return {
        id: `onb-task-${Date.now()}-${index}`,
        title: tmplTask.title,
        description: tmplTask.description,
        category: tmplTask.category,
        isMandatory: tmplTask.isMandatory,
        status: 'PENDING',
        dueDate: dueDateObj.toISOString().split('T')[0],
        order: index + 1
      };
    });

    const newRecord: OnboardingRecord = {
      id: `onb-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      staffId: staff.id,
      employeeCode: staff.employeeCode,
      staffName: `${staff.firstName} ${staff.lastName}`,
      staffType: staff.staffType as any,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      designation: staff.designation,
      joiningDate,
      candidateId,
      applicationId,
      templateId: template?.id,
      templateName: template?.name,
      status: 'IN_PROGRESS',
      totalTasks: tasks.length,
      completedTasks: 0,
      progressPercentage: 0,
      startDate: joiningDate,
      targetCompletionDate,
      tasks,
      createdAt: now,
      updatedAt: now
    };

    database.onboardingRecords.unshift(newRecord);

    this.logAudit('INITIALIZE_ONBOARDING', 'OnboardingRecord', newRecord.id, actor, {
      staffName: newRecord.staffName,
      employeeCode: newRecord.employeeCode
    });

    return newRecord;
  }

  public addOnboardingTask(
    onboardingId: string,
    payload: CreateOnboardingTaskPayload,
    actor?: User
  ): OnboardingRecord {
    const onbIndex = database.onboardingRecords.findIndex((o) => o.id === onboardingId);
    if (onbIndex === -1) {
      throw new Error(`Onboarding record with ID '${onboardingId}' not found.`);
    }

    if (!payload.title?.trim()) {
      throw new Error('Task title is required.');
    }

    const record = database.onboardingRecords[onbIndex];
    const newTask: OnboardingTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: payload.title.trim(),
      description: payload.description?.trim(),
      category: payload.category || 'DOCUMENTATION',
      isMandatory: Boolean(payload.isMandatory),
      status: 'PENDING',
      dueDate: payload.dueDate,
      assignedToId: payload.assignedToId,
      notes: payload.notes?.trim(),
      order: record.tasks.length + 1
    };

    record.tasks.push(newTask);
    record.totalTasks = record.tasks.length;
    record.completedTasks = record.tasks.filter((t) => t.status === 'COMPLETED').length;
    record.progressPercentage = Math.round((record.completedTasks / record.totalTasks) * 100);
    record.updatedAt = new Date().toISOString();

    database.onboardingRecords[onbIndex] = record;
    return record;
  }

  public updateOnboardingTask(
    onboardingId: string,
    taskId: string,
    payload: UpdateOnboardingTaskPayload,
    actor?: User
  ): OnboardingRecord {
    const onbIndex = database.onboardingRecords.findIndex((o) => o.id === onboardingId);
    if (onbIndex === -1) {
      throw new Error(`Onboarding record with ID '${onboardingId}' not found.`);
    }

    const record = database.onboardingRecords[onbIndex];
    const taskIndex = record.tasks.findIndex((t) => t.id === taskId);
    if (taskIndex === -1) {
      throw new Error(`Onboarding task with ID '${taskId}' not found.`);
    }

    const task = record.tasks[taskIndex];
    const now = new Date().toISOString();
    const actorName = actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Supervisor';

    if (payload.status === 'COMPLETED' && task.status !== 'COMPLETED') {
      task.completedAt = now;
      task.completedBy = actor?.id;
      task.completedByName = actorName;
    } else if (payload.status && payload.status !== 'COMPLETED') {
      task.completedAt = undefined;
      task.completedBy = undefined;
      task.completedByName = undefined;
    }

    record.tasks[taskIndex] = {
      ...task,
      ...payload
    };

    // Recompute summary
    record.totalTasks = record.tasks.length;
    record.completedTasks = record.tasks.filter((t) => t.status === 'COMPLETED').length;
    record.progressPercentage = record.totalTasks > 0 ? Math.round((record.completedTasks / record.totalTasks) * 100) : 0;

    if (record.progressPercentage === 100) {
      record.status = 'COMPLETED';
      record.completedAt = now;
    } else {
      record.status = 'IN_PROGRESS';
      record.completedAt = undefined;
    }

    record.updatedAt = now;
    database.onboardingRecords[onbIndex] = record;

    this.logAudit('UPDATE_ONBOARDING_TASK', 'OnboardingRecord', onboardingId, actor, {
      taskId,
      status: payload.status
    });

    return record;
  }

  // ==========================================
  // 9. DASHBOARD & METRICS
  // ==========================================

  public getDashboardMetrics(): RecruitmentDashboardMetrics {
    const openJobOpenings = database.jobOpenings.filter((j) =>
      ['PUBLISHED', 'APPLICATIONS_OPEN'].includes(j.status)
    ).length;

    const totalApplications = database.jobApplications.length;
    const candidatesUnderScreening = database.jobApplications.filter((a) =>
      ['APPLIED', 'SCREENING'].includes(a.stage)
    ).length;
    const shortlistedCandidates = database.jobApplications.filter((a) => a.stage === 'SHORTLISTED').length;
    const upcomingInterviews = database.interviews.filter((i) =>
      ['SCHEDULED', 'CONFIRMED'].includes(i.status)
    ).length;
    const selectedCandidates = database.jobApplications.filter((a) => a.stage === 'SELECTED').length;
    const pendingOffers = database.jobOffers.filter((o) =>
      ['DRAFT', 'PENDING_APPROVAL', 'APPROVED', 'SENT'].includes(o.status)
    ).length;
    const acceptedOffers = database.jobOffers.filter((o) => o.status === 'ACCEPTED').length;

    const activeOnboarding = database.onboardingRecords.filter((o) => o.status === 'IN_PROGRESS').length;
    const completedOnboarding = database.onboardingRecords.filter((o) => o.status === 'COMPLETED').length;

    const hiredCount = database.jobApplications.filter((a) => a.stage === 'HIRED').length;
    const conversionRate = totalApplications > 0 ? Math.round((hiredCount / totalApplications) * 100) : 0;

    // Department breakdown
    const departmentDistribution = database.departments.map((dept) => {
      const openingsCount = database.jobOpenings.filter((j) => j.departmentId === dept.id).length;
      const applicationsCount = database.jobApplications.filter((a) => a.departmentId === dept.id).length;
      const hired = database.jobApplications.filter(
        (a) => a.departmentId === dept.id && a.stage === 'HIRED'
      ).length;
      return {
        departmentId: dept.id,
        departmentName: dept.name,
        openingsCount,
        applicationsCount,
        hiredCount: hired
      };
    });

    // Stage breakdown
    const stages: Array<JobApplication['stage']> = [
      'APPLIED',
      'SCREENING',
      'SHORTLISTED',
      'INTERVIEW',
      'SELECTED',
      'OFFER',
      'ACCEPTED',
      'ONBOARDING',
      'HIRED',
      'REJECTED',
      'WITHDRAWN',
      'ON_HOLD'
    ];

    const stageDistribution = stages.map((stg) => ({
      stage: stg,
      count: database.jobApplications.filter((a) => a.stage === stg).length
    }));

    return {
      openJobOpenings,
      totalApplications,
      candidatesUnderScreening,
      shortlistedCandidates,
      upcomingInterviews,
      selectedCandidates,
      pendingOffers,
      acceptedOffers,
      activeOnboarding,
      completedOnboarding,
      conversionRate,
      departmentDistribution,
      stageDistribution
    };
  }
}

export const staffRecruitmentService = new StaffRecruitmentService();
