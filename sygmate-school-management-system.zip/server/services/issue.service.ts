/**
 * Issue, Return & Allocation Workflow Service (Part 14E)
 * Sygmate School Management System
 *
 * Implements:
 * - Issue Requests with approval lifecycle (DRAFT -> SUBMITTED -> APPROVED -> PARTIALLY_ISSUED -> FULLY_ISSUED)
 * - Controlled Stock Issue execution with strict atomic stock deductions via StockService (Part 14B)
 * - Negative stock prevention and partial issue tracking
 * - Controlled Inventory Returns restoring stock atomically via StockService (Part 14B)
 * - Asset Handover, Return, Transfer & Reassignment integrating with AssetService (Part 14C)
 * - Bulk Asset Allocation
 * - Concurrency control & Mutex locking
 * - Idempotency guards
 * - Full audit trails & notifications
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { StockService } from './stock.service.js';
import { AssetService, withAssetLock } from './asset.service.js';
import {
  IssueRequest,
  IssueRequestItem,
  IssueRequestStatus,
  CreateIssueRequestPayload,
  ReviewIssueRequestPayload,
  StockIssue,
  StockIssueItem,
  ExecuteStockIssuePayload,
  InventoryReturn,
  InventoryReturnItem,
  CreateInventoryReturnPayload,
  BulkAssetAllocationPayload,
  DepartmentAllocationSummary,
  Asset,
  AssetAssignment,
  AssetTransfer,
  AssetReturn,
  UserRole
} from '../../src/types/index.js';
import { ensureInventoryCollections } from '../routes/inventory.routes.js';

// ============================================================================
// CONCURRENCY & MUTEX LOCKING
// ============================================================================

type MutexTask<T> = () => Promise<T> | T;
const issueLockQueues = new Map<string, Promise<any>>();

export async function withIssueLock<T>(key: string, task: MutexTask<T>): Promise<T> {
  const currentLock = issueLockQueues.get(key) || Promise.resolve();
  let releaseLock: () => void;
  const newLock = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });
  issueLockQueues.set(key, newLock);

  try {
    await currentLock;
    return await task();
  } finally {
    releaseLock!();
    if (issueLockQueues.get(key) === newLock) {
      issueLockQueues.delete(key);
    }
  }
}

// ============================================================================
// IDEMPOTENCY CACHE
// ============================================================================

const processedIdempotencyKeys = new Set<string>();

export function checkAndRegisterIdempotencyKey(key?: string): void {
  if (!key) return;
  if (processedIdempotencyKeys.has(key)) {
    throw new Error(`Transaction with idempotency key '${key}' has already been processed.`);
  }
  processedIdempotencyKeys.add(key);
  // Auto-expire keys after 15 minutes
  setTimeout(() => processedIdempotencyKeys.delete(key), 15 * 60 * 1000);
}

// ============================================================================
// NUMBER GENERATORS
// ============================================================================

function generateNextIssueRequestNumber(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let count = (database.issueRequests || []).filter((r) => r.schoolId === schoolId).length + 1;
  let num = `IR-${year}-${String(count).padStart(4, '0')}`;
  while ((database.issueRequests || []).some((r) => r.schoolId === schoolId && r.requestNumber === num)) {
    count++;
    num = `IR-${year}-${String(count).padStart(4, '0')}`;
  }
  return num;
}

function generateNextStockIssueNumber(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let count = (database.stockIssues || []).filter((i) => i.schoolId === schoolId).length + 1;
  let num = `ISS-${year}-${String(count).padStart(4, '0')}`;
  while ((database.stockIssues || []).some((i) => i.schoolId === schoolId && i.issueNumber === num)) {
    count++;
    num = `ISS-${year}-${String(count).padStart(4, '0')}`;
  }
  return num;
}

function generateNextInventoryReturnNumber(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let count = (database.inventoryReturns || []).filter((r) => r.schoolId === schoolId).length + 1;
  let num = `RET-${year}-${String(count).padStart(4, '0')}`;
  while ((database.inventoryReturns || []).some((r) => r.schoolId === schoolId && r.returnNumber === num)) {
    count++;
    num = `RET-${year}-${String(count).padStart(4, '0')}`;
  }
  return num;
}

// ============================================================================
// USER NORMALIZATION HELPER
// ============================================================================

export interface NormalizedUser {
  id: string;
  name: string;
  role: UserRole;
}

export function normalizeUser(rawUser: any): NormalizedUser {
  return {
    id: rawUser?.id || 'usr-admin-1',
    name: rawUser?.name || 'Administrator',
    role: rawUser?.role || 'SUPER_ADMIN'
  };
}

// ============================================================================
// NOTIFICATION HELPER
// ============================================================================

function sendInternalNotification(
  schoolId: string,
  targetUserId: string,
  title: string,
  message: string,
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT' = 'INFO'
): void {
  if (!database.notifications) database.notifications = [];
  database.notifications.unshift({
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    schoolId,
    userId: targetUserId,
    title,
    message,
    type: type as any,
    isRead: false,
    createdAt: new Date().toISOString()
  } as any);
}

// ============================================================================
// MAIN SERVICE CLASS
// ============================================================================

export class IssueService {
  // --------------------------------------------------------------------------
  // 1. ISSUE REQUESTS
  // --------------------------------------------------------------------------

  /**
   * List Issue Requests with multifaceted filtering
   */
  static getIssueRequests(
    schoolId: string,
    filters?: {
      search?: string;
      status?: IssueRequestStatus | 'ALL';
      departmentId?: string;
      recipientId?: string;
      sourceLocationId?: string;
      page?: number;
      limit?: number;
    }
  ): { data: IssueRequest[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureInventoryCollections();

    let result = (database.issueRequests || []).filter((r) => r.schoolId === schoolId);

    if (filters) {
      if (filters.status && filters.status !== 'ALL') {
        result = result.filter((r) => r.status === filters.status);
      }
      if (filters.departmentId && filters.departmentId !== 'ALL') {
        result = result.filter((r) => r.departmentId === filters.departmentId);
      }
      if (filters.recipientId) {
        result = result.filter((r) => r.recipientId === filters.recipientId);
      }
      if (filters.sourceLocationId && filters.sourceLocationId !== 'ALL') {
        result = result.filter((r) => r.sourceLocationId === filters.sourceLocationId);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.toLowerCase().trim();
        result = result.filter(
          (r) =>
            r.requestNumber.toLowerCase().includes(q) ||
            r.purpose.toLowerCase().includes(q) ||
            r.recipientName.toLowerCase().includes(q) ||
            (r.departmentName && r.departmentName.toLowerCase().includes(q)) ||
            r.items.some((i) => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
        );
      }
    }

    // Sort newest first
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, Math.min(100, filters?.limit || 20));
    const total = result.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = result.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: { total, page, limit, pages }
    };
  }

  /**
   * Get single Issue Request by ID
   */
  static getIssueRequestById(schoolId: string, id: string): IssueRequest {
    ensureInventoryCollections();
    const req = (database.issueRequests || []).find((r) => r.id === id && r.schoolId === schoolId);
    if (!req) {
      throw new Error(`Issue Request not found with ID '${id}'.`);
    }
    return req;
  }

  /**
   * Create an Issue Request
   */
  static async createIssueRequest(
    schoolId: string,
    payload: CreateIssueRequestPayload,
    user: any
  ): Promise<IssueRequest> {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    if (!payload.items || payload.items.length === 0) {
      throw new Error('An Issue Request must contain at least one line item.');
    }
    if (!payload.sourceLocationId) {
      throw new Error('Source warehouse/location is required.');
    }
    if (!payload.purpose || !payload.purpose.trim()) {
      throw new Error('A business purpose or requisition reason is required.');
    }

    // Validate location
    const sourceLoc = database.inventoryLocations.find(
      (l) => l.id === payload.sourceLocationId && l.schoolId === schoolId
    );
    if (!sourceLoc) {
      throw new Error('Specified source warehouse / store location does not exist.');
    }

    // Validate recipient and department
    let departmentName = payload.departmentName;
    if (payload.departmentId) {
      const dept = database.departments.find((d) => d.id === payload.departmentId);
      if (dept) departmentName = dept.name;
    }

    let locationName = payload.locationName;
    if (payload.locationId) {
      const loc = database.inventoryLocations.find(
        (l) => l.id === payload.locationId && l.schoolId === schoolId
      );
      if (loc) locationName = loc.name;
    }

    const now = new Date().toISOString();
    let totalEstimatedCost = 0;

    const requestItems: IssueRequestItem[] = payload.items.map((itemPayload, idx) => {
      if (!itemPayload.itemId) {
        throw new Error(`Line item #${idx + 1} has no item specified.`);
      }
      const qtyRequested = typeof itemPayload.requestedQuantity === 'number'
        ? itemPayload.requestedQuantity
        : typeof itemPayload.quantityRequested === 'number'
        ? itemPayload.quantityRequested
        : 0;
      if (qtyRequested <= 0) {
        throw new Error(`Requested quantity for item #${idx + 1} must be a positive number.`);
      }

      const invItem = database.inventoryItems.find(
        (i) => i.id === itemPayload.itemId && i.schoolId === schoolId
      );
      if (!invItem) {
        throw new Error(`Inventory item '${itemPayload.itemId}' does not exist.`);
      }
      if (invItem.status !== 'ACTIVE') {
        throw new Error(`Inventory item '${invItem.name}' is inactive.`);
      }

      const unitCost = invItem.unitPrice || 0;
      const estimatedTotal = unitCost * qtyRequested;
      totalEstimatedCost += estimatedTotal;

      return {
        id: `iri-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
        issueRequestId: '',
        itemId: invItem.id,
        itemName: invItem.name,
        itemCode: invItem.itemCode,
        requestedQuantity: qtyRequested,
        quantityRequested: qtyRequested,
        availableQuantityAtRequest: 0,
        approvedQuantity: 0,
        quantityApproved: 0,
        issuedQuantity: 0,
        quantityIssued: 0,
        unitId: invItem.unitId,
        unitShortCode: invItem.unitShortCode,
        unitCost,
        estimatedTotal,
        notes: itemPayload.notes?.trim()
      };
    });

    const requestNumber = generateNextIssueRequestNumber(schoolId);

    const issueRequest: IssueRequest = {
      id: `ir-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      requestNumber,
      requestDate: now,
      requiredDate: payload.requiredDate,
      priority: payload.priority || 'MEDIUM',
      status: 'SUBMITTED',
      requestedBy: normalizedUser.id,
      requestedByName: normalizedUser.name,
      requestingUserId: normalizedUser.id,
      requestingUserName: normalizedUser.name,
      requesterName: normalizedUser.name,
      destinationType: (payload.destinationType || payload.recipientType || 'DEPARTMENT') as any,
      destinationId: payload.destinationId || payload.recipientId,
      destinationName: payload.destinationName || payload.recipientName || departmentName,
      recipientType: (payload.recipientType || payload.destinationType || 'DEPARTMENT') as any,
      recipientId: payload.recipientId || payload.destinationId,
      recipientName: payload.recipientName || payload.destinationName || departmentName,
      departmentId: payload.departmentId,
      departmentName,
      locationId: payload.locationId || sourceLoc.id,
      locationName: locationName || sourceLoc.name,
      sourceLocationId: sourceLoc.id,
      sourceLocationName: sourceLoc.name,
      purpose: (payload.purpose || '').trim(),
      notes: payload.notes?.trim(),
      items: requestItems,
      createdAt: now,
      updatedAt: now
    };

    issueRequest.items.forEach((item) => {
      item.issueRequestId = issueRequest.id;
    });

    database.issueRequests.unshift(issueRequest);

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'IssueRequest',
      entityId: issueRequest.id,
      details: `Created Issue Request ${issueRequest.requestNumber} for ${issueRequest.recipientName} (${requestItems.length} items).`
    });

    return issueRequest;
  }

  /**
   * Review Issue Request (Approve or Reject)
   */
  static async reviewIssueRequest(
    schoolId: string,
    id: string,
    payload: ReviewIssueRequestPayload,
    user: any
  ): Promise<IssueRequest> {
    return withIssueLock(`ir:${id}`, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const req = database.issueRequests.find((r) => r.id === id && r.schoolId === schoolId);
      if (!req) {
        throw new Error(`Issue Request not found with ID '${id}'.`);
      }

      if (req.status !== 'SUBMITTED' && req.status !== 'DRAFT') {
        throw new Error(
          `Issue Request ${req.requestNumber} cannot be reviewed because its current status is '${req.status}'.`
        );
      }

      const now = new Date().toISOString();

      if (payload.decision === 'REJECT') {
        req.status = 'REJECTED';
        req.reviewedBy = normalizedUser.id;
        req.reviewedByName = normalizedUser.name;
        req.reviewedAt = now;
        req.rejectionReason = payload.rejectionReason?.trim() || payload.reviewNotes?.trim() || 'Rejected by authorized administrator.';
        req.updatedAt = now;

        logAudit({
          userId: normalizedUser.id,
          userName: normalizedUser.name,
          userRole: normalizedUser.role,
          action: 'UPDATE',
          entity: 'OTHER',
          entityType: 'IssueRequest',
          entityId: req.id,
          details: `Rejected Issue Request ${req.requestNumber}: ${req.rejectionReason}`
        });

        sendInternalNotification(
          schoolId,
          req.requestingUserId || req.requestedBy,
          `Issue Request Rejected (${req.requestNumber})`,
          `Your inventory issue request ${req.requestNumber} was rejected: ${req.rejectionReason}`,
          'WARNING'
        );

        return req;
      }

      // APPROVAL
      req.status = 'APPROVED';
      req.reviewedBy = normalizedUser.id;
      req.reviewedByName = normalizedUser.name;
      req.reviewedAt = now;
      req.reviewNotes = payload.reviewNotes?.trim() || 'Approved for dispatch.';

      // Apply approved quantities if provided, otherwise approve full requested quantity
      const approvedList = payload.approvedItems || (payload as any).items;
      if (approvedList && approvedList.length > 0) {
        req.items.forEach((item) => {
          const matched = approvedList.find((ai: any) => ai.itemId === item.itemId);
          const approvedVal = matched && typeof (matched.approvedQuantity ?? matched.quantityApproved) === 'number'
            ? Math.max(0, (matched.approvedQuantity ?? matched.quantityApproved))
            : (item.quantityRequested ?? item.requestedQuantity);
          item.quantityApproved = approvedVal;
          item.approvedQuantity = approvedVal;
        });
      } else {
        req.items.forEach((item) => {
          const reqVal = item.quantityRequested ?? item.requestedQuantity;
          item.quantityApproved = reqVal;
          item.approvedQuantity = reqVal;
        });
      }

      req.updatedAt = now;

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'IssueRequest',
        entityId: req.id,
        details: `Approved Issue Request ${req.requestNumber} by ${normalizedUser.name}.`
      });

      sendInternalNotification(
        schoolId,
        req.requestingUserId || req.requestedBy,
        `Issue Request Approved (${req.requestNumber})`,
        `Your inventory issue request ${req.requestNumber} was approved and is ready for dispatch.`,
        'SUCCESS'
      );

      return req;
    });
  }

  // --------------------------------------------------------------------------
  // 2. STOCK ISSUE EXECUTION (Atomic Stock Out Integration)
  // --------------------------------------------------------------------------

  /**
   * Execute physical stock issue.
   * Decrements stock atomically using Part 14B StockService.recordStockOut,
   * enforces negative stock prevention, and tracks partial issue remaining balances.
   */
  static async executeStockIssue(
    schoolId: string,
    payload: ExecuteStockIssuePayload,
    user: any
  ): Promise<StockIssue> {
    checkAndRegisterIdempotencyKey(payload.idempotencyKey);

    const lockKey = payload.issueRequestId
      ? `issue:ir:${payload.issueRequestId}`
      : `issue:loc:${payload.sourceLocationId}`;

    return withIssueLock(lockKey, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      if (!payload.items || payload.items.length === 0) {
        throw new Error('Stock issue must contain at least one item to issue.');
      }
      if (!payload.sourceLocationId) {
        throw new Error('Source warehouse location ID is required.');
      }

      // Verify location
      const sourceLocation = database.inventoryLocations.find(
        (l) => l.id === payload.sourceLocationId && l.schoolId === schoolId
      );
      if (!sourceLocation) {
        throw new Error('Source location does not exist in this institution.');
      }
      if (sourceLocation.status === 'INACTIVE') {
        throw new Error(`Location '${sourceLocation.name}' is currently inactive.`);
      }

      let issueRequest: IssueRequest | undefined;
      if (payload.issueRequestId) {
        issueRequest = database.issueRequests.find(
          (r) => r.id === payload.issueRequestId && r.schoolId === schoolId
        );
        if (!issueRequest) {
          throw new Error(`Associated Issue Request '${payload.issueRequestId}' not found.`);
        }
        if (issueRequest.status !== 'APPROVED' && issueRequest.status !== 'PARTIALLY_ISSUED') {
          throw new Error(
            `Cannot issue against Request ${issueRequest.requestNumber} with status '${issueRequest.status}'. Must be APPROVED or PARTIALLY_ISSUED.`
          );
        }
      }

      // Pre-validation pass: Ensure every item exists and location has sufficient stock
      for (const reqItem of payload.items) {
        if (typeof reqItem.quantityToIssue !== 'number' || reqItem.quantityToIssue <= 0) {
          throw new Error(`Issue quantity must be greater than zero for item ${reqItem.itemId}.`);
        }

        const invItem = database.inventoryItems.find(
          (i) => i.id === reqItem.itemId && i.schoolId === schoolId
        );
        if (!invItem) {
          throw new Error(`Inventory item '${reqItem.itemId}' not found.`);
        }

        // Check stock balance at location
        const balance = (database.stockBalances || []).find(
          (b) => b.itemId === invItem.id && b.locationId === sourceLocation.id && b.schoolId === schoolId
        );
        const currentQty = balance ? balance.quantity : 0;
        if (currentQty < reqItem.quantityToIssue) {
          throw new Error(
            `Insufficient stock for '${invItem.name}' at ${sourceLocation.name}. Available: ${currentQty} ${invItem.unitShortCode}, requested to issue: ${reqItem.quantityToIssue} ${invItem.unitShortCode}. Negative stock is prohibited.`
          );
        }

        // If linked to an Issue Request, verify not exceeding remaining approved quantity
        if (issueRequest) {
          const prItem = issueRequest.items.find((i) => i.itemId === invItem.id);
          if (!prItem) {
            throw new Error(`Item '${invItem.name}' was not part of Issue Request ${issueRequest.requestNumber}.`);
          }
          const remainingEligible = prItem.quantityApproved - prItem.quantityIssued;
          if (reqItem.quantityToIssue > remainingEligible) {
            throw new Error(
              `Cannot issue ${reqItem.quantityToIssue} units of '${invItem.name}'. Only ${remainingEligible} approved units remain on request ${issueRequest.requestNumber}.`
            );
          }
        }
      }

      const issueNumber = generateNextStockIssueNumber(schoolId);
      const now = new Date().toISOString();
      const issueDate = payload.issueDate || now;
      let totalCost = 0;
      const issueItems: StockIssueItem[] = [];

      // Execute atomic stock-outs via Part 14B StockService
      for (const reqItem of payload.items) {
        const invItem = database.inventoryItems.find(
          (i) => i.id === reqItem.itemId && i.schoolId === schoolId
        )!;

        const recipientLabel = `${payload.recipientName} (${payload.recipientType})`;
        const notes = `Stock Issue ${issueNumber}${payload.purpose ? ` - ${payload.purpose}` : ''}`;

        // Deduct stock using the authoritative Part 14B StockService
        const stockOutResult = await StockService.recordStockOut(
          schoolId,
          {
            itemId: invItem.id,
            locationId: sourceLocation.id,
            quantity: reqItem.quantityToIssue,
            recipient: recipientLabel,
            department: payload.departmentName,
            referenceNumber: issueNumber,
            date: issueDate,
            purpose: payload.purpose,
            notes
          },
          normalizedUser
        );

        const unitCost = invItem.unitPrice || 0;
        const lineTotal = unitCost * reqItem.quantityToIssue;
        totalCost += lineTotal;

        issueItems.push({
          id: `issi-${Date.now()}-${issueItems.length}-${Math.random().toString(36).substring(2, 6)}`,
          itemId: invItem.id,
          itemName: invItem.name,
          itemCode: invItem.itemCode,
          quantityIssued: reqItem.quantityToIssue,
          quantityReturned: 0,
          unitId: invItem.unitId,
          unitShortCode: invItem.unitShortCode,
          unitCost,
          totalCost: lineTotal,
          stockTransactionId: stockOutResult.transaction.id,
          notes: reqItem.notes
        });

        // Update Issue Request line items if applicable
        if (issueRequest) {
          const prItem = issueRequest.items.find((i) => i.itemId === invItem.id);
          if (prItem) {
            prItem.quantityIssued += reqItem.quantityToIssue;
          }
        }
      }

      // Update Issue Request overall status
      if (issueRequest) {
        const allFullyIssued = issueRequest.items.every(
          (i) => i.quantityIssued >= i.quantityApproved
        );
        issueRequest.status = allFullyIssued ? 'FULLY_ISSUED' : 'PARTIALLY_ISSUED';
        issueRequest.updatedAt = now;
      }

      // Create StockIssue record
      const stockIssue: StockIssue = {
        id: `iss-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        issueNumber,
        issueDate,
        issueRequestId: issueRequest?.id,
        issueRequestNumber: issueRequest?.requestNumber,
        sourceLocationId: sourceLocation.id,
        sourceLocationName: sourceLocation.name,
        recipientType: payload.recipientType,
        recipientId: payload.recipientId,
        recipientName: payload.recipientName,
        departmentId: payload.departmentId,
        departmentName: payload.departmentName,
        locationId: payload.locationId,
        locationName: payload.locationName,
        purpose: payload.purpose,
        notes: payload.notes,
        items: issueItems,
        totalItemsCount: issueItems.length,
        totalCost,
        issuedBy: normalizedUser.id,
        issuedByName: normalizedUser.name,
        status: 'COMPLETED',
        createdAt: now,
        updatedAt: now
      };

      database.stockIssues.unshift(stockIssue);

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockIssue',
        entityId: stockIssue.id,
        details: `Issued ${issueItems.length} items from ${sourceLocation.name} to ${payload.recipientName} (${issueNumber}).`
      });

      sendInternalNotification(
        schoolId,
        payload.recipientId,
        `Inventory Issued (${issueNumber})`,
        `Stock issue ${issueNumber} has been dispatched to you from ${sourceLocation.name}.`,
        'INFO'
      );

      return stockIssue;
    });
  }

  /**
   * List Stock Issues with multifaceted filters
   */
  static getStockIssues(
    schoolId: string,
    filters?: {
      search?: string;
      recipientId?: string;
      departmentId?: string;
      locationId?: string;
      status?: string;
      page?: number;
      limit?: number;
    }
  ): { data: StockIssue[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureInventoryCollections();

    let result = (database.stockIssues || []).filter((i) => i.schoolId === schoolId);

    if (filters) {
      if (filters.recipientId) {
        result = result.filter((i) => i.recipientId === filters.recipientId);
      }
      if (filters.departmentId && filters.departmentId !== 'ALL') {
        result = result.filter((i) => i.departmentId === filters.departmentId);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        result = result.filter((i) => i.sourceLocationId === filters.locationId);
      }
      if (filters.status && filters.status !== 'ALL') {
        result = result.filter((i) => i.status === filters.status);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.toLowerCase().trim();
        result = result.filter(
          (i) =>
            i.issueNumber.toLowerCase().includes(q) ||
            i.recipientName.toLowerCase().includes(q) ||
            (i.departmentName && i.departmentName.toLowerCase().includes(q)) ||
            (i.purpose && i.purpose.toLowerCase().includes(q)) ||
            i.items.some((item) => item.itemName.toLowerCase().includes(q) || item.itemCode.toLowerCase().includes(q))
        );
      }
    }

    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, Math.min(100, filters?.limit || 20));
    const total = result.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = result.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: { total, page, limit, pages }
    };
  }

  // --------------------------------------------------------------------------
  // 3. INVENTORY RETURNS (Atomic Stock In Integration)
  // --------------------------------------------------------------------------

  /**
   * Process Inventory Return.
   * Validates return quantities against original issue (if linked),
   * increments stock atomically via Part 14B StockService.recordStockReturn if GOOD condition,
   * updates issue tracking, and produces an immutable audit record.
   */
  static async createInventoryReturn(
    schoolId: string,
    payload: CreateInventoryReturnPayload,
    user: any
  ): Promise<InventoryReturn> {
    checkAndRegisterIdempotencyKey(payload.idempotencyKey);

    const lockKey = payload.originalIssueId
      ? `return:iss:${payload.originalIssueId}`
      : `return:loc:${payload.returnLocationId}`;

    return withIssueLock(lockKey, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      if (!payload.items || payload.items.length === 0) {
        throw new Error('Return record must contain at least one item.');
      }
      if (!payload.returnLocationId) {
        throw new Error('Return warehouse/store location ID is required.');
      }

      // Check receiving location
      const returnLocation = database.inventoryLocations.find(
        (l) => l.id === payload.returnLocationId && l.schoolId === schoolId
      );
      if (!returnLocation) {
        throw new Error('Target receiving warehouse location does not exist.');
      }
      if (returnLocation.status === 'INACTIVE') {
        throw new Error(`Location '${returnLocation.name}' is inactive.`);
      }

      let originalIssue: StockIssue | undefined;
      if (payload.originalIssueId) {
        originalIssue = database.stockIssues.find(
          (i) => i.id === payload.originalIssueId && i.schoolId === schoolId
        );
        if (!originalIssue) {
          throw new Error(`Referenced original Stock Issue '${payload.originalIssueId}' not found.`);
        }
      }

      // Validate items and quantities
      for (const itemPayload of payload.items) {
        if (typeof itemPayload.quantity !== 'number' || itemPayload.quantity <= 0) {
          throw new Error(`Return quantity must be greater than zero for item ${itemPayload.itemId}.`);
        }

        const invItem = database.inventoryItems.find(
          (i) => i.id === itemPayload.itemId && i.schoolId === schoolId
        );
        if (!invItem) {
          throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);
        }

        // If linked to an issue, verify return does not exceed issued minus already returned
        if (originalIssue) {
          const issueLine = originalIssue.items.find((l) => l.itemId === invItem.id);
          if (!issueLine) {
            throw new Error(
              `Item '${invItem.name}' was not part of original Issue ${originalIssue.issueNumber}.`
            );
          }
          const eligibleToReturn = issueLine.quantityIssued - issueLine.quantityReturned;
          if (itemPayload.quantity > eligibleToReturn) {
            throw new Error(
              `Cannot return ${itemPayload.quantity} units of '${invItem.name}'. Only ${eligibleToReturn} units eligible for return from Issue ${originalIssue.issueNumber}.`
            );
          }
        }
      }

      const returnNumber = generateNextInventoryReturnNumber(schoolId);
      const now = new Date().toISOString();
      const returnDate = payload.returnDate || now;
      const returnItems: InventoryReturnItem[] = [];

      for (const itemPayload of payload.items) {
        const invItem = database.inventoryItems.find(
          (i) => i.id === itemPayload.itemId && i.schoolId === schoolId
        )!;

        let txId: string | undefined;

        // If condition is GOOD, restore stock into the warehouse via Part 14B StockService
        if (itemPayload.condition === 'GOOD') {
          const stockReturnResult = await StockService.recordStockReturn(
            schoolId,
            {
              itemId: invItem.id,
              locationId: returnLocation.id,
              quantity: itemPayload.quantity,
              referenceNumber: returnNumber,
              date: returnDate,
              notes: `Inventory Return ${returnNumber}: ${payload.reason}`
            },
            normalizedUser
          );
          txId = stockReturnResult.transaction.id;
        }

        returnItems.push({
          id: `reti-${Date.now()}-${returnItems.length}-${Math.random().toString(36).substring(2, 6)}`,
          itemId: invItem.id,
          itemName: invItem.name,
          itemCode: invItem.itemCode,
          quantityReturned: itemPayload.quantity,
          unitId: invItem.unitId,
          unitShortCode: invItem.unitShortCode,
          condition: itemPayload.condition,
          reason: itemPayload.reason || payload.reason,
          stockTransactionId: txId,
          notes: itemPayload.notes
        });

        // Update original issue line if linked
        if (originalIssue) {
          const issueLine = originalIssue.items.find((l) => l.itemId === invItem.id);
          if (issueLine) {
            issueLine.quantityReturned += itemPayload.quantity;
          }
        }
      }

      // Update original issue status
      if (originalIssue) {
        const allFullyReturned = originalIssue.items.every(
          (l) => l.quantityReturned >= l.quantityIssued
        );
        originalIssue.status = allFullyReturned ? 'RETURNED' : 'PARTIALLY_RETURNED';
        originalIssue.updatedAt = now;
      }

      const invReturn: InventoryReturn = {
        id: `ret-inv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        returnNumber,
        returnDate,
        originalIssueId: originalIssue?.id,
        originalIssueNumber: originalIssue?.issueNumber,
        returnLocationId: returnLocation.id,
        returnLocationName: returnLocation.name,
        returnedByType: payload.returnedByType,
        returnedById: payload.returnedById,
        returnedByName: payload.returnedByName,
        departmentId: payload.departmentId,
        departmentName: payload.departmentName,
        reason: payload.reason,
        notes: payload.notes,
        items: returnItems,
        receivedByUserId: normalizedUser.id,
        receivedByUserName: normalizedUser.name,
        createdAt: now
      };

      database.inventoryReturns.unshift(invReturn);

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryReturn',
        entityId: invReturn.id,
        details: `Processed Inventory Return ${returnNumber} from ${payload.returnedByName} (${returnItems.length} items).`
      });

      return invReturn;
    });
  }

  /**
   * List Inventory Returns
   */
  static getInventoryReturns(
    schoolId: string,
    filters?: {
      search?: string;
      returnedById?: string;
      departmentId?: string;
      locationId?: string;
      page?: number;
      limit?: number;
    }
  ): { data: InventoryReturn[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureInventoryCollections();

    let result = (database.inventoryReturns || []).filter((r) => r.schoolId === schoolId);

    if (filters) {
      if (filters.returnedById) {
        result = result.filter((r) => r.returnedById === filters.returnedById);
      }
      if (filters.departmentId && filters.departmentId !== 'ALL') {
        result = result.filter((r) => r.departmentId === filters.departmentId);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        result = result.filter((r) => r.returnLocationId === filters.locationId);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.toLowerCase().trim();
        result = result.filter(
          (r) =>
            r.returnNumber.toLowerCase().includes(q) ||
            r.returnedByName.toLowerCase().includes(q) ||
            r.reason.toLowerCase().includes(q) ||
            (r.originalIssueNumber && r.originalIssueNumber.toLowerCase().includes(q)) ||
            r.items.some((i) => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
        );
      }
    }

    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, Math.min(100, filters?.limit || 20));
    const total = result.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = result.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: { total, page, limit, pages }
    };
  }

  // --------------------------------------------------------------------------
  // 4. BULK ASSET ALLOCATION (Part 14C Asset Integration)
  // --------------------------------------------------------------------------

  /**
   * Bulk assign multiple physical assets to a custodian or department.
   * Validates each asset individually and executes atomically with mutex locking.
   */
  static async bulkAllocateAssets(
    schoolId: string,
    payload: BulkAssetAllocationPayload,
    user: any
  ): Promise<{ assignedCount: number; assets: Asset[]; assignments: AssetAssignment[] }> {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    if (!payload.assetIds || payload.assetIds.length === 0) {
      throw new Error('Please select at least one asset to allocate.');
    }
    if (!payload.assigneeId || !payload.assigneeName) {
      throw new Error('Target assignee information is required.');
    }

    const assignedAssets: Asset[] = [];
    const assignments: AssetAssignment[] = [];

    for (const assetId of payload.assetIds) {
      const res = await AssetService.assignAsset(
        schoolId,
        assetId,
        {
          assigneeType: payload.assigneeType,
          assigneeId: payload.assigneeId,
          assigneeName: payload.assigneeName,
          department: payload.department,
          locationId: payload.locationId,
          locationName: payload.locationName,
          assignedDate: payload.assignedDate,
          expectedReturnDate: payload.expectedReturnDate,
          conditionAtHandover: payload.conditionAtHandover,
          handoverNotes: payload.handoverNotes,
          accessories: payload.accessories ? payload.accessories.map((a) => typeof a === 'string' ? a : a.name) : undefined
        },
        normalizedUser
      );
      assignedAssets.push(res.asset);
      assignments.push(res.assignment);
    }

    return {
      assignedCount: assignedAssets.length,
      assets: assignedAssets,
      assignments
    };
  }

  // --------------------------------------------------------------------------
  // 5. DEPARTMENT ALLOCATION SUMMARY
  // --------------------------------------------------------------------------

  /**
   * Aggregates active assets and inventory issues by department
   */
  static getDepartmentAllocations(schoolId: string): DepartmentAllocationSummary[] {
    ensureInventoryCollections();

    const departments = database.departments || [];
    const assets = database.assets.filter((a) => a.schoolId === schoolId && a.status === 'ASSIGNED');
    const issues = database.stockIssues.filter((i) => i.schoolId === schoolId);

    return departments.map((dept) => {
      const deptAssets = assets.filter(
        (a) => a.department === dept.name || a.department === dept.code
      );
      const deptIssues = issues.filter(
        (i) => i.departmentId === dept.id || i.departmentName === dept.name
      );

      let totalVolume = 0;
      deptIssues.forEach((issue) => {
        issue.items.forEach((item) => {
          totalVolume += item.quantityIssued;
        });
      });

      const staffCount = (database.staffProfiles || []).filter(
        (s) => s.departmentId === dept.id || s.departmentName === dept.name
      ).length;

      const locCount = (database.inventoryLocations || []).filter(
        (l) => l.schoolId === schoolId && (l.departmentId === dept.id || l.department === dept.name)
      ).length;

      return {
        departmentId: dept.id,
        departmentName: dept.name,
        assignedAssetsCount: deptAssets.length,
        totalIssuedInventoryVolume: totalVolume,
        recentIssuesCount: deptIssues.length,
        activeStaffCount: staffCount,
        locationsCount: locCount
      };
    });
  }
}
