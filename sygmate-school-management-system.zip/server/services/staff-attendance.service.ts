/**
 * Sygmate School Management System
 * Staff Attendance, Work Schedule & Leave Integration (Part 12B)
 * Core Staff Attendance Service
 */

import { database } from '../db/database.js';
import {
  StaffProfile,
  StaffAttendanceRecord,
  StaffAttendanceStatus,
  StaffWorkSchedule,
  StaffWorkScheduleScope,
  StaffEffectiveSchedule,
  StaffDailyAttendanceResponse,
  StaffDailyRosterItem,
  StaffMonthlyAttendanceResponse,
  StaffMonthlyMatrixDay,
  StaffMonthlyMatrixRow,
  StaffAttendanceStatsResponse,
  StaffAttendanceCorrectionHistoryItem,
  MarkStaffAttendancePayload,
  BulkMarkStaffAttendancePayload,
  CorrectStaffAttendancePayload,
  CreateStaffSchedulePayload,
  UpdateStaffSchedulePayload,
  StaffLeaveApplicationPayload,
  ReviewStaffLeavePayload,
  LeaveApplication,
  LeaveStatus,
  User,
  TeacherAttendanceRecord,
  TeacherAttendanceCorrectionHistoryItem
} from '../../src/types/index.js';
import { logAudit } from '../security/audit.js';
import { getDateWorkingStatus, calculateLeaveWorkingDates } from '../routes/attendance.routes.js';

function getStaffFullName(staff: StaffProfile): string {
  if (staff.displayName && staff.displayName.trim().length > 0) {
    return staff.displayName.trim();
  }
  return `${staff.firstName || ''} ${staff.lastName || ''}`.trim() || 'Staff Member';
}

class StaffAttendanceService {
  // =========================================================================
  // 1. WORK SCHEDULE RESOLUTION ENGINE
  // =========================================================================

  /**
   * Resolves the effective schedule for a specific staff member on a specific date.
   * Hierarchical Priority:
   * 1. Individual Staff Schedule (Priority 1)
   * 2. Designation Schedule (Priority 2)
   * 3. Department Schedule (Priority 3)
   * 4. Staff Type / Category Schedule (Priority 4)
   * 5. School Default Schedule (Priority 5)
   */
  public resolveEffectiveSchedule(staffId: string, dateStr: string): StaffEffectiveSchedule {
    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) {
      throw new Error(`Staff member with ID '${staffId}' not found.`);
    }

    const staffName = getStaffFullName(staff);
    const [year, month, day] = dateStr.split('-').map(Number);
    const dateObj = new Date(year, month - 1, day);
    const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 1 = Monday ... 6 = Saturday
    const dayNames = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'] as const;
    const dayName = dayNames[dayOfWeek];

    // Check institutional school calendar status for this date
    const targetSessionId = database.schoolSettings.academicSessionId;
    const calStatus = getDateWorkingStatus(dateStr, targetSessionId);

    const activeSchedules = (database.staffWorkSchedules || [])
      .filter((s) => s.isActive)
      .filter((s) => s.effectiveFrom <= dateStr && (!s.effectiveTo || s.effectiveTo >= dateStr))
      .sort((a, b) => a.priority - b.priority);

    // 1. Check Individual schedule (Priority 1)
    let matchedSchedule = activeSchedules.find(
      (s) => s.scope === 'INDIVIDUAL' && (s.staffId === staff.id || s.employeeCode === staff.employeeCode)
    );

    // 2. Check Designation schedule (Priority 2)
    if (!matchedSchedule && staff.designationId) {
      matchedSchedule = activeSchedules.find(
        (s) => s.scope === 'DESIGNATION' && s.designationId === staff.designationId
      );
    }

    // 3. Check Department schedule (Priority 3)
    if (!matchedSchedule && staff.departmentId) {
      matchedSchedule = activeSchedules.find(
        (s) => s.scope === 'DEPARTMENT' && s.departmentId === staff.departmentId
      );
    }

    // 4. Check Staff Type schedule (Priority 4)
    if (!matchedSchedule && staff.staffType) {
      matchedSchedule = activeSchedules.find(
        (s) => s.scope === 'STAFF_TYPE' && s.staffType === staff.staffType
      );
    }

    // 5. Fallback to School Default schedule (Priority 5)
    if (!matchedSchedule) {
      matchedSchedule = activeSchedules.find((s) => s.scope === 'SCHOOL_DEFAULT');
    }

    // Default fallback timings if no schedule matched
    let isWorkingDay = true;
    let startTime = '08:00';
    let endTime = '16:00';
    let breakStartTime = '12:00';
    let breakEndTime = '13:00';
    let breakMinutes = 60;
    let scheduleId = 'sched-fallback';
    let scheduleName = 'Standard Fallback Hours';
    let scheduleScope: StaffWorkScheduleScope = 'SCHOOL_DEFAULT';
    let priority = 5;

    if (matchedSchedule) {
      scheduleId = matchedSchedule.id;
      scheduleName = matchedSchedule.name;
      scheduleScope = matchedSchedule.scope;
      priority = matchedSchedule.priority;

      const dayConfig = matchedSchedule.days?.find((d) => d.dayOfWeek === dayOfWeek);
      if (dayConfig) {
        isWorkingDay = dayConfig.isWorkingDay;
        if (dayConfig.startTime) startTime = dayConfig.startTime;
        if (dayConfig.endTime) endTime = dayConfig.endTime;
        if (dayConfig.breakStartTime) breakStartTime = dayConfig.breakStartTime;
        if (dayConfig.breakEndTime) breakEndTime = dayConfig.breakEndTime;
        if (dayConfig.breakMinutes !== undefined) breakMinutes = dayConfig.breakMinutes;
      }
    }

    // Reconcile with Institutional School Calendar
    let finalDayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY' = 'WORKING_DAY';
    let finalReason: string | undefined = calStatus.reason;

    if (calStatus.dayType === 'HOLIDAY') {
      isWorkingDay = false;
      finalDayType = 'HOLIDAY';
      finalReason = calStatus.reason;
    } else if (calStatus.dayType === 'SPECIAL_WORKING_DAY') {
      isWorkingDay = true;
      finalDayType = 'SPECIAL_WORKING_DAY';
      finalReason = calStatus.reason;
    } else if (!isWorkingDay) {
      finalDayType = dayOfWeek === 0 || dayOfWeek === 6 ? 'WEEKEND' : 'WEEKEND';
      finalReason = 'Scheduled Rest Day';
    } else if (calStatus.dayType === 'WEEKEND') {
      // If calendar says weekend but staff schedule explicitly marked it as working (e.g., security shift)
      if (isWorkingDay && matchedSchedule && matchedSchedule.scope !== 'SCHOOL_DEFAULT') {
        finalDayType = 'WORKING_DAY';
        finalReason = `Rostered Operational Shift (${matchedSchedule.name})`;
      } else {
        isWorkingDay = false;
        finalDayType = 'WEEKEND';
        finalReason = calStatus.reason;
      }
    }

    return {
      staffId: staff.id,
      staffName,
      employeeCode: staff.employeeCode,
      staffType: staff.staffType,
      departmentName: staff.departmentName || 'General Administration',
      date: dateStr,
      dayOfWeek,
      dayName,
      isWorkingDay,
      isCalendarWorkingDay: calStatus.isWorkingDay,
      dayType: finalDayType,
      dayReason: finalReason,
      startTime,
      endTime,
      breakStartTime,
      breakEndTime,
      breakMinutes,
      scheduleId,
      scheduleName,
      scheduleScope,
      priority
    };
  }

  // =========================================================================
  // 2. DAILY STAFF ATTENDANCE ROSTER
  // =========================================================================

  /**
   * Retrieves the daily attendance roster for all staff on a specific date,
   * unifying non-teaching staff and teachers, with effective work schedules and live statistics.
   */
  public getStaffDailyRoster(
    dateStr: string,
    filters?: {
      departmentId?: string;
      staffType?: string;
      status?: string;
      search?: string;
      academicSessionId?: string;
    }
  ): StaffDailyAttendanceResponse {
    const targetSessionId = filters?.academicSessionId || database.schoolSettings.academicSessionId;
    const session =
      database.academicSessions.find((s) => s.id === targetSessionId) ||
      database.academicSessions.find((s) => s.isActive) ||
      database.academicSessions[0];

    const calStatus = getDateWorkingStatus(dateStr, session?.id);

    // Get all active staff
    const allStaff = (database.staffProfiles || []).filter(
      (s) => s.employmentStatus === 'active' || s.employmentStatus === 'probation' || s.employmentStatus === 'on_leave'
    );

    const staffRecords = (database.staffAttendanceRecords || []).filter(
      (r) => r.date === dateStr && !r.isDeleted
    );
    const teacherRecords = (database.teacherAttendanceRecords || []).filter(
      (r) => r.date === dateStr && !r.isDeleted
    );

    const roster: StaffDailyRosterItem[] = allStaff.map((staff) => {
      const staffName = getStaffFullName(staff);
      let effectiveSchedule: StaffEffectiveSchedule;
      try {
        effectiveSchedule = this.resolveEffectiveSchedule(staff.id, dateStr);
      } catch {
        effectiveSchedule = {
          staffId: staff.id,
          staffName,
          employeeCode: staff.employeeCode,
          staffType: staff.staffType,
          departmentName: staff.departmentName || '',
          date: dateStr,
          dayOfWeek: new Date(dateStr).getDay(),
          dayName: 'MONDAY',
          isWorkingDay: calStatus.isWorkingDay,
          isCalendarWorkingDay: calStatus.isWorkingDay,
          dayType: calStatus.dayType as any,
          startTime: '08:00',
          endTime: '16:00',
          breakMinutes: 60,
          scheduleId: 'default',
          scheduleName: 'Default Schedule',
          scheduleScope: 'SCHOOL_DEFAULT',
          priority: 5
        };
      }

      // Check existing staff attendance record
      let record = staffRecords.find((r) => r.staffId === staff.id);

      // If no staff record exists but staff is linked to a teacher, check teacher record
      if (!record && staff.teacherProfileId) {
        const tRec = teacherRecords.find((tr) => tr.teacherProfileId === staff.teacherProfileId);
        if (tRec) {
          record = {
            id: tRec.id,
            staffId: staff.id,
            teacherProfileId: staff.teacherProfileId,
            userId: staff.userId,
            staffName,
            employeeCode: staff.employeeCode,
            staffType: staff.staffType,
            departmentId: staff.departmentId,
            departmentName: staff.departmentName,
            designation: staff.designation,
            avatarUrl: staff.avatarUrl,
            academicSessionId: tRec.academicSessionId,
            date: tRec.date,
            status: tRec.status,
            checkInTime: tRec.checkInTime,
            checkOutTime: tRec.checkOutTime,
            remarks: tRec.remarks,
            isOverridden: tRec.isOverridden,
            overrideReason: tRec.overrideReason,
            history: tRec.history as any,
            createdBy: tRec.createdBy,
            createdByName: tRec.createdByName,
            updatedBy: tRec.updatedBy,
            updatedByName: tRec.updatedByName,
            createdAt: tRec.createdAt,
            updatedAt: tRec.updatedAt
          };
        }
      }

      return {
        staffId: staff.id,
        teacherProfileId: staff.teacherProfileId,
        userId: staff.userId,
        staffName,
        employeeCode: staff.employeeCode,
        staffType: staff.staffType,
        departmentId: staff.departmentId,
        departmentName: staff.departmentName,
        designation: staff.designation,
        avatarUrl: staff.avatarUrl,
        status: record?.status,
        recordId: record?.id,
        checkInTime: record?.checkInTime,
        checkOutTime: record?.checkOutTime,
        remarks: record?.remarks,
        isOverridden: record?.isOverridden,
        overrideReason: record?.overrideReason,
        history: record?.history,
        effectiveSchedule,
        updatedAt: record?.updatedAt,
        updatedByName: record?.updatedByName
      };
    });

    // Compute institution stats before filtering
    const totalStaff = roster.length;
    let markedStaff = 0;
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;
    let halfDayCount = 0;
    let leaveCount = 0;
    let excusedCount = 0;

    for (const item of roster) {
      if (item.status) {
        markedStaff++;
        switch (item.status) {
          case 'PRESENT':
            presentCount++;
            break;
          case 'ABSENT':
            absentCount++;
            break;
          case 'LATE':
            lateCount++;
            break;
          case 'HALF_DAY':
            halfDayCount++;
            break;
          case 'LEAVE':
            leaveCount++;
            break;
          case 'EXCUSED':
            excusedCount++;
            break;
        }
      }
    }

    const unmarkedCount = totalStaff - markedStaff;
    const rateEligible = presentCount + lateCount + halfDayCount * 0.5;
    const attendanceRate = totalStaff > 0 ? Math.round((rateEligible / totalStaff) * 1000) / 10 : 0;

    // Apply filters
    let filteredRoster = roster;
    if (filters?.departmentId && filters.departmentId !== 'ALL') {
      filteredRoster = filteredRoster.filter((item) => item.departmentId === filters.departmentId);
    }
    if (filters?.staffType && filters.staffType !== 'ALL') {
      filteredRoster = filteredRoster.filter((item) => item.staffType === filters.staffType);
    }
    if (filters?.status && filters.status !== 'ALL') {
      if (filters.status === 'UNMARKED') {
        filteredRoster = filteredRoster.filter((item) => !item.status);
      } else {
        filteredRoster = filteredRoster.filter((item) => item.status === filters.status);
      }
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      filteredRoster = filteredRoster.filter(
        (item) =>
          item.staffName.toLowerCase().includes(q) ||
          item.employeeCode.toLowerCase().includes(q) ||
          (item.designation || '').toLowerCase().includes(q) ||
          (item.departmentName || '').toLowerCase().includes(q)
      );
    }

    // Sort by department name, then staff name
    filteredRoster.sort((a, b) => {
      const depA = a.departmentName || '';
      const depB = b.departmentName || '';
      if (depA !== depB) return depA.localeCompare(depB);
      return a.staffName.localeCompare(b.staffName);
    });

    return {
      date: dateStr,
      academicSessionId: session?.id || 'session-2026-2027',
      academicSessionName: session?.name || 'Academic Session 2026-2027',
      dayType: calStatus.dayType,
      isWorkingDay: calStatus.isWorkingDay,
      dayReason: calStatus.reason,
      canMarkAttendance: calStatus.isWorkingDay,
      stats: {
        totalStaff,
        markedStaff,
        presentCount,
        absentCount,
        lateCount,
        halfDayCount,
        leaveCount,
        excusedCount,
        unmarkedCount,
        attendanceRate
      },
      roster: filteredRoster
    };
  }

  // =========================================================================
  // 3. MARK & BULK MARK ATTENDANCE
  // =========================================================================

  /**
   * Mark individual staff attendance with automatic teacher profile synchronization
   * and calendar working status validation.
   */
  public markStaffAttendance(
    payload: MarkStaffAttendancePayload,
    user: User,
    ipAddress?: string
  ): StaffAttendanceRecord {
    const {
      staffId,
      date,
      status,
      checkInTime,
      checkOutTime,
      remarks,
      academicSessionId,
      allowOverride,
      overrideReason
    } = payload;

    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) {
      throw new Error(`Staff member with ID '${staffId}' not found.`);
    }

    const staffName = getStaffFullName(staff);
    const targetSessionId =
      academicSessionId || database.schoolSettings.academicSessionId;
    const session =
      database.academicSessions.find((s) => s.id === targetSessionId) ||
      database.academicSessions.find((s) => s.isActive) ||
      database.academicSessions[0];

    // Calendar check: allowOverride required on holidays/weekends unless scheduled operational shift
    const calStatus = getDateWorkingStatus(date, session?.id);
    if (!calStatus.isWorkingDay && !allowOverride) {
      const schedule = this.resolveEffectiveSchedule(staffId, date);
      if (!schedule.isWorkingDay) {
        throw new Error(
          `Cannot mark attendance on non-working day (${date} is a ${calStatus.dayType}: ${calStatus.reason}). Super Admin override required with reason.`
        );
      }
    }

    if (!database.staffAttendanceRecords) {
      database.staffAttendanceRecords = [];
    }

    const now = new Date().toISOString();
    const existingIndex = database.staffAttendanceRecords.findIndex(
      (r) => r.staffId === staffId && r.date === date && !r.isDeleted
    );

    let resultRecord: StaffAttendanceRecord;

    if (existingIndex !== -1) {
      const prev = database.staffAttendanceRecords[existingIndex];
      const historyItem: StaffAttendanceCorrectionHistoryItem = {
        id: `s-hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        fromStatus: prev.status,
        toStatus: status,
        fromCheckInTime: prev.checkInTime,
        toCheckInTime: checkInTime || prev.checkInTime,
        fromCheckOutTime: prev.checkOutTime,
        toCheckOutTime: checkOutTime || prev.checkOutTime,
        reason: overrideReason || remarks || `Updated attendance status from ${prev.status} to ${status}`,
        correctedByUserId: user.id,
        correctedByUserName: user.name,
        correctedAt: now
      };

      resultRecord = {
        ...prev,
        status,
        checkInTime: checkInTime !== undefined ? checkInTime : prev.checkInTime,
        checkOutTime: checkOutTime !== undefined ? checkOutTime : prev.checkOutTime,
        remarks: remarks !== undefined ? remarks : prev.remarks,
        isOverridden: !!allowOverride || prev.isOverridden,
        overrideReason: overrideReason || prev.overrideReason,
        updatedBy: user.id,
        updatedByName: user.name,
        updatedAt: now,
        history: [...(prev.history || []), historyItem]
      };

      database.staffAttendanceRecords[existingIndex] = resultRecord;

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'STAFF_ATTENDANCE_RECORD',
        entityType: 'STAFF_ATTENDANCE_RECORD',
        entityId: resultRecord.id,
        details: `Updated staff attendance for ${staffName} on ${date} from ${prev.status} to ${status}.`,
        ipAddress
      });
    } else {
      const newRecordId = `s-att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      resultRecord = {
        id: newRecordId,
        staffId: staff.id,
        teacherProfileId: staff.teacherProfileId,
        userId: staff.userId,
        staffName,
        employeeCode: staff.employeeCode,
        staffType: staff.staffType,
        departmentId: staff.departmentId,
        departmentName: staff.departmentName,
        designationId: staff.designationId,
        designation: staff.designation,
        avatarUrl: staff.avatarUrl,
        academicSessionId: session?.id || 'session-2026-2027',
        academicSessionName: session?.name || 'Academic Session 2026-2027',
        date,
        status,
        checkInTime: checkInTime || '',
        checkOutTime: checkOutTime || '',
        remarks: remarks || '',
        isOverridden: !!allowOverride,
        overrideReason: overrideReason || '',
        history: [],
        createdBy: user.id,
        createdByName: user.name,
        updatedBy: user.id,
        updatedByName: user.name,
        createdAt: now,
        updatedAt: now
      };

      database.staffAttendanceRecords.push(resultRecord);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        entity: 'STAFF_ATTENDANCE_RECORD',
        entityType: 'STAFF_ATTENDANCE_RECORD',
        entityId: newRecordId,
        details: `Recorded staff attendance for ${staffName} on ${date} as ${status}.`,
        ipAddress
      });
    }

    // Two-Way Sync: If this staff member is a teacher, synchronize teacherAttendanceRecords
    if (staff.teacherProfileId) {
      this.syncTeacherAttendanceRecord(staff.teacherProfileId, date, status, checkInTime, checkOutTime, remarks, user, now, overrideReason);
    }

    return resultRecord;
  }

  /**
   * Bulk mark attendance for multiple staff members in one request
   */
  public bulkMarkStaffAttendance(
    payload: BulkMarkStaffAttendancePayload,
    user: User,
    ipAddress?: string
  ): { savedCount: number; records: StaffAttendanceRecord[] } {
    const { date, records, allowOverride, overrideReason, academicSessionId } = payload;
    if (!date || !records || !Array.isArray(records) || records.length === 0) {
      throw new Error('Valid date and an array of records are required for bulk marking.');
    }

    const targetSessionId = academicSessionId || database.schoolSettings.academicSessionId;
    const calStatus = getDateWorkingStatus(date, targetSessionId);
    if (!calStatus.isWorkingDay && !allowOverride) {
      throw new Error(
        `Cannot bulk mark attendance on a ${calStatus.dayType} (${calStatus.reason}) without Super Admin override.`
      );
    }

    const savedRecords: StaffAttendanceRecord[] = [];

    for (const item of records) {
      try {
        const saved = this.markStaffAttendance(
          {
            staffId: item.staffId,
            date,
            status: item.status,
            checkInTime: item.checkInTime,
            checkOutTime: item.checkOutTime,
            remarks: item.remarks,
            academicSessionId,
            allowOverride,
            overrideReason
          },
          user,
          ipAddress
        );
        savedRecords.push(saved);
      } catch (err: any) {
        console.error(`[Bulk Mark Warning]: Failed to mark staff ID ${item.staffId}:`, err.message);
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'BULK_UPDATE',
      entity: 'STAFF_ATTENDANCE_RECORD',
      entityType: 'STAFF_ATTENDANCE_RECORD',
      entityId: `bulk-${date}`,
      details: `Bulk recorded staff attendance for ${savedRecords.length} staff members on ${date}.`,
      ipAddress
    });

    return {
      savedCount: savedRecords.length,
      records: savedRecords
    };
  }

  /**
   * Correct or adjust an existing staff attendance record with full audit history
   */
  public correctStaffAttendance(
    recordId: string,
    payload: CorrectStaffAttendancePayload,
    user: User,
    ipAddress?: string
  ): StaffAttendanceRecord {
    if (!database.staffAttendanceRecords) {
      database.staffAttendanceRecords = [];
    }

    const recordIndex = database.staffAttendanceRecords.findIndex(
      (r) => r.id === recordId && !r.isDeleted
    );
    if (recordIndex === -1) {
      throw new Error(`Staff attendance record with ID '${recordId}' not found.`);
    }

    const record = database.staffAttendanceRecords[recordIndex];
    const now = new Date().toISOString();

    const historyItem: StaffAttendanceCorrectionHistoryItem = {
      id: `s-hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      fromStatus: record.status,
      toStatus: payload.status || record.status,
      fromCheckInTime: record.checkInTime,
      toCheckInTime: payload.checkInTime !== undefined ? payload.checkInTime : record.checkInTime,
      fromCheckOutTime: record.checkOutTime,
      toCheckOutTime: payload.checkOutTime !== undefined ? payload.checkOutTime : record.checkOutTime,
      reason: payload.reason,
      correctedByUserId: user.id,
      correctedByUserName: user.name,
      correctedAt: now
    };

    const updatedRecord: StaffAttendanceRecord = {
      ...record,
      status: payload.status || record.status,
      checkInTime: payload.checkInTime !== undefined ? payload.checkInTime : record.checkInTime,
      checkOutTime: payload.checkOutTime !== undefined ? payload.checkOutTime : record.checkOutTime,
      remarks: payload.remarks !== undefined ? payload.remarks : record.remarks,
      isOverridden: true,
      overrideReason: payload.reason,
      updatedBy: user.id,
      updatedByName: user.name,
      updatedAt: now,
      history: [...(record.history || []), historyItem]
    };

    database.staffAttendanceRecords[recordIndex] = updatedRecord;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'STAFF_ATTENDANCE_RECORD',
      entityType: 'STAFF_ATTENDANCE_RECORD',
      entityId: record.id,
      details: `Corrected staff attendance for ${record.staffName} on ${record.date} to ${updatedRecord.status}. Reason: ${payload.reason}`,
      ipAddress
    });

    if (record.teacherProfileId) {
      this.syncTeacherAttendanceRecord(
        record.teacherProfileId,
        record.date,
        updatedRecord.status,
        updatedRecord.checkInTime,
        updatedRecord.checkOutTime,
        updatedRecord.remarks,
        user,
        now,
        payload.reason
      );
    }

    return updatedRecord;
  }

  // =========================================================================
  // 4. MONTHLY MATRIX & STATS
  // =========================================================================

  /**
   * Generates comprehensive monthly attendance matrix for all staff or filtered subset
   */
  public getStaffMonthlyMatrix(
    year: number,
    month: number, // 1 to 12
    filters?: {
      departmentId?: string;
      staffType?: string;
      search?: string;
      academicSessionId?: string;
    }
  ): StaffMonthlyAttendanceResponse {
    const targetSessionId = filters?.academicSessionId || database.schoolSettings.academicSessionId;
    const session =
      database.academicSessions.find((s) => s.id === targetSessionId) ||
      database.academicSessions.find((s) => s.isActive) ||
      database.academicSessions[0];

    const daysInMonth = new Date(year, month, 0).getDate();
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const monthName = monthNames[month - 1];

    const days: StaffMonthlyMatrixDay[] = [];
    let totalWorkingDays = 0;

    for (let d = 1; d <= daysInMonth; d++) {
      const dayPad = String(d).padStart(2, '0');
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${dayPad}`;
      const dateObj = new Date(year, month - 1, d);
      const dayOfWeek = dateObj.getDay();
      const dayNamesShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const status = getDateWorkingStatus(dateStr, session?.id);

      if (status.isWorkingDay) {
        totalWorkingDays++;
      }

      days.push({
        date: dateStr,
        dayOfMonth: d,
        dayOfWeek,
        dayName: dayNamesShort[dayOfWeek],
        dayType: status.dayType,
        isWorkingDay: status.isWorkingDay,
        reason: status.reason
      });
    }

    let staffList = (database.staffProfiles || []).filter(
      (s) => s.employmentStatus === 'active' || s.employmentStatus === 'probation' || s.employmentStatus === 'on_leave'
    );

    if (filters?.departmentId && filters.departmentId !== 'ALL') {
      staffList = staffList.filter((s) => s.departmentId === filters.departmentId);
    }
    if (filters?.staffType && filters.staffType !== 'ALL') {
      staffList = staffList.filter((s) => s.staffType === filters.staffType);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      staffList = staffList.filter(
        (s) =>
          getStaffFullName(s).toLowerCase().includes(q) ||
          s.employeeCode.toLowerCase().includes(q) ||
          (s.departmentName || '').toLowerCase().includes(q) ||
          (s.designation || '').toLowerCase().includes(q)
      );
    }

    const startDateMonth = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDateMonth = `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;

    const staffAttendanceRecords = (database.staffAttendanceRecords || []).filter(
      (r) => r.date >= startDateMonth && r.date <= endDateMonth && !r.isDeleted
    );
    const teacherAttendanceRecords = (database.teacherAttendanceRecords || []).filter(
      (r) => r.date >= startDateMonth && r.date <= endDateMonth && !r.isDeleted
    );

    let totalPresentSum = 0;
    let totalAbsentSum = 0;
    let totalLateSum = 0;
    let totalHalfDaySum = 0;
    let totalLeaveSum = 0;
    let totalExcusedSum = 0;
    let rateSum = 0;

    const rows: StaffMonthlyMatrixRow[] = staffList.map((staff) => {
      const staffName = getStaffFullName(staff);
      const attendanceByDate: StaffMonthlyMatrixRow['attendanceByDate'] = {};
      let present = 0;
      let absent = 0;
      let late = 0;
      let halfDay = 0;
      let leave = 0;
      let excused = 0;
      let unmarked = 0;

      for (const dayItem of days) {
        let rec = staffAttendanceRecords.find((r) => r.staffId === staff.id && r.date === dayItem.date);
        if (!rec && staff.teacherProfileId) {
          const tRec = teacherAttendanceRecords.find(
            (tr) => tr.teacherProfileId === staff.teacherProfileId && tr.date === dayItem.date
          );
          if (tRec) {
            rec = {
              id: tRec.id,
              staffId: staff.id,
              status: tRec.status,
              checkInTime: tRec.checkInTime,
              checkOutTime: tRec.checkOutTime,
              remarks: tRec.remarks,
              isOverridden: tRec.isOverridden
            } as any;
          }
        }

        if (rec) {
          attendanceByDate[dayItem.date] = {
            status: rec.status,
            recordId: rec.id,
            checkInTime: rec.checkInTime,
            checkOutTime: rec.checkOutTime,
            remarks: rec.remarks,
            isOverridden: rec.isOverridden
          };

          switch (rec.status) {
            case 'PRESENT':
              present++;
              break;
            case 'ABSENT':
              absent++;
              break;
            case 'LATE':
              late++;
              break;
            case 'HALF_DAY':
              halfDay++;
              break;
            case 'LEAVE':
              leave++;
              break;
            case 'EXCUSED':
              excused++;
              break;
          }
        } else if (dayItem.isWorkingDay) {
          unmarked++;
        }
      }

      const applicableDays = totalWorkingDays > 0 ? totalWorkingDays : 1;
      const ratePoints = present + late + halfDay * 0.5;
      const rate = Math.round((ratePoints / applicableDays) * 1000) / 10;

      totalPresentSum += present;
      totalAbsentSum += absent;
      totalLateSum += late;
      totalHalfDaySum += halfDay;
      totalLeaveSum += leave;
      totalExcusedSum += excused;
      rateSum += rate;

      return {
        staffId: staff.id,
        teacherProfileId: staff.teacherProfileId,
        staffName,
        employeeCode: staff.employeeCode,
        staffType: staff.staffType,
        departmentName: staff.departmentName || 'General',
        designation: staff.designation || 'Staff',
        attendanceByDate,
        summary: {
          totalApplicableWorkingDays: totalWorkingDays,
          present,
          absent,
          late,
          halfDay,
          leave,
          excused,
          unmarked,
          rate
        }
      };
    });

    const totalStaff = rows.length;
    const avgRate = totalStaff > 0 ? Math.round((rateSum / totalStaff) * 10) / 10 : 0;

    return {
      academicSessionId: session?.id || 'session-2026-2027',
      academicSessionName: session?.name || 'Academic Session 2026-2027',
      year,
      month,
      monthName,
      days,
      staff: rows,
      overallSummary: {
        totalStaff,
        averageAttendanceRate: avgRate,
        totalPresent: totalPresentSum,
        totalAbsent: totalAbsentSum,
        totalLate: totalLateSum,
        totalHalfDay: totalHalfDaySum,
        totalLeave: totalLeaveSum,
        totalExcused: totalExcusedSum
      },
      totalWorkingDays
    };
  }

  /**
   * Institution-wide staff attendance statistics for dashboard and reporting
   */
  public getStaffAttendanceStats(targetDate?: string): StaffAttendanceStatsResponse {
    const date = targetDate || new Date().toISOString().split('T')[0];
    const dailyRoster = this.getStaffDailyRoster(date);

    const departments = database.departments || [];

    const byDepartment = departments.map((dept) => {
      const deptStaff = dailyRoster.roster.filter((r) => r.departmentId === dept.id);
      const totalStaff = deptStaff.length;
      const presentCount = deptStaff.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length;
      const attendanceRate = totalStaff > 0 ? Math.round((presentCount / totalStaff) * 1000) / 10 : 0;
      return {
        departmentId: dept.id,
        departmentName: dept.name,
        totalStaff,
        presentCount,
        attendanceRate
      };
    });

    const staffTypes = ['teaching', 'administrative', 'support', 'management', 'operational'];
    const byStaffType = staffTypes.map((type) => {
      const typeStaff = dailyRoster.roster.filter((r) => r.staffType === type);
      const totalStaff = typeStaff.length;
      const presentCount = typeStaff.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length;
      const attendanceRate = totalStaff > 0 ? Math.round((presentCount / totalStaff) * 1000) / 10 : 0;
      return {
        staffType: type,
        totalStaff,
        presentCount,
        attendanceRate
      };
    });

    const pendingLeavesCount = (database.leaveApplications || []).filter(
      (l) => l.applicantType === 'STAFF' && (l.status === 'PENDING' || l.status === 'SUBMITTED')
    ).length;

    const totalActiveSchedules = (database.staffWorkSchedules || []).filter((s) => s.isActive).length;

    return {
      totalStaff: dailyRoster.stats.totalStaff,
      todayMarked: dailyRoster.stats.markedStaff,
      todayPresent: dailyRoster.stats.presentCount,
      todayAbsent: dailyRoster.stats.absentCount,
      todayLate: dailyRoster.stats.lateCount,
      todayLeave: dailyRoster.stats.leaveCount,
      todayRate: dailyRoster.stats.attendanceRate,
      monthlyAverageRate: dailyRoster.stats.attendanceRate,
      totalActiveSchedules,
      pendingLeavesCount,
      byDepartment: byDepartment.filter((d) => d.totalStaff > 0),
      byStaffType
    };
  }

  // =========================================================================
  // 5. WORK SCHEDULE MANAGEMENT
  // =========================================================================

  public getWorkSchedules(filters?: {
    scope?: string;
    isActive?: boolean;
    departmentId?: string;
    designationId?: string;
    search?: string;
  }): StaffWorkSchedule[] {
    let list = database.staffWorkSchedules || [];

    if (filters?.scope && filters.scope !== 'ALL') {
      list = list.filter((s) => s.scope === filters.scope);
    }
    if (filters?.isActive !== undefined) {
      list = list.filter((s) => s.isActive === filters.isActive);
    }
    if (filters?.departmentId && filters.departmentId !== 'ALL') {
      list = list.filter((s) => s.departmentId === filters.departmentId);
    }
    if (filters?.designationId && filters.designationId !== 'ALL') {
      list = list.filter((s) => s.designationId === filters.designationId);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          (s.staffName || '').toLowerCase().includes(q) ||
          (s.departmentName || '').toLowerCase().includes(q) ||
          (s.designationName || '').toLowerCase().includes(q)
      );
    }

    return list.sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name));
  }

  public getWorkScheduleById(id: string): StaffWorkSchedule | undefined {
    return (database.staffWorkSchedules || []).find((s) => s.id === id);
  }

  public createWorkSchedule(payload: CreateStaffSchedulePayload, user: User, ipAddress?: string): StaffWorkSchedule {
    if (!payload.name || !payload.scope || !payload.days || !payload.effectiveFrom) {
      throw new Error('Schedule Name, Scope, Days Configuration, and Effective From date are required.');
    }

    if (!database.staffWorkSchedules) {
      database.staffWorkSchedules = [];
    }

    // Determine priority based on scope
    const priorityMap: Record<StaffWorkScheduleScope, number> = {
      INDIVIDUAL: 1,
      DESIGNATION: 2,
      DEPARTMENT: 3,
      STAFF_TYPE: 4,
      SCHOOL_DEFAULT: 5
    };
    const priority = priorityMap[payload.scope] || 5;

    let staffName: string | undefined;
    let employeeCode: string | undefined;
    if (payload.staffId) {
      const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
      if (staff) {
        staffName = getStaffFullName(staff);
        employeeCode = staff.employeeCode;
      }
    }

    let designationName: string | undefined;
    if (payload.designationId) {
      const desig = (database.designations || []).find((d) => d.id === payload.designationId);
      if (desig) designationName = desig.title;
    }

    let departmentName: string | undefined;
    if (payload.departmentId) {
      const dept = (database.departments || []).find((d) => d.id === payload.departmentId);
      if (dept) departmentName = dept.name;
    }

    const now = new Date().toISOString();
    const newSchedule: StaffWorkSchedule = {
      id: `sched-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: payload.name,
      scope: payload.scope,
      priority,
      staffId: payload.staffId,
      staffName,
      employeeCode,
      designationId: payload.designationId,
      designationName,
      departmentId: payload.departmentId,
      departmentName,
      staffType: payload.staffType,
      days: payload.days,
      effectiveFrom: payload.effectiveFrom,
      effectiveTo: payload.effectiveTo,
      isActive: payload.isActive !== undefined ? payload.isActive : true,
      notes: payload.notes,
      createdAt: now,
      updatedAt: now,
      createdBy: user.id,
      createdByName: user.name
    };

    database.staffWorkSchedules.push(newSchedule);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'STAFF_WORK_SCHEDULE',
      entityType: 'STAFF_WORK_SCHEDULE',
      entityId: newSchedule.id,
      details: `Created work schedule '${newSchedule.name}' (${newSchedule.scope}, priority ${priority}).`,
      ipAddress
    });

    return newSchedule;
  }

  public updateWorkSchedule(
    id: string,
    payload: UpdateStaffSchedulePayload,
    user: User,
    ipAddress?: string
  ): StaffWorkSchedule {
    if (!database.staffWorkSchedules) {
      database.staffWorkSchedules = [];
    }

    const index = database.staffWorkSchedules.findIndex((s) => s.id === id);
    if (index === -1) {
      throw new Error(`Work schedule with ID '${id}' not found.`);
    }

    const existing = database.staffWorkSchedules[index];
    const now = new Date().toISOString();

    const priorityMap: Record<StaffWorkScheduleScope, number> = {
      INDIVIDUAL: 1,
      DESIGNATION: 2,
      DEPARTMENT: 3,
      STAFF_TYPE: 4,
      SCHOOL_DEFAULT: 5
    };
    const scope = payload.scope || existing.scope;
    const priority = priorityMap[scope] || existing.priority;

    const updated: StaffWorkSchedule = {
      ...existing,
      ...payload,
      scope,
      priority,
      updatedAt: now
    };

    database.staffWorkSchedules[index] = updated;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'STAFF_WORK_SCHEDULE',
      entityType: 'STAFF_WORK_SCHEDULE',
      entityId: id,
      details: `Updated work schedule '${updated.name}'.`,
      ipAddress
    });

    return updated;
  }

  public deleteWorkSchedule(id: string, user: User, ipAddress?: string): void {
    if (!database.staffWorkSchedules) return;

    const index = database.staffWorkSchedules.findIndex((s) => s.id === id);
    if (index === -1) {
      throw new Error(`Work schedule with ID '${id}' not found.`);
    }

    const sched = database.staffWorkSchedules[index];
    if (sched.scope === 'SCHOOL_DEFAULT') {
      throw new Error('The institutional School Default work schedule cannot be deleted.');
    }

    database.staffWorkSchedules.splice(index, 1);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'STAFF_WORK_SCHEDULE',
      entityType: 'STAFF_WORK_SCHEDULE',
      entityId: id,
      details: `Deleted work schedule '${sched.name}'.`,
      ipAddress
    });
  }

  // =========================================================================
  // 6. STAFF LEAVE INTEGRATION
  // =========================================================================

  /**
   * Submit a staff leave application (Part 12B)
   */
  public applyStaffLeave(
    payload: StaffLeaveApplicationPayload,
    user: User,
    ipAddress?: string
  ): LeaveApplication {
    const staffId = payload.staffId || (database.staffProfiles || []).find((s) => s.userId === user.id)?.id;
    if (!staffId) {
      throw new Error('Staff profile could not be determined for the submitting user.');
    }

    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) {
      throw new Error(`Staff member with ID '${staffId}' not found.`);
    }

    const staffName = getStaffFullName(staff);
    const leaveType = (database.leaveTypes || []).find((lt) => lt.id === payload.leaveTypeId);
    if (!leaveType) {
      throw new Error(`Leave type with ID '${payload.leaveTypeId}' not found.`);
    }

    const startDate = payload.startDate;
    const endDate = payload.endDate || startDate;

    const targetSessionId = database.schoolSettings.academicSessionId;
    const workingBreakdown = calculateLeaveWorkingDates(startDate, endDate, targetSessionId);

    const now = new Date().toISOString();
    const newLeaveId = `leave-staff-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    const leaveApp: LeaveApplication = {
      id: newLeaveId,
      applicantType: 'STAFF',
      applicantId: staff.id,
      userId: staff.userId || user.id,
      applicantName: staffName,
      staffId: staff.id,
      staffName,
      staffType: staff.staffType,
      designation: staff.designation,
      designationId: staff.designationId,
      employeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      academicSessionId: targetSessionId,
      academicSessionName: 'Academic Session 2026-2027',
      leaveTypeId: leaveType.id,
      leaveTypeName: leaveType.name,
      startDate,
      endDate,
      leaveDate: startDate,
      totalDays: workingBreakdown.totalCalendarDays || 1,
      workingDays: workingBreakdown.workingDates.length,
      reason: payload.reason,
      description: payload.description,
      remarks: payload.remarks,
      attachmentUrl: payload.attachmentUrl,
      attachmentName: payload.attachmentName,
      attachmentSize: payload.attachmentSize,
      attachmentType: payload.attachmentType,
      status: payload.status === 'DRAFT' ? 'DRAFT' : 'PENDING',
      submissionDate: now.split('T')[0],
      submittedAt: now,
      appliedAt: now,
      createdAt: now,
      updatedAt: now
    };

    if (!database.leaveApplications) {
      database.leaveApplications = [];
    }
    database.leaveApplications.push(leaveApp);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: newLeaveId,
      details: `Staff member ${staffName} submitted leave application for ${startDate} to ${endDate} (${workingBreakdown.workingDates.length} working days).`,
      ipAddress
    });

    return leaveApp;
  }

  /**
   * Helper to synchronize teacher attendance records when a teaching staff's attendance changes
   */
  private syncTeacherAttendanceRecord(
    teacherProfileId: string,
    date: string,
    status: StaffAttendanceStatus,
    checkInTime?: string,
    checkOutTime?: string,
    remarks?: string,
    user?: User,
    now?: string,
    overrideReason?: string
  ): void {
    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    const tIndex = database.teacherAttendanceRecords.findIndex(
      (r) => r.teacherProfileId === teacherProfileId && r.date === date && !r.isDeleted
    );

    const timestamp = now || new Date().toISOString();
    const userId = user?.id || 'usr-system';
    const userName = user?.name || 'System Auto-Sync';

    if (tIndex !== -1) {
      const prev = database.teacherAttendanceRecords[tIndex];
      const historyItem: TeacherAttendanceCorrectionHistoryItem = {
        id: `t-sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        fromStatus: prev.status,
        toStatus: status,
        fromCheckInTime: prev.checkInTime,
        toCheckInTime: checkInTime || prev.checkInTime,
        fromCheckOutTime: prev.checkOutTime,
        toCheckOutTime: checkOutTime || prev.checkOutTime,
        reason: overrideReason || remarks || 'Synchronized from Staff Attendance Management',
        correctedByUserId: userId,
        correctedByUserName: userName,
        correctedAt: timestamp
      };

      database.teacherAttendanceRecords[tIndex] = {
        ...prev,
        status,
        checkInTime: checkInTime !== undefined ? checkInTime : prev.checkInTime,
        checkOutTime: checkOutTime !== undefined ? checkOutTime : prev.checkOutTime,
        remarks: remarks !== undefined ? remarks : prev.remarks,
        updatedBy: userId,
        updatedByName: userName,
        updatedAt: timestamp,
        history: [...(prev.history || []), historyItem]
      };
    } else {
      const teacher = (database.teacherProfiles || []).find((t) => t.id === teacherProfileId);
      const teacherName = teacher ? `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() : 'Teacher';
      const newTeacherRecord: TeacherAttendanceRecord = {
        id: `t-att-sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        teacherProfileId,
        userId: teacher?.userId || userId,
        teacherName,
        employeeCode: teacher?.employeeCode || '',
        departmentId: teacher?.departmentId || '',
        departmentName: teacher?.department || '',
        academicSessionId: database.schoolSettings.academicSessionId || 'session-2026-2027',
        date,
        status,
        checkInTime: checkInTime || '',
        checkOutTime: checkOutTime || '',
        remarks: remarks || '',
        history: [],
        createdBy: userId,
        createdByName: userName,
        updatedBy: userId,
        updatedByName: userName,
        createdAt: timestamp,
        updatedAt: timestamp
      };
      database.teacherAttendanceRecords.push(newTeacherRecord);
    }
  }
}

export const staffAttendanceService = new StaffAttendanceService();
