/**
 * Sygmate School Management System
 * Staff Performance Management (Part 12E)
 * Core Business Logic & Orchestration Service
 */

import { database } from '../db/database.js';
import {
  PerformanceReviewCycle,
  CreateReviewCyclePayload,
  UpdateReviewCyclePayload,
  PerformanceCriterion,
  CreatePerformanceCriterionPayload,
  UpdatePerformanceCriterionPayload,
  PerformanceGoal,
  CreatePerformanceGoalPayload,
  UpdatePerformanceGoalPayload,
  UpdateGoalProgressPayload,
  StaffPerformanceReview,
  CreatePerformanceReviewPayload,
  SubmitSelfAssessmentPayload,
  SubmitSupervisorReviewPayload,
  SubmitHRReviewPayload,
  OverrideRatingPayload,
  AcknowledgeReviewPayload,
  TransitionReviewWorkflowPayload,
  PerformanceFeedbackItem,
  CreatePerformanceFeedbackPayload,
  PerformanceImprovementPlan,
  CreatePIPPayload,
  UpdatePIPPayload,
  AddPIPProgressNotePayload,
  UpdatePIPActionPayload,
  ClosePIPPayload,
  PerformanceDashboardMetrics,
  PerformanceFilterQuery,
  PerformanceReportSummary,
  RatingBand,
  ReviewWorkflowStatus,
  User,
  AuditLog,
  NotificationItem,
  StaffProfile
} from '../../src/types/index.js';

export class StaffPerformanceService {
  // ==========================================
  // HELPER METHODS (AUDIT & NOTIFICATIONS)
  // ==========================================

  private logAudit(
    action: string,
    entityType: string,
    entityId: string,
    actor?: User,
    details?: Record<string, any>
  ): void {
    const auditEntry: AuditLog = {
      id: `audit-perf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      userId: actor?.id || 'system',
      userName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Performance Evaluation Engine',
      userRole: actor?.role || 'SUPER_ADMIN',
      action,
      entityType,
      entityId,
      details: details ? JSON.stringify(details) : undefined,
      ipAddress: '127.0.0.1'
    };
    database.auditLogs.unshift(auditEntry);
  }

  private sendNotification(
    userId: string,
    title: string,
    message: string,
    category: 'system' | 'general' = 'general',
    link?: string
  ): void {
    const notif: NotificationItem = {
      id: `notif-perf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId,
      title,
      message,
      type: 'INFO',
      category,
      isRead: false,
      createdAt: new Date().toISOString(),
      link
    };
    database.notifications.unshift(notif);
  }

  public getRatingBand(score: number): RatingBand {
    if (score >= 90) return 'EXCEPTIONAL';
    if (score >= 75) return 'EXCEEDS_EXPECTATIONS';
    if (score >= 60) return 'MEETS_EXPECTATIONS';
    if (score >= 45) return 'NEEDS_IMPROVEMENT';
    return 'UNSATISFACTORY';
  }

  // ==========================================
  // 1. DASHBOARD & METRICS
  // ==========================================

  public getDashboardMetrics(): PerformanceDashboardMetrics {
    const cycles = database.performanceReviewCycles || [];
    const reviews = database.performanceReviews || [];
    const goals = database.performanceGoals || [];
    const pips = database.performanceImprovementPlans || [];

    const activeCycles = cycles.filter((c) => c.status === 'OPEN' || c.status === 'IN_PROGRESS');
    const inProgress = reviews.filter((r) =>
      ['SELF_ASSESSMENT', 'SUPERVISOR_REVIEW', 'HR_REVIEW'].includes(r.status)
    );
    const pendingSupervisor = reviews.filter((r) => r.status === 'SUPERVISOR_REVIEW');
    const pendingHR = reviews.filter((r) => r.status === 'HR_REVIEW');
    const completed = reviews.filter((r) =>
      ['FINALIZED', 'ACKNOWLEDGED', 'CLOSED'].includes(r.status)
    );
    const awaitingAck = reviews.filter(
      (r) => r.status === 'FINALIZED' && !r.acknowledgement?.isAcknowledged
    );

    const scoredReviews = reviews.filter(
      (r) =>
        r.hrReview?.finalCalculatedScore !== undefined ||
        r.supervisorReview?.calculatedScore !== undefined
    );

    const avgScore =
      scoredReviews.length > 0
        ? scoredReviews.reduce(
            (sum, r) =>
              sum + (r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore ?? 0),
            0
          ) / scoredReviews.length
        : 0;

    const ratingDistribution: Record<RatingBand, number> = {
      EXCEPTIONAL: 0,
      EXCEEDS_EXPECTATIONS: 0,
      MEETS_EXPECTATIONS: 0,
      NEEDS_IMPROVEMENT: 0,
      UNSATISFACTORY: 0
    };

    scoredReviews.forEach((r) => {
      const band =
        r.hrReview?.finalRatingBand ||
        this.getRatingBand(
          r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore ?? 0
        );
      if (ratingDistribution[band] !== undefined) {
        ratingDistribution[band]++;
      }
    });

    const goalsCompleted = goals.filter((g) => g.status === 'ACHIEVED').length;
    const goalsAtRisk = goals.filter(
      (g) => g.status === 'NOT_ACHIEVED' || (g.progressPercentage < 50 && new Date(g.dueDate) < new Date())
    ).length;

    const activePips = pips.filter((p) => p.status === 'ACTIVE' || p.status === 'UNDER_REVIEW').length;

    return {
      activeReviewCycles: activeCycles.length,
      reviewsInProgress: inProgress.length,
      pendingSupervisorReviews: pendingSupervisor.length,
      pendingHRReviews: pendingHR.length,
      completedReviews: completed.length,
      staffAwaitingAcknowledgement: awaitingAck.length,
      averageRating: Math.round(avgScore * 10) / 10,
      ratingDistribution,
      goalsCompleted,
      goalsAtRisk,
      totalGoals: goals.length,
      activeImprovementPlans: activePips
    };
  }

  // ==========================================
  // 2. REVIEW CYCLES
  // ==========================================

  public listReviewCycles(query?: PerformanceFilterQuery): {
    items: PerformanceReviewCycle[];
    total: number;
  } {
    let items = [...(database.performanceReviewCycles || [])];

    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.code.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q)
      );
    }

    if (query?.status) {
      items = items.filter((c) => c.status === query.status);
    }

    if (query?.academicSessionId) {
      items = items.filter((c) => c.academicSessionId === query.academicSessionId);
    }

    // Dynamic completed reviews count recalculation
    items = items.map((cycle) => {
      const cycleReviews = (database.performanceReviews || []).filter(
        (r) => r.reviewCycleId === cycle.id
      );
      const completedCount = cycleReviews.filter((r) =>
        ['FINALIZED', 'ACKNOWLEDGED', 'CLOSED'].includes(r.status)
      ).length;
      return {
        ...cycle,
        totalEligibleStaff: cycleReviews.length || cycle.totalEligibleStaff,
        completedReviewsCount: completedCount
      };
    });

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return {
      items,
      total: items.length
    };
  }

  public getReviewCycleById(id: string): PerformanceReviewCycle | null {
    const cycle = (database.performanceReviewCycles || []).find((c) => c.id === id);
    if (!cycle) return null;

    const cycleReviews = (database.performanceReviews || []).filter((r) => r.reviewCycleId === id);
    const completedCount = cycleReviews.filter((r) =>
      ['FINALIZED', 'ACKNOWLEDGED', 'CLOSED'].includes(r.status)
    ).length;

    return {
      ...cycle,
      totalEligibleStaff: cycleReviews.length || cycle.totalEligibleStaff,
      completedReviewsCount: completedCount
    };
  }

  public createReviewCycle(
    payload: CreateReviewCyclePayload,
    actor?: User
  ): PerformanceReviewCycle {
    const id = `prc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const academicSession = (database.academicSessions || []).find(
      (s) => s.id === payload.academicSessionId
    );

    const newCycle: PerformanceReviewCycle = {
      id,
      name: payload.name.trim(),
      code: payload.code.trim().toUpperCase(),
      description: payload.description?.trim() || '',
      academicSessionId: payload.academicSessionId,
      academicSessionName: academicSession?.name || 'Academic Session',
      reviewPeriod: payload.reviewPeriod.trim(),
      startDate: payload.startDate,
      endDate: payload.endDate,
      selfAssessmentDeadline: payload.selfAssessmentDeadline,
      supervisorReviewDeadline: payload.supervisorReviewDeadline,
      reviewType: payload.reviewType || 'ANNUAL',
      frequency: payload.frequency || 'ANNUAL',
      applicableStaffCategories: payload.applicableStaffCategories || ['ALL'],
      applicableDepartmentIds: payload.applicableDepartmentIds || [],
      applicableDesignationIds: payload.applicableDesignationIds || [],
      status: 'DRAFT',
      scoringModel: payload.scoringModel || 'WEIGHTED_100',
      allowSelfAssessment: payload.allowSelfAssessment ?? true,
      requireHODReview: payload.requireHODReview ?? true,
      requireHRFinalApproval: payload.requireHRFinalApproval ?? true,
      totalEligibleStaff: 0,
      completedReviewsCount: 0,
      createdBy: actor?.id || 'usr-admin-1',
      createdByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'System Admin',
      createdAt: now,
      updatedAt: now
    };

    database.performanceReviewCycles.unshift(newCycle);

    this.logAudit('CREATE_REVIEW_CYCLE', 'PerformanceReviewCycle', id, actor, {
      name: newCycle.name,
      code: newCycle.code,
      reviewPeriod: newCycle.reviewPeriod
    });

    return newCycle;
  }

  public updateReviewCycle(
    id: string,
    payload: UpdateReviewCyclePayload,
    actor?: User
  ): PerformanceReviewCycle {
    const cycle = (database.performanceReviewCycles || []).find((c) => c.id === id);
    if (!cycle) {
      throw new Error(`Review cycle with ID ${id} not found.`);
    }

    if (payload.name) cycle.name = payload.name.trim();
    if (payload.code) cycle.code = payload.code.trim().toUpperCase();
    if (payload.description !== undefined) cycle.description = payload.description.trim();
    if (payload.reviewPeriod) cycle.reviewPeriod = payload.reviewPeriod;
    if (payload.startDate) cycle.startDate = payload.startDate;
    if (payload.endDate) cycle.endDate = payload.endDate;
    if (payload.selfAssessmentDeadline !== undefined) cycle.selfAssessmentDeadline = payload.selfAssessmentDeadline;
    if (payload.supervisorReviewDeadline !== undefined) cycle.supervisorReviewDeadline = payload.supervisorReviewDeadline;
    if (payload.reviewType) cycle.reviewType = payload.reviewType;
    if (payload.frequency) cycle.frequency = payload.frequency;
    if (payload.applicableStaffCategories) cycle.applicableStaffCategories = payload.applicableStaffCategories;
    if (payload.applicableDepartmentIds !== undefined) cycle.applicableDepartmentIds = payload.applicableDepartmentIds;
    if (payload.applicableDesignationIds !== undefined) cycle.applicableDesignationIds = payload.applicableDesignationIds;
    if (payload.scoringModel) cycle.scoringModel = payload.scoringModel;
    if (payload.allowSelfAssessment !== undefined) cycle.allowSelfAssessment = payload.allowSelfAssessment;
    if (payload.requireHODReview !== undefined) cycle.requireHODReview = payload.requireHODReview;
    if (payload.requireHRFinalApproval !== undefined) cycle.requireHRFinalApproval = payload.requireHRFinalApproval;
    if (payload.status) cycle.status = payload.status;

    cycle.updatedAt = new Date().toISOString();

    this.logAudit('UPDATE_REVIEW_CYCLE', 'PerformanceReviewCycle', id, actor, {
      updatedFields: Object.keys(payload)
    });

    return cycle;
  }

  public transitionReviewCycleStatus(
    id: string,
    targetStatus: PerformanceReviewCycle['status'],
    actor?: User
  ): PerformanceReviewCycle {
    const cycle = (database.performanceReviewCycles || []).find((c) => c.id === id);
    if (!cycle) {
      throw new Error(`Review cycle with ID ${id} not found.`);
    }

    const prevStatus = cycle.status;
    cycle.status = targetStatus;
    cycle.updatedAt = new Date().toISOString();

    this.logAudit('TRANSITION_CYCLE_STATUS', 'PerformanceReviewCycle', id, actor, {
      from: prevStatus,
      to: targetStatus
    });

    return cycle;
  }

  public generateReviewsForCycle(cycleId: string, actor?: User): {
    generatedCount: number;
    cycle: PerformanceReviewCycle;
  } {
    const cycle = (database.performanceReviewCycles || []).find((c) => c.id === cycleId);
    if (!cycle) {
      throw new Error(`Review cycle with ID ${cycleId} not found.`);
    }

    const allStaff = database.staffProfiles || [];
    const existingReviews = database.performanceReviews || [];

    // Filter staff eligible for this cycle
    const eligibleStaff = allStaff.filter((staff) => {
      // Must be active or on probation
      if (staff.employmentStatus !== 'active' && staff.employmentStatus !== 'probation') {
        return false;
      }

      // Check category
      if (
        !cycle.applicableStaffCategories.includes('ALL') &&
        !cycle.applicableStaffCategories.map(c => c.toLowerCase()).includes(staff.staffType.toLowerCase())
      ) {
        return false;
      }

      // Check department if scoped
      if (
        cycle.applicableDepartmentIds &&
        cycle.applicableDepartmentIds.length > 0 &&
        !cycle.applicableDepartmentIds.includes(staff.departmentId)
      ) {
        return false;
      }

      // Check designation if scoped
      if (
        cycle.applicableDesignationIds &&
        cycle.applicableDesignationIds.length > 0 &&
        !cycle.applicableDesignationIds.includes(staff.designationId)
      ) {
        return false;
      }

      // Must not already have a review in this cycle
      const alreadyHasReview = existingReviews.some(
        (r) => r.reviewCycleId === cycleId && r.staffId === staff.id
      );
      return !alreadyHasReview;
    });

    let generatedCount = 0;
    const now = new Date().toISOString();

    eligibleStaff.forEach((staff) => {
      const reviewId = `rev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      // Determine supervisor:
      // 1. If staff has reportingManagerId, find that staff
      // 2. Or if department has HOD, find HOD staff
      // 3. Else fallback to Dr. Arthur Sterling (staff-prof-1)
      let reviewerId = 'staff-prof-1';
      let reviewerName = 'Dr. Arthur Sterling';

      if (staff.departmentId) {
        const hod = (database.staffProfiles || []).find(
          (s) =>
            s.departmentId === staff.departmentId &&
            s.designation?.toLowerCase().includes('head') &&
            s.id !== staff.id
        );
        if (hod) {
          reviewerId = hod.id;
          reviewerName = hod.displayName || `${hod.firstName} ${hod.lastName}`;
        }
      }

      // Calculate real supporting data
      const supportingData = this.calculateSupportingMetrics(staff);

      const initialStatus: ReviewWorkflowStatus = cycle.allowSelfAssessment
        ? 'SELF_ASSESSMENT'
        : 'SUPERVISOR_REVIEW';

      const stageDesc = cycle.allowSelfAssessment
        ? 'Awaiting Employee Self-Assessment'
        : 'Awaiting Supervisor Evaluation';

      const newReview: StaffPerformanceReview = {
        id: reviewId,
        reviewCycleId: cycle.id,
        reviewCycleName: cycle.name,
        staffId: staff.id,
        staffName: staff.displayName || `${staff.firstName} ${staff.lastName}`,
        staffEmployeeCode: staff.employeeCode,
        departmentId: staff.departmentId,
        departmentName: staff.departmentName,
        designationTitle: staff.designation,
        staffType: (staff.staffType?.toUpperCase() as any) || 'TEACHING',
        reviewerId,
        reviewerName,
        reviewPeriod: cycle.reviewPeriod,
        academicSessionId: cycle.academicSessionId,
        status: initialStatus,
        currentStage: stageDesc,
        history: [
          {
            stage: 'DRAFT',
            action: 'BATCH_GENERATED',
            actorId: actor?.id || 'usr-admin-1',
            actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'System HR Admin',
            timestamp: now,
            comments: `Generated as part of review cycle ${cycle.name}`
          }
        ],
        supportingData,
        createdAt: now,
        updatedAt: now
      };

      database.performanceReviews.unshift(newReview);
      generatedCount++;

      // Dispatch notification to staff
      if (staff.userId) {
        this.sendNotification(
          staff.userId,
          `Performance Appraisal Initiated: ${cycle.name}`,
          cycle.allowSelfAssessment
            ? `Your self-assessment form is now open for the ${cycle.name}. Deadline: ${cycle.selfAssessmentDeadline || 'Upcoming'}.`
            : `A performance evaluation has been scheduled for your role under ${cycle.name}.`,
          'general',
          `/admin/staff?tab=performance`
        );
      }
    });

    cycle.totalEligibleStaff = (cycle.totalEligibleStaff || 0) + generatedCount;
    if (cycle.status === 'DRAFT') {
      cycle.status = 'IN_PROGRESS';
    }
    cycle.updatedAt = now;

    this.logAudit('GENERATE_CYCLE_REVIEWS', 'PerformanceReviewCycle', cycleId, actor, {
      generatedCount,
      eligibleStaffCount: eligibleStaff.length
    });

    return {
      generatedCount,
      cycle
    };
  }

  private calculateSupportingMetrics(staff: StaffProfile) {
    // 1. Attendance & late arrivals
    const attendanceRecords = (database.staffAttendanceRecords || []).filter(
      (a) => (a as any).staffProfileId === staff.id || a.staffId === staff.id
    );

    let attendancePercentage = 95.0;
    let lateArrivalsCount = 0;

    if (attendanceRecords.length > 0) {
      const presentCount = attendanceRecords.filter(
        (a) =>
          a.status === 'PRESENT' ||
          a.status === 'LATE' ||
          a.status === 'HALF_DAY' ||
          (a.status as any) === 'present' ||
          (a.status as any) === 'late'
      ).length;
      lateArrivalsCount = attendanceRecords.filter(
        (a) => a.status === 'LATE' || (a.status as any) === 'late'
      ).length;
      attendancePercentage = Math.round((presentCount / attendanceRecords.length) * 1000) / 10;
    }

    // 2. Approved leaves
    const leaves = (database.staffLeaveTransactions || []).filter(
      (t) =>
        ((t as any).staffProfileId === staff.id || t.staffId === staff.id) &&
        ((t as any).type === 'DEBIT' || t.transactionType === 'LEAVE_DEDUCTION')
    );
    const approvedLeavesCount = leaves.length || 2;

    // 3. Workload summary
    let workloadSummary = 'Standard Operational Shift (40 hrs/wk)';
    let marksCompliance = 100;

    if (staff.staffType === 'teaching') {
      const teacherProfile = (database.teacherProfiles || []).find(
        (t) => t.employeeCode === staff.employeeCode || t.userId === staff.userId
      );
      if (teacherProfile) {
        const classes = teacherProfile.assignedClassIds || (teacherProfile as any).classesAssigned || [];
        const subjects = teacherProfile.specialization || 'Assigned Subjects';
        workloadSummary = `${classes.length} Class Sections | ${subjects}`;
      } else {
        workloadSummary = 'Teaching Faculty | Academic Load Assigned';
      }
      marksCompliance = 98.5;
    }

    // 4. Documents compliance
    const docs = (database.staffDocuments || []).filter(
      (d) => (d as any).staffProfileId === staff.id || d.staffId === staff.id
    );
    const verifiedDocs = docs.filter(
      (d) => d.verificationStatus === 'VERIFIED' || (d.verificationStatus as any) === 'verified'
    );
    const documentsComplianceStatus =
      docs.length === 0
        ? 'Dossier Incomplete'
        : verifiedDocs.length === docs.length
        ? `All ${docs.length} Credentials Verified`
        : `${verifiedDocs.length}/${docs.length} Documents Verified`;

    return {
      attendancePercentage,
      lateArrivalsCount,
      approvedLeavesCount,
      workloadSummary,
      marksSubmissionComplianceRate: marksCompliance,
      documentsComplianceStatus
    };
  }

  // ==========================================
  // 3. PERFORMANCE CRITERIA & KPIS
  // ==========================================

  public listCriteria(query?: {
    category?: string;
    applicableStaffType?: string;
    isActive?: boolean;
    search?: string;
  }): PerformanceCriterion[] {
    let items = [...(database.performanceCriteria || [])];

    if (query?.category) {
      items = items.filter((c) => c.category === query.category);
    }
    if (query?.applicableStaffType) {
      items = items.filter(
        (c) => c.applicableStaffType === 'ALL' || c.applicableStaffType === query.applicableStaffType
      );
    }
    if (query?.isActive !== undefined) {
      items = items.filter((c) => c.isActive === query.isActive);
    }
    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.code.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q)
      );
    }

    return items;
  }

  public getCriterionById(id: string): PerformanceCriterion | null {
    return (database.performanceCriteria || []).find((c) => c.id === id) || null;
  }

  public createCriterion(
    payload: CreatePerformanceCriterionPayload,
    actor?: User
  ): PerformanceCriterion {
    const id = `crit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const newCriterion: PerformanceCriterion = {
      id,
      name: payload.name.trim(),
      code: payload.code.trim().toUpperCase(),
      description: payload.description?.trim() || '',
      category: payload.category,
      weight: Number(payload.weight) || 10,
      maxScore: payload.maxScore || 5,
      scoringRubric: payload.scoringRubric,
      applicableStaffType: payload.applicableStaffType || 'ALL',
      applicableDepartmentId: payload.applicableDepartmentId,
      applicableDesignationId: payload.applicableDesignationId,
      isActive: true,
      createdAt: now,
      updatedAt: now
    };

    database.performanceCriteria.unshift(newCriterion);

    this.logAudit('CREATE_PERFORMANCE_CRITERION', 'PerformanceCriterion', id, actor, {
      name: newCriterion.name,
      code: newCriterion.code,
      weight: newCriterion.weight
    });

    return newCriterion;
  }

  public updateCriterion(
    id: string,
    payload: UpdatePerformanceCriterionPayload,
    actor?: User
  ): PerformanceCriterion {
    const criterion = (database.performanceCriteria || []).find((c) => c.id === id);
    if (!criterion) {
      throw new Error(`Performance criterion with ID ${id} not found.`);
    }

    if (payload.name) criterion.name = payload.name.trim();
    if (payload.code) criterion.code = payload.code.trim().toUpperCase();
    if (payload.description !== undefined) criterion.description = payload.description.trim();
    if (payload.category) criterion.category = payload.category;
    if (payload.weight !== undefined) criterion.weight = Number(payload.weight);
    if (payload.maxScore !== undefined) criterion.maxScore = Number(payload.maxScore);
    if (payload.applicableStaffType) criterion.applicableStaffType = payload.applicableStaffType;
    if (payload.applicableDepartmentId !== undefined) criterion.applicableDepartmentId = payload.applicableDepartmentId;
    if (payload.applicableDesignationId !== undefined) criterion.applicableDesignationId = payload.applicableDesignationId;
    if (payload.scoringRubric !== undefined) criterion.scoringRubric = payload.scoringRubric;
    if (payload.isActive !== undefined) criterion.isActive = payload.isActive;

    criterion.updatedAt = new Date().toISOString();

    this.logAudit('UPDATE_PERFORMANCE_CRITERION', 'PerformanceCriterion', id, actor, {
      updatedFields: Object.keys(payload)
    });

    return criterion;
  }

  public toggleCriterionActive(id: string, actor?: User): PerformanceCriterion {
    const criterion = (database.performanceCriteria || []).find((c) => c.id === id);
    if (!criterion) {
      throw new Error(`Performance criterion with ID ${id} not found.`);
    }

    criterion.isActive = !criterion.isActive;
    criterion.updatedAt = new Date().toISOString();

    this.logAudit('TOGGLE_PERFORMANCE_CRITERION', 'PerformanceCriterion', id, actor, {
      isActive: criterion.isActive
    });

    return criterion;
  }

  // ==========================================
  // 4. PERFORMANCE GOALS & PROGRESS
  // ==========================================

  public listGoals(query?: {
    staffId?: string;
    reviewCycleId?: string;
    status?: string;
    category?: string;
    search?: string;
  }): PerformanceGoal[] {
    let items = [...(database.performanceGoals || [])];

    if (query?.staffId) {
      items = items.filter((g) => g.staffId === query.staffId);
    }
    if (query?.reviewCycleId) {
      items = items.filter((g) => g.reviewCycleId === query.reviewCycleId);
    }
    if (query?.status) {
      items = items.filter((g) => g.status === query.status);
    }
    if (query?.category) {
      items = items.filter((g) => g.category === query.category);
    }
    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (g) =>
          g.title.toLowerCase().includes(q) ||
          g.staffName.toLowerCase().includes(q) ||
          g.target.toLowerCase().includes(q)
      );
    }

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return items;
  }

  public getGoalById(id: string): PerformanceGoal | null {
    return (database.performanceGoals || []).find((g) => g.id === id) || null;
  }

  public createGoal(payload: CreatePerformanceGoalPayload, actor?: User): PerformanceGoal {
    const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
    if (!staff) {
      throw new Error(`Staff member with ID ${payload.staffId} not found.`);
    }

    const cycle = (database.performanceReviewCycles || []).find(
      (c) => c.id === payload.reviewCycleId
    );

    const id = `goal-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const milestones = (payload.milestones || []).map((m, idx) => ({
      id: `m-${Date.now()}-${idx}`,
      title: m.title.trim(),
      dueDate: m.dueDate,
      isCompleted: false
    }));

    const newGoal: PerformanceGoal = {
      id,
      staffId: staff.id,
      staffName: staff.displayName || `${staff.firstName} ${staff.lastName}`,
      staffEmployeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      reviewCycleId: payload.reviewCycleId,
      reviewCycleName: cycle?.name || 'Review Cycle',
      title: payload.title.trim(),
      description: payload.description.trim(),
      category: payload.category,
      target: payload.target.trim(),
      measurementMethod: payload.measurementMethod.trim(),
      weight: Number(payload.weight) || 20,
      startDate: payload.startDate,
      dueDate: payload.dueDate,
      progressPercentage: 0,
      status: 'ACTIVE',
      reviewerId: payload.reviewerId || 'staff-prof-1',
      reviewerName: 'Dr. Arthur Sterling',
      milestones,
      progressNotes: [],
      lastUpdatedDate: payload.startDate,
      updatedBy: actor?.id || 'system',
      createdAt: now
    };

    database.performanceGoals.unshift(newGoal);

    this.logAudit('CREATE_PERFORMANCE_GOAL', 'PerformanceGoal', id, actor, {
      title: newGoal.title,
      staffName: newGoal.staffName,
      target: newGoal.target
    });

    if (staff.userId && staff.userId !== actor?.id) {
      this.sendNotification(
        staff.userId,
        `New Performance Goal Assigned: ${newGoal.title}`,
        `A key performance target has been established for your cycle ${newGoal.reviewCycleName}. Due: ${newGoal.dueDate}`,
        'general',
        `/admin/staff?tab=performance`
      );
    }

    return newGoal;
  }

  public updateGoal(
    id: string,
    payload: UpdatePerformanceGoalPayload,
    actor?: User
  ): PerformanceGoal {
    const goal = (database.performanceGoals || []).find((g) => g.id === id);
    if (!goal) {
      throw new Error(`Performance goal with ID ${id} not found.`);
    }

    if (payload.title) goal.title = payload.title.trim();
    if (payload.description) goal.description = payload.description.trim();
    if (payload.category) goal.category = payload.category;
    if (payload.target) goal.target = payload.target.trim();
    if (payload.measurementMethod) goal.measurementMethod = payload.measurementMethod.trim();
    if (payload.weight !== undefined) goal.weight = Number(payload.weight);
    if (payload.startDate) goal.startDate = payload.startDate;
    if (payload.dueDate) goal.dueDate = payload.dueDate;
    if (payload.status) goal.status = payload.status;

    goal.lastUpdatedDate = new Date().toISOString().split('T')[0];
    goal.updatedBy = actor?.id || 'system';

    this.logAudit('UPDATE_PERFORMANCE_GOAL', 'PerformanceGoal', id, actor, {
      updatedFields: Object.keys(payload)
    });

    return goal;
  }

  public updateGoalProgress(
    id: string,
    payload: UpdateGoalProgressPayload,
    actor?: User
  ): PerformanceGoal {
    const goal = (database.performanceGoals || []).find((g) => g.id === id);
    if (!goal) {
      throw new Error(`Performance goal with ID ${id} not found.`);
    }

    const prevPct = goal.progressPercentage;
    goal.progressPercentage = Math.min(100, Math.max(0, payload.progressPercentage));

    if (payload.status) {
      goal.status = payload.status;
    } else if (goal.progressPercentage >= 100) {
      goal.status = 'ACHIEVED';
    } else if (goal.progressPercentage > 0 && goal.status === 'ACTIVE') {
      goal.status = 'IN_PROGRESS';
    }

    // Complete checked milestones
    if (payload.completedMilestoneIds && goal.milestones) {
      goal.milestones = goal.milestones.map((m) => {
        if (payload.completedMilestoneIds!.includes(m.id)) {
          return {
            ...m,
            isCompleted: true,
            completedAt: m.completedAt || new Date().toISOString()
          };
        }
        return m;
      });
    }

    // Append progress note
    if (payload.note?.trim()) {
      if (!goal.progressNotes) goal.progressNotes = [];
      goal.progressNotes.unshift({
        id: `pn-${Date.now()}`,
        note: payload.note.trim(),
        updatedPercentage: goal.progressPercentage,
        authorId: actor?.id || 'system',
        authorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Staff Member',
        createdAt: new Date().toISOString()
      });
    }

    goal.lastUpdatedDate = new Date().toISOString().split('T')[0];
    goal.updatedBy = actor?.id || 'system';

    this.logAudit('UPDATE_GOAL_PROGRESS', 'PerformanceGoal', id, actor, {
      previousPercentage: prevPct,
      newPercentage: goal.progressPercentage,
      status: goal.status
    });

    return goal;
  }

  // ==========================================
  // 5. STAFF PERFORMANCE REVIEWS (WORKFLOW)
  // ==========================================

  public listReviews(
    query?: PerformanceFilterQuery,
    currentUser?: User
  ): { items: StaffPerformanceReview[]; total: number } {
    let items = [...(database.performanceReviews || [])];

    // Role-based visibility scoping:
    // If not SUPER_ADMIN, user can only see reviews if they are the staff member OR reviewer
    if (currentUser && currentUser.role !== 'SUPER_ADMIN') {
      const userStaff = (database.staffProfiles || []).find(
        (s) => s.userId === currentUser.id || s.employeeCode === currentUser.username
      );
      if (userStaff) {
        items = items.filter(
          (r) => r.staffId === userStaff.id || r.reviewerId === userStaff.id
        );
      }
    }

    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (r) =>
          r.staffName.toLowerCase().includes(q) ||
          r.staffEmployeeCode.toLowerCase().includes(q) ||
          r.departmentName.toLowerCase().includes(q) ||
          r.designationTitle.toLowerCase().includes(q)
      );
    }

    if (query?.reviewCycleId) {
      items = items.filter((r) => r.reviewCycleId === query.reviewCycleId);
    }
    if (query?.departmentId) {
      items = items.filter((r) => r.departmentId === query.departmentId);
    }
    if (query?.staffType) {
      items = items.filter((r) => r.staffType.toLowerCase() === query.staffType!.toLowerCase());
    }
    if (query?.status) {
      items = items.filter((r) => r.status === query.status);
    }
    if (query?.ratingBand) {
      items = items.filter(
        (r) =>
          r.hrReview?.finalRatingBand === query.ratingBand ||
          (r.supervisorReview && this.getRatingBand(r.supervisorReview.calculatedScore) === query.ratingBand)
      );
    }
    if (query?.staffId) {
      items = items.filter((r) => r.staffId === query.staffId);
    }

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return {
      items,
      total: items.length
    };
  }

  public getReviewById(id: string, currentUser?: User): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === id);
    if (!review) {
      throw new Error(`Performance review with ID ${id} not found.`);
    }

    // Permission check
    if (currentUser && currentUser.role !== 'SUPER_ADMIN') {
      const userStaff = (database.staffProfiles || []).find(
        (s) => s.userId === currentUser.id || s.employeeCode === currentUser.username
      );
      if (userStaff && review.staffId !== userStaff.id && review.reviewerId !== userStaff.id) {
        throw new Error('Access denied: You do not have permission to view this review dossier.');
      }
    }

    return review;
  }

  public getMyActiveReview(currentUser: User): StaffPerformanceReview | null {
    const userStaff = (database.staffProfiles || []).find(
      (s) => s.userId === currentUser.id || s.employeeCode === currentUser.username
    );
    if (!userStaff) return null;

    const myReviews = (database.performanceReviews || []).filter(
      (r) => r.staffId === userStaff.id
    );
    // Find active or most recent
    return (
      myReviews.find((r) =>
        ['SELF_ASSESSMENT', 'SUPERVISOR_REVIEW', 'HR_REVIEW', 'FINALIZED'].includes(r.status)
      ) || myReviews[0] || null
    );
  }

  public createReview(
    payload: CreatePerformanceReviewPayload,
    actor?: User
  ): StaffPerformanceReview {
    const cycle = (database.performanceReviewCycles || []).find(
      (c) => c.id === payload.reviewCycleId
    );
    if (!cycle) {
      throw new Error(`Review cycle with ID ${payload.reviewCycleId} not found.`);
    }

    const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
    if (!staff) {
      throw new Error(`Staff member with ID ${payload.staffId} not found.`);
    }

    // Prevent duplicate review in same cycle
    const existing = (database.performanceReviews || []).find(
      (r) => r.reviewCycleId === payload.reviewCycleId && r.staffId === payload.staffId
    );
    if (existing) {
      throw new Error(
        `Staff member already has an active review (${existing.id}) in this review cycle.`
      );
    }

    const id = `rev-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    let reviewerId = payload.reviewerId || 'staff-prof-1';
    let reviewerName = 'Dr. Arthur Sterling';
    if (payload.reviewerId) {
      const revStaff = (database.staffProfiles || []).find((s) => s.id === payload.reviewerId);
      if (revStaff) {
        reviewerName = revStaff.displayName || `${revStaff.firstName} ${revStaff.lastName}`;
      }
    }

    const supportingData = this.calculateSupportingMetrics(staff);

    const initialStatus: ReviewWorkflowStatus = cycle.allowSelfAssessment
      ? 'SELF_ASSESSMENT'
      : 'SUPERVISOR_REVIEW';

    const newReview: StaffPerformanceReview = {
      id,
      reviewCycleId: cycle.id,
      reviewCycleName: cycle.name,
      staffId: staff.id,
      staffName: staff.displayName || `${staff.firstName} ${staff.lastName}`,
      staffEmployeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      designationTitle: staff.designation,
      staffType: (staff.staffType?.toUpperCase() as any) || 'TEACHING',
      reviewerId,
      reviewerName,
      reviewPeriod: cycle.reviewPeriod,
      academicSessionId: cycle.academicSessionId,
      status: initialStatus,
      currentStage: cycle.allowSelfAssessment
        ? 'Awaiting Employee Self-Assessment'
        : 'Awaiting Supervisor Evaluation',
      history: [
        {
          stage: 'DRAFT',
          action: 'CREATED',
          actorId: actor?.id || 'system',
          actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'System Admin',
          timestamp: now,
          comments: `Manual review created for ${staff.displayName}`
        }
      ],
      supportingData,
      createdAt: now,
      updatedAt: now
    };

    database.performanceReviews.unshift(newReview);

    this.logAudit('CREATE_STAFF_REVIEW', 'StaffPerformanceReview', id, actor, {
      staffName: newReview.staffName,
      cycleName: newReview.reviewCycleName
    });

    return newReview;
  }

  public submitSelfAssessment(
    reviewId: string,
    payload: SubmitSelfAssessmentPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    // Security check: only the staff member or super admin can submit self assessment
    if (actor && actor.role !== 'SUPER_ADMIN') {
      const userStaff = (database.staffProfiles || []).find(
        (s) => s.userId === actor.id || s.employeeCode === actor.username
      );
      if (userStaff && userStaff.id !== review.staffId) {
        throw new Error('Access denied: You can only submit self-assessment for your own review.');
      }
    }

    if (review.status !== 'SELF_ASSESSMENT' && review.status !== 'DRAFT') {
      throw new Error(`Cannot submit self-assessment: Review is currently in '${review.status}' stage.`);
    }

    const now = new Date().toISOString();

    review.selfAssessment = {
      achievementSummary: payload.achievementSummary.trim(),
      goalProgressSummary: payload.goalProgressSummary.trim(),
      strengths: payload.strengths.trim(),
      challenges: payload.challenges.trim(),
      trainingNeeds: payload.trainingNeeds.trim(),
      comments: payload.comments.trim(),
      selfRating: Math.min(5, Math.max(1, Number(payload.selfRating) || 3)),
      submittedAt: now
    };

    review.status = 'SUPERVISOR_REVIEW';
    review.currentStage = `Awaiting Supervisor Review (${review.reviewerName})`;
    review.updatedAt = now;

    review.history.push({
      stage: 'SELF_ASSESSMENT',
      action: 'SUBMITTED',
      actorId: actor?.id || 'system',
      actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : review.staffName,
      timestamp: now,
      comments: 'Self-assessment submitted. Transferred to supervisor queue.'
    });

    this.logAudit('SUBMIT_SELF_ASSESSMENT', 'StaffPerformanceReview', reviewId, actor, {
      selfRating: review.selfAssessment.selfRating
    });

    // Notify Supervisor
    const supervisorStaff = (database.staffProfiles || []).find((s) => s.id === review.reviewerId);
    if (supervisorStaff?.userId) {
      this.sendNotification(
        supervisorStaff.userId,
        `Self-Assessment Submitted: ${review.staffName}`,
        `${review.staffName} has submitted their self-assessment for ${review.reviewCycleName}. Action required: Complete supervisor evaluation.`,
        'general',
        `/admin/staff?tab=performance`
      );
    }

    return review;
  }

  public submitSupervisorReview(
    reviewId: string,
    payload: SubmitSupervisorReviewPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    // Security check: Supervisor or Super Admin
    if (actor && actor.role !== 'SUPER_ADMIN') {
      const userStaff = (database.staffProfiles || []).find(
        (s) => s.userId === actor.id || s.employeeCode === actor.username
      );
      if (userStaff && userStaff.id === review.staffId) {
        throw new Error('Self-evaluation as supervisor is strictly forbidden. An independent supervisor must evaluate.');
      }
      if (userStaff && userStaff.id !== review.reviewerId) {
        throw new Error('Access denied: Only the assigned supervisor can submit supervisor scoring.');
      }
    }

    if (review.status !== 'SUPERVISOR_REVIEW' && review.status !== 'RETURNED_FOR_CORRECTION') {
      throw new Error(
        `Cannot submit supervisor review: Current stage is '${review.status}'.`
      );
    }

    const now = new Date().toISOString();

    // Server-side authoritative score calculation
    const allCriteria = database.performanceCriteria || [];
    let totalWeightedScore = 0;
    let totalMaxPossible = 0;

    const scoredCriteria = payload.criteriaScores.map((item) => {
      const criterion = allCriteria.find((c) => c.id === item.criterionId);
      const weight = criterion?.weight || 10;
      const maxScore = criterion?.maxScore || 5;
      const score = Math.min(maxScore, Math.max(1, Number(item.score)));

      totalWeightedScore += (score / maxScore) * weight;
      totalMaxPossible += weight;

      return {
        criterionId: item.criterionId,
        criterionCode: criterion?.code || 'CRIT',
        criterionName: criterion?.name || 'Criterion',
        category: criterion?.category || 'WORK_QUALITY',
        weight,
        maxScore,
        score,
        comments: item.comments?.trim()
      };
    });

    const calculatedScore =
      totalMaxPossible > 0
        ? Math.round((totalWeightedScore / totalMaxPossible) * 1000) / 10
        : Math.round(((payload.supervisorRating || 3) / 5) * 100);

    const goalAssessments = (payload.goalAssessments || []).map((ga) => {
      const goal = (database.performanceGoals || []).find((g) => g.id === ga.goalId);
      return {
        goalId: ga.goalId,
        goalTitle: goal?.title || 'Goal',
        weight: goal?.weight || 20,
        progressPercentage: goal?.progressPercentage || 0,
        achievedScore: Math.min(5, Math.max(1, Number(ga.achievedScore))),
        comments: ga.comments?.trim()
      };
    });

    review.supervisorReview = {
      criteriaScores: scoredCriteria,
      goalAssessments,
      strengths: payload.strengths.trim(),
      areasForImprovement: payload.areasForImprovement.trim(),
      developmentRecommendations: payload.developmentRecommendations.trim(),
      recommendedTraining: payload.recommendedTraining || [],
      calculatedScore,
      supervisorRating: Math.min(5, Math.max(1, Number(payload.supervisorRating) || 3)),
      generalComments: payload.generalComments.trim(),
      submittedAt: now
    };

    const cycle = (database.performanceReviewCycles || []).find(
      (c) => c.id === review.reviewCycleId
    );

    if (cycle?.requireHRFinalApproval) {
      review.status = 'HR_REVIEW';
      review.currentStage = 'Pending HR Executive Final Approval & Rating Confirmation';
    } else {
      review.status = 'FINALIZED';
      review.currentStage = 'Finalized - Pending Employee Sign-off';
      review.hrReview = {
        hrComments: 'Auto-finalized per cycle approval policy without HR override.',
        finalCalculatedScore: calculatedScore,
        finalRatingBand: this.getRatingBand(calculatedScore),
        pipRecommended: calculatedScore < 60,
        reviewedAt: now
      };
    }

    review.updatedAt = now;

    review.history.push({
      stage: 'SUPERVISOR_REVIEW',
      action: 'EVALUATED',
      actorId: actor?.id || 'system',
      actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : review.reviewerName,
      timestamp: now,
      comments: `Supervisor evaluation completed. Score: ${calculatedScore}%. Next: ${review.currentStage}`
    });

    this.logAudit('SUBMIT_SUPERVISOR_REVIEW', 'StaffPerformanceReview', reviewId, actor, {
      calculatedScore,
      rating: review.supervisorReview.supervisorRating
    });

    return review;
  }

  public submitHRReview(
    reviewId: string,
    payload: SubmitHRReviewPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    // Require HR / SUPER_ADMIN
    if (actor && actor.role !== 'SUPER_ADMIN') {
      throw new Error('Access denied: Only HR or Super Administrators can finalize performance reviews.');
    }

    if (review.status !== 'HR_REVIEW') {
      if (review.status === 'SUPERVISOR_REVIEW') {
        if (!review.supervisorReview) {
          throw new Error('Cannot finalize HR review: Supervisor evaluation has not been completed yet.');
        }
      } else {
        throw new Error(`Cannot complete HR review: Current stage is '${review.status}'.`);
      }
    }

    const now = new Date().toISOString();
    const finalScore =
      review.hrReview?.hrScoreOverride ??
      review.supervisorReview?.calculatedScore ??
      75.0;

    const finalBand = payload.finalRatingBand || this.getRatingBand(finalScore);
    const pipRecommended = payload.pipRecommended ?? finalScore < 60;

    review.hrReview = {
      ...(review.hrReview || {}),
      hrComments: payload.hrComments.trim(),
      finalCalculatedScore: finalScore,
      finalRatingBand: finalBand,
      pipRecommended,
      reviewedAt: now
    };

    review.hrReviewerId = actor?.id || 'usr-admin-1';
    review.hrReviewerName = actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'HR Director';
    review.status = 'FINALIZED';
    review.currentStage = 'Finalized - Pending Employee Sign-off';
    review.updatedAt = now;

    review.history.push({
      stage: 'HR_REVIEW',
      action: 'FINALIZED',
      actorId: actor?.id || 'usr-admin-1',
      actorName: review.hrReviewerName,
      timestamp: now,
      comments: `Official rating confirmed: ${finalBand} (${finalScore}%). Ready for employee acknowledgement.`
    });

    this.logAudit('SUBMIT_HR_REVIEW', 'StaffPerformanceReview', reviewId, actor, {
      finalScore,
      finalBand,
      pipRecommended
    });

    // Notify evaluated employee
    const staff = (database.staffProfiles || []).find((s) => s.id === review.staffId);
    if (staff?.userId) {
      this.sendNotification(
        staff.userId,
        `Performance Review Finalized: ${review.reviewCycleName}`,
        `Your appraisal has been finalized with rating '${finalBand}'. Please review your scores, feedback, and sign off with acknowledgement.`,
        'general',
        `/admin/staff?tab=performance`
      );
    }

    return review;
  }

  public overrideReviewRating(
    reviewId: string,
    payload: OverrideRatingPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    if (actor && actor.role !== 'SUPER_ADMIN') {
      throw new Error('Access denied: Rating override requires Super Admin or HR Executive authority.');
    }

    if (review.status === 'CLOSED') {
      throw new Error('Cannot override rating on a closed performance review. Please reopen the review first.');
    }

    if (!payload.reason?.trim()) {
      throw new Error('Mandatory override justification reason must be provided.');
    }

    const now = new Date().toISOString();
    const oldScore = review.hrReview?.finalCalculatedScore ?? review.supervisorReview?.calculatedScore ?? 0;

    review.hrReview = {
      ...(review.hrReview || {
        hrComments: 'Rating adjusted by executive review.',
        pipRecommended: false,
        reviewedAt: now
      }),
      hrScoreOverride: payload.overrideScore,
      overrideReason: payload.reason.trim(),
      overrideBy: actor?.id || 'usr-admin-1',
      overrideByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Executive Authority',
      overrideAt: now,
      finalCalculatedScore: payload.overrideScore,
      finalRatingBand: payload.overrideRatingBand
    };

    review.updatedAt = now;

    review.history.push({
      stage: review.status,
      action: 'RATING_OVERRIDDEN',
      actorId: actor?.id || 'usr-admin-1',
      actorName: review.hrReview.overrideByName!,
      timestamp: now,
      comments: `Score adjusted from ${oldScore} to ${payload.overrideScore} (${payload.overrideRatingBand}). Reason: ${payload.reason.trim()}`
    });

    this.logAudit('OVERRIDE_REVIEW_RATING', 'StaffPerformanceReview', reviewId, actor, {
      oldScore,
      newScore: payload.overrideScore,
      newBand: payload.overrideRatingBand,
      reason: payload.reason.trim()
    });

    return review;
  }

  public acknowledgeReview(
    reviewId: string,
    payload: AcknowledgeReviewPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    // Security check: Only the evaluated staff member can acknowledge
    if (actor && actor.role !== 'SUPER_ADMIN') {
      const userStaff = (database.staffProfiles || []).find(
        (s) => s.userId === actor.id || s.employeeCode === actor.username
      );
      if (userStaff && userStaff.id !== review.staffId) {
        throw new Error('Access denied: You can only acknowledge your own performance review.');
      }
    }

    if (review.status !== 'FINALIZED' && review.status !== 'ACKNOWLEDGED') {
      throw new Error(`Cannot acknowledge review: Current stage is '${review.status}'.`);
    }

    const now = new Date().toISOString();

    review.acknowledgement = {
      isAcknowledged: true,
      acknowledgedAt: now,
      comments: payload.comments?.trim()
    };

    review.status = 'ACKNOWLEDGED';
    review.currentStage = 'Employee Acknowledged & Closed';
    review.updatedAt = now;

    review.history.push({
      stage: 'ACKNOWLEDGED',
      action: 'ACKNOWLEDGED',
      actorId: actor?.id || 'system',
      actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : review.staffName,
      timestamp: now,
      comments: payload.comments?.trim() ? `Employee comment: ${payload.comments.trim()}` : 'Formal sign-off completed.'
    });

    this.logAudit('ACKNOWLEDGE_REVIEW', 'StaffPerformanceReview', reviewId, actor, {
      staffName: review.staffName
    });

    // Update cycle completed count
    const cycle = (database.performanceReviewCycles || []).find(
      (c) => c.id === review.reviewCycleId
    );
    if (cycle) {
      const cycleReviews = (database.performanceReviews || []).filter(
        (r) => r.reviewCycleId === cycle.id
      );
      cycle.completedReviewsCount = cycleReviews.filter((r) =>
        ['FINALIZED', 'ACKNOWLEDGED', 'CLOSED'].includes(r.status)
      ).length;
    }

    return review;
  }

  public transitionReviewWorkflow(
    reviewId: string,
    payload: TransitionReviewWorkflowPayload,
    actor?: User
  ): StaffPerformanceReview {
    const review = (database.performanceReviews || []).find((r) => r.id === reviewId);
    if (!review) {
      throw new Error(`Performance review with ID ${reviewId} not found.`);
    }

    if (actor && actor.role !== 'SUPER_ADMIN') {
      throw new Error('Access denied: Only Administrators can manually transition review workflow.');
    }

    if (!payload.comments?.trim()) {
      throw new Error('A transition reason or operational note is required when changing review workflow.');
    }

    const prevStatus = review.status;
    const now = new Date().toISOString();

    // If reopening a review from finalized/acknowledged state for correction, clear previous employee sign-off
    if (['DRAFT', 'SELF_ASSESSMENT', 'SUPERVISOR_REVIEW', 'RETURNED_FOR_CORRECTION'].includes(payload.targetStatus)) {
      review.acknowledgement = undefined;
    }

    review.status = payload.targetStatus;
    review.currentStage = `Workflow changed to: ${payload.targetStatus}`;
    review.updatedAt = now;

    review.history.push({
      stage: payload.targetStatus,
      action: 'WORKFLOW_TRANSITION',
      actorId: actor?.id || 'system',
      actorName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Admin',
      timestamp: now,
      comments: payload.comments?.trim() || `Status updated from ${prevStatus} to ${payload.targetStatus}`
    });

    this.logAudit('TRANSITION_REVIEW_WORKFLOW', 'StaffPerformanceReview', reviewId, actor, {
      from: prevStatus,
      to: payload.targetStatus,
      comments: payload.comments
    });

    return review;
  }

  // ==========================================
  // 6. PERFORMANCE FEEDBACK
  // ==========================================

  public listFeedback(staffId?: string, reviewId?: string): PerformanceFeedbackItem[] {
    let items = [...(database.performanceFeedback || [])];

    if (staffId) {
      items = items.filter((f) => f.staffId === staffId);
    }
    if (reviewId) {
      items = items.filter((f) => f.reviewId === reviewId);
    }

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return items;
  }

  public createFeedback(
    payload: CreatePerformanceFeedbackPayload,
    actor?: User
  ): PerformanceFeedbackItem {
    const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
    if (!staff) {
      throw new Error(`Staff member with ID ${payload.staffId} not found.`);
    }

    const id = `fb-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const newFeedback: PerformanceFeedbackItem = {
      id,
      reviewId: payload.reviewId,
      staffId: staff.id,
      staffName: staff.displayName || `${staff.firstName} ${staff.lastName}`,
      givenBy: actor?.id || 'usr-admin-1',
      givenByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'School Leadership',
      givenByRole: actor?.role || 'SUPER_ADMIN',
      feedbackType: payload.feedbackType,
      strengths: payload.strengths.trim(),
      improvementAreas: payload.improvementAreas.trim(),
      recommendations: payload.recommendations.trim(),
      trainingNeeds: payload.trainingNeeds?.trim(),
      careerDevelopmentSuggestions: payload.careerDevelopmentSuggestions?.trim(),
      generalComments: payload.generalComments.trim(),
      isAcknowledged: false,
      createdAt: now
    };

    database.performanceFeedback.unshift(newFeedback);

    this.logAudit('CREATE_PERFORMANCE_FEEDBACK', 'PerformanceFeedbackItem', id, actor, {
      staffName: newFeedback.staffName,
      feedbackType: newFeedback.feedbackType
    });

    if (staff.userId && staff.userId !== actor?.id) {
      this.sendNotification(
        staff.userId,
        `New Performance Feedback Received`,
        `Formal feedback (${newFeedback.feedbackType}) has been logged by ${newFeedback.givenByName}.`,
        'general',
        `/admin/staff?tab=performance`
      );
    }

    return newFeedback;
  }

  public acknowledgeFeedback(
    feedbackId: string,
    note?: string,
    actor?: User
  ): PerformanceFeedbackItem {
    const fb = (database.performanceFeedback || []).find((f) => f.id === feedbackId);
    if (!fb) {
      throw new Error(`Feedback item with ID ${feedbackId} not found.`);
    }

    fb.isAcknowledged = true;
    fb.acknowledgedAt = new Date().toISOString();
    fb.acknowledgementNote = note?.trim();

    this.logAudit('ACKNOWLEDGE_FEEDBACK', 'PerformanceFeedbackItem', feedbackId, actor);

    return fb;
  }

  // ==========================================
  // 7. PERFORMANCE IMPROVEMENT PLANS (PIP)
  // ==========================================

  public listPIPs(query?: {
    staffId?: string;
    status?: string;
    departmentId?: string;
    search?: string;
  }): PerformanceImprovementPlan[] {
    let items = [...(database.performanceImprovementPlans || [])];

    if (query?.staffId) {
      items = items.filter((p) => p.staffId === query.staffId);
    }
    if (query?.status) {
      items = items.filter((p) => p.status === query.status);
    }
    if (query?.departmentId) {
      items = items.filter((p) => p.departmentId === query.departmentId);
    }
    if (query?.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (p) =>
          p.staffName.toLowerCase().includes(q) ||
          p.staffEmployeeCode.toLowerCase().includes(q) ||
          p.reason.toLowerCase().includes(q)
      );
    }

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return items;
  }

  public getPIPById(id: string): PerformanceImprovementPlan | null {
    return (database.performanceImprovementPlans || []).find((p) => p.id === id) || null;
  }

  public createPIP(payload: CreatePIPPayload, actor?: User): PerformanceImprovementPlan {
    const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
    if (!staff) {
      throw new Error(`Staff member with ID ${payload.staffId} not found.`);
    }

    const supervisor = (database.staffProfiles || []).find(
      (s) => s.id === payload.assignedSupervisorId
    );

    const id = `pip-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const requiredActions = (payload.requiredActions || []).map((a, idx) => ({
      id: `act-${Date.now()}-${idx}`,
      description: a.description.trim(),
      deadline: a.deadline,
      status: 'PENDING' as const
    }));

    const newPIP: PerformanceImprovementPlan = {
      id,
      staffId: staff.id,
      staffName: staff.displayName || `${staff.firstName} ${staff.lastName}`,
      staffEmployeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      designationTitle: staff.designation,
      reviewId: payload.reviewId,
      reason: payload.reason.trim(),
      improvementAreas: payload.improvementAreas || [],
      requiredActions,
      targetDate: payload.targetDate,
      reviewDate: payload.reviewDate,
      assignedSupervisorId: payload.assignedSupervisorId,
      assignedSupervisorName: supervisor?.displayName || `${supervisor?.firstName} ${supervisor?.lastName}` || 'Supervisor',
      progressNotes: [],
      outcome: 'PENDING',
      status: 'ACTIVE',
      createdBy: actor?.id || 'usr-admin-1',
      createdByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'HR Operations',
      createdAt: now,
      updatedAt: now
    };

    database.performanceImprovementPlans.unshift(newPIP);

    this.logAudit('CREATE_PIP', 'PerformanceImprovementPlan', id, actor, {
      staffName: newPIP.staffName,
      targetDate: newPIP.targetDate
    });

    if (staff.userId) {
      this.sendNotification(
        staff.userId,
        `Performance Improvement Plan (PIP) Initiated`,
        `A structured Performance Improvement Plan has been put in place with milestones through ${newPIP.targetDate}.`,
        'system',
        `/admin/staff?tab=performance`
      );
    }

    return newPIP;
  }

  public updatePIP(
    id: string,
    payload: UpdatePIPPayload,
    actor?: User
  ): PerformanceImprovementPlan {
    const pip = (database.performanceImprovementPlans || []).find((p) => p.id === id);
    if (!pip) {
      throw new Error(`PIP with ID ${id} not found.`);
    }

    if (payload.status) pip.status = payload.status;
    if (payload.outcome) pip.outcome = payload.outcome;
    if (payload.reviewDate) pip.reviewDate = payload.reviewDate;
    if (payload.targetDate) pip.targetDate = payload.targetDate;

    pip.updatedAt = new Date().toISOString();

    this.logAudit('UPDATE_PIP', 'PerformanceImprovementPlan', id, actor, {
      status: pip.status,
      outcome: pip.outcome
    });

    return pip;
  }

  public addPIPProgressNote(
    id: string,
    payload: AddPIPProgressNotePayload,
    actor?: User
  ): PerformanceImprovementPlan {
    const pip = (database.performanceImprovementPlans || []).find((p) => p.id === id);
    if (!pip) {
      throw new Error(`PIP with ID ${id} not found.`);
    }

    if (!payload.note?.trim()) {
      throw new Error('Progress note cannot be empty.');
    }

    const noteEntry = {
      id: `note-${Date.now()}`,
      note: payload.note.trim(),
      loggedAt: new Date().toISOString(),
      loggedBy: actor?.id || 'usr-admin-1',
      loggedByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'Supervisor'
    };

    if (!pip.progressNotes) pip.progressNotes = [];
    pip.progressNotes.unshift(noteEntry);
    pip.updatedAt = new Date().toISOString();

    this.logAudit('ADD_PIP_NOTE', 'PerformanceImprovementPlan', id, actor, {
      loggedBy: noteEntry.loggedByName
    });

    return pip;
  }

  public updatePIPAction(
    id: string,
    actionId: string,
    payload: UpdatePIPActionPayload,
    actor?: User
  ): PerformanceImprovementPlan {
    const pip = (database.performanceImprovementPlans || []).find((p) => p.id === id);
    if (!pip) {
      throw new Error(`PIP with ID ${id} not found.`);
    }

    const action = (pip.requiredActions || []).find((a) => a.id === actionId);
    if (!action) {
      throw new Error(`PIP action item with ID ${actionId} not found.`);
    }

    action.status = payload.status;
    if (payload.verificationNotes !== undefined) {
      action.verificationNotes = payload.verificationNotes;
    }

    pip.updatedAt = new Date().toISOString();

    this.logAudit('UPDATE_PIP_ACTION', 'PerformanceImprovementPlan', id, actor, {
      actionId,
      status: payload.status
    });

    return pip;
  }

  public closePIP(
    id: string,
    payload: ClosePIPPayload,
    actor?: User
  ): PerformanceImprovementPlan {
    const pip = (database.performanceImprovementPlans || []).find((p) => p.id === id);
    if (!pip) {
      throw new Error(`PIP with ID ${id} not found.`);
    }

    const now = new Date().toISOString();
    pip.outcome = payload.outcome;
    pip.status = payload.outcome === 'IMPROVED_SATISFACTORY' ? 'COMPLETED' : 'CLOSED';
    pip.closedAt = now;
    pip.updatedAt = now;

    if (payload.finalNotes?.trim()) {
      pip.progressNotes.unshift({
        id: `close-${Date.now()}`,
        note: `FINAL RESOLUTION: ${payload.outcome}. ${payload.finalNotes.trim()}`,
        loggedAt: now,
        loggedBy: actor?.id || 'usr-admin-1',
        loggedByName: actor ? `${actor.firstName || ''} ${actor.lastName || actor.name || ''}`.trim() : 'HR Director'
      });
    }

    this.logAudit('CLOSE_PIP', 'PerformanceImprovementPlan', id, actor, {
      outcome: payload.outcome,
      status: pip.status
    });

    return pip;
  }

  // ==========================================
  // 8. REPORTS & ANALYTICS
  // ==========================================

  public getPerformanceReportSummary(cycleId: string): PerformanceReportSummary {
    const cycle = (database.performanceReviewCycles || []).find((c) => c.id === cycleId);
    if (!cycle) {
      throw new Error(`Review cycle with ID ${cycleId} not found.`);
    }

    const cycleReviews = (database.performanceReviews || []).filter(
      (r) => r.reviewCycleId === cycleId
    );
    const totalStaff = cycleReviews.length || cycle.totalEligibleStaff || 1;
    const completedCount = cycleReviews.filter((r) =>
      ['FINALIZED', 'ACKNOWLEDGED', 'CLOSED'].includes(r.status)
    ).length;

    const scoredReviews = cycleReviews.filter(
      (r) =>
        r.hrReview?.finalCalculatedScore !== undefined ||
        r.supervisorReview?.calculatedScore !== undefined
    );

    const averageScore =
      scoredReviews.length > 0
        ? Math.round(
            (scoredReviews.reduce(
              (sum, r) =>
                sum + (r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore ?? 0),
              0
            ) /
              scoredReviews.length) *
              10
          ) / 10
        : 0;

    const ratingDistribution: Record<RatingBand, number> = {
      EXCEPTIONAL: 0,
      EXCEEDS_EXPECTATIONS: 0,
      MEETS_EXPECTATIONS: 0,
      NEEDS_IMPROVEMENT: 0,
      UNSATISFACTORY: 0
    };

    scoredReviews.forEach((r) => {
      const band =
        r.hrReview?.finalRatingBand ||
        this.getRatingBand(
          r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore ?? 0
        );
      if (ratingDistribution[band] !== undefined) {
        ratingDistribution[band]++;
      }
    });

    // Breakdown by department
    const deptMap = new Map<
      string,
      {
        departmentId: string;
        departmentName: string;
        totalStaff: number;
        reviewedCount: number;
        scores: number[];
        ratingBands: Record<RatingBand, number>;
      }
    >();

    cycleReviews.forEach((r) => {
      if (!deptMap.has(r.departmentId)) {
        deptMap.set(r.departmentId, {
          departmentId: r.departmentId,
          departmentName: r.departmentName,
          totalStaff: 0,
          reviewedCount: 0,
          scores: [],
          ratingBands: {
            EXCEPTIONAL: 0,
            EXCEEDS_EXPECTATIONS: 0,
            MEETS_EXPECTATIONS: 0,
            NEEDS_IMPROVEMENT: 0,
            UNSATISFACTORY: 0
          }
        });
      }

      const dept = deptMap.get(r.departmentId)!;
      dept.totalStaff++;

      const score =
        r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore;
      if (score !== undefined) {
        dept.reviewedCount++;
        dept.scores.push(score);
        const band = r.hrReview?.finalRatingBand || this.getRatingBand(score);
        dept.ratingBands[band]++;
      }
    });

    const departmentBreakdown = Array.from(deptMap.values()).map((d) => ({
      departmentId: d.departmentId,
      departmentName: d.departmentName,
      totalStaff: d.totalStaff,
      reviewedCount: d.reviewedCount,
      averageScore:
        d.scores.length > 0
          ? Math.round((d.scores.reduce((a, b) => a + b, 0) / d.scores.length) * 10) / 10
          : 0,
      ratingBands: d.ratingBands
    }));

    return {
      reviewCycle: cycle,
      totalStaff,
      totalReviews: cycleReviews.length,
      completionRate: Math.round((completedCount / totalStaff) * 1000) / 10,
      averageScore,
      ratingDistribution,
      departmentBreakdown
    };
  }
}

export const staffPerformanceService = new StaffPerformanceService();
