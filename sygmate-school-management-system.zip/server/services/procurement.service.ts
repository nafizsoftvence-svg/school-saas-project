/**
 * Procurement & Purchase Workflow Service (Part 14D)
 * Sygmate School Management System
 *
 * Implements authoritative procurement business rules:
 * - Purchase Requests with lifecycle (DRAFT -> SUBMITTED -> UNDER_REVIEW -> APPROVED -> REJECTED / CANCELLED -> CONVERTED_TO_PO)
 * - Concurrency-safe Purchase Orders (DRAFT -> PENDING_APPROVAL -> APPROVED -> SENT_TO_SUPPLIER -> PARTIALLY_RECEIVED -> FULLY_RECEIVED -> COMPLETED)
 * - Atomic Goods Receiving with stock ledger integration and discrepancy tracking
 * - Capital Asset creation from received items without duplicating asset logic
 * - Concurrency mutex locks on PO and Goods Receiving to prevent over-receiving and race conditions
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { StockService } from './stock.service.js';
import { AssetService } from './asset.service.js';
import {
  PurchaseRequest,
  PurchaseRequestItem,
  PurchaseOrder,
  PurchaseOrderItem,
  GoodsReceipt,
  GoodsReceiptItem,
  CreatePurchaseRequestPayload,
  UpdatePurchaseRequestPayload,
  ReviewPurchaseRequestPayload,
  ConvertRequestToPOPayload,
  CreatePurchaseOrderPayload,
  UpdatePurchaseOrderPayload,
  ReviewPurchaseOrderPayload,
  ReceiveGoodsPayload,
  CreateAssetFromReceiptPayload,
  ProcurementDashboardSummary,
  UserRole
} from '../../src/types/index.js';

// ============================================================================
// CONCURRENCY & MUTEX LOCKING
// ============================================================================

type MutexTask<T> = () => Promise<T> | T;
const procurementLockQueues = new Map<string, Promise<any>>();

export async function withProcurementLock<T>(lockKey: string, task: MutexTask<T>): Promise<T> {
  const currentLock = procurementLockQueues.get(lockKey) || Promise.resolve();
  let releaseLock: () => void;
  const newLock = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });
  procurementLockQueues.set(lockKey, newLock);

  try {
    await currentLock;
    return await task();
  } finally {
    releaseLock!();
    if (procurementLockQueues.get(lockKey) === newLock) {
      procurementLockQueues.delete(lockKey);
    }
  }
}

// ============================================================================
// DEFENSIVE INITIALIZATION & USER NORMALIZATION
// ============================================================================

export function ensureProcurementCollections(): void {
  if (!database.purchaseRequests) database.purchaseRequests = [];
  if (!database.purchaseOrders) database.purchaseOrders = [];
  if (!database.goodsReceipts) database.goodsReceipts = [];
  if (!database.inventoryItems) database.inventoryItems = [];
  if (!database.suppliers) database.suppliers = [];
  if (!database.inventoryLocations) database.inventoryLocations = [];
  if (!database.assets) database.assets = [];
  if (!database.assetCategories) database.assetCategories = [];
  if (!database.notifications) database.notifications = [];
}

export interface NormalizedActor {
  id: string;
  name: string;
  role: UserRole;
}

export function normalizeActor(user: any): NormalizedActor {
  return {
    id: user?.id || 'usr-admin-1',
    name: user?.name || 'Administrator',
    role: (user?.role as UserRole) || 'SUPER_ADMIN'
  };
}

// ============================================================================
// CONCURRENCY-SAFE DOCUMENT NUMBER GENERATORS
// ============================================================================

export function generatePurchaseRequestNumber(schoolId: string): string {
  ensureProcurementCollections();
  const year = new Date().getFullYear();
  let counter = database.purchaseRequests.filter(pr => pr.schoolId === schoolId).length + 1;
  let code = `PR-${year}-${String(counter).padStart(4, '0')}`;
  while (database.purchaseRequests.some(pr => pr.schoolId === schoolId && pr.requestNumber.toUpperCase() === code.toUpperCase())) {
    counter++;
    code = `PR-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

export function generatePurchaseOrderNumber(schoolId: string): string {
  ensureProcurementCollections();
  const year = new Date().getFullYear();
  let counter = database.purchaseOrders.filter(po => po.schoolId === schoolId).length + 1;
  let code = `PO-${year}-${String(counter).padStart(4, '0')}`;
  while (database.purchaseOrders.some(po => po.schoolId === schoolId && po.poNumber.toUpperCase() === code.toUpperCase())) {
    counter++;
    code = `PO-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

export function generateGoodsReceiptNumber(schoolId: string): string {
  ensureProcurementCollections();
  const year = new Date().getFullYear();
  let counter = database.goodsReceipts.filter(gr => gr.schoolId === schoolId).length + 1;
  let code = `GRN-${year}-${String(counter).padStart(4, '0')}`;
  while (database.goodsReceipts.some(gr => gr.schoolId === schoolId && gr.receiptNumber.toUpperCase() === code.toUpperCase())) {
    counter++;
    code = `GRN-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

// ============================================================================
// PROCUREMENT NOTIFICATIONS HELPER
// ============================================================================

export function sendProcurementNotification(params: {
  userId?: string;
  roleTarget?: UserRole;
  title: string;
  message: string;
  link?: string;
  metadata?: any;
}): void {
  ensureProcurementCollections();
  database.notifications.unshift({
    id: `notif-proc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userId: params.userId || 'usr-admin-1',
    roleTarget: params.roleTarget || 'SUPER_ADMIN',
    category: 'system',
    type: 'PROCUREMENT_ALERT',
    title: params.title,
    message: params.message,
    isRead: false,
    link: params.link || '/admin/inventory',
    createdAt: new Date().toISOString(),
    metadata: params.metadata
  });
}

// ============================================================================
// MAIN PROCUREMENT SERVICE
// ============================================================================

export class ProcurementService {
  // --------------------------------------------------------------------------
  // 1. PURCHASE REQUESTS
  // --------------------------------------------------------------------------

  /**
   * List purchase requests with filtering & search
   */
  static listPurchaseRequests(schoolId: string, filters: {
    status?: string;
    priority?: string;
    search?: string;
    department?: string;
    page?: number;
    limit?: number;
  } = {}) {
    ensureProcurementCollections();
    let prs = database.purchaseRequests.filter(pr => pr.schoolId === schoolId);

    if (filters.status && filters.status !== 'ALL') {
      prs = prs.filter(pr => pr.status === filters.status);
    }
    if (filters.priority && filters.priority !== 'ALL') {
      prs = prs.filter(pr => pr.priority === filters.priority);
    }
    if (filters.department && filters.department !== 'ALL') {
      prs = prs.filter(pr => pr.departmentName.toLowerCase().includes(filters.department!.toLowerCase()));
    }
    if (filters.search && filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      prs = prs.filter(pr =>
        pr.requestNumber.toLowerCase().includes(q) ||
        pr.purpose.toLowerCase().includes(q) ||
        pr.requestingUserName.toLowerCase().includes(q) ||
        pr.items.some(i => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
      );
    }

    prs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters.page || 1);
    const limit = Math.max(1, Math.min(100, filters.limit || 20));
    const total = prs.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const paginated = prs.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, totalPages }
    };
  }

  /**
   * Get single purchase request by ID
   */
  static getPurchaseRequestById(schoolId: string, id: string): PurchaseRequest {
    ensureProcurementCollections();
    const pr = database.purchaseRequests.find(r => r.id === id && r.schoolId === schoolId);
    if (!pr) throw new Error(`Purchase Request '${id}' not found.`);
    return pr;
  }

  /**
   * Create a new Purchase Request
   */
  static createPurchaseRequest(schoolId: string, payload: CreatePurchaseRequestPayload, rawUser: any): PurchaseRequest {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    if (!payload.purpose || !payload.purpose.trim()) {
      throw new Error('Purchase request purpose/reason is required.');
    }
    if (!payload.targetLocationId) {
      throw new Error('Target receiving store/location is required.');
    }

    const location = database.inventoryLocations.find(l => l.id === payload.targetLocationId && l.schoolId === schoolId);
    if (!location) {
      throw new Error(`Target store/location '${payload.targetLocationId}' does not exist.`);
    }

    if (!payload.items || !Array.isArray(payload.items) || payload.items.length === 0) {
      throw new Error('At least one line item is required in the purchase request.');
    }

    let calculatedTotal = 0;
    const parsedItems: PurchaseRequestItem[] = [];

    for (const itemPayload of payload.items) {
      if (!itemPayload.itemId) throw new Error('Item ID is required for each requested line.');
      const inventoryItem = database.inventoryItems.find(i => i.id === itemPayload.itemId && i.schoolId === schoolId);
      if (!inventoryItem) throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);

      const qty = Number(itemPayload.quantity);
      if (isNaN(qty) || qty <= 0) throw new Error(`Quantity for '${inventoryItem.name}' must be greater than zero.`);

      const unitCost = Number(itemPayload.estimatedUnitCost !== undefined ? itemPayload.estimatedUnitCost : inventoryItem.unitPrice || 0);
      const estTotal = Math.round(qty * unitCost * 100) / 100;
      calculatedTotal += estTotal;

      let prefSupplierName: string | undefined;
      if (itemPayload.preferredSupplierId) {
        const sup = database.suppliers.find(s => s.id === itemPayload.preferredSupplierId && s.schoolId === schoolId);
        if (sup) prefSupplierName = sup.name;
      }

      parsedItems.push({
        id: `pri-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        itemId: inventoryItem.id,
        itemName: inventoryItem.name,
        itemCode: inventoryItem.itemCode,
        description: itemPayload.description?.trim() || inventoryItem.description,
        quantity: qty,
        unitId: inventoryItem.unitId,
        unitShortCode: inventoryItem.unitShortCode,
        estimatedUnitCost: unitCost,
        estimatedTotal: estTotal,
        preferredSupplierId: itemPayload.preferredSupplierId,
        preferredSupplierName: prefSupplierName,
        requiredDate: itemPayload.requiredDate || payload.requiredDate,
        isCapitalAsset: Boolean(itemPayload.isCapitalAsset || inventoryItem.itemType === 'NON_CONSUMABLE'),
        notes: itemPayload.notes?.trim()
      });
    }

    const now = new Date().toISOString();
    const reqNumber = generatePurchaseRequestNumber(schoolId);

    const newRequest: PurchaseRequest = {
      id: `pr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      requestNumber: reqNumber,
      requestDate: now,
      requiredDate: payload.requiredDate,
      priority: payload.priority || 'MEDIUM',
      status: 'SUBMITTED',
      requestingUserId: actor.id,
      requestingUserName: actor.name,
      departmentId: payload.departmentId,
      departmentName: payload.departmentName?.trim() || location.department || 'Operations',
      targetLocationId: location.id,
      targetLocationName: location.name,
      purpose: payload.purpose.trim(),
      notes: payload.notes?.trim(),
      items: parsedItems,
      totalEstimatedAmount: Math.round(calculatedTotal * 100) / 100,
      createdAt: now,
      updatedAt: now
    };

    database.purchaseRequests.unshift(newRequest);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'PurchaseRequest',
      entityId: newRequest.id,
      details: `Created Purchase Request ${newRequest.requestNumber} with ${newRequest.items.length} item(s) (Est. total: $${newRequest.totalEstimatedAmount})`
    });

    sendProcurementNotification({
      title: `New Purchase Request: ${newRequest.requestNumber}`,
      message: `${actor.name} submitted Purchase Request ${newRequest.requestNumber} for ${newRequest.departmentName} ($${newRequest.totalEstimatedAmount}).`,
      metadata: { purchaseRequestId: newRequest.id, requestNumber: newRequest.requestNumber }
    });

    return newRequest;
  }

  /**
   * Update draft/submitted purchase request
   */
  static updatePurchaseRequest(schoolId: string, id: string, payload: UpdatePurchaseRequestPayload, rawUser: any): PurchaseRequest {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);
    const pr = this.getPurchaseRequestById(schoolId, id);

    if (pr.status !== 'DRAFT' && pr.status !== 'SUBMITTED') {
      throw new Error(`Cannot modify Purchase Request in '${pr.status}' status. Only DRAFT or SUBMITTED requests can be modified.`);
    }

    if (payload.purpose !== undefined) {
      if (!payload.purpose.trim()) throw new Error('Purpose cannot be empty.');
      pr.purpose = payload.purpose.trim();
    }
    if (payload.priority !== undefined) pr.priority = payload.priority;
    if (payload.requiredDate !== undefined) pr.requiredDate = payload.requiredDate;
    if (payload.notes !== undefined) pr.notes = payload.notes?.trim();

    if (payload.targetLocationId !== undefined) {
      const loc = database.inventoryLocations.find(l => l.id === payload.targetLocationId && l.schoolId === schoolId);
      if (!loc) throw new Error('Target location not found.');
      pr.targetLocationId = loc.id;
      pr.targetLocationName = loc.name;
    }

    if (payload.items && Array.isArray(payload.items) && payload.items.length > 0) {
      let calculatedTotal = 0;
      const parsedItems: PurchaseRequestItem[] = [];

      for (const itemPayload of payload.items) {
        const inventoryItem = database.inventoryItems.find(i => i.id === itemPayload.itemId && i.schoolId === schoolId);
        if (!inventoryItem) throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);

        const qty = Number(itemPayload.quantity);
        if (isNaN(qty) || qty <= 0) throw new Error(`Quantity for '${inventoryItem.name}' must be greater than zero.`);

        const unitCost = Number(itemPayload.estimatedUnitCost !== undefined ? itemPayload.estimatedUnitCost : inventoryItem.unitPrice || 0);
        const estTotal = Math.round(qty * unitCost * 100) / 100;
        calculatedTotal += estTotal;

        parsedItems.push({
          id: `pri-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          itemId: inventoryItem.id,
          itemName: inventoryItem.name,
          itemCode: inventoryItem.itemCode,
          description: itemPayload.description?.trim() || inventoryItem.description,
          quantity: qty,
          unitId: inventoryItem.unitId,
          unitShortCode: inventoryItem.unitShortCode,
          estimatedUnitCost: unitCost,
          estimatedTotal: estTotal,
          preferredSupplierId: itemPayload.preferredSupplierId,
          preferredSupplierName: itemPayload.preferredSupplierId ? database.suppliers.find(s => s.id === itemPayload.preferredSupplierId)?.name : undefined,
          requiredDate: itemPayload.requiredDate || pr.requiredDate,
          isCapitalAsset: Boolean(itemPayload.isCapitalAsset || inventoryItem.itemType === 'NON_CONSUMABLE'),
          notes: itemPayload.notes?.trim()
        });
      }

      pr.items = parsedItems;
      pr.totalEstimatedAmount = Math.round(calculatedTotal * 100) / 100;
    }

    pr.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'PurchaseRequest',
      entityId: pr.id,
      details: `Updated Purchase Request ${pr.requestNumber}`
    });

    return pr;
  }

  /**
   * Review Purchase Request (Approve / Reject)
   */
  static reviewPurchaseRequest(schoolId: string, id: string, payload: ReviewPurchaseRequestPayload, rawUser: any): PurchaseRequest {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);
    const pr = this.getPurchaseRequestById(schoolId, id);

    if (pr.status !== 'SUBMITTED' && pr.status !== 'UNDER_REVIEW') {
      throw new Error(`Cannot review Purchase Request in '${pr.status}' status. Only SUBMITTED or UNDER_REVIEW requests can be reviewed.`);
    }

    const now = new Date().toISOString();
    pr.reviewedBy = actor.id;
    pr.reviewedByName = actor.name;
    pr.reviewedAt = now;
    pr.reviewNotes = payload.reviewNotes?.trim();

    if (payload.decision === 'APPROVE') {
      pr.status = 'APPROVED';
      logAudit({
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'PurchaseRequest',
        entityId: pr.id,
        details: `Approved Purchase Request ${pr.requestNumber}`
      });

      sendProcurementNotification({
        userId: pr.requestingUserId,
        title: `Purchase Request Approved: ${pr.requestNumber}`,
        message: `Your purchase request ${pr.requestNumber} has been approved by ${actor.name}.`,
        metadata: { purchaseRequestId: pr.id }
      });
    } else if (payload.decision === 'REJECT') {
      if (!payload.rejectionReason || !payload.rejectionReason.trim()) {
        throw new Error('A meaningful rejection reason is required when rejecting a purchase request.');
      }
      pr.status = 'REJECTED';
      pr.rejectionReason = payload.rejectionReason.trim();

      logAudit({
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'PurchaseRequest',
        entityId: pr.id,
        details: `Rejected Purchase Request ${pr.requestNumber}: ${pr.rejectionReason}`
      });

      sendProcurementNotification({
        userId: pr.requestingUserId,
        title: `Purchase Request Rejected: ${pr.requestNumber}`,
        message: `Your purchase request ${pr.requestNumber} was rejected: ${pr.rejectionReason}`,
        metadata: { purchaseRequestId: pr.id }
      });
    } else {
      throw new Error("Invalid review decision. Must be 'APPROVE' or 'REJECT'.");
    }

    pr.updatedAt = now;
    return pr;
  }

  /**
   * Cancel Purchase Request
   */
  static cancelPurchaseRequest(schoolId: string, id: string, reason: string, rawUser: any): PurchaseRequest {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);
    const pr = this.getPurchaseRequestById(schoolId, id);

    if (pr.status === 'CONVERTED_TO_PO') {
      throw new Error('Cannot cancel a Purchase Request that has already been converted into a Purchase Order.');
    }
    if (pr.status === 'CANCELLED') {
      throw new Error('Purchase Request is already cancelled.');
    }

    pr.status = 'CANCELLED';
    pr.reviewNotes = reason ? `Cancelled: ${reason.trim()}` : pr.reviewNotes;
    pr.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'PurchaseRequest',
      entityId: pr.id,
      details: `Cancelled Purchase Request ${pr.requestNumber}. Reason: ${reason || 'User cancelled'}`
    });

    return pr;
  }

  /**
   * Convert an Approved Purchase Request to a Purchase Order
   */
  static async convertRequestToPurchaseOrder(
    schoolId: string,
    requestId: string,
    payload: ConvertRequestToPOPayload,
    rawUser: any
  ): Promise<PurchaseOrder> {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    return withProcurementLock(`pr:${schoolId}:${requestId}`, async () => {
      const pr = this.getPurchaseRequestById(schoolId, requestId);

      if (pr.status !== 'APPROVED') {
        throw new Error(`Only APPROVED Purchase Requests can be converted to Purchase Orders. Current status: '${pr.status}'.`);
      }
      if (pr.purchaseOrderId) {
        throw new Error(`Purchase Request ${pr.requestNumber} has already been converted to PO (${pr.purchaseOrderNumber}). Duplicate conversion prevented.`);
      }

      const supplier = database.suppliers.find(s => s.id === payload.supplierId && s.schoolId === schoolId);
      if (!supplier) throw new Error(`Supplier '${payload.supplierId}' not found.`);
      if (supplier.status === 'INACTIVE') throw new Error(`Supplier '${supplier.name}' is inactive.`);

      // Map lines from PR to PO
      const poItemsPayload = pr.items.map(item => {
        const override = payload.itemsOverrides?.find(o => o.itemId === item.itemId);
        return {
          itemId: item.itemId,
          description: item.description,
          quantityOrdered: override?.quantityOrdered !== undefined ? override.quantityOrdered : item.quantity,
          unitPrice: override?.unitPrice !== undefined ? override.unitPrice : item.estimatedUnitCost,
          discountPercentage: override?.discountPercentage || 0,
          taxPercentage: override?.taxPercentage || 0,
          isCapitalAsset: item.isCapitalAsset,
          expectedDeliveryDate: item.requiredDate || payload.expectedDeliveryDate,
          notes: item.notes
        };
      });

      const poPayload: CreatePurchaseOrderPayload = {
        supplierId: supplier.id,
        purchaseRequestId: pr.id,
        departmentId: pr.departmentId,
        departmentName: pr.departmentName,
        deliveryLocationId: pr.targetLocationId,
        expectedDeliveryDate: payload.expectedDeliveryDate || pr.requiredDate,
        paymentTerms: payload.paymentTerms || 'NET 30',
        notes: payload.notes || pr.notes,
        items: poItemsPayload
      };

      const po = await this.createPurchaseOrder(schoolId, poPayload, actor);

      // Mark PR as converted
      pr.status = 'CONVERTED_TO_PO';
      pr.purchaseOrderId = po.id;
      pr.purchaseOrderNumber = po.poNumber;
      pr.updatedAt = new Date().toISOString();

      logAudit({
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'PurchaseRequest',
        entityId: pr.id,
        details: `Converted Purchase Request ${pr.requestNumber} to Purchase Order ${po.poNumber}`
      });

      return po;
    });
  }

  // --------------------------------------------------------------------------
  // 2. PURCHASE ORDERS
  // --------------------------------------------------------------------------

  /**
   * List Purchase Orders with filters
   */
  static listPurchaseOrders(schoolId: string, filters: {
    status?: string;
    supplierId?: string;
    search?: string;
    page?: number;
    limit?: number;
  } = {}) {
    ensureProcurementCollections();
    let pos = database.purchaseOrders.filter(po => po.schoolId === schoolId);

    if (filters.status && filters.status !== 'ALL') {
      pos = pos.filter(po => po.status === filters.status);
    }
    if (filters.supplierId && filters.supplierId !== 'ALL') {
      pos = pos.filter(po => po.supplierId === filters.supplierId);
    }
    if (filters.search && filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      pos = pos.filter(po =>
        po.poNumber.toLowerCase().includes(q) ||
        po.supplierName.toLowerCase().includes(q) ||
        po.supplierCode.toLowerCase().includes(q) ||
        (po.supplierInvoiceNumber && po.supplierInvoiceNumber.toLowerCase().includes(q)) ||
        po.items.some(i => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
      );
    }

    pos.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters.page || 1);
    const limit = Math.max(1, Math.min(100, filters.limit || 20));
    const total = pos.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const paginated = pos.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, totalPages }
    };
  }

  /**
   * Get single Purchase Order by ID
   */
  static getPurchaseOrderById(schoolId: string, id: string): PurchaseOrder {
    ensureProcurementCollections();
    const po = database.purchaseOrders.find(o => o.id === id && o.schoolId === schoolId);
    if (!po) throw new Error(`Purchase Order '${id}' not found.`);
    return po;
  }

  /**
   * Create Purchase Order directly or from PR
   */
  static async createPurchaseOrder(
    schoolId: string,
    payload: CreatePurchaseOrderPayload,
    rawUser: any
  ): Promise<PurchaseOrder> {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    const supplier = database.suppliers.find(s => s.id === payload.supplierId && s.schoolId === schoolId);
    if (!supplier) throw new Error(`Supplier '${payload.supplierId}' not found.`);
    if (supplier.status === 'INACTIVE') throw new Error(`Supplier '${supplier.name}' is inactive.`);

    const deliveryLocation = database.inventoryLocations.find(l => l.id === payload.deliveryLocationId && l.schoolId === schoolId);
    if (!deliveryLocation) throw new Error(`Delivery location '${payload.deliveryLocationId}' not found.`);

    if (!payload.items || !Array.isArray(payload.items) || payload.items.length === 0) {
      throw new Error('At least one item must be ordered in a Purchase Order.');
    }

    let subtotal = 0;
    let totalDiscount = 0;
    let totalTax = 0;
    const parsedItems: PurchaseOrderItem[] = [];

    for (const itemPayload of payload.items) {
      const inventoryItem = database.inventoryItems.find(i => i.id === itemPayload.itemId && i.schoolId === schoolId);
      if (!inventoryItem) throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);

      const qty = Number(itemPayload.quantityOrdered);
      if (isNaN(qty) || qty <= 0) throw new Error(`Quantity ordered for '${inventoryItem.name}' must be greater than zero.`);

      const unitPrice = Number(itemPayload.unitPrice);
      if (isNaN(unitPrice) || unitPrice < 0) throw new Error(`Unit price for '${inventoryItem.name}' must be non-negative.`);

      const lineRawTotal = qty * unitPrice;
      const discountPct = Number(itemPayload.discountPercentage || 0);
      const discountAmt = Math.round(lineRawTotal * (discountPct / 100) * 100) / 100;
      const taxableAmount = lineRawTotal - discountAmt;
      const taxPct = Number(itemPayload.taxPercentage || 0);
      const taxAmt = Math.round(taxableAmount * (taxPct / 100) * 100) / 100;
      const lineTotal = Math.round((taxableAmount + taxAmt) * 100) / 100;

      subtotal += lineRawTotal;
      totalDiscount += discountAmt;
      totalTax += taxAmt;

      parsedItems.push({
        id: `poi-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        itemId: inventoryItem.id,
        itemName: inventoryItem.name,
        itemCode: inventoryItem.itemCode,
        description: itemPayload.description?.trim() || inventoryItem.description,
        quantityOrdered: qty,
        quantityReceived: 0,
        quantityRemaining: qty,
        unitId: inventoryItem.unitId,
        unitShortCode: inventoryItem.unitShortCode,
        unitPrice,
        discountPercentage: discountPct,
        discountAmount: discountAmt,
        taxPercentage: taxPct,
        taxAmount: taxAmt,
        lineTotal,
        isCapitalAsset: Boolean(itemPayload.isCapitalAsset || inventoryItem.itemType === 'NON_CONSUMABLE'),
        expectedDeliveryDate: itemPayload.expectedDeliveryDate || payload.expectedDeliveryDate,
        notes: itemPayload.notes?.trim()
      });
    }

    const grandTotal = Math.round((subtotal - totalDiscount + totalTax) * 100) / 100;
    const now = new Date().toISOString();
    const poNumber = generatePurchaseOrderNumber(schoolId);

    let prNumber: string | undefined;
    if (payload.purchaseRequestId) {
      const pr = database.purchaseRequests.find(r => r.id === payload.purchaseRequestId && r.schoolId === schoolId);
      if (pr) prNumber = pr.requestNumber;
    }

    const newPO: PurchaseOrder = {
      id: `po-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      poNumber,
      poDate: now,
      supplierId: supplier.id,
      supplierName: supplier.name,
      supplierCode: supplier.supplierCode,
      purchaseRequestId: payload.purchaseRequestId,
      purchaseRequestNumber: prNumber,
      departmentId: payload.departmentId,
      departmentName: payload.departmentName?.trim() || deliveryLocation.department || 'Operations',
      deliveryLocationId: deliveryLocation.id,
      deliveryLocationName: deliveryLocation.name,
      expectedDeliveryDate: payload.expectedDeliveryDate,
      paymentTerms: payload.paymentTerms?.trim() || 'NET 30',
      supplierInvoiceNumber: payload.supplierInvoiceNumber?.trim(),
      financialReference: payload.financialReference?.trim(),
      status: 'PENDING_APPROVAL',
      items: parsedItems,
      subtotal: Math.round(subtotal * 100) / 100,
      totalDiscount: Math.round(totalDiscount * 100) / 100,
      totalTax: Math.round(totalTax * 100) / 100,
      grandTotal,
      notes: payload.notes?.trim(),
      createdBy: actor.id,
      createdByName: actor.name,
      createdAt: now,
      updatedAt: now
    };

    database.purchaseOrders.unshift(newPO);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'PurchaseOrder',
      entityId: newPO.id,
      details: `Created Purchase Order ${newPO.poNumber} for '${newPO.supplierName}' ($${newPO.grandTotal})`
    });

    sendProcurementNotification({
      title: `Purchase Order Pending Approval: ${newPO.poNumber}`,
      message: `Purchase Order ${newPO.poNumber} to ${newPO.supplierName} ($${newPO.grandTotal}) is awaiting administrative approval.`,
      metadata: { purchaseOrderId: newPO.id, poNumber: newPO.poNumber }
    });

    return newPO;
  }

  /**
   * Review Purchase Order (Approve / Reject)
   */
  static async reviewPurchaseOrder(
    schoolId: string,
    id: string,
    payload: ReviewPurchaseOrderPayload,
    rawUser: any
  ): Promise<PurchaseOrder> {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    return withProcurementLock(`po:${schoolId}:${id}`, async () => {
      const po = this.getPurchaseOrderById(schoolId, id);

      if (po.status !== 'PENDING_APPROVAL' && po.status !== 'DRAFT') {
        throw new Error(`Cannot review Purchase Order in '${po.status}' status. Only PENDING_APPROVAL orders can be reviewed.`);
      }

      const now = new Date().toISOString();

      if (payload.decision === 'APPROVE') {
        po.status = 'APPROVED';
        po.approvedBy = actor.id;
        po.approvedByName = actor.name;
        po.approvedAt = now;
        po.rejectionReason = undefined;

        logAudit({
          userId: actor.id,
          userName: actor.name,
          userRole: actor.role,
          action: 'UPDATE',
          entity: 'OTHER',
          entityType: 'PurchaseOrder',
          entityId: po.id,
          details: `Approved Purchase Order ${po.poNumber}`
        });

        sendProcurementNotification({
          userId: po.createdBy,
          title: `Purchase Order Approved: ${po.poNumber}`,
          message: `Purchase Order ${po.poNumber} was approved by ${actor.name}. You may now dispatch it to ${po.supplierName}.`,
          metadata: { purchaseOrderId: po.id }
        });
      } else if (payload.decision === 'REJECT') {
        if (!payload.rejectionReason || !payload.rejectionReason.trim()) {
          throw new Error('A rejection reason is required when rejecting a Purchase Order.');
        }
        po.status = 'REJECTED';
        po.rejectionReason = payload.rejectionReason.trim();

        logAudit({
          userId: actor.id,
          userName: actor.name,
          userRole: actor.role,
          action: 'UPDATE',
          entity: 'OTHER',
          entityType: 'PurchaseOrder',
          entityId: po.id,
          details: `Rejected Purchase Order ${po.poNumber}. Reason: ${po.rejectionReason}`
        });

        sendProcurementNotification({
          userId: po.createdBy,
          title: `Purchase Order Rejected: ${po.poNumber}`,
          message: `Purchase Order ${po.poNumber} was rejected: ${po.rejectionReason}`,
          metadata: { purchaseOrderId: po.id }
        });
      }

      po.updatedAt = now;
      return po;
    });
  }

  /**
   * Mark Purchase Order as dispatched / Sent to Supplier
   */
  static markPurchaseOrderSent(schoolId: string, id: string, rawUser: any): PurchaseOrder {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);
    const po = this.getPurchaseOrderById(schoolId, id);

    if (po.status !== 'APPROVED') {
      throw new Error(`Only APPROVED Purchase Orders can be marked as sent to supplier. Current status: '${po.status}'.`);
    }

    const now = new Date().toISOString();
    po.status = 'SENT_TO_SUPPLIER';
    po.sentAt = now;
    po.updatedAt = now;

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'PurchaseOrder',
      entityId: po.id,
      details: `Marked Purchase Order ${po.poNumber} as Sent to Supplier '${po.supplierName}'`
    });

    return po;
  }

  /**
   * Cancel Purchase Order
   */
  static async cancelPurchaseOrder(
    schoolId: string,
    id: string,
    reason: string,
    rawUser: any
  ): Promise<PurchaseOrder> {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    return withProcurementLock(`po:${schoolId}:${id}`, async () => {
      const po = this.getPurchaseOrderById(schoolId, id);

      if (po.status === 'FULLY_RECEIVED' || po.status === 'COMPLETED') {
        throw new Error(`Cannot cancel Purchase Order in '${po.status}' status. Received items have already entered physical inventory.`);
      }
      if (po.status === 'CANCELLED') {
        throw new Error('Purchase Order is already cancelled.');
      }

      // Check if any goods were already received
      const hasReceivedItems = po.items.some(i => i.quantityReceived > 0);
      if (hasReceivedItems) {
        throw new Error('Cannot cancel Purchase Order with partial goods already received. Please close the remaining balance or perform stock adjustment.');
      }

      po.status = 'CANCELLED';
      po.cancellationReason = reason?.trim() || 'Administrative cancellation';
      po.cancelledBy = actor.id;
      po.cancelledByName = actor.name;
      po.cancelledAt = new Date().toISOString();
      po.updatedAt = po.cancelledAt;

      logAudit({
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'PurchaseOrder',
        entityId: po.id,
        details: `Cancelled Purchase Order ${po.poNumber}. Reason: ${po.cancellationReason}`
      });

      return po;
    });
  }

  // --------------------------------------------------------------------------
  // 3. GOODS RECEIVING & STOCK INTEGRATION
  // --------------------------------------------------------------------------

  /**
   * List Goods Receipts with pagination & filtering
   */
  static listGoodsReceipts(schoolId: string, filters: {
    purchaseOrderId?: string;
    supplierId?: string;
    search?: string;
    page?: number;
    limit?: number;
  } = {}) {
    ensureProcurementCollections();
    let grns = database.goodsReceipts.filter(gr => gr.schoolId === schoolId);

    if (filters.purchaseOrderId && filters.purchaseOrderId !== 'ALL') {
      grns = grns.filter(gr => gr.purchaseOrderId === filters.purchaseOrderId);
    }
    if (filters.supplierId && filters.supplierId !== 'ALL') {
      grns = grns.filter(gr => gr.supplierId === filters.supplierId);
    }
    if (filters.search && filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      grns = grns.filter(gr =>
        gr.receiptNumber.toLowerCase().includes(q) ||
        gr.purchaseOrderNumber.toLowerCase().includes(q) ||
        gr.supplierName.toLowerCase().includes(q) ||
        (gr.referenceNumber && gr.referenceNumber.toLowerCase().includes(q))
      );
    }

    grns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, filters.page || 1);
    const limit = Math.max(1, Math.min(100, filters.limit || 20));
    const total = grns.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const paginated = grns.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, totalPages }
    };
  }

  /**
   * Get single Goods Receipt by ID
   */
  static getGoodsReceiptById(schoolId: string, id: string): GoodsReceipt {
    ensureProcurementCollections();
    const gr = database.goodsReceipts.find(g => g.id === id && g.schoolId === schoolId);
    if (!gr) throw new Error(`Goods Receipt '${id}' not found.`);
    return gr;
  }

  /**
   * Process Goods Receiving against an active Purchase Order
   * ATOMIC TRANSACTION:
   * 1. Validates PO status (APPROVED, SENT_TO_SUPPLIER, PARTIALLY_RECEIVED)
   * 2. Validates receiving location, quantities (prevents over-receiving)
   * 3. Creates GoodsReceipt & GoodsReceiptItem records
   * 4. Dispatches StockIn to Part 14B StockService (increases physical stock & creates StockMovement)
   * 5. Optionally registers individual Capital Assets in Part 14C AssetService
   * 6. Updates PO line received/remaining quantities and PO status
   * 7. Concurrency-safe mutex locking by PO ID
   */
  static async receiveGoods(
    schoolId: string,
    purchaseOrderId: string,
    payload: ReceiveGoodsPayload,
    rawUser: any
  ): Promise<{ goodsReceipt: GoodsReceipt; purchaseOrder: PurchaseOrder }> {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    // Mutual exclusion lock on this Purchase Order
    return withProcurementLock(`po:${schoolId}:${purchaseOrderId}`, async () => {
      const po = this.getPurchaseOrderById(schoolId, purchaseOrderId);

      const validReceivingStatuses = ['APPROVED', 'SENT_TO_SUPPLIER', 'PARTIALLY_RECEIVED'];
      if (!validReceivingStatuses.includes(po.status)) {
        throw new Error(`Cannot receive goods for Purchase Order in '${po.status}' status. Only APPROVED, SENT_TO_SUPPLIER, or PARTIALLY_RECEIVED orders can be received.`);
      }

      const receivingLocation = database.inventoryLocations.find(
        l => l.id === payload.receivingLocationId && l.schoolId === schoolId
      );
      if (!receivingLocation) {
        throw new Error(`Receiving store/location '${payload.receivingLocationId}' does not exist.`);
      }
      if (receivingLocation.status === 'INACTIVE') {
        throw new Error(`Receiving store/location '${receivingLocation.name}' is inactive.`);
      }

      if (!payload.items || !Array.isArray(payload.items) || payload.items.length === 0) {
        throw new Error('At least one receipt line item is required.');
      }

      // Check idempotency if key provided
      if (payload.idempotencyKey) {
        const existingGrn = database.goodsReceipts.find(
          g => g.schoolId === schoolId &&
               g.purchaseOrderId === po.id &&
               g.notes?.includes(`[IDEMPOTENCY:${payload.idempotencyKey}]`)
        );
        if (existingGrn) {
          return { goodsReceipt: existingGrn, purchaseOrder: po };
        }
      }

      const now = new Date().toISOString();
      const grnNumber = generateGoodsReceiptNumber(schoolId);
      const parsedReceiptItems: GoodsReceiptItem[] = [];

      let totalOrderedQtySum = 0;
      let totalReceivedQtySum = 0;
      let totalAcceptedQtySum = 0;
      let totalRejectedQtySum = 0;

      // Track created entities for rollback if any step throws
      const createdStockTxs: string[] = [];
      const createdAssetIds: string[] = [];

      try {
        for (const itemPayload of payload.items) {
          const poItem = po.items.find(i => i.id === itemPayload.poItemId);
          if (!poItem) {
            throw new Error(`Line item '${itemPayload.poItemId}' does not exist on Purchase Order ${po.poNumber}.`);
          }

          const qtyReceived = Number(itemPayload.quantityReceived);
          const qtyAccepted = Number(itemPayload.quantityAccepted);
          const qtyRejected = Number(itemPayload.quantityRejected || 0);

          if (isNaN(qtyReceived) || qtyReceived <= 0) {
            throw new Error(`Received quantity for '${poItem.itemName}' must be greater than zero.`);
          }
          if (qtyAccepted + qtyRejected !== qtyReceived) {
            throw new Error(`Quantity breakdown mismatch for '${poItem.itemName}': Accepted (${qtyAccepted}) + Rejected (${qtyRejected}) must equal Total Received (${qtyReceived}).`);
          }

          // Strict over-receiving prevention
          if (qtyReceived > poItem.quantityRemaining) {
            throw new Error(
              `Cannot receive ${qtyReceived} ${poItem.unitShortCode} of '${poItem.itemName}'. Remaining balance on order is only ${poItem.quantityRemaining} (Ordered: ${poItem.quantityOrdered}, Previously Received: ${poItem.quantityReceived}). Over-receiving is not permitted.`
            );
          }

          if (qtyRejected > 0 && (!itemPayload.rejectionReason || !itemPayload.rejectionReason.trim())) {
            throw new Error(`A rejection reason is required for the ${qtyRejected} rejected units of '${poItem.itemName}'.`);
          }

          totalOrderedQtySum += poItem.quantityOrdered;
          totalReceivedQtySum += qtyReceived;
          totalAcceptedQtySum += qtyAccepted;
          totalRejectedQtySum += qtyRejected;

          let stockTxId: string | undefined;

          // ------------------------------------------------------------------
          // 4. INTEGRATE WITH INVENTORY STOCK IN (Part 14B)
          // ------------------------------------------------------------------
          // Only accepted quantities enter usable stock
          if (qtyAccepted > 0) {
            const stockInResult = await StockService.recordStockIn(
              schoolId,
              {
                itemId: poItem.itemId,
                locationId: receivingLocation.id,
                quantity: qtyAccepted,
                supplierId: po.supplierId,
                unitCost: poItem.unitPrice,
                referenceNumber: `${po.poNumber} / ${grnNumber}`,
                date: payload.receiptDate || now,
                notes: `Received via Goods Receipt ${grnNumber} against Purchase Order ${po.poNumber}. Accepted: ${qtyAccepted} ${poItem.unitShortCode}.`
              },
              actor
            );

            stockTxId = stockInResult.transaction.id;
            createdStockTxs.push(stockTxId);
          }

          // ------------------------------------------------------------------
          // 5. INTEGRATE WITH ASSET REGISTER (Part 14C)
          // ------------------------------------------------------------------
          const lineAssetIds: string[] = [];
          if (poItem.isCapitalAsset && itemPayload.createAssets && Array.isArray(itemPayload.createAssets)) {
            for (const assetSpec of itemPayload.createAssets) {
              const defaultCat = database.assetCategories.find(c => c.schoolId === schoolId);
              const categoryId = assetSpec.categoryId || defaultCat?.id;

              if (!categoryId) {
                throw new Error(`Asset category is required to create capital asset for '${poItem.itemName}'.`);
              }

              const newAsset = AssetService.createAsset(
                schoolId,
                {
                  name: assetSpec.name || poItem.itemName,
                  categoryId,
                  locationId: receivingLocation.id,
                  supplierId: po.supplierId,
                  assetTag: assetSpec.assetTag,
                  serialNumber: assetSpec.serialNumber,
                  brand: assetSpec.brand,
                  model: assetSpec.model,
                  purchaseDate: payload.receiptDate ? payload.receiptDate.split('T')[0] : now.split('T')[0],
                  purchaseCost: poItem.unitPrice,
                  warrantyEnd: assetSpec.warrantyEnd,
                  condition: itemPayload.itemCondition || 'NEW',
                  status: 'AVAILABLE',
                  description: `Acquired via Purchase Order ${po.poNumber} (Receipt: ${grnNumber}) from ${po.supplierName}.`
                },
                actor
              );

              lineAssetIds.push(newAsset.id);
              createdAssetIds.push(newAsset.id);
            }
          }

          // Update PO item counters
          poItem.quantityReceived += qtyReceived;
          poItem.quantityRemaining -= qtyReceived;

          parsedReceiptItems.push({
            id: `gri-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            poItemId: poItem.id,
            itemId: poItem.itemId,
            itemName: poItem.itemName,
            itemCode: poItem.itemCode,
            unitId: poItem.unitId,
            unitShortCode: poItem.unitShortCode,
            quantityOrdered: poItem.quantityOrdered,
            previouslyReceived: poItem.quantityReceived - qtyReceived,
            quantityReceived: qtyReceived,
            quantityAccepted: qtyAccepted,
            quantityRejected: qtyRejected,
            remainingQuantity: poItem.quantityRemaining,
            rejectionReason: itemPayload.rejectionReason?.trim(),
            itemCondition: itemPayload.itemCondition || 'NEW',
            isCapitalAsset: poItem.isCapitalAsset,
            notes: itemPayload.notes?.trim(),
            stockTransactionId: stockTxId,
            createdAssetIds: lineAssetIds.length > 0 ? lineAssetIds : undefined
          });
        }

        // Determine updated PO status
        const allItemsFullyReceived = po.items.every(i => i.quantityRemaining <= 0);
        if (allItemsFullyReceived) {
          po.status = 'FULLY_RECEIVED';
          po.completedAt = now;
        } else {
          po.status = 'PARTIALLY_RECEIVED';
        }

        po.updatedAt = now;
        if (payload.supplierInvoiceNumber && !po.supplierInvoiceNumber) {
          po.supplierInvoiceNumber = payload.supplierInvoiceNumber.trim();
        }

        const goodsReceipt: GoodsReceipt = {
          id: `grn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          schoolId,
          receiptNumber: grnNumber,
          purchaseOrderId: po.id,
          purchaseOrderNumber: po.poNumber,
          supplierId: po.supplierId,
          supplierName: po.supplierName,
          supplierCode: po.supplierCode,
          receivingLocationId: receivingLocation.id,
          receivingLocationName: receivingLocation.name,
          receiptDate: payload.receiptDate || now,
          receivedBy: actor.id,
          receivedByName: actor.name,
          referenceNumber: payload.referenceNumber?.trim(),
          supplierInvoiceNumber: payload.supplierInvoiceNumber?.trim(),
          status: 'COMPLETED',
          items: parsedReceiptItems,
          totalOrderedQty: totalOrderedQtySum,
          totalReceivedQty: totalReceivedQtySum,
          totalAcceptedQty: totalAcceptedQtySum,
          totalRejectedQty: totalRejectedQtySum,
          notes: payload.idempotencyKey
            ? `${payload.notes || ''} [IDEMPOTENCY:${payload.idempotencyKey}]`.trim()
            : payload.notes?.trim(),
          createdAt: now,
          updatedAt: now
        };

        database.goodsReceipts.unshift(goodsReceipt);

        logAudit({
          userId: actor.id,
          userName: actor.name,
          userRole: actor.role,
          action: 'CREATE',
          entity: 'OTHER',
          entityType: 'GoodsReceipt',
          entityId: goodsReceipt.id,
          details: `Processed Goods Receipt ${goodsReceipt.receiptNumber} for PO ${po.poNumber}. Total Accepted: ${totalAcceptedQtySum}, Rejected: ${totalRejectedQtySum}.`
        });

        sendProcurementNotification({
          title: `Goods Received: ${goodsReceipt.receiptNumber}`,
          message: `${totalAcceptedQtySum} unit(s) accepted from ${po.supplierName} under PO ${po.poNumber} at ${receivingLocation.name}.`,
          metadata: { goodsReceiptId: goodsReceipt.id, poId: po.id }
        });

        return { goodsReceipt, purchaseOrder: po };
      } catch (err: any) {
        // Rollback any stock transactions or created assets if an unexpected error occurs midway
        if (createdStockTxs.length > 0) {
          database.stockTransactions = database.stockTransactions.filter(tx => !createdStockTxs.includes(tx.id));
        }
        if (createdAssetIds.length > 0) {
          database.assets = database.assets.filter(a => !createdAssetIds.includes(a.id));
        }
        throw err;
      }
    });
  }

  /**
   * Create an individual Asset from a previously completed Goods Receipt line
   */
  static createAssetFromReceiptLine(
    schoolId: string,
    payload: CreateAssetFromReceiptPayload,
    rawUser: any
  ) {
    ensureProcurementCollections();
    const actor = normalizeActor(rawUser);

    const grn = this.getGoodsReceiptById(schoolId, payload.goodsReceiptId);
    const grnItem = grn.items.find(i => i.id === payload.goodsReceiptItemId);
    if (!grnItem) {
      throw new Error(`Receipt line '${payload.goodsReceiptItemId}' not found in Goods Receipt ${grn.receiptNumber}.`);
    }

    const po = this.getPurchaseOrderById(schoolId, grn.purchaseOrderId);
    const poItem = po.items.find(i => i.id === grnItem.poItemId);

    const locationId = payload.locationId || grn.receivingLocationId;

    const newAsset = AssetService.createAsset(
      schoolId,
      {
        name: payload.name || grnItem.itemName,
        categoryId: payload.categoryId,
        locationId,
        supplierId: grn.supplierId,
        assetTag: payload.assetTag,
        serialNumber: payload.serialNumber,
        brand: payload.brand,
        model: payload.model,
        purchaseDate: grn.receiptDate.split('T')[0],
        purchaseCost: poItem ? poItem.unitPrice : 0,
        warrantyEnd: payload.warrantyEnd,
        condition: grnItem.itemCondition || 'NEW',
        status: 'AVAILABLE',
        description: `Registered from Goods Receipt ${grn.receiptNumber} under PO ${grn.purchaseOrderNumber}. ${payload.notes || ''}`.trim()
      },
      actor
    );

    if (!grnItem.createdAssetIds) grnItem.createdAssetIds = [];
    grnItem.createdAssetIds.push(newAsset.id);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: newAsset.id,
      details: `Created Asset ${newAsset.assetTag} from Goods Receipt ${grn.receiptNumber} (${grnItem.itemName})`
    });

    return newAsset;
  }

  // --------------------------------------------------------------------------
  // 4. SUPPLIER PROCUREMENT HISTORY & ENHANCED METRICS
  // --------------------------------------------------------------------------

  /**
   * Retrieve rich procurement analytics for a specific supplier
   */
  static getSupplierProcurementHistory(schoolId: string, supplierId: string) {
    ensureProcurementCollections();
    const supplier = database.suppliers.find(s => s.id === supplierId && s.schoolId === schoolId);
    if (!supplier) throw new Error(`Supplier '${supplierId}' not found.`);

    const pos = database.purchaseOrders.filter(po => po.schoolId === schoolId && po.supplierId === supplier.id);
    const grns = database.goodsReceipts.filter(gr => gr.schoolId === schoolId && gr.supplierId === supplier.id);

    const totalOrders = pos.length;
    const openOrders = pos.filter(po => ['APPROVED', 'SENT_TO_SUPPLIER', 'PARTIALLY_RECEIVED'].includes(po.status)).length;
    const completedOrders = pos.filter(po => ['FULLY_RECEIVED', 'COMPLETED'].includes(po.status)).length;
    const partiallyReceivedOrders = pos.filter(po => po.status === 'PARTIALLY_RECEIVED').length;

    let totalOrderedQty = 0;
    let totalReceivedQty = 0;
    let totalOrderValue = 0;

    pos.forEach(po => {
      totalOrderValue += po.grandTotal;
      po.items.forEach(item => {
        totalOrderedQty += item.quantityOrdered;
        totalReceivedQty += item.quantityReceived;
      });
    });

    const recentPurchaseOrders = [...pos]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);

    const recentGoodsReceipts = [...grns]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);

    return {
      supplier,
      metrics: {
        totalOrders,
        openOrders,
        completedOrders,
        partiallyReceivedOrders,
        totalOrderedQty,
        totalReceivedQty,
        fulfillmentRatePercentage: totalOrderedQty > 0 ? Math.round((totalReceivedQty / totalOrderedQty) * 100) : 0,
        totalOrderValue: Math.round(totalOrderValue * 100) / 100
      },
      recentPurchaseOrders,
      recentGoodsReceipts
    };
  }

  // --------------------------------------------------------------------------
  // 5. DASHBOARD SUMMARY ANALYTICS
  // --------------------------------------------------------------------------

  /**
   * Aggregate procurement dashboard KPIs
   */
  static getDashboardSummary(schoolId: string): ProcurementDashboardSummary {
    ensureProcurementCollections();
    const prs = database.purchaseRequests.filter(pr => pr.schoolId === schoolId);
    const pos = database.purchaseOrders.filter(po => po.schoolId === schoolId);
    const grns = database.goodsReceipts.filter(gr => gr.schoolId === schoolId);
    const suppliers = database.suppliers.filter(s => s.schoolId === schoolId && s.status === 'ACTIVE');

    const pendingRequestsCount = prs.filter(pr => pr.status === 'SUBMITTED' || pr.status === 'UNDER_REVIEW').length;
    const pendingPoApprovalsCount = pos.filter(po => po.status === 'PENDING_APPROVAL').length;
    const openPoCount = pos.filter(po => ['APPROVED', 'SENT_TO_SUPPLIER', 'PARTIALLY_RECEIVED'].includes(po.status)).length;
    const partiallyReceivedPoCount = pos.filter(po => po.status === 'PARTIALLY_RECEIVED').length;
    const completedPoCount = pos.filter(po => ['FULLY_RECEIVED', 'COMPLETED'].includes(po.status)).length;
    const totalSuppliersCount = suppliers.length;
    const recentGoodsReceiptsCount = grns.length;
    const totalProcurementSpent = pos
      .filter(po => po.status !== 'CANCELLED' && po.status !== 'REJECTED')
      .reduce((sum, po) => sum + (Number(po.grandTotal) || 0), 0);

    return {
      pendingRequestsCount,
      pendingPoApprovalsCount,
      openPoCount,
      partiallyReceivedPoCount,
      completedPoCount,
      totalSuppliersCount,
      recentGoodsReceiptsCount,
      totalProcurementSpent: Math.round(totalProcurementSpent * 100) / 100
    };
  }
}
