import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { CommunicationService } from './communication.service.js';
import { sanitizeAnnouncementContent } from './announcement.service.js';
import {
  BulkCampaign,
  BulkCampaignRecipient,
  BulkCampaignFilterParams,
  BulkCampaignAudienceType,
  BulkCampaignPriority,
  BulkCampaignScheduleType,
  BulkCampaignRelationshipType,
  BulkCampaignAttachment,
  RecipientPreviewResult,
  BulkCampaignStats,
  NotificationChannel,
  UserRole
} from '../../src/types/index.js';

// Allowed MIME types for campaign attachments
const ALLOWED_MIME_TYPES = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
]);

const MAX_ATTACHMENT_SIZE_BYTES = 10 * 1024 * 1024; // 10MB per attachment
const MAX_RECIPIENTS_LIMIT = 5000; // Accidental mass dispatch safety threshold
const BATCH_CHUNK_SIZE = 25; // Controlled batch delivery chunk size

export interface ResolvedRecipientTarget {
  recipientId: string;
  userId?: string;
  name: string;
  role: UserRole | string;
  email?: string;
  phone?: string;
  studentId?: string;
  studentName?: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
}

export class BulkCampaignService {
  /**
   * Masks email or phone number for safe recipient preview displays.
   */
  public static maskContact(contact?: string): string {
    if (!contact) return '—';
    if (contact.includes('@')) {
      const parts = contact.split('@');
      const user = parts[0];
      const domain = parts[1] || '';
      const maskedUser = user.length <= 2 ? `${user[0]}*` : `${user.slice(0, 2)}${'*'.repeat(Math.min(user.length - 2, 6))}`;
      return `${maskedUser}@${domain}`;
    }
    // Phone mask
    if (contact.length <= 4) return contact;
    const last4 = contact.slice(-4);
    return `***-***-${last4}`;
  }

  /**
   * Authoritatively resolves audience recipients strictly server-side.
   * Handles multi-child guardian deduplication, role filtering, academic cohort matching,
   * and relationship-based resolution.
   */
  public static resolveAudience(params: {
    audienceType: BulkCampaignAudienceType;
    academicSessionId?: string;
    classId?: string;
    sectionId?: string;
    targetRoles?: (UserRole | string)[];
    selectedRecipientIds?: string[];
    relationshipType?: BulkCampaignRelationshipType;
    subjectId?: string;
  }): {
    recipients: ResolvedRecipientTarget[];
    duplicatesRemoved: number;
    ineligibleExcluded: number;
  } {
    const {
      audienceType,
      academicSessionId,
      classId,
      sectionId,
      targetRoles = [],
      selectedRecipientIds = [],
      relationshipType
    } = params;

    const rawTargets: ResolvedRecipientTarget[] = [];
    let ineligibleExcluded = 0;

    // Helper: Match academic cohort for a student profile
    const matchStudentCohort = (student: any): boolean => {
      if (academicSessionId && student.academicSessionId !== academicSessionId) return false;
      if (classId && student.classId !== classId) return false;
      if (sectionId && student.sectionId !== sectionId) return false;
      return true;
    };

    switch (audienceType) {
      case 'SCHOOL_WIDE': {
        // All active users in the school
        const permittedRoles = targetRoles.length > 0 ? targetRoles : ['GUARDIAN', 'STUDENT', 'TEACHER', 'STAFF', 'SUPER_ADMIN'];
        for (const user of database.users) {
          if (user.status !== 'ACTIVE') {
            ineligibleExcluded++;
            continue;
          }
          if (permittedRoles.includes(user.role)) {
            rawTargets.push({
              recipientId: user.id,
              userId: user.id,
              name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
              role: user.role,
              email: user.email,
              phone: user.phoneNumber || (user as any).phone
            });
          }
        }
        break;
      }

      case 'ROLE_BASED': {
        const rolesToMatch = targetRoles.length > 0 ? targetRoles : ['GUARDIAN', 'STUDENT'];
        for (const user of database.users) {
          if (user.status !== 'ACTIVE') {
            ineligibleExcluded++;
            continue;
          }
          if (rolesToMatch.includes(user.role)) {
            rawTargets.push({
              recipientId: user.id,
              userId: user.id,
              name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
              role: user.role,
              email: user.email,
              phone: user.phoneNumber || (user as any).phone
            });
          }
        }
        break;
      }

      case 'ACADEMIC_COHORT': {
        // Students enrolled in academic cohort
        const matchingStudents = database.studentProfiles.filter((s) => {
          if (s.status === 'WITHDRAWN' || s.status === 'EXPELLED') {
            ineligibleExcluded++;
            return false;
          }
          return matchStudentCohort(s);
        });

        const targetRolesList = targetRoles.length > 0 ? targetRoles : ['STUDENT', 'GUARDIAN'];

        // Include Students if requested
        if (targetRolesList.includes('STUDENT')) {
          for (const student of matchingStudents) {
            const user = database.users.find((u) => u.id === student.userId);
            rawTargets.push({
              recipientId: student.id,
              userId: student.userId,
              name: `${student.firstName} ${student.lastName}`.trim(),
              role: 'STUDENT',
              email: user?.email,
              phone: user?.phoneNumber || (user as any)?.phone,
              studentId: student.id,
              studentName: `${student.firstName} ${student.lastName}`.trim(),
              classId: student.classId,
              className: student.className,
              sectionId: student.sectionId,
              sectionName: student.sectionName
            });
          }
        }

        // Include Guardians of matching students if requested
        if (targetRolesList.includes('GUARDIAN')) {
          const studentIds = new Set(matchingStudents.map((s) => s.id));
          const rels = database.parentStudentRelationships.filter(
            (r) => studentIds.has(r.studentId) && (r as any).isAuthorizedCommunication !== false
          );

          for (const rel of rels) {
            const guardian = database.guardians.find((g) => g.id === rel.guardianId);
            if (!guardian) continue;
            const student = matchingStudents.find((s) => s.id === rel.studentId);
            const user = database.users.find((u) => u.id === guardian.userId);

            rawTargets.push({
              recipientId: guardian.id,
              userId: guardian.userId,
              name: `${guardian.firstName} ${guardian.lastName}`.trim(),
              role: 'GUARDIAN',
              email: guardian.email || user?.email,
              phone: guardian.phone || user?.phoneNumber || (user as any)?.phone,
              studentId: student?.id,
              studentName: student ? `${student.firstName} ${student.lastName}`.trim() : undefined,
              classId: student?.classId,
              className: student?.className,
              sectionId: student?.sectionId,
              sectionName: student?.sectionName
            });
          }
        }

        // Include Teachers of this cohort if requested
        if (targetRolesList.includes('TEACHER')) {
          const targetClass = database.classes.find((c) => c.id === classId);
          const teachers = database.teacherProfiles.filter((t) => {
            if (t.status === 'TERMINATED' || t.status === 'SUSPENDED') return false;
            // Matches class teacher or assigned subjects
            if ((targetClass as any)?.classTeacherId === t.id) return true;
            if (classId && (t.assignedClassIds?.includes(classId) || (t as any).assignedClasses?.includes(classId))) return true;
            return false;
          });

          for (const teacher of teachers) {
            const user = database.users.find((u) => u.id === teacher.userId);
            rawTargets.push({
              recipientId: teacher.id,
              userId: teacher.userId,
              name: `${teacher.firstName} ${teacher.lastName}`.trim(),
              role: 'TEACHER',
              email: teacher.email || user?.email,
              phone: (teacher as any).phone || teacher.contactNumber || user?.phoneNumber || (user as any)?.phone,
              classId: classId,
              className: targetClass?.name
            });
          }
        }
        break;
      }

      case 'RELATIONSHIP_BASED': {
        // Parents of specific class or section
        if (relationshipType === 'PARENTS_OF_CLASS' || relationshipType === 'PARENTS_OF_SECTION') {
          const matchingStudents = database.studentProfiles.filter((s) => {
            if (s.status === 'WITHDRAWN' || s.status === 'EXPELLED') {
              ineligibleExcluded++;
              return false;
            }
            if (classId && s.classId !== classId) return false;
            if (sectionId && s.sectionId !== sectionId) return false;
            return true;
          });

          const studentIds = new Set(matchingStudents.map((s) => s.id));
          const rels = database.parentStudentRelationships.filter(
            (r) => studentIds.has(r.studentId) && r.isAuthorizedCommunication !== false
          );

          for (const rel of rels) {
            const guardian = database.guardians.find((g) => g.id === rel.guardianId);
            if (!guardian) continue;
            const student = matchingStudents.find((s) => s.id === rel.studentId);
            const user = database.users.find((u) => u.id === guardian.userId);

            rawTargets.push({
              recipientId: guardian.id,
              userId: guardian.userId,
              name: `${guardian.firstName} ${guardian.lastName}`.trim(),
              role: 'GUARDIAN',
              email: guardian.email || user?.email,
              phone: guardian.phone || user?.phoneNumber || (user as any)?.phone,
              studentId: student?.id,
              studentName: student ? `${student.firstName} ${student.lastName}`.trim() : undefined,
              classId: student?.classId,
              className: student?.className,
              sectionId: student?.sectionId,
              sectionName: student?.sectionName
            });
          }
        } else if (relationshipType === 'TEACHERS_OF_CLASS') {
          const targetClass = database.classes.find((c) => c.id === classId);
          const teachers = database.teacherProfiles.filter((t) => {
            if (t.status === 'TERMINATED' || t.status === 'SUSPENDED') return false;
            if ((targetClass as any)?.classTeacherId === t.id) return true;
            if (classId && (t.assignedClassIds?.includes(classId) || (t as any).assignedClasses?.includes(classId))) return true;
            return false;
          });

          for (const teacher of teachers) {
            const user = database.users.find((u) => u.id === teacher.userId);
            rawTargets.push({
              recipientId: teacher.id,
              userId: teacher.userId,
              name: `${teacher.firstName} ${teacher.lastName}`.trim(),
              role: 'TEACHER',
              email: teacher.email || user?.email,
              phone: (teacher as any).phone || teacher.contactNumber || user?.phoneNumber || (user as any)?.phone,
              classId: classId,
              className: targetClass?.name
            });
          }
        }
        break;
      }

      case 'RECIPIENT_LIST': {
        // Explicitly selected recipients
        const selectedSet = new Set(selectedRecipientIds);
        for (const user of database.users) {
          if (!selectedSet.has(user.id)) continue;
          if (user.status !== 'ACTIVE') {
            ineligibleExcluded++;
            continue;
          }
          rawTargets.push({
            recipientId: user.id,
            userId: user.id,
            name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username,
            role: user.role,
            email: user.email,
            phone: user.phoneNumber || (user as any).phone
          });
        }
        break;
      }
    }

    // Server-Side Deduplication:
    // If a parent has multiple children in the targeted cohort, combine children's names
    // so the parent receives ONE message with full context, rather than multiple duplicate messages.
    const deduplicatedMap = new Map<string, ResolvedRecipientTarget>();
    let duplicatesRemoved = 0;

    for (const target of rawTargets) {
      const dedupId = target.userId || target.recipientId;
      if (deduplicatedMap.has(dedupId)) {
        duplicatesRemoved++;
        const existing = deduplicatedMap.get(dedupId)!;
        // If there's an additional student name, aggregate it cleanly
        if (target.studentName && existing.studentName && !existing.studentName.includes(target.studentName)) {
          existing.studentName = `${existing.studentName} & ${target.studentName}`;
        }
      } else {
        deduplicatedMap.set(dedupId, { ...target });
      }
    }

    const recipients = Array.from(deduplicatedMap.values());
    return {
      recipients,
      duplicatesRemoved,
      ineligibleExcluded
    };
  }

  /**
   * Recipient preview calculation.
   * CRITICAL: Never sends messages or writes to delivery logs!
   */
  public static previewRecipients(params: {
    audienceType: BulkCampaignAudienceType;
    academicSessionId?: string;
    classId?: string;
    sectionId?: string;
    targetRoles?: (UserRole | string)[];
    selectedRecipientIds?: string[];
    relationshipType?: BulkCampaignRelationshipType;
    subjectId?: string;
    channels?: NotificationChannel[];
  }): RecipientPreviewResult {
    const { recipients, duplicatesRemoved, ineligibleExcluded } = this.resolveAudience(params);

    const roleBreakdown: Record<string, number> = {};
    for (const r of recipients) {
      const role = String(r.role);
      roleBreakdown[role] = (roleBreakdown[role] || 0) + 1;
    }

    const cls = params.classId ? database.classes.find((c) => c.id === params.classId) : undefined;
    const sec = params.sectionId ? database.sections.find((s) => s.id === params.sectionId) : undefined;

    // Capped sample (first 15 items) with masked contact info for PII protection
    const sampleRecipients = recipients.slice(0, 15).map((r) => ({
      id: r.recipientId,
      name: r.name,
      role: String(r.role),
      contactMasked: this.maskContact(r.email || r.phone),
      studentName: r.studentName
    }));

    return {
      totalCount: recipients.length,
      duplicatesRemoved,
      ineligibleExcluded,
      channelsSelected: params.channels && params.channels.length > 0 ? params.channels : ['IN_APP', 'EMAIL'],
      audienceType: params.audienceType,
      classId: params.classId,
      className: cls?.name,
      sectionId: params.sectionId,
      sectionName: sec?.name,
      sampleRecipients,
      roleBreakdown
    };
  }

  /**
   * Resolves template variables in title and message text.
   */
  public static personalizeContent(
    templateText: string,
    context: {
      recipientName?: string;
      studentName?: string;
      className?: string;
      sectionName?: string;
      sessionName?: string;
      schoolName?: string;
      date?: string;
      campaignName?: string;
    }
  ): string {
    if (!templateText) return '';
    let result = templateText;
    const schoolName = context.schoolName || database.schoolSettings?.schoolName || 'Sygmate International Academy';
    const dateStr = context.date || new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    result = result.replace(/\{\{\s*recipient_name\s*\}\}/gi, context.recipientName || 'Parent / Guardian');
    result = result.replace(/\{\{\s*student_name\s*\}\}/gi, context.studentName || 'your child');
    result = result.replace(/\{\{\s*class_name\s*\}\}/gi, context.className || '');
    result = result.replace(/\{\{\s*section_name\s*\}\}/gi, context.sectionName || '');
    result = result.replace(/\{\{\s*session_name\s*\}\}/gi, context.sessionName || '');
    result = result.replace(/\{\{\s*school_name\s*\}\}/gi, schoolName);
    result = result.replace(/\{\{\s*date\s*\}\}/gi, dateStr);
    result = result.replace(/\{\{\s*campaign_name\s*\}\}/gi, context.campaignName || '');

    return result;
  }

  /**
   * Validates attachments for MIME type and file size.
   */
  public static validateAttachments(attachments: BulkCampaignAttachment[] = []): void {
    for (const att of attachments) {
      if (att.sizeBytes && att.sizeBytes > MAX_ATTACHMENT_SIZE_BYTES) {
        throw new Error(`Attachment '${att.name}' exceeds the maximum allowed size of 10 MB.`);
      }
      if (att.type && !ALLOWED_MIME_TYPES.has(att.type.toLowerCase())) {
        throw new Error(`Attachment '${att.name}' has an unsupported file format (${att.type}). Allowed formats: PDF, DOCX, XLSX, TXT, CSV, JPEG, PNG.`);
      }
    }
  }

  /**
   * Query all campaigns with filtering, sorting, and pagination.
   */
  public static getCampaigns(params: BulkCampaignFilterParams = {}): {
    data: BulkCampaign[];
    total: number;
    stats: BulkCampaignStats;
    pagination: { page: number; limit: number; totalPages: number };
  } {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];

    let filtered = [...database.bulkCampaigns];

    if (params.search) {
      const q = params.search.toLowerCase().trim();
      filtered = filtered.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.title.toLowerCase().includes(q) ||
          (c.internalDescription && c.internalDescription.toLowerCase().includes(q))
      );
    }

    if (params.status && params.status !== 'all') {
      filtered = filtered.filter((c) => c.status === params.status);
    }

    if (params.category && params.category !== 'all') {
      filtered = filtered.filter((c) => c.category === params.category);
    }

    if (params.audienceType && params.audienceType !== 'all') {
      filtered = filtered.filter((c) => c.audienceType === params.audienceType);
    }

    if (params.startDate) {
      filtered = filtered.filter((c) => c.createdAt >= params.startDate!);
    }
    if (params.endDate) {
      filtered = filtered.filter((c) => c.createdAt <= params.endDate!);
    }

    // Sort descending by creation date
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const total = filtered.length;
    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(params.limit) || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const paginated = filtered.slice(startIndex, startIndex + limit);

    return {
      data: paginated,
      total,
      stats: this.getCampaignStats(),
      pagination: {
        page,
        limit,
        totalPages
      }
    };
  }

  /**
   * Aggregate statistics for bulk campaigns.
   */
  public static getCampaignStats(): BulkCampaignStats {
    const campaigns = database.bulkCampaigns || [];

    let draftCount = 0;
    let scheduledCount = 0;
    let processingCount = 0;
    let completedCount = 0;
    let failedCount = 0;
    let cancelledCount = 0;
    let totalRecipientsReached = 0;
    let totalDelivered = 0;
    const byCategory: Record<string, number> = {};
    const byAudience: Record<string, number> = {};

    for (const c of campaigns) {
      if (c.status === 'DRAFT') draftCount++;
      else if (c.status === 'SCHEDULED') scheduledCount++;
      else if (c.status === 'PROCESSING') processingCount++;
      else if (c.status === 'COMPLETED' || c.status === 'PARTIALLY_FAILED') completedCount++;
      else if (c.status === 'FAILED') failedCount++;
      else if (c.status === 'CANCELLED') cancelledCount++;

      totalRecipientsReached += c.sentCount || 0;
      totalDelivered += c.deliveredCount || 0;

      byCategory[c.category] = (byCategory[c.category] || 0) + 1;
      byAudience[c.audienceType] = (byAudience[c.audienceType] || 0) + 1;
    }

    const overallDeliveryRate =
      totalRecipientsReached > 0 ? Math.round((totalDelivered / totalRecipientsReached) * 100) : 100;

    return {
      totalCampaigns: campaigns.length,
      draftCount,
      scheduledCount,
      processingCount,
      completedCount,
      failedCount,
      cancelledCount,
      totalRecipientsReached,
      totalDelivered,
      overallDeliveryRate,
      byCategory,
      byAudience
    };
  }

  /**
   * Get campaign by ID with associated delivery logs.
   */
  public static getCampaignById(id: string): {
    campaign: BulkCampaign;
    recipients: BulkCampaignRecipient[];
  } | null {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) return null;

    if (!database.bulkCampaignRecipients) database.bulkCampaignRecipients = [];
    const recipients = database.bulkCampaignRecipients.filter((r) => r.campaignId === id);

    return {
      campaign,
      recipients
    };
  }

  /**
   * Create a new campaign (in DRAFT, SCHEDULED, or IMMEDIATE).
   */
  public static async createCampaign(
    payload: Partial<BulkCampaign>,
    actor: { id: string; name: string; role: UserRole | string }
  ): Promise<BulkCampaign> {
    if (!payload.name?.trim()) throw new Error('Campaign Name is required.');
    if (!payload.title?.trim()) throw new Error('Message Title is required.');
    if (!payload.body?.trim()) throw new Error('Message Content is required.');
    if (!payload.channels || payload.channels.length === 0) {
      throw new Error('At least one communication channel must be selected.');
    }

    // Validate attachments
    if (payload.attachments) {
      this.validateAttachments(payload.attachments);
    }

    // Sanitize content server-side to prevent XSS
    const sanitizedBody = sanitizeAnnouncementContent(payload.body);

    const nowIso = new Date().toISOString();
    const id = `camp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    // Resolve class / session names for denormalized storage
    const cls = payload.classId ? database.classes.find((c) => c.id === payload.classId) : undefined;
    const sec = payload.sectionId ? database.sections.find((s) => s.id === payload.sectionId) : undefined;
    const ses = payload.academicSessionId ? database.academicSessions.find((s) => s.id === payload.academicSessionId) : undefined;

    let initialStatus = payload.status || 'DRAFT';
    if (payload.scheduleType === 'SCHEDULED') {
      if (!payload.scheduledAt) throw new Error('Scheduled date/time is required for scheduled campaigns.');
      if (new Date(payload.scheduledAt).getTime() <= Date.now()) {
        throw new Error('Scheduled date/time must be in the future.');
      }
      initialStatus = 'SCHEDULED';
    }

    const campaign: BulkCampaign = {
      id,
      name: payload.name.trim(),
      internalDescription: payload.internalDescription?.trim() || '',
      title: payload.title.trim(),
      body: sanitizedBody,
      category: payload.category || 'general',
      priority: (payload.priority as BulkCampaignPriority) || 'NORMAL',
      audienceType: payload.audienceType || 'ROLE_BASED',
      academicSessionId: payload.academicSessionId,
      academicSessionName: ses?.name,
      classId: payload.classId,
      className: cls?.name,
      sectionId: payload.sectionId,
      sectionName: sec?.name,
      targetRoles: payload.targetRoles || ['GUARDIAN', 'STUDENT'],
      selectedRecipientIds: payload.selectedRecipientIds || [],
      relationshipType: payload.relationshipType,
      subjectId: payload.subjectId,
      templateId: payload.templateId,
      templateName: payload.templateName,
      channels: payload.channels,
      attachments: payload.attachments || [],
      scheduleType: payload.scheduleType || 'IMMEDIATE',
      scheduledAt: payload.scheduledAt,
      expiresAt: payload.expiresAt,
      status: initialStatus,
      totalRecipientsCount: 0,
      queuedCount: 0,
      sentCount: 0,
      deliveredCount: 0,
      failedCount: 0,
      readCount: 0,
      duplicateCount: 0,
      channelStats: {
        inApp: { sent: 0, failed: 0, read: 0 },
        email: { sent: 0, delivered: 0, failed: 0 },
        sms: { sent: 0, delivered: 0, failed: 0 },
        push: { sent: 0, delivered: 0, failed: 0 }
      },
      idempotencyKey: payload.idempotencyKey,
      createdBy: actor.id,
      createdByName: actor.name,
      createdByRole: actor.role,
      createdAt: nowIso,
      updatedAt: nowIso
    };

    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    database.bulkCampaigns.unshift(campaign);

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_CREATE',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Created campaign '${campaign.name}' with status '${campaign.status}'. Audience: ${campaign.audienceType}. Channels: ${campaign.channels.join(', ')}.`
    });

    // If immediate execution requested
    if (payload.scheduleType === 'IMMEDIATE' && payload.status !== 'DRAFT') {
      // Fire execution in background task
      this.executeCampaignAsync(campaign.id, actor);
    }

    return campaign;
  }

  /**
   * Update an existing campaign (only permitted in DRAFT status).
   */
  public static updateCampaign(
    id: string,
    updates: Partial<BulkCampaign>,
    actor: { id: string; name: string; role: UserRole | string }
  ): BulkCampaign {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) throw new Error('Campaign not found.');

    if (campaign.status !== 'DRAFT') {
      throw new Error(`Campaign cannot be edited in '${campaign.status}' status. Only drafts can be modified.`);
    }

    if (updates.attachments) {
      this.validateAttachments(updates.attachments);
    }

    if (updates.name) campaign.name = updates.name.trim();
    if (updates.internalDescription !== undefined) campaign.internalDescription = updates.internalDescription;
    if (updates.title) campaign.title = updates.title.trim();
    if (updates.body) campaign.body = sanitizeAnnouncementContent(updates.body);
    if (updates.category) campaign.category = updates.category;
    if (updates.priority) campaign.priority = updates.priority as BulkCampaignPriority;
    if (updates.audienceType) campaign.audienceType = updates.audienceType;
    if (updates.academicSessionId !== undefined) campaign.academicSessionId = updates.academicSessionId;
    if (updates.classId !== undefined) {
      campaign.classId = updates.classId;
      const cls = updates.classId ? database.classes.find((c) => c.id === updates.classId) : undefined;
      campaign.className = cls?.name;
    }
    if (updates.sectionId !== undefined) {
      campaign.sectionId = updates.sectionId;
      const sec = updates.sectionId ? database.sections.find((s) => s.id === updates.sectionId) : undefined;
      campaign.sectionName = sec?.name;
    }
    if (updates.targetRoles) campaign.targetRoles = updates.targetRoles;
    if (updates.selectedRecipientIds) campaign.selectedRecipientIds = updates.selectedRecipientIds;
    if (updates.relationshipType !== undefined) campaign.relationshipType = updates.relationshipType;
    if (updates.subjectId !== undefined) campaign.subjectId = updates.subjectId;
    if (updates.channels) campaign.channels = updates.channels;
    if (updates.attachments) campaign.attachments = updates.attachments;
    if (updates.scheduleType) campaign.scheduleType = updates.scheduleType;
    if (updates.scheduledAt !== undefined) campaign.scheduledAt = updates.scheduledAt;
    if (updates.expiresAt !== undefined) campaign.expiresAt = updates.expiresAt;

    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_UPDATE',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Updated campaign draft '${campaign.name}'.`
    });

    return campaign;
  }

  /**
   * Schedule a campaign for future delivery.
   */
  public static scheduleCampaign(
    id: string,
    scheduledAt: string,
    actor: { id: string; name: string; role: UserRole | string }
  ): BulkCampaign {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) throw new Error('Campaign not found.');

    if (campaign.status !== 'DRAFT' && campaign.status !== 'SCHEDULED') {
      throw new Error(`Cannot schedule campaign with status '${campaign.status}'.`);
    }

    const scheduledDate = new Date(scheduledAt);
    if (isNaN(scheduledDate.getTime()) || scheduledDate.getTime() <= Date.now()) {
      throw new Error('Scheduled date/time must be a valid timestamp in the future.');
    }

    campaign.scheduleType = 'SCHEDULED';
    campaign.scheduledAt = scheduledDate.toISOString();
    campaign.status = 'SCHEDULED';
    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_SCHEDULE',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Campaign '${campaign.name}' scheduled for dispatch at ${campaign.scheduledAt}.`
    });

    return campaign;
  }

  /**
   * Cancel a scheduled or currently processing campaign.
   */
  public static cancelCampaign(
    id: string,
    reason: string = 'Cancelled by administrator',
    actor: { id: string; name: string; role: UserRole | string }
  ): BulkCampaign {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) throw new Error('Campaign not found.');

    if (campaign.status !== 'SCHEDULED' && campaign.status !== 'PROCESSING') {
      throw new Error(`Cannot cancel campaign in '${campaign.status}' status.`);
    }

    campaign.status = 'CANCELLED';
    campaign.statusReason = reason;
    campaign.cancelledAt = new Date().toISOString();
    campaign.cancelledBy = actor.name;
    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_CANCEL',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Campaign '${campaign.name}' cancelled. Reason: ${reason}.`
    });

    return campaign;
  }

  /**
   * Archive a completed, failed, or cancelled campaign.
   */
  public static archiveCampaign(
    id: string,
    actor: { id: string; name: string; role: UserRole | string }
  ): BulkCampaign {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) throw new Error('Campaign not found.');

    if (campaign.status === 'PROCESSING') {
      throw new Error('Cannot archive a campaign that is actively processing.');
    }

    campaign.status = 'ARCHIVED';
    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_ARCHIVE',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Campaign '${campaign.name}' moved to archive.`
    });

    return campaign;
  }

  /**
   * Trigger immediate sending of a draft or scheduled campaign.
   */
  public static async sendCampaignNow(
    id: string,
    actor: { id: string; name: string; role: UserRole | string }
  ): Promise<BulkCampaign> {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const campaign = database.bulkCampaigns.find((c) => c.id === id);
    if (!campaign) throw new Error('Campaign not found.');

    if (campaign.status === 'PROCESSING') {
      throw new Error('Campaign is already currently being processed.');
    }
    if (campaign.status === 'COMPLETED' || campaign.status === 'ARCHIVED') {
      throw new Error(`Cannot re-send campaign in '${campaign.status}' state.`);
    }

    campaign.status = 'PROCESSING';
    campaign.processedAt = new Date().toISOString();
    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_SEND_STARTED',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Administrator '${actor.name}' initiated immediate dispatch of campaign '${campaign.name}'.`
    });

    // Run batch dispatch asynchronously
    this.executeCampaignAsync(campaign.id, actor);

    return campaign;
  }

  /**
   * Asynchronous background queue processing.
   * Large campaigns never block the web request thread!
   */
  private static executeCampaignAsync(
    campaignId: string,
    actor: { id: string; name: string; role: UserRole | string }
  ): void {
    // Non-blocking setImmediate to yield back to event loop immediately
    setImmediate(async () => {
      try {
        await this.processCampaignBatches(campaignId, actor);
      } catch (err) {
        console.error(`[BulkCampaignService] Fatal error processing campaign ${campaignId}:`, err);
        const campaign = database.bulkCampaigns?.find((c) => c.id === campaignId);
        if (campaign && campaign.status === 'PROCESSING') {
          campaign.status = 'FAILED';
          campaign.statusReason = err instanceof Error ? err.message : 'Unknown processing error';
          campaign.updatedAt = new Date().toISOString();
        }
      }
    });
  }

  /**
   * Controlled batch execution engine.
   * Resolves recipients authoritatively, generates communication logs and in-app alerts,
   * tracks channel statistics, and enforces rate limits.
   */
  private static async processCampaignBatches(
    campaignId: string,
    actor: { id: string; name: string; role: UserRole | string }
  ): Promise<void> {
    const campaign = database.bulkCampaigns?.find((c) => c.id === campaignId);
    if (!campaign) return;

    if (!database.bulkCampaignRecipients) database.bulkCampaignRecipients = [];

    // Authoritatively resolve audience server-side
    const { recipients, duplicatesRemoved } = this.resolveAudience({
      audienceType: campaign.audienceType,
      academicSessionId: campaign.academicSessionId,
      classId: campaign.classId,
      sectionId: campaign.sectionId,
      targetRoles: campaign.targetRoles,
      selectedRecipientIds: campaign.selectedRecipientIds,
      relationshipType: campaign.relationshipType,
      subjectId: campaign.subjectId
    });

    campaign.totalRecipientsCount = recipients.length;
    campaign.duplicateCount = duplicatesRemoved;
    campaign.queuedCount = recipients.length;

    // Safety threshold check
    if (recipients.length > MAX_RECIPIENTS_LIMIT) {
      campaign.status = 'FAILED';
      campaign.statusReason = `Safety limit exceeded: recipient count (${recipients.length}) exceeds maximum allowable threshold (${MAX_RECIPIENTS_LIMIT}).`;
      campaign.updatedAt = new Date().toISOString();
      return;
    }

    if (recipients.length === 0) {
      campaign.status = 'COMPLETED';
      campaign.completedAt = new Date().toISOString();
      campaign.statusReason = 'No matching eligible recipients found for the targeted audience criteria.';
      campaign.updatedAt = new Date().toISOString();
      return;
    }

    const channels = campaign.channels;
    const settings = database.communicationSettings;

    // Process in controlled chunks
    for (let i = 0; i < recipients.length; i += BATCH_CHUNK_SIZE) {
      // Check if campaign was cancelled mid-flight
      const current = database.bulkCampaigns?.find((c) => c.id === campaignId);
      if (!current || current.status === 'CANCELLED') {
        console.log(`[BulkCampaignService] Campaign ${campaignId} was cancelled during batch dispatch.`);
        break;
      }

      const chunk = recipients.slice(i, i + BATCH_CHUNK_SIZE);

      for (const target of chunk) {
        const recipientUserId = target.userId;
        const dedupKey = `${campaign.id}-${target.recipientId}`;

        // Personalize text
        const personalizedBody = this.personalizeContent(campaign.body, {
          recipientName: target.name,
          studentName: target.studentName,
          className: target.className,
          sectionName: target.sectionName,
          schoolName: database.schoolSettings?.schoolName,
          campaignName: campaign.name
        });

        const personalizedTitle = this.personalizeContent(campaign.title, {
          recipientName: target.name,
          studentName: target.studentName,
          className: target.className,
          sectionName: target.sectionName,
          schoolName: database.schoolSettings?.schoolName,
          campaignName: campaign.name
        });

        const deliveredChannels: NotificationChannel[] = [];
        const failedChannels: NotificationChannel[] = [];
        const failureReasons: Record<string, string> = {};

        // Dispatch across configured and selected channels
        for (const channel of channels) {
          try {
            // Check provider status
            if (channel === 'EMAIL' && (!settings.email.enabled || settings.email.status === 'DISABLED')) {
              failedChannels.push(channel);
              failureReasons[channel] = 'Email channel is disabled in school communication settings.';
              campaign.channelStats.email.failed++;
              continue;
            }
            if (channel === 'SMS' && (!settings.sms.enabled || settings.sms.status === 'DISABLED')) {
              failedChannels.push(channel);
              failureReasons[channel] = 'SMS channel is disabled in school communication settings.';
              campaign.channelStats.sms.failed++;
              continue;
            }
            if (channel === 'PUSH' && (!settings.push.enabled || settings.push.status === 'DISABLED')) {
              failedChannels.push(channel);
              failureReasons[channel] = 'Push notification channel is disabled.';
              campaign.channelStats.push.failed++;
              continue;
            }

            // In-app alert creation
            if (channel === 'IN_APP' && recipientUserId) {
              const notifId = `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
              database.notifications.unshift({
                id: notifId,
                userId: recipientUserId,
                type: 'SYSTEM',
                title: personalizedTitle,
                message: personalizedBody,
                isRead: false,
                createdAt: new Date().toISOString(),
                link: `/communication/campaigns`
              });
              campaign.channelStats.inApp.sent++;
              deliveredChannels.push(channel);
            } else if (channel === 'EMAIL') {
              campaign.channelStats.email.sent++;
              campaign.channelStats.email.delivered++;
              deliveredChannels.push(channel);
            } else if (channel === 'SMS') {
              campaign.channelStats.sms.sent++;
              campaign.channelStats.sms.delivered++;
              deliveredChannels.push(channel);
            } else if (channel === 'PUSH') {
              campaign.channelStats.push.sent++;
              campaign.channelStats.push.delivered++;
              deliveredChannels.push(channel);
            }

            // Record authoritative communication log
            const logId = `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
            database.communicationLogs.unshift({
              id: logId,
              dedupKey: `${dedupKey}-${channel}`,
              eventType: 'SCHOOL_ANNOUNCEMENT',
              channel,
              recipientId: target.recipientId,
              recipientUserId,
              recipientName: target.name,
              recipientRole: target.role,
              recipientContact: target.email || target.phone,
              title: personalizedTitle,
              message: personalizedBody,
              emailSubject: channel === 'EMAIL' ? personalizedTitle : undefined,
              status: 'DELIVERED',
              relatedStudentId: target.studentId,
              relatedStudentName: target.studentName,
              relatedEntityId: campaign.id,
              relatedEntityType: 'BULK_CAMPAIGN',
              retryCount: 0,
              maxRetries: 3,
              createdAt: new Date().toISOString(),
              sentAt: new Date().toISOString(),
              deliveredAt: new Date().toISOString()
            });
          } catch (err: any) {
            failedChannels.push(channel);
            failureReasons[channel] = err.message || 'Delivery error';
          }
        }

        const isFullyDelivered = deliveredChannels.length > 0;
        if (isFullyDelivered) {
          campaign.sentCount++;
          campaign.deliveredCount++;
        } else {
          campaign.failedCount++;
        }

        // Record campaign recipient ledger record
        const bcrId = `bcr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        database.bulkCampaignRecipients.push({
          id: bcrId,
          campaignId: campaign.id,
          recipientId: target.recipientId,
          userId: target.userId,
          recipientName: target.name,
          recipientRole: target.role,
          contact: target.email || target.phone,
          studentId: target.studentId,
          studentName: target.studentName,
          channels: campaign.channels,
          status: isFullyDelivered ? 'DELIVERED' : 'FAILED',
          deliveredChannels,
          failedChannels,
          failureReasons: Object.keys(failureReasons).length > 0 ? failureReasons : undefined,
          isRead: false,
          sentAt: new Date().toISOString(),
          deliveredAt: isFullyDelivered ? new Date().toISOString() : undefined,
          dedupKey
        });
      }

      // Small async pause between chunks to keep event loop responsive
      await new Promise((resolve) => setTimeout(resolve, 50));
    }

    // Finalize campaign status
    campaign.queuedCount = 0;
    campaign.completedAt = new Date().toISOString();
    if (campaign.failedCount > 0 && campaign.deliveredCount > 0) {
      campaign.status = 'PARTIALLY_FAILED';
    } else if (campaign.failedCount > 0 && campaign.deliveredCount === 0) {
      campaign.status = 'FAILED';
    } else {
      campaign.status = 'COMPLETED';
    }
    campaign.updatedAt = new Date().toISOString();

    logAudit({
      userId: actor.id,
      userName: actor.name,
      userRole: (actor.role as UserRole) || 'SUPER_ADMIN',
      action: 'CAMPAIGN_DISPATCH_COMPLETED',
      entity: 'BulkCampaign',
      entityType: 'BulkCampaign',
      entityId: campaign.id,
      details: `Dispatched campaign '${campaign.name}'. Reached: ${campaign.sentCount}, Delivered: ${campaign.deliveredCount}, Failed: ${campaign.failedCount}. Status: ${campaign.status}.`
    });
  }

  /**
   * Periodic scheduler evaluation called by system background scheduler.
   * Finds scheduled campaigns whose time has arrived and executes them idempotently.
   */
  public static evaluateLifecycle(): { fired: number } {
    if (!database.bulkCampaigns) database.bulkCampaigns = [];
    const now = new Date();
    let fired = 0;

    for (const campaign of database.bulkCampaigns) {
      if (campaign.status === 'SCHEDULED' && campaign.scheduledAt) {
        const scheduledTime = new Date(campaign.scheduledAt);
        if (scheduledTime <= now) {
          // Atomically lock status
          campaign.status = 'PROCESSING';
          campaign.processedAt = now.toISOString();
          campaign.updatedAt = now.toISOString();
          fired++;

          logAudit({
            userId: campaign.createdBy || 'system-scheduler',
            userName: campaign.createdByName || 'System Scheduler',
            userRole: (campaign.createdByRole as UserRole) || 'SUPER_ADMIN',
            action: 'CAMPAIGN_SCHEDULE_FIRED',
            entity: 'BulkCampaign',
            entityType: 'BulkCampaign',
            entityId: campaign.id,
            details: `Scheduled campaign '${campaign.name}' automatically triggered by background scheduler.`
          });

          this.executeCampaignAsync(campaign.id, {
            id: campaign.createdBy || 'system-scheduler',
            name: campaign.createdByName || 'System Scheduler',
            role: campaign.createdByRole || 'SUPER_ADMIN'
          });
        }
      }
    }

    return { fired };
  }
}
