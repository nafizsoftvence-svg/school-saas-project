/**
 * Sygmate School Management System
 * Staff Leave Policy, Balance Engine & Approval Workflow Service (Part 12C)
 *
 * Provides authoritative server-side leave policy matching, entitlement allocation,
 * ledger-backed balance calculation, multi-level approval hierarchy, race-condition safety,
 * automated attendance synchronization, balance adjustments, and carry-forward processing.
 */

import { database } from '../db/database.js';
import {
  StaffLeavePolicy,
  CreateStaffLeavePolicyPayload,
  UpdateStaffLeavePolicyPayload,
  StaffLeaveEntitlement,
  StaffLeaveTransaction,
  StaffLeaveTransactionType,
  StaffLeaveBalance,
  StaffLeaveBalancesQuery,
  StaffLeaveBalancesResponse,
  StaffLeaveLedgerQuery,
  StaffLeaveLedgerResponse,
  StaffLeaveReportsSummary,
  StaffLeaveApplicationPayload,
  ReviewStaffLeavePayload,
  AdjustStaffLeaveBalancePayload,
  CarryForwardProcessPayload,
  CarryForwardResult,
  LeaveApplication,
  User,
  StaffProfile,
  AuditLog
} from '../../src/types/index.js';
import { staffAttendanceService } from './staff-attendance.service.js';

// Concurrency In-Memory Lock Registry to serialize balance-modifying operations per staff+leaveType
const balanceLocks = new Map<string, Promise<void>>();

async function acquireLock(key: string): Promise<() => void> {
  while (balanceLocks.has(key)) {
    try {
      await balanceLocks.get(key);
    } catch {
      // Continue waiting for slot
    }
  }

  let release!: () => void;
  const lockPromise = new Promise<void>((resolve) => {
    release = () => {
      balanceLocks.delete(key);
      resolve();
    };
  });

  balanceLocks.set(key, lockPromise);
  return release;
}

export class StaffLeaveService {
  /**
   * Helper: Get current active academic session
   */
  private getActiveAcademicSession(): string {
    const activeSession = database.academicSessions?.find((s) => s.status === 'ACTIVE') || database.academicSessions?.[0];
    return activeSession?.id || 'session-2026-2027';
  }

  /**
   * Helper: Create audit log
   */
  private logAudit(
    actorUser: User,
    action: string,
    entityId: string,
    details: Record<string, any>
  ): void {
    const auditEntry: AuditLog = {
      id: `audit-staff-leave-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId: actorUser.id,
      userName: actorUser.name,
      userRole: actorUser.role,
      action,
      entityType: 'STAFF_LEAVE',
      entityId,
      details: typeof details === 'string' ? details : JSON.stringify(details),
      ipAddress: '127.0.0.1',
      timestamp: new Date().toISOString()
    };
    if (!database.auditLogs) database.auditLogs = [];
    database.auditLogs.unshift(auditEntry);
  }

  /**
   * Helper: Dispatch in-app notification
   */
  private sendNotification(
    recipientUserId: string,
    title: string,
    message: string,
    type: 'LEAVE_APPLICATION' | 'SYSTEM' = 'LEAVE_APPLICATION'
  ): void {
    if (!database.notifications) database.notifications = [];
    database.notifications.unshift({
      id: `notif-leave-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId: recipientUserId,
      title,
      message,
      type: type as any,
      isRead: false,
      createdAt: new Date().toISOString()
    });
  }

  // =========================================================================
  // 1. LEAVE POLICIES MANAGEMENT & DETERMINISTIC MATCHING
  // =========================================================================

  /**
   * List all leave policies for an academic session
   */
  public getPolicies(academicSessionId?: string): StaffLeavePolicy[] {
    const sessionId = academicSessionId || this.getActiveAcademicSession();
    return (database.staffLeavePolicies || []).filter(
      (p) => !p.academicSessionId || p.academicSessionId === sessionId
    );
  }

  /**
   * Get single policy by ID
   */
  public getPolicyById(id: string): StaffLeavePolicy | undefined {
    return (database.staffLeavePolicies || []).find((p) => p.id === id);
  }

  /**
   * Create a new leave policy
   */
  public createPolicy(payload: CreateStaffLeavePolicyPayload, actorUser: User): StaffLeavePolicy {
    if (!payload.name?.trim()) throw new Error('Policy name is required.');
    if (!payload.code?.trim()) throw new Error('Policy code is required.');
    if (!payload.leaveTypeId) throw new Error('Leave type reference is required.');
    if (payload.entitlementDays === undefined || payload.entitlementDays < 0) {
      throw new Error('Entitlement days must be a non-negative number.');
    }

    const leaveType = database.leaveTypes?.find((lt) => lt.id === payload.leaveTypeId);
    const leaveTypeName = leaveType?.name || 'Institutional Leave';
    const academicSessionId = payload.academicSessionId || this.getActiveAcademicSession();

    // Determine default priority if not explicitly provided
    // Priority: 1: Designation, 2: Department, 3: Staff Category, 4: School Default
    let priority = payload.priority;
    if (!priority) {
      if (payload.applicableDesignationId && payload.applicableDesignationId !== 'ALL') priority = 1;
      else if (payload.applicableDepartmentId && payload.applicableDepartmentId !== 'ALL') priority = 2;
      else if (payload.applicableStaffCategory && payload.applicableStaffCategory !== 'ALL') priority = 3;
      else priority = 4;
    }

    const department = payload.applicableDepartmentId && payload.applicableDepartmentId !== 'ALL'
      ? database.departments?.find((d) => d.id === payload.applicableDepartmentId)
      : undefined;

    const designation = payload.applicableDesignationId && payload.applicableDesignationId !== 'ALL'
      ? database.designations?.find((d) => d.id === payload.applicableDesignationId)
      : undefined;

    const newPolicy: StaffLeavePolicy = {
      id: `pol-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      name: payload.name.trim(),
      code: payload.code.trim().toUpperCase(),
      leaveTypeId: payload.leaveTypeId,
      leaveTypeName,
      applicableStaffCategory: payload.applicableStaffCategory || 'ALL',
      applicableDepartmentId: payload.applicableDepartmentId,
      applicableDepartmentName: department?.name,
      applicableDesignationId: payload.applicableDesignationId,
      applicableDesignationName: designation?.title,
      academicSessionId,
      entitlementDays: payload.entitlementDays,
      paidType: payload.paidType || (leaveType?.paidType === 'UNPAID' || (leaveType as any)?.isPaid === false ? 'UNPAID' : 'PAID'),
      carryForwardAllowed: Boolean(payload.carryForwardAllowed),
      maxCarryForwardDays: payload.carryForwardAllowed ? (payload.maxCarryForwardDays ?? 0) : 0,
      carryForwardExpiryMonths: payload.carryForwardExpiryMonths,
      minNoticeDays: payload.minNoticeDays ?? 0,
      maxConsecutiveDays: payload.maxConsecutiveDays ?? 14,
      requiresAttachment: Boolean(payload.requiresAttachment),
      attachmentMandatoryAboveDays: payload.attachmentMandatoryAboveDays,
      requiresApproval: payload.requiresApproval !== false,
      approvalHierarchy: payload.approvalHierarchy || 'SINGLE',
      allowNegativeBalance: Boolean(payload.allowNegativeBalance),
      reservePendingBalance: payload.reservePendingBalance !== false,
      isActive: payload.isActive !== false,
      priority,
      notes: payload.notes?.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.staffLeavePolicies) database.staffLeavePolicies = [];
    database.staffLeavePolicies.push(newPolicy);

    this.logAudit(actorUser, 'CREATE_LEAVE_POLICY', newPolicy.id, {
      policyName: newPolicy.name,
      leaveTypeId: newPolicy.leaveTypeId,
      entitlementDays: newPolicy.entitlementDays
    });

    return newPolicy;
  }

  /**
   * Update an existing leave policy
   */
  public updatePolicy(
    id: string,
    payload: UpdateStaffLeavePolicyPayload,
    actorUser: User
  ): StaffLeavePolicy {
    const policy = (database.staffLeavePolicies || []).find((p) => p.id === id);
    if (!policy) throw new Error(`Leave policy with ID '${id}' not found.`);

    if (payload.name !== undefined) policy.name = payload.name.trim();
    if (payload.code !== undefined) policy.code = payload.code.trim().toUpperCase();
    if (payload.entitlementDays !== undefined) {
      if (payload.entitlementDays < 0) throw new Error('Entitlement days cannot be negative.');
      policy.entitlementDays = payload.entitlementDays;
    }
    if (payload.applicableStaffCategory !== undefined) policy.applicableStaffCategory = payload.applicableStaffCategory;
    if (payload.applicableDepartmentId !== undefined) {
      policy.applicableDepartmentId = payload.applicableDepartmentId;
      const dept = database.departments?.find((d) => d.id === payload.applicableDepartmentId);
      policy.applicableDepartmentName = dept?.name;
    }
    if (payload.applicableDesignationId !== undefined) {
      policy.applicableDesignationId = payload.applicableDesignationId;
      const desig = database.designations?.find((d) => d.id === payload.applicableDesignationId);
      policy.applicableDesignationName = desig?.title;
    }
    if (payload.paidType !== undefined) policy.paidType = payload.paidType;
    if (payload.carryForwardAllowed !== undefined) {
      policy.carryForwardAllowed = payload.carryForwardAllowed;
      if (!payload.carryForwardAllowed) policy.maxCarryForwardDays = 0;
    }
    if (payload.maxCarryForwardDays !== undefined) policy.maxCarryForwardDays = payload.maxCarryForwardDays;
    if (payload.carryForwardExpiryMonths !== undefined) policy.carryForwardExpiryMonths = payload.carryForwardExpiryMonths;
    if (payload.minNoticeDays !== undefined) policy.minNoticeDays = payload.minNoticeDays;
    if (payload.maxConsecutiveDays !== undefined) policy.maxConsecutiveDays = payload.maxConsecutiveDays;
    if (payload.requiresAttachment !== undefined) policy.requiresAttachment = payload.requiresAttachment;
    if (payload.attachmentMandatoryAboveDays !== undefined) policy.attachmentMandatoryAboveDays = payload.attachmentMandatoryAboveDays;
    if (payload.requiresApproval !== undefined) policy.requiresApproval = payload.requiresApproval;
    if (payload.approvalHierarchy !== undefined) policy.approvalHierarchy = payload.approvalHierarchy;
    if (payload.allowNegativeBalance !== undefined) policy.allowNegativeBalance = payload.allowNegativeBalance;
    if (payload.reservePendingBalance !== undefined) policy.reservePendingBalance = payload.reservePendingBalance;
    if (payload.isActive !== undefined) policy.isActive = payload.isActive;
    if (payload.priority !== undefined) policy.priority = payload.priority;
    if (payload.notes !== undefined) policy.notes = payload.notes.trim();

    policy.updatedAt = new Date().toISOString();

    this.logAudit(actorUser, 'UPDATE_LEAVE_POLICY', policy.id, {
      policyName: policy.name,
      updatedFields: Object.keys(payload)
    });

    return policy;
  }

  /**
   * Delete a leave policy
   */
  public deletePolicy(id: string, actorUser: User): boolean {
    const index = (database.staffLeavePolicies || []).findIndex((p) => p.id === id);
    if (index === -1) throw new Error(`Leave policy with ID '${id}' not found.`);

    const policy = database.staffLeavePolicies[index];
    database.staffLeavePolicies.splice(index, 1);

    this.logAudit(actorUser, 'DELETE_LEAVE_POLICY', id, {
      policyName: policy.name,
      leaveTypeId: policy.leaveTypeId
    });

    return true;
  }

  /**
   * Deterministic Policy Matching Engine:
   * 1. Priority 1: Specific Designation match
   * 2. Priority 2: Specific Department match
   * 3. Priority 3: Specific Staff Category match
   * 4. Priority 4: School Default (ALL)
   */
  public resolveStaffPolicy(
    staffId: string,
    leaveTypeId: string,
    sessionId?: string
  ): StaffLeavePolicy | null {
    const targetSession = sessionId || this.getActiveAcademicSession();
    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) return null;

    const candidatePolicies = (database.staffLeavePolicies || []).filter(
      (p) =>
        p.isActive &&
        p.leaveTypeId === leaveTypeId &&
        (!p.academicSessionId || p.academicSessionId === targetSession)
    );

    if (candidatePolicies.length === 0) return null;

    // 1. Check Designation
    if (staff.designationId) {
      const designationMatch = candidatePolicies.find(
        (p) => p.applicableDesignationId && p.applicableDesignationId === staff.designationId
      );
      if (designationMatch) return designationMatch;
    }

    // 2. Check Department
    if (staff.departmentId) {
      const deptMatch = candidatePolicies.find(
        (p) => p.applicableDepartmentId && p.applicableDepartmentId === staff.departmentId
      );
      if (deptMatch) return deptMatch;
    }

    // 3. Check Staff Category
    if (staff.staffType) {
      const categoryMatch = candidatePolicies.find(
        (p) => p.applicableStaffCategory && p.applicableStaffCategory === staff.staffType
      );
      if (categoryMatch) return categoryMatch;
    }

    // 4. Check School Default
    const defaultMatch = candidatePolicies.find(
      (p) =>
        (!p.applicableStaffCategory || p.applicableStaffCategory === 'ALL') &&
        (!p.applicableDepartmentId || p.applicableDepartmentId === 'ALL') &&
        (!p.applicableDesignationId || p.applicableDesignationId === 'ALL')
    );

    if (defaultMatch) return defaultMatch;

    // Sort by priority ascending (1 = highest)
    candidatePolicies.sort((a, b) => (a.priority || 4) - (b.priority || 4));
    return candidatePolicies[0] || null;
  }

  // =========================================================================
  // 2. ENTITLEMENT ALLOCATION & IDEMPOTENT INITIALIZATION
  // =========================================================================

  /**
   * Ensure entitlement record exists for a staff member and leave type in the session
   */
  public ensureStaffEntitlement(
    staffId: string,
    leaveTypeId: string,
    sessionId?: string
  ): StaffLeaveEntitlement {
    const targetSession = sessionId || this.getActiveAcademicSession();
    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) throw new Error(`Staff profile with ID '${staffId}' not found.`);

    if (!database.staffLeaveEntitlements) database.staffLeaveEntitlements = [];

    let entitlement = database.staffLeaveEntitlements.find(
      (e) =>
        e.staffId === staffId &&
        e.leaveTypeId === leaveTypeId &&
        e.academicSessionId === targetSession
    );

    if (!entitlement) {
      const policy = this.resolveStaffPolicy(staffId, leaveTypeId, targetSession);
      const leaveType = database.leaveTypes?.find((lt) => lt.id === leaveTypeId);
      const entitlementDays = policy ? policy.entitlementDays : leaveType?.maxDays || 12;

      entitlement = {
        id: `ent-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        staffId: staff.id,
        staffName: staff.fullName,
        employeeCode: staff.employeeCode,
        departmentId: staff.departmentId,
        departmentName: staff.departmentName,
        staffType: staff.staffType,
        leaveTypeId,
        leaveTypeName: leaveType?.name || policy?.leaveTypeName || 'Leave',
        policyId: policy ? policy.id : 'pol-fallback',
        policyName: policy ? policy.name : 'System Default Entitlement',
        academicSessionId: targetSession,
        entitlementDays,
        carryForwardDays: 0,
        effectiveFrom: `${new Date().getFullYear()}-08-01`,
        effectiveTo: `${new Date().getFullYear() + 1}-06-30`,
        allocationType: 'POLICY_DEFAULT',
        allocatedBy: 'system',
        allocatedByName: 'System Auto-Allocator',
        allocatedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.staffLeaveEntitlements.push(entitlement);

      // Create initial ENTITLEMENT transaction in the ledger
      if (!database.staffLeaveTransactions) database.staffLeaveTransactions = [];
      database.staffLeaveTransactions.push({
        id: `txn-ent-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        staffId: staff.id,
        staffName: staff.fullName,
        employeeCode: staff.employeeCode,
        departmentId: staff.departmentId,
        leaveTypeId,
        leaveTypeName: entitlement.leaveTypeName,
        academicSessionId: targetSession,
        transactionType: 'ENTITLEMENT',
        amount: entitlementDays,
        balanceBefore: 0,
        balanceAfter: entitlementDays,
        referenceType: 'POLICY',
        referenceId: entitlement.policyId,
        reason: `Auto-allocated entitlement under policy: ${entitlement.policyName}`,
        performedBy: 'system',
        performedByName: 'System Engine',
        createdAt: new Date().toISOString()
      });
    }

    return entitlement;
  }

  // =========================================================================
  // 3. AUTHORITATIVE LEAVE BALANCE CALCULATION ENGINE
  // =========================================================================

  /**
   * Authoritative server-side balance calculation:
   * - Reads ledger transactions for staff, leaveType, and academicSession
   * - Computes:
   *     entitlementDays = sum(ENTITLEMENT)
   *     carryForwardDays = sum(CARRY_FORWARD)
   *     adjustmentsDays = sum(ADJUSTMENT_ADD - ADJUSTMENT_DEDUCT)
   *     usedDays = sum(LEAVE_DEDUCTION - LEAVE_REVERSAL)
   *     expiredDays = sum(EXPIRED)
   *     remainingDays = entitlement + carryForward + adjustments - used - expired
   *     pendingDays = sum(workingDays of non-terminal leave applications)
   *     availableDays = policy.reservePendingBalance ? max(0, remaining - pending) : remaining
   */
  public getStaffLeaveBalance(
    staffId: string,
    leaveTypeId: string,
    sessionId?: string
  ): StaffLeaveBalance {
    const targetSession = sessionId || this.getActiveAcademicSession();
    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) throw new Error(`Staff profile with ID '${staffId}' not found.`);

    // Ensure entitlement is in place
    const entitlement = this.ensureStaffEntitlement(staffId, leaveTypeId, targetSession);
    const policy = this.resolveStaffPolicy(staffId, leaveTypeId, targetSession);
    const leaveType = database.leaveTypes?.find((lt) => lt.id === leaveTypeId);

    const transactions = (database.staffLeaveTransactions || []).filter(
      (t) =>
        t.staffId === staffId &&
        t.leaveTypeId === leaveTypeId &&
        t.academicSessionId === targetSession
    );

    let entitlementDays = 0;
    let carryForwardDays = 0;
    let adjustmentsDays = 0;
    let usedDays = 0;
    let expiredDays = 0;
    let lastTransactionAt: string | undefined = undefined;

    transactions.forEach((tx) => {
      if (!lastTransactionAt || tx.createdAt > lastTransactionAt) {
        lastTransactionAt = tx.createdAt;
      }
      switch (tx.transactionType) {
        case 'ENTITLEMENT':
          entitlementDays += tx.amount;
          break;
        case 'CARRY_FORWARD':
          carryForwardDays += tx.amount;
          break;
        case 'ADJUSTMENT_ADD':
          adjustmentsDays += Math.abs(tx.amount);
          break;
        case 'ADJUSTMENT_DEDUCT':
          adjustmentsDays -= Math.abs(tx.amount);
          break;
        case 'LEAVE_DEDUCTION':
          usedDays += Math.abs(tx.amount);
          break;
        case 'LEAVE_REVERSAL':
          usedDays -= Math.abs(tx.amount);
          break;
        case 'EXPIRED':
          expiredDays += Math.abs(tx.amount);
          break;
      }
    });

    const remainingDays = entitlementDays + carryForwardDays + adjustmentsDays - usedDays - expiredDays;

    // Calculate active pending days (SUBMITTED, PENDING, UNDER_REVIEW, PARTIALLY_APPROVED)
    const activeApplications = (database.leaveApplications || []).filter(
      (app) =>
        (app.staffId === staffId || app.userId === staff.userId) &&
        app.leaveTypeId === leaveTypeId &&
        ['PENDING', 'SUBMITTED', 'UNDER_REVIEW', 'PARTIALLY_APPROVED'].includes(app.status)
    );

    let pendingDays = 0;
    activeApplications.forEach((app) => {
      const days = app.workingDays !== undefined ? app.workingDays : app.totalDays || 1;
      pendingDays += days;
    });

    const reservePending = policy ? policy.reservePendingBalance : true;
    const availableDays = reservePending ? Math.max(0, remainingDays - pendingDays) : remainingDays;

    return {
      id: `bal-${staff.id}-${leaveTypeId}`,
      staffId: staff.id,
      staffName: staff.fullName,
      employeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      staffType: staff.staffType,
      leaveTypeId,
      leaveTypeName: leaveType?.name || entitlement.leaveTypeName || 'Leave',
      leaveTypeCode: leaveType?.code || leaveType?.name?.substring(0, 3).toUpperCase() || 'LV',
      paidType: policy?.paidType || (leaveType?.paidType === 'UNPAID' || (leaveType as any)?.isPaid === false ? 'UNPAID' : 'PAID'),
      policyId: policy?.id || entitlement.policyId,
      policyName: policy?.name || entitlement.policyName,
      academicSessionId: targetSession,
      entitlementDays,
      carryForwardDays,
      adjustmentsDays,
      usedDays,
      pendingDays,
      remainingDays,
      availableDays,
      expiredDays,
      lastTransactionAt,
      lastCalculatedAt: new Date().toISOString()
    };
  }

  /**
   * Get all balances for all leave types for a specific staff member
   */
  public getStaffLeaveBalancesForStaff(staffId: string, sessionId?: string): StaffLeaveBalance[] {
    const targetSession = sessionId || this.getActiveAcademicSession();
    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) return [];

    const activeLeaveTypes = (database.leaveTypes || []).filter(
      (lt) => lt.isActive !== false && (lt.applicableTo === 'STAFF' || lt.applicableTo === 'BOTH' || lt.applicableTo === 'ALL' || !lt.applicableTo)
    );

    return activeLeaveTypes.map((lt) => this.getStaffLeaveBalance(staff.id, lt.id, targetSession));
  }

  /**
   * Get balances for authenticated user (staff or teacher)
   */
  public getStaffBalancesForUser(userId: string, sessionId?: string): StaffLeaveBalance[] {
    const staff = (database.staffProfiles || []).find((s) => s.userId === userId);
    if (!staff) return [];
    return this.getStaffLeaveBalancesForStaff(staff.id, sessionId);
  }

  /**
   * Query all staff balances with filters, search, and summary analytics
   */
  public getAllStaffBalances(query: StaffLeaveBalancesQuery): StaffLeaveBalancesResponse {
    const targetSession = query.academicSessionId || this.getActiveAcademicSession();
    let staffMembers = database.staffProfiles || [];

    if (query.departmentId && query.departmentId !== 'ALL') {
      staffMembers = staffMembers.filter((s) => s.departmentId === query.departmentId);
    }
    if (query.staffType && query.staffType !== 'ALL') {
      staffMembers = staffMembers.filter((s) => s.staffType === query.staffType);
    }
    if (query.search) {
      const q = query.search.toLowerCase().trim();
      staffMembers = staffMembers.filter(
        (s) =>
          s.fullName.toLowerCase().includes(q) ||
          s.employeeCode.toLowerCase().includes(q) ||
          s.email.toLowerCase().includes(q) ||
          (s.departmentName && s.departmentName.toLowerCase().includes(q))
      );
    }

    const leaveTypesToQuery = query.leaveTypeId && query.leaveTypeId !== 'ALL'
      ? (database.leaveTypes || []).filter((lt) => lt.id === query.leaveTypeId)
      : (database.leaveTypes || []).filter(
          (lt) => lt.isActive !== false && (lt.applicableTo === 'STAFF' || lt.applicableTo === 'BOTH' || lt.applicableTo === 'ALL' || !lt.applicableTo)
        );

    const allBalances: StaffLeaveBalance[] = [];
    staffMembers.forEach((staff) => {
      leaveTypesToQuery.forEach((lt) => {
        allBalances.push(this.getStaffLeaveBalance(staff.id, lt.id, targetSession));
      });
    });

    // Aggregated Summary
    let totalEntitlementDays = 0;
    let totalCarryForwardDays = 0;
    let totalAdjustmentsDays = 0;
    let totalUsedDays = 0;
    let totalPendingDays = 0;
    let totalRemainingDays = 0;

    allBalances.forEach((b) => {
      totalEntitlementDays += b.entitlementDays;
      totalCarryForwardDays += b.carryForwardDays;
      totalAdjustmentsDays += b.adjustmentsDays;
      totalUsedDays += b.usedDays;
      totalPendingDays += b.pendingDays;
      totalRemainingDays += b.remainingDays;
    });

    const totalPool = totalEntitlementDays + totalCarryForwardDays + totalAdjustmentsDays;
    const averageUtilizationRate = totalPool > 0 ? Number(((totalUsedDays / totalPool) * 100).toFixed(1)) : 0;

    // Pagination
    const page = query.page && query.page > 0 ? Number(query.page) : 1;
    const limit = query.limit && query.limit > 0 ? Number(query.limit) : 25;
    const startIndex = (page - 1) * limit;
    const pagedItems = allBalances.slice(startIndex, startIndex + limit);

    return {
      items: pagedItems,
      pagination: {
        page,
        limit,
        total: allBalances.length,
        totalPages: Math.ceil(allBalances.length / limit) || 1
      },
      summary: {
        totalStaff: staffMembers.length,
        totalEntitlementDays,
        totalCarryForwardDays,
        totalAdjustmentsDays,
        totalUsedDays,
        totalPendingDays,
        totalRemainingDays,
        averageUtilizationRate
      }
    };
  }

  // =========================================================================
  // 4. BALANCE TRANSACTION LEDGER & ADMINISTRATIVE ADJUSTMENTS
  // =========================================================================

  /**
   * Query the authoritative transaction ledger
   */
  public getLedger(query: StaffLeaveLedgerQuery): StaffLeaveLedgerResponse {
    let list = [...(database.staffLeaveTransactions || [])];

    if (query.academicSessionId) {
      list = list.filter((t) => t.academicSessionId === query.academicSessionId);
    }
    if (query.staffId) {
      list = list.filter((t) => t.staffId === query.staffId);
    }
    if (query.leaveTypeId) {
      list = list.filter((t) => t.leaveTypeId === query.leaveTypeId);
    }
    if (query.transactionType) {
      list = list.filter((t) => t.transactionType === query.transactionType);
    }
    if (query.startDate) {
      list = list.filter((t) => t.createdAt >= query.startDate!);
    }
    if (query.endDate) {
      list = list.filter((t) => t.createdAt <= query.endDate!);
    }
    if (query.search) {
      const q = query.search.toLowerCase().trim();
      list = list.filter(
        (t) =>
          t.staffName.toLowerCase().includes(q) ||
          (t.employeeCode && t.employeeCode.toLowerCase().includes(q)) ||
          t.reason.toLowerCase().includes(q) ||
          t.performedByName.toLowerCase().includes(q) ||
          t.leaveTypeName.toLowerCase().includes(q)
      );
    }

    // Sort descending by creation time
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = query.page && query.page > 0 ? Number(query.page) : 1;
    const limit = query.limit && query.limit > 0 ? Number(query.limit) : 25;
    const startIndex = (page - 1) * limit;
    const pagedItems = list.slice(startIndex, startIndex + limit);

    return {
      items: pagedItems,
      pagination: {
        page,
        limit,
        total: list.length,
        totalPages: Math.ceil(list.length / limit) || 1
      }
    };
  }

  /**
   * Execute an administrative leave balance adjustment (ADD or DEDUCT)
   * with concurrency locking and ledger transaction recording.
   */
  public async adjustStaffBalance(
    payload: AdjustStaffLeaveBalancePayload,
    actorUser: User
  ): Promise<StaffLeaveTransaction> {
    if (!payload.staffId) throw new Error('Staff selection is required.');
    if (!payload.leaveTypeId) throw new Error('Leave type is required.');
    if (!payload.days || payload.days <= 0) throw new Error('Days must be a positive number.');
    if (!payload.reason?.trim() || payload.reason.trim().length < 5) {
      throw new Error('A comprehensive institutional audit reason (min 5 characters) is mandatory.');
    }

    const targetSession = payload.academicSessionId || this.getActiveAcademicSession();
    const lockKey = `${payload.staffId}:${payload.leaveTypeId}:${targetSession}`;
    const release = await acquireLock(lockKey);

    try {
      const staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
      if (!staff) throw new Error(`Staff profile with ID '${payload.staffId}' not found.`);

      const balance = this.getStaffLeaveBalance(payload.staffId, payload.leaveTypeId, targetSession);
      const leaveType = database.leaveTypes?.find((lt) => lt.id === payload.leaveTypeId);

      const delta = payload.adjustmentType === 'ADD' ? payload.days : -payload.days;
      const balanceBefore = balance.remainingDays;
      const balanceAfter = balanceBefore + delta;

      if (payload.adjustmentType === 'DEDUCT' && balanceAfter < 0) {
        const policy = this.resolveStaffPolicy(payload.staffId, payload.leaveTypeId, targetSession);
        if (!policy?.allowNegativeBalance) {
          throw new Error(
            `Adjustment rejected: Remaining balance (${balanceBefore} days) is insufficient for a deduction of ${payload.days} days, and policy does not permit negative balance.`
          );
        }
      }

      const transaction: StaffLeaveTransaction = {
        id: `txn-adj-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        staffId: staff.id,
        staffName: staff.fullName,
        employeeCode: staff.employeeCode,
        departmentId: staff.departmentId,
        leaveTypeId: payload.leaveTypeId,
        leaveTypeName: leaveType?.name || balance.leaveTypeName,
        academicSessionId: targetSession,
        transactionType: payload.adjustmentType === 'ADD' ? 'ADJUSTMENT_ADD' : 'ADJUSTMENT_DEDUCT',
        amount: delta,
        balanceBefore,
        balanceAfter,
        referenceType: 'ADJUSTMENT',
        referenceId: `manual-adj-${Date.now()}`,
        reason: payload.reason.trim(),
        performedBy: actorUser.id,
        performedByName: actorUser.name,
        createdAt: new Date().toISOString()
      };

      if (!database.staffLeaveTransactions) database.staffLeaveTransactions = [];
      database.staffLeaveTransactions.push(transaction);

      // Audit Log
      this.logAudit(actorUser, 'ADJUST_STAFF_LEAVE_BALANCE', transaction.id, {
        staffId: staff.id,
        staffName: staff.fullName,
        leaveTypeName: transaction.leaveTypeName,
        adjustmentType: payload.adjustmentType,
        days: payload.days,
        balanceBefore,
        balanceAfter,
        reason: payload.reason.trim()
      });

      // Notification to Staff
      if (staff.userId) {
        const title = `Leave Balance Adjusted (${transaction.leaveTypeName})`;
        const message = `An administrative adjustment of ${delta > 0 ? `+${delta}` : delta} days has been recorded by ${actorUser.name}. New remaining balance: ${balanceAfter} days. Reason: ${payload.reason.trim()}`;
        this.sendNotification(staff.userId, title, message);
      }

      return transaction;
    } finally {
      release();
    }
  }

  // =========================================================================
  // 5. CARRY-FORWARD ENGINE (SESSION TRANSITION)
  // =========================================================================

  /**
   * Run idempotent session carry-forward calculation
   */
  public async runCarryForward(
    payload: CarryForwardProcessPayload,
    actorUser: User
  ): Promise<CarryForwardResult> {
    if (!payload.fromSessionId) throw new Error('Origin session (fromSessionId) is required.');
    if (!payload.toSessionId) throw new Error('Target session (toSessionId) is required.');
    if (payload.fromSessionId === payload.toSessionId) {
      throw new Error('Origin and target sessions must be distinct.');
    }

    let staffList = database.staffProfiles || [];
    if (payload.staffId) {
      staffList = staffList.filter((s) => s.id === payload.staffId);
    } else if (payload.staffCategory && payload.staffCategory !== 'ALL') {
      staffList = staffList.filter((s) => s.staffType === payload.staffCategory);
    }

    const leaveTypes = payload.leaveTypeId && payload.leaveTypeId !== 'ALL'
      ? (database.leaveTypes || []).filter((lt) => lt.id === payload.leaveTypeId)
      : (database.leaveTypes || []).filter((lt) => lt.isActive !== false);

    let processedCount = 0;
    let totalDaysCarried = 0;
    let skippedCount = 0;
    const details: CarryForwardResult['details'] = [];

    for (const staff of staffList) {
      for (const lt of leaveTypes) {
        // Check if carry forward is already recorded in toSessionId
        const existingCf = (database.staffLeaveTransactions || []).find(
          (t) =>
            t.staffId === staff.id &&
            t.leaveTypeId === lt.id &&
            t.academicSessionId === payload.toSessionId &&
            t.transactionType === 'CARRY_FORWARD'
        );

        if (existingCf) {
          skippedCount++;
          details.push({
            staffId: staff.id,
            staffName: staff.fullName,
            leaveTypeName: lt.name,
            remainingDays: 0,
            daysCarried: 0,
            reason: 'Carry-forward already recorded for this session.'
          });
          continue;
        }

        // Check policy in target session
        const policy = this.resolveStaffPolicy(staff.id, lt.id, payload.toSessionId);
        if (!policy || !policy.carryForwardAllowed || policy.maxCarryForwardDays <= 0) {
          skippedCount++;
          details.push({
            staffId: staff.id,
            staffName: staff.fullName,
            leaveTypeName: lt.name,
            remainingDays: 0,
            daysCarried: 0,
            reason: 'Policy does not permit carry-forward.'
          });
          continue;
        }

        // Calculate remaining unused days from origin session
        const originBalance = this.getStaffLeaveBalance(staff.id, lt.id, payload.fromSessionId);
        const unusedDays = Math.max(0, originBalance.remainingDays);

        if (unusedDays <= 0) {
          skippedCount++;
          details.push({
            staffId: staff.id,
            staffName: staff.fullName,
            leaveTypeName: lt.name,
            remainingDays: 0,
            daysCarried: 0,
            reason: 'Zero unused remaining days in origin session.'
          });
          continue;
        }

        const daysToCarry = Math.min(unusedDays, policy.maxCarryForwardDays);

        // Ensure entitlement exists in target session
        this.ensureStaffEntitlement(staff.id, lt.id, payload.toSessionId);

        // Get balance before CF in target session
        const targetBalBefore = this.getStaffLeaveBalance(staff.id, lt.id, payload.toSessionId);

        const cfTransaction: StaffLeaveTransaction = {
          id: `txn-cf-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          staffId: staff.id,
          staffName: staff.fullName,
          employeeCode: staff.employeeCode,
          departmentId: staff.departmentId,
          leaveTypeId: lt.id,
          leaveTypeName: lt.name,
          academicSessionId: payload.toSessionId,
          transactionType: 'CARRY_FORWARD',
          amount: daysToCarry,
          balanceBefore: targetBalBefore.remainingDays,
          balanceAfter: targetBalBefore.remainingDays + daysToCarry,
          referenceType: 'CARRY_FORWARD_JOB',
          referenceId: `cf-${payload.fromSessionId}-to-${payload.toSessionId}`,
          reason: `Automated session carry-forward from ${payload.fromSessionId} (Unused: ${unusedDays} days, Capped at max ${policy.maxCarryForwardDays} days)`,
          performedBy: actorUser.id,
          performedByName: actorUser.name,
          createdAt: new Date().toISOString()
        };

        if (!database.staffLeaveTransactions) database.staffLeaveTransactions = [];
        database.staffLeaveTransactions.push(cfTransaction);

        processedCount++;
        totalDaysCarried += daysToCarry;
        details.push({
          staffId: staff.id,
          staffName: staff.fullName,
          leaveTypeName: lt.name,
          remainingDays: unusedDays,
          daysCarried: daysToCarry
        });
      }
    }

    this.logAudit(actorUser, 'RUN_CARRY_FORWARD_JOB', `job-${Date.now()}`, {
      fromSessionId: payload.fromSessionId,
      toSessionId: payload.toSessionId,
      processedCount,
      totalDaysCarried,
      skippedCount
    });

    return {
      processedCount,
      totalDaysCarried,
      skippedCount,
      details
    };
  }

  // =========================================================================
  // 6. WORKING DATES CALCULATION & POLICY VALIDATION PREVIEW
  // =========================================================================

  /**
   * Helper: Calculate working dates excluding weekend off-days and school holidays
   */
  public calculateLeaveWorkingDates(
    startDateStr: string,
    endDateStr: string,
    sessionId?: string
  ): { workingDaysCount: number; workingDates: string[]; holidayDates: string[]; weekendDates: string[] } {
    const workingDates: string[] = [];
    const holidayDates: string[] = [];
    const weekendDates: string[] = [];

    const start = new Date(startDateStr);
    const end = new Date(endDateStr);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return { workingDaysCount: 1, workingDates: [startDateStr], holidayDates: [], weekendDates: [] };
    }

    const holidays = (database.holidays || []).flatMap((h: any) => {
      if (h.date) return [h.date];
      if (h.startDate && h.endDate) {
        const dates: string[] = [];
        const cur = new Date(h.startDate);
        const stop = new Date(h.endDate);
        while (cur <= stop) {
          dates.push(cur.toISOString().split('T')[0]);
          cur.setDate(cur.getDate() + 1);
        }
        return dates;
      }
      return h.startDate ? [h.startDate] : [];
    });
    const current = new Date(start);

    while (current <= end) {
      const dateIso = current.toISOString().split('T')[0];
      const dayOfWeek = current.getDay(); // 0 = Sun, 6 = Sat

      if (dayOfWeek === 0 || dayOfWeek === 6) {
        weekendDates.push(dateIso);
      } else if (holidays.includes(dateIso)) {
        holidayDates.push(dateIso);
      } else {
        workingDates.push(dateIso);
      }

      current.setDate(current.getDate() + 1);
    }

    return {
      workingDaysCount: workingDates.length,
      workingDates,
      holidayDates,
      weekendDates
    };
  }

  /**
   * Validate leave application against institutional policies & live balances
   */
  public validateLeaveApplication(
    staffId: string,
    leaveTypeId: string,
    startDate: string,
    endDate: string,
    attachmentUrl?: string,
    allowBalanceOverride?: boolean
  ): {
    isValid: boolean;
    errors: string[];
    warnings: string[];
    policy: StaffLeavePolicy | null;
    balance: StaffLeaveBalance;
    workingDaysCount: number;
    workingDates: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];

    const staff = (database.staffProfiles || []).find((s) => s.id === staffId);
    if (!staff) {
      errors.push(`Staff profile with ID '${staffId}' not found.`);
      return {
        isValid: false,
        errors,
        warnings,
        policy: null,
        balance: {} as any,
        workingDaysCount: 0,
        workingDates: []
      };
    }

    const targetSession = this.getActiveAcademicSession();
    const policy = this.resolveStaffPolicy(staffId, leaveTypeId, targetSession);
    const balance = this.getStaffLeaveBalance(staffId, leaveTypeId, targetSession);

    const { workingDaysCount, workingDates } = this.calculateLeaveWorkingDates(startDate, endDate, targetSession);

    if (workingDaysCount <= 0) {
      errors.push('Selected date range contains zero institutional working days (all dates fall on weekends or school holidays).');
    }

    if (policy) {
      // Minimum Notice Period Check
      if (policy.minNoticeDays > 0) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const reqStart = new Date(startDate);
        const diffDays = Math.ceil((reqStart.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays < policy.minNoticeDays) {
          warnings.push(
            `Policy Notice Rule: This leave type requires at least ${policy.minNoticeDays} days advance notice. (Submitted: ${diffDays} days before start date).`
          );
        }
      }

      // Maximum Consecutive Days Check
      if (policy.maxConsecutiveDays > 0 && workingDaysCount > policy.maxConsecutiveDays) {
        errors.push(
          `Consecutive Days Exceeded: Requested leave duration (${workingDaysCount} working days) exceeds policy maximum limit of ${policy.maxConsecutiveDays} consecutive days.`
        );
      }

      // Mandatory Attachment Check
      const attachmentMandatory =
        policy.requiresAttachment ||
        (policy.attachmentMandatoryAboveDays !== undefined && workingDaysCount > policy.attachmentMandatoryAboveDays);

      if (attachmentMandatory && !attachmentUrl) {
        errors.push(
          `Document Required: Under institutional policy, an official supporting document/certificate is mandatory for requests exceeding ${policy.attachmentMandatoryAboveDays ?? 0} days.`
        );
      }
    }

    // Overlapping Leave Check
    const overlapping = (database.leaveApplications || []).filter((app) => {
      if (app.status === 'REJECTED' || app.status === 'CANCELLED') return false;
      const appStaffId = app.staffId || (database.staffProfiles?.find((s) => s.userId === app.userId)?.id);
      if (appStaffId !== staffId) return false;

      const appStart = app.startDate;
      const appEnd = app.endDate || app.startDate;
      return startDate <= appEnd && endDate >= appStart;
    });

    if (overlapping.length > 0) {
      errors.push(
        `Overlapping Leave Detected: An active or approved leave application already covers part of this date range (${overlapping[0].startDate} to ${overlapping[0].endDate || overlapping[0].startDate}).`
      );
    }

    // Authoritative Balance Sufficiency Check
    if (workingDaysCount > balance.availableDays) {
      const msg = `Insufficient Balance: Requested ${workingDaysCount} working days, but only ${balance.availableDays} days are available (${balance.remainingDays} remaining, ${balance.pendingDays} pending reservation).`;
      if (allowBalanceOverride) {
        warnings.push(`${msg} [BALANCE OVERRIDE APPLIED]`);
      } else if (policy && policy.allowNegativeBalance) {
        warnings.push(`${msg} [NEGATIVE BALANCE ALLOWED BY POLICY]`);
      } else {
        errors.push(msg);
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      policy,
      balance,
      workingDaysCount,
      workingDates
    };
  }

  // =========================================================================
  // 7. LEAVE APPLICATION SUBMISSION & MULTI-TIER APPROVAL WORKFLOW
  // =========================================================================

  /**
   * Submit a new staff leave application
   */
  public async applyStaffLeave(
    payload: StaffLeaveApplicationPayload,
    actorUser: User
  ): Promise<LeaveApplication> {
    // Resolve target staff profile
    let staff: StaffProfile | undefined;
    if (payload.staffId) {
      staff = (database.staffProfiles || []).find((s) => s.id === payload.staffId);
    } else {
      staff = (database.staffProfiles || []).find((s) => s.userId === actorUser.id);
    }

    if (!staff) throw new Error('Could not identify a valid staff profile for this leave application.');

    const startDate = payload.startDate;
    const endDate = payload.endDate || payload.startDate;

    if (!startDate) throw new Error('Start date is required.');
    if (endDate < startDate) throw new Error('End date cannot be prior to start date.');
    if (!payload.leaveTypeId) throw new Error('Leave category is required.');
    if (!payload.reason?.trim()) throw new Error('Please specify the primary reason for leave.');

    const validation = this.validateLeaveApplication(
      staff.id,
      payload.leaveTypeId,
      startDate,
      endDate,
      payload.attachmentUrl,
      payload.allowBalanceOverride
    );

    if (!validation.isValid) {
      throw new Error(validation.errors.join(' '));
    }

    const targetSession = this.getActiveAcademicSession();
    const leaveType = database.leaveTypes?.find((lt) => lt.id === payload.leaveTypeId);
    const policy = validation.policy;

    const initialTier = 1;
    const totalTiers = policy?.approvalHierarchy === 'TWO_TIER' ? 2 : policy?.approvalHierarchy === 'THREE_TIER' ? 3 : 1;

    const newApplication: LeaveApplication = {
      id: `leave-staff-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId: staff.userId || actorUser.id,
      applicantType: staff.staffType === 'teaching' ? 'TEACHER' : 'STAFF',
      applicantId: staff.id,
      applicantName: staff.fullName,
      staffId: staff.id,
      employeeCode: staff.employeeCode,
      departmentId: staff.departmentId,
      departmentName: staff.departmentName,
      staffType: staff.staffType,
      leaveTypeId: payload.leaveTypeId,
      leaveTypeName: leaveType?.name || policy?.leaveTypeName || 'Leave',
      leaveTypeCode: leaveType?.code || 'LV',
      startDate,
      endDate,
      leaveDate: startDate,
      totalDays: validation.workingDaysCount,
      workingDays: validation.workingDaysCount,
      workingDates: validation.workingDates,
      reason: payload.reason.trim(),
      description: payload.description?.trim(),
      remarks: payload.remarks?.trim(),
      attachmentUrl: payload.attachmentUrl,
      attachmentName: payload.attachmentName,
      attachmentSize: payload.attachmentSize,
      attachmentType: payload.attachmentType,
      status: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
      academicSessionId: targetSession,
      policyId: policy?.id,
      policyName: policy?.name,
      currentApprovalTier: initialTier,
      totalApprovalTiers: totalTiers,
      approvalHistory: [
        {
          tier: 1,
          approverRole: 'HR_ADMIN',
          approverUserId: actorUser.id,
          approverName: actorUser.name,
          action: 'SUBMISSION',
          decisionDate: new Date().toISOString(),
          remarks: payload.remarks || 'Initial leave application submission',
          previousStatus: 'DRAFT',
          newStatus: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED'
        } as any
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.leaveApplications) database.leaveApplications = [];
    database.leaveApplications.unshift(newApplication);

    // Audit Log
    this.logAudit(actorUser, 'SUBMIT_STAFF_LEAVE', newApplication.id, {
      staffId: staff.id,
      staffName: staff.fullName,
      leaveTypeName: newApplication.leaveTypeName,
      startDate,
      endDate,
      workingDays: validation.workingDaysCount,
      warnings: validation.warnings
    });

    // Notify Department Head or HR
    const notifMsg = `${staff.fullName} submitted a leave request for ${startDate} to ${endDate} (${validation.workingDaysCount} working days).`;
    const adminUser = database.users?.find((u) => u.role === 'SUPER_ADMIN');
    if (adminUser) {
      this.sendNotification(adminUser.id, 'New Staff Leave Request', notifMsg);
    }

    return newApplication;
  }

  /**
   * Multi-Level Leave Review with Self-Approval Prevention,
   * Race-Condition Locking, Ledger Deductions, and Attendance Sync.
   */
  public async reviewStaffLeave(
    applicationId: string,
    payload: ReviewStaffLeavePayload,
    reviewerUser: User
  ): Promise<LeaveApplication> {
    const application = (database.leaveApplications || []).find((a) => a.id === applicationId);
    if (!application) throw new Error(`Leave application with ID '${applicationId}' not found.`);

    // 1. INSTITUTIONAL RULE: Self-approval prevention
    const reviewerStaff = (database.staffProfiles || []).find((s) => s.userId === reviewerUser.id);
    if (
      application.userId === reviewerUser.id ||
      (reviewerStaff && (reviewerStaff.id === application.staffId || reviewerStaff.employeeCode === application.employeeCode))
    ) {
      throw new Error(
        'Institutional Policy Violation: Staff members and approvers are strictly prohibited from reviewing or approving their own leave requests.'
      );
    }

    const staff = (database.staffProfiles || []).find(
      (s) => s.id === application.staffId || s.userId === application.userId
    );
    if (!staff) throw new Error('Associated staff profile not found.');

    const targetSession = application.academicSessionId || this.getActiveAcademicSession();
    const lockKey = `${staff.id}:${application.leaveTypeId}:${targetSession}`;
    const release = await acquireLock(lockKey);

    try {
      const policy = this.resolveStaffPolicy(staff.id, application.leaveTypeId, targetSession);
      const workingDays = application.workingDays !== undefined ? application.workingDays : application.totalDays || 1;
      const previousStatus = application.status;

      if (!application.approvalHistory) application.approvalHistory = [];

      // Case 1: REJECTION
      if (payload.status === 'REJECTED') {
        if (!payload.rejectionReason?.trim()) {
          throw new Error('An explicit rejection reason is mandatory when declining a staff leave request.');
        }

        application.status = 'REJECTED';
        application.rejectionReason = payload.rejectionReason.trim();
        application.adminRemarks = payload.adminRemarks?.trim();
        application.reviewedBy = reviewerUser.id;
        application.reviewedByName = reviewerUser.name;
        application.reviewedAt = new Date().toISOString();
        application.updatedAt = new Date().toISOString();

        application.approvalHistory.push({
          tier: application.currentApprovalTier || 1,
          approverRole: reviewerUser.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'DEPARTMENT_HEAD',
          approverUserId: reviewerUser.id,
          approverName: reviewerUser.name,
          action: 'REJECT',
          decisionDate: new Date().toISOString(),
          rejectionReason: payload.rejectionReason.trim(),
          remarks: payload.adminRemarks?.trim(),
          previousStatus,
          newStatus: 'REJECTED'
        } as any);

        this.logAudit(reviewerUser, 'REJECT_STAFF_LEAVE', application.id, {
          staffId: staff.id,
          rejectionReason: payload.rejectionReason.trim()
        });

        if (staff.userId) {
          this.sendNotification(
            staff.userId,
            'Leave Request Declined',
            `Your leave application for ${application.startDate} to ${application.endDate || application.startDate} was rejected. Reason: ${payload.rejectionReason.trim()}`
          );
        }

        return application;
      }

      // Case 2: APPROVAL (Check Multi-Tier Hierarchy)
      const currentTier = application.currentApprovalTier || 1;
      const totalTiers = application.totalApprovalTiers || (policy?.approvalHierarchy === 'TWO_TIER' ? 2 : 1);

      // Check if this review is advancing to next tier or final approval
      const isFinalApproval = currentTier >= totalTiers || payload.status === 'APPROVED';

      if (!isFinalApproval && policy?.approvalHierarchy === 'TWO_TIER') {
        // Advancing to Tier 2 (Department Head Approved, pending HR final)
        application.currentApprovalTier = 2;
        application.status = 'PARTIALLY_APPROVED';
        application.adminRemarks = payload.adminRemarks?.trim();
        application.reviewedBy = reviewerUser.id;
        application.reviewedByName = reviewerUser.name;
        application.reviewedAt = new Date().toISOString();
        application.updatedAt = new Date().toISOString();

        application.approvalHistory.push({
          tier: 1,
          approverRole: 'DEPARTMENT_HEAD',
          approverUserId: reviewerUser.id,
          approverName: reviewerUser.name,
          action: 'TIER_APPROVE',
          decisionDate: new Date().toISOString(),
          remarks: payload.adminRemarks?.trim() || 'Tier 1 Department Head recommendation granted',
          previousStatus,
          newStatus: 'PARTIALLY_APPROVED'
        } as any);

        this.logAudit(reviewerUser, 'TIER_APPROVE_STAFF_LEAVE', application.id, {
          staffId: staff.id,
          tier: 1,
          nextTier: 2
        });

        if (staff.userId) {
          this.sendNotification(
            staff.userId,
            'Leave Request Recommended (Tier 1)',
            `Your leave application has received Tier 1 departmental approval and forwarded for final administrative clearance.`
          );
        }

        return application;
      }

      // FINAL APPROVAL EXECUTION
      // 1. Balance sufficiency check
      const currentBalance = this.getStaffLeaveBalance(staff.id, application.leaveTypeId, targetSession);
      if (workingDays > currentBalance.remainingDays && !payload.allowBalanceOverride && !policy?.allowNegativeBalance) {
        throw new Error(
          `Cannot grant approval: Requested duration (${workingDays} days) exceeds available balance (${currentBalance.remainingDays} days). Provide an administrative override if authorized.`
        );
      }

      // 2. Atomically record LEAVE_DEDUCTION in the ledger
      const deductionTx: StaffLeaveTransaction = {
        id: `txn-ded-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        staffId: staff.id,
        staffName: staff.fullName,
        employeeCode: staff.employeeCode,
        departmentId: staff.departmentId,
        leaveTypeId: application.leaveTypeId,
        leaveTypeName: application.leaveTypeName,
        academicSessionId: targetSession,
        transactionType: 'LEAVE_DEDUCTION',
        amount: -workingDays,
        balanceBefore: currentBalance.remainingDays,
        balanceAfter: currentBalance.remainingDays - workingDays,
        referenceType: 'LEAVE_APPLICATION',
        referenceId: application.id,
        reason: `Approved leave deduction: ${application.startDate} to ${application.endDate || application.startDate} (${workingDays} working days)`,
        performedBy: reviewerUser.id,
        performedByName: reviewerUser.name,
        createdAt: new Date().toISOString()
      };

      if (!database.staffLeaveTransactions) database.staffLeaveTransactions = [];
      database.staffLeaveTransactions.push(deductionTx);

      // 3. Mark attendance records as LEAVE for all working days
      const workingDates = application.workingDates || [application.startDate];
      for (const date of workingDates) {
        try {
          staffAttendanceService.markStaffAttendance(
            {
              staffId: staff.id,
              date,
              status: 'LEAVE',
              remarks: `Approved leave: ${application.leaveTypeName} (Ref: ${application.id})`
            },
            reviewerUser
          );
        } catch (attErr) {
          console.warn(`Could not sync staff attendance for date ${date}:`, attErr);
        }
      }

      // 4. Update application status
      application.status = 'APPROVED';
      application.adminRemarks = payload.adminRemarks?.trim();
      application.reviewedBy = reviewerUser.id;
      application.reviewedByName = reviewerUser.name;
      application.reviewedAt = new Date().toISOString();
      application.updatedAt = new Date().toISOString();

      application.approvalHistory.push({
        tier: totalTiers,
        approverRole: reviewerUser.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'HR_ADMIN',
        approverUserId: reviewerUser.id,
        approverName: reviewerUser.name,
        action: payload.allowBalanceOverride ? 'OVERRIDE' : 'FINAL_APPROVE',
        decisionDate: new Date().toISOString(),
        remarks: payload.adminRemarks?.trim() || (payload.allowBalanceOverride ? `Approved with balance override: ${payload.overrideReason || 'Administrative discretion'}` : 'Institutional approval confirmed'),
        previousStatus,
        newStatus: 'APPROVED'
      } as any);

      // 5. Audit Log
      this.logAudit(reviewerUser, 'FINAL_APPROVE_STAFF_LEAVE', application.id, {
        staffId: staff.id,
        workingDays,
        balanceBefore: deductionTx.balanceBefore,
        balanceAfter: deductionTx.balanceAfter,
        overrideApplied: Boolean(payload.allowBalanceOverride)
      });

      // 6. Notify Employee
      if (staff.userId) {
        this.sendNotification(
          staff.userId,
          'Leave Request Approved',
          `Your leave application for ${application.startDate} to ${application.endDate || application.startDate} has been officially approved. Deduction: ${workingDays} days. New remaining balance: ${deductionTx.balanceAfter} days.`
        );
      }

      return application;
    } finally {
      release();
    }
  }

  /**
   * Cancel and safely reverse an approved or submitted leave application
   */
  public async cancelStaffLeave(
    applicationId: string,
    reason: string,
    actorUser: User
  ): Promise<LeaveApplication> {
    const application = (database.leaveApplications || []).find((a) => a.id === applicationId);
    if (!application) throw new Error(`Leave application with ID '${applicationId}' not found.`);

    if (application.status === 'CANCELLED') {
      throw new Error('Leave application is already cancelled.');
    }

    const staff = (database.staffProfiles || []).find(
      (s) => s.id === application.staffId || s.userId === application.userId
    );
    if (!staff) throw new Error('Associated staff profile not found.');

    // Only applicant or Super Admin can cancel
    const isApplicant = application.userId === actorUser.id || staff.userId === actorUser.id;
    const isAdmin = actorUser.role === 'SUPER_ADMIN';
    if (!isApplicant && !isAdmin) {
      throw new Error('Unauthorized. Only the applicant or an institutional administrator can cancel a leave request.');
    }

    const targetSession = application.academicSessionId || this.getActiveAcademicSession();
    const lockKey = `${staff.id}:${application.leaveTypeId}:${targetSession}`;
    const release = await acquireLock(lockKey);

    try {
      const previousStatus = application.status;
      const workingDays = application.workingDays !== undefined ? application.workingDays : application.totalDays || 1;

      // If already APPROVED, we MUST perform an atomic reversal transaction in the ledger
      if (previousStatus === 'APPROVED') {
        const currentBalance = this.getStaffLeaveBalance(staff.id, application.leaveTypeId, targetSession);
        const reversalTx: StaffLeaveTransaction = {
          id: `txn-rev-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          staffId: staff.id,
          staffName: staff.fullName,
          employeeCode: staff.employeeCode,
          departmentId: staff.departmentId,
          leaveTypeId: application.leaveTypeId,
          leaveTypeName: application.leaveTypeName,
          academicSessionId: targetSession,
          transactionType: 'LEAVE_REVERSAL',
          amount: workingDays,
          balanceBefore: currentBalance.remainingDays,
          balanceAfter: currentBalance.remainingDays + workingDays,
          referenceType: 'LEAVE_APPLICATION',
          referenceId: application.id,
          reason: `Reversal of approved leave cancellation: ${reason.trim() || 'Leave request cancelled'}`,
          performedBy: actorUser.id,
          performedByName: actorUser.name,
          createdAt: new Date().toISOString()
        };

        if (!database.staffLeaveTransactions) database.staffLeaveTransactions = [];
        database.staffLeaveTransactions.push(reversalTx);

        // Revert attendance marks for those dates
        const workingDates = application.workingDates || [application.startDate];
        if (database.staffAttendanceRecords) {
          database.staffAttendanceRecords = database.staffAttendanceRecords.filter(
            (rec) => !(rec.staffId === staff.id && workingDates.includes(rec.date) && rec.status === 'LEAVE')
          );
        }
      }

      application.status = 'CANCELLED';
      application.adminRemarks = `Cancelled by ${actorUser.name}: ${reason.trim()}`;
      application.updatedAt = new Date().toISOString();

      if (!application.approvalHistory) application.approvalHistory = [];
      application.approvalHistory.push({
        tier: application.currentApprovalTier || 1,
        approverRole: isAdmin ? 'SUPER_ADMIN' : 'HR_ADMIN',
        approverUserId: actorUser.id,
        approverName: actorUser.name,
        action: 'CANCEL',
        decisionDate: new Date().toISOString(),
        remarks: reason.trim() || 'Leave cancelled',
        previousStatus,
        newStatus: 'CANCELLED'
      } as any);

      this.logAudit(actorUser, 'CANCEL_STAFF_LEAVE', application.id, {
        staffId: staff.id,
        workingDays,
        previousStatus,
        reason: reason.trim()
      });

      if (staff.userId && staff.userId !== actorUser.id) {
        this.sendNotification(
          staff.userId,
          'Leave Request Cancelled',
          `Your leave request for ${application.startDate} to ${application.endDate || application.startDate} was cancelled. Days restored: ${previousStatus === 'APPROVED' ? workingDays : 0}.`
        );
      }

      return application;
    } finally {
      release();
    }
  }

  // =========================================================================
  // 8. LEAVE REPORTS & ANALYTICS
  // =========================================================================

  /**
   * Comprehensive Leave Reports summary
   */
  public getStaffLeaveReportsSummary(academicSessionId?: string): StaffLeaveReportsSummary {
    const targetSession = academicSessionId || this.getActiveAcademicSession();
    const staffList = database.staffProfiles || [];
    const departments = database.departments || [];
    const leaveTypes = (database.leaveTypes || []).filter((lt) => lt.isActive !== false);

    let totalEntitlement = 0;
    let totalUsed = 0;
    let totalPending = 0;
    let totalRemaining = 0;
    let totalCarryForward = 0;

    const deptUsageMap = new Map<string, { totalDays: number; totalApplications: number }>();
    const typeUsageMap = new Map<string, { totalDays: number; applicationCount: number }>();

    departments.forEach((d) => deptUsageMap.set(d.id, { totalDays: 0, totalApplications: 0 }));
    leaveTypes.forEach((lt) => typeUsageMap.set(lt.id, { totalDays: 0, applicationCount: 0 }));

    staffList.forEach((staff) => {
      leaveTypes.forEach((lt) => {
        const bal = this.getStaffLeaveBalance(staff.id, lt.id, targetSession);
        totalEntitlement += bal.entitlementDays;
        totalUsed += bal.usedDays;
        totalPending += bal.pendingDays;
        totalRemaining += bal.remainingDays;
        totalCarryForward += bal.carryForwardDays;

        if (staff.departmentId && deptUsageMap.has(staff.departmentId)) {
          const entry = deptUsageMap.get(staff.departmentId)!;
          entry.totalDays += bal.usedDays;
        }

        if (typeUsageMap.has(lt.id)) {
          const typeEntry = typeUsageMap.get(lt.id)!;
          typeEntry.totalDays += bal.usedDays;
        }
      });
    });

    const applications = (database.leaveApplications || []).filter(
      (app) => !app.academicSessionId || app.academicSessionId === targetSession
    );

    let totalSubmitted = 0;
    let approved = 0;
    let partiallyApproved = 0;
    let rejected = 0;
    let cancelled = 0;
    let pending = 0;

    applications.forEach((app) => {
      totalSubmitted++;
      if (app.status === 'APPROVED') approved++;
      else if (app.status === 'PARTIALLY_APPROVED') partiallyApproved++;
      else if (app.status === 'REJECTED') rejected++;
      else if (app.status === 'CANCELLED') cancelled++;
      else pending++;

      if (app.departmentId && deptUsageMap.has(app.departmentId)) {
        deptUsageMap.get(app.departmentId)!.totalApplications++;
      }
      if (app.leaveTypeId && typeUsageMap.has(app.leaveTypeId)) {
        typeUsageMap.get(app.leaveTypeId)!.applicationCount++;
      }
    });

    const totalPool = totalEntitlement + totalCarryForward;
    const utilizationRate = totalPool > 0 ? Number(((totalUsed / totalPool) * 100).toFixed(1)) : 0;

    const usageByDepartment = departments.map((d) => ({
      departmentId: d.id,
      departmentName: d.name,
      totalDays: deptUsageMap.get(d.id)?.totalDays || 0,
      totalApplications: deptUsageMap.get(d.id)?.totalApplications || 0
    }));

    const usageByLeaveType = leaveTypes.map((lt) => ({
      leaveTypeId: lt.id,
      leaveTypeName: lt.name,
      leaveTypeCode: lt.code || lt.name.substring(0, 3).toUpperCase(),
      totalDays: typeUsageMap.get(lt.id)?.totalDays || 0,
      applicationCount: typeUsageMap.get(lt.id)?.applicationCount || 0
    }));

    return {
      balanceReport: {
        totalEntitlement,
        totalUsed,
        totalPending,
        totalRemaining,
        totalCarryForward,
        utilizationRate
      },
      usageByDepartment,
      usageByLeaveType,
      approvalStats: {
        totalSubmitted,
        approved,
        partiallyApproved,
        rejected,
        cancelled,
        pending
      }
    };
  }

  /**
   * Export Staff Leave Balances as CSV
   */
  public exportStaffLeaveBalancesCSV(query: StaffLeaveBalancesQuery): string {
    const res = this.getAllStaffBalances({ ...query, limit: 10000 });
    const headers = [
      'Employee Code',
      'Staff Name',
      'Department',
      'Staff Category',
      'Leave Type',
      'Policy Applied',
      'Entitlement Days',
      'Carry-Forward Days',
      'Adjustments Days',
      'Used Days',
      'Pending Days',
      'Remaining Days',
      'Available Days',
      'Last Transaction'
    ];

    const rows = res.items.map((b) => [
      `"${b.employeeCode}"`,
      `"${b.staffName}"`,
      `"${b.departmentName || 'N/A'}"`,
      `"${b.staffType}"`,
      `"${b.leaveTypeName}"`,
      `"${b.policyName || 'Default'}"`,
      b.entitlementDays,
      b.carryForwardDays,
      b.adjustmentsDays,
      b.usedDays,
      b.pendingDays,
      b.remainingDays,
      b.availableDays,
      `"${b.lastTransactionAt || 'None'}"`
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }
}

export const staffLeaveService = new StaffLeaveService();
