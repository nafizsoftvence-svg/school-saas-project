/**
 * Issue, Return, Allocation & Department Workflow Service (Part 14E)
 * Sygmate School Management System
 *
 * Implements authoritative Issue Requests, Multi-Item Stock Issues, Partial Issues,
 * Inventory Returns with Condition Handling, Asset Handover & Allocation,
 * Concurrency serialized custody transfers, Department ownership views,
 * notifications, and audit logging.
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import { StockService } from './stock.service.js';
import { AssetService, withAssetLock } from './asset.service.js';
import {
  IssueRequest,
  IssueRequestItem,
  CreateIssueRequestPayload,
  ReviewIssueRequestPayload,
  StockIssue,
  StockIssueItem,
  ExecuteStockIssuePayload,
  InventoryReturn,
  InventoryReturnItem,
  RecordInventoryReturnPayload,
  BulkAssetAllocationPayload,
  DepartmentAllocationSummary,
  IssueAllocationDashboardKPIs,
  Asset,
  AssetAssignment,
  AssetCondition,
  UserRole
} from '../../src/types/index.js';

// ============================================================================
// CONCURRENCY CONTROL & MUTEX
// ============================================================================

const issueLockQueues = new Map<string, Promise<any>>();

async function withIssueLock<T>(lockKey: string, fn: () => Promise<T> | T): Promise<T> {
  const currentPromise = issueLockQueues.get(lockKey) || Promise.resolve();
  let releaseLock: () => void;
  const newPromise = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });

  issueLockQueues.set(lockKey, currentPromise.then(() => newPromise));

  try {
    await currentPromise;
    return await fn();
  } finally {
    releaseLock!();
    if (issueLockQueues.get(lockKey) === newPromise) {
      issueLockQueues.delete(lockKey);
    }
  }
}

// ============================================================================
// DEFENSIVE INITIALIZATION
// ============================================================================

export function ensureIssueAllocationCollections(): void {
  if (!database.issueRequests) database.issueRequests = [];
  if (!database.stockIssues) database.stockIssues = [];
  if (!database.inventoryReturns) database.inventoryReturns = [];
  if (!database.inventoryItems) database.inventoryItems = [];
  if (!database.inventoryLocations) database.inventoryLocations = [];
  if (!database.stockBalances) database.stockBalances = [];
  if (!database.stockMovements) database.stockMovements = [];
  if (!database.stockTransactions) database.stockTransactions = [];
  if (!database.assets) database.assets = [];
  if (!database.assetAssignments) database.assetAssignments = [];
  if (!database.assetTransfers) database.assetTransfers = [];
  if (!database.assetReturns) database.assetReturns = [];
  if (!database.assetTimelineEvents) database.assetTimelineEvents = [];
  if (!database.departments) database.departments = [];
  if (!database.staffProfiles) database.staffProfiles = [];
  if (!database.notifications) database.notifications = [];
}

export function normalizeUser(rawUser: any): { id: string; name: string; role: UserRole } {
  return {
    id: rawUser?.id || 'usr-admin-1',
    name: rawUser?.name || 'System Administrator',
    role: rawUser?.role || 'SUPER_ADMIN'
  };
}

// ============================================================================
// NUMBER GENERATORS
// ============================================================================

function generateNextIssueRequestNumber(schoolId: string): string {
  ensureIssueAllocationCollections();
  const year = new Date().getFullYear();
  let counter = database.issueRequests.filter((r) => r.schoolId === schoolId).length + 1;
  let code = `IR-${year}-${String(counter).padStart(4, '0')}`;
  while (
    database.issueRequests.some(
      (r) => r.schoolId === schoolId && r.requestNumber.toUpperCase() === code.toUpperCase()
    )
  ) {
    counter++;
    code = `IR-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

function generateNextStockIssueNumber(schoolId: string): string {
  ensureIssueAllocationCollections();
  const year = new Date().getFullYear();
  let counter = database.stockIssues.filter((i) => i.schoolId === schoolId).length + 1;
  let code = `ISS-${year}-${String(counter).padStart(4, '0')}`;
  while (
    database.stockIssues.some(
      (i) => i.schoolId === schoolId && i.issueNumber.toUpperCase() === code.toUpperCase()
    )
  ) {
    counter++;
    code = `ISS-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

function generateNextReturnNumber(schoolId: string): string {
  ensureIssueAllocationCollections();
  const year = new Date().getFullYear();
  let counter = database.inventoryReturns.filter((r) => r.schoolId === schoolId).length + 1;
  let code = `RET-${year}-${String(counter).padStart(4, '0')}`;
  while (
    database.inventoryReturns.some(
      (r) => r.schoolId === schoolId && r.returnNumber.toUpperCase() === code.toUpperCase()
    )
  ) {
    counter++;
    code = `RET-${year}-${String(counter).padStart(4, '0')}`;
  }
  return code;
}

// ============================================================================
// NOTIFICATION HELPER
// ============================================================================

function sendNotification(
  userId: string,
  roleTarget: UserRole | string,
  title: string,
  message: string,
  link: string,
  type: string
): void {
  ensureIssueAllocationCollections();
  database.notifications.unshift({
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    userId,
    roleTarget: roleTarget as any,
    category: 'system',
    type,
    title,
    message,
    isRead: false,
    link,
    createdAt: new Date().toISOString()
  });
}

// ============================================================================
// SERVICE IMPLEMENTATION
// ============================================================================

export class IssueAllocationService {
  // ==========================================================================
  // 1. INVENTORY ISSUE REQUESTS
  // ==========================================================================

  /**
   * Create a new Issue Request
   */
  static async createIssueRequest(
    schoolId: string,
    payload: CreateIssueRequestPayload,
    userArg: any
  ): Promise<IssueRequest> {
    ensureIssueAllocationCollections();
    const user = normalizeUser(userArg);

    if (!payload.items || payload.items.length === 0) {
      throw new Error('An issue request must include at least one inventory item.');
    }

    const locId = payload.locationId || (payload as any).targetLocationId;
    const location = database.inventoryLocations.find(
      (l) => l.schoolId === schoolId && (l.id === locId || l.code === locId)
    );
    if (!location) {
      throw new Error('Source inventory store/location not found.');
    }
    if (location.status === 'INACTIVE') {
      throw new Error(`Location '${location.name}' is inactive.`);
    }

    const now = new Date().toISOString();
    const requestNumber = generateNextIssueRequestNumber(schoolId);

    const items: IssueRequestItem[] = [];

    for (const itemPayload of payload.items) {
      if (typeof itemPayload.requestedQuantity !== 'number' || itemPayload.requestedQuantity <= 0) {
        throw new Error('Requested quantity must be greater than zero for all items.');
      }

      const invItem = database.inventoryItems.find(
        (i) => i.schoolId === schoolId && i.id === itemPayload.itemId
      );
      if (!invItem) {
        throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);
      }

      // Check current available stock at the source location
      const balance = database.stockBalances.find(
        (b) =>
          b.schoolId === schoolId &&
          b.itemId === invItem.id &&
          b.locationId === location.id
      );
      const availableQuantity = balance ? balance.quantity : 0;

      items.push({
        id: `iri-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        issueRequestId: '',
        itemId: invItem.id,
        itemName: invItem.name,
        itemCode: invItem.itemCode,
        unitId: invItem.unitId,
        unitShortCode: invItem.unitShortCode,
        requestedQuantity: itemPayload.requestedQuantity,
        availableQuantityAtRequest: availableQuantity,
        approvedQuantity: 0,
        issuedQuantity: 0,
        notes: itemPayload.notes
      });
    }

    const issueRequest: IssueRequest = {
      id: `ir-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      schoolId,
      requestNumber,
      requestDate: now,
      requiredDate: payload.requiredDate,
      priority: payload.priority || 'MEDIUM',
      status: 'SUBMITTED',
      requestedBy: user.id,
      requestedByName: user.name,
      requestedByRole: user.role,
      departmentId: payload.departmentId,
      departmentName: payload.departmentName || 'General Administration',
      destinationType: payload.destinationType || 'DEPARTMENT',
      destinationId: payload.destinationId,
      destinationName: payload.destinationName || payload.departmentName || 'Office',
      locationId: location.id,
      locationName: location.name,
      purpose: payload.purpose?.trim() || 'General educational and operational requirement',
      notes: payload.notes?.trim(),
      items,
      attachments: payload.attachments || [],
      createdAt: now,
      updatedAt: now
    };

    // Attach parent ID to line items
    items.forEach((item) => {
      item.issueRequestId = issueRequest.id;
    });

    database.issueRequests.unshift(issueRequest);

    // Notify administrators
    sendNotification(
      'usr-admin-1',
      'SUPER_ADMIN',
      `New Issue Request: ${requestNumber}`,
      `${user.name} submitted an issue request for ${items.length} items to ${issueRequest.destinationName}. Priority: ${issueRequest.priority}.`,
      '/admin/inventory',
      'ISSUE_REQUEST_SUBMITTED'
    );

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'IssueRequest',
      entityId: issueRequest.id,
      details: `Created issue request ${requestNumber} for ${items.length} line items to ${issueRequest.destinationName}.`
    });

    return issueRequest;
  }

  /**
   * Get Issue Requests with multifaceted filters and pagination
   */
  static getIssueRequests(
    schoolId: string,
    filters?: {
      search?: string;
      status?: string;
      priority?: string;
      departmentId?: string;
      locationId?: string;
      requestedBy?: string;
      page?: number;
      limit?: number;
    }
  ): { data: IssueRequest[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureIssueAllocationCollections();

    let list = database.issueRequests.filter((r) => r.schoolId === schoolId);

    if (filters) {
      if (filters.status && filters.status !== 'ALL') {
        list = list.filter((r) => r.status === filters.status);
      }
      if (filters.priority && filters.priority !== 'ALL') {
        list = list.filter((r) => r.priority === filters.priority);
      }
      if (filters.departmentId && filters.departmentId !== 'ALL') {
        list = list.filter((r) => r.departmentId === filters.departmentId);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        list = list.filter((r) => r.locationId === filters.locationId);
      }
      if (filters.requestedBy) {
        list = list.filter((r) => r.requestedBy === filters.requestedBy);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.trim().toLowerCase();
        list = list.filter(
          (r) =>
            r.requestNumber.toLowerCase().includes(q) ||
            r.requestedByName.toLowerCase().includes(q) ||
            r.destinationName.toLowerCase().includes(q) ||
            r.departmentName.toLowerCase().includes(q) ||
            r.purpose.toLowerCase().includes(q) ||
            r.items.some((i) => i.itemName.toLowerCase().includes(q) || i.itemCode.toLowerCase().includes(q))
        );
      }
    }

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, filters?.limit || 20);
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const paginated = list.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, pages }
    };
  }

  /**
   * Get single Issue Request with live stock status lookup
   */
  static getIssueRequestById(schoolId: string, id: string): IssueRequest {
    ensureIssueAllocationCollections();
    const request = database.issueRequests.find(
      (r) => r.schoolId === schoolId && (r.id === id || r.requestNumber === id)
    );
    if (!request) {
      throw new Error(`Issue request not found with ID '${id}'.`);
    }

    // Refresh live available quantities
    request.items = request.items.map((item) => {
      const balance = database.stockBalances.find(
        (b) =>
          b.schoolId === schoolId &&
          b.itemId === item.itemId &&
          b.locationId === request.locationId
      );
      return {
        ...item,
        availableQuantityAtRequest: balance ? balance.quantity : 0
      };
    });

    return request;
  }

  /**
   * Review Issue Request (Approve, Partial Approve, Reject, Cancel)
   */
  static async reviewIssueRequest(
    schoolId: string,
    id: string,
    payload: ReviewIssueRequestPayload,
    userArg: any
  ): Promise<IssueRequest> {
    ensureIssueAllocationCollections();
    const user = normalizeUser(userArg);
    const lockKey = `issue-req:${schoolId}:${id}`;

    return withIssueLock(lockKey, async () => {
      const request = database.issueRequests.find(
        (r) => r.schoolId === schoolId && (r.id === id || r.requestNumber === id)
      );
      if (!request) {
        throw new Error(`Issue request not found with ID '${id}'.`);
      }

      if (request.status !== 'SUBMITTED' && request.status !== 'UNDER_REVIEW') {
        throw new Error(
          `Cannot review issue request in '${request.status}' status. Only SUBMITTED or UNDER_REVIEW requests can be reviewed.`
        );
      }

      const now = new Date().toISOString();
      request.reviewedBy = user.id;
      request.reviewedByName = user.name;
      request.reviewedAt = now;
      request.reviewNotes = payload.reviewNotes?.trim();
      request.updatedAt = now;

      if (payload.decision === 'REJECT') {
        request.status = 'REJECTED';
        request.rejectionReason = payload.rejectionReason?.trim() || 'Request rejected during administrative review.';

        sendNotification(
          request.requestedBy,
          request.requestedByRole || 'TEACHER',
          `Issue Request Rejected: ${request.requestNumber}`,
          `Your issue request ${request.requestNumber} was rejected. Reason: ${request.rejectionReason}`,
          '/admin/inventory',
          'ISSUE_REJECTED'
        );

        logAudit({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action: 'UPDATE',
          entity: 'OTHER',
          entityType: 'IssueRequest',
          entityId: request.id,
          details: `Rejected issue request ${request.requestNumber}. Reason: ${request.rejectionReason}`
        });

        return request;
      }

      // APPROVE DECISION
      let totalApprovedQty = 0;
      for (const item of request.items) {
        let approvedQty = item.requestedQuantity;
        if (payload.itemApprovals && payload.itemApprovals.length > 0) {
          const match = payload.itemApprovals.find((a) => a.itemId === item.itemId);
          if (match) {
            if (typeof match.approvedQuantity !== 'number' || match.approvedQuantity < 0) {
              throw new Error(`Approved quantity for '${item.itemName}' must be zero or a positive number.`);
            }
            if (match.approvedQuantity > item.requestedQuantity) {
              throw new Error(
                `Approved quantity (${match.approvedQuantity}) cannot exceed requested quantity (${item.requestedQuantity}) for '${item.itemName}'.`
              );
            }
            approvedQty = match.approvedQuantity;
          }
        }
        item.approvedQuantity = approvedQty;
        item.remainingQuantity = approvedQty - (item.issuedQuantity || 0);
        totalApprovedQty += approvedQty;
      }

      if (totalApprovedQty === 0) {
        request.status = 'REJECTED';
        request.rejectionReason = 'All items were approved with 0 quantity.';
      } else {
        request.status = 'APPROVED';
      }

      sendNotification(
        request.requestedBy,
        request.requestedByRole || 'TEACHER',
        `Issue Request Approved: ${request.requestNumber}`,
        `Your issue request ${request.requestNumber} has been approved and queued for warehouse fulfillment.`,
        '/admin/inventory',
        'ISSUE_APPROVED'
      );

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'IssueRequest',
        entityId: request.id,
        details: `Approved issue request ${request.requestNumber} with total approved quantity of ${totalApprovedQty}.`
      });

      return request;
    });
  }

  // ==========================================================================
  // 2. STOCK ISSUE EXECUTION (AUTHORITATIVE STOCK DEDUCTION)
  // ==========================================================================

  /**
   * Execute Stock Issue (Full or Partial)
   *
   * Validates available stock server-side.
   * Prevents negative inventory strictly.
   * Calls StockService.recordStockOut for atomic stock balance & ledger generation.
   */
  static async executeStockIssue(
    schoolId: string,
    payload: ExecuteStockIssuePayload,
    userArg: any
  ): Promise<{ stockIssue: StockIssue; issueRequest?: IssueRequest }> {
    ensureIssueAllocationCollections();
    const user = normalizeUser(userArg);

    if (!payload.items || payload.items.length === 0) {
      throw new Error('Stock issue execution requires at least one item.');
    }

    const locId = payload.locationId || (payload as any).sourceLocationId;
    const location = database.inventoryLocations.find(
      (l) => l.schoolId === schoolId && (l.id === locId || l.code === locId)
    );
    if (!location) {
      throw new Error('Dispatch store/location not found.');
    }
    if (location.status === 'INACTIVE') {
      throw new Error(`Location '${location.name}' is inactive.`);
    }

    const lockKey = `stock-issue:${schoolId}:${location.id}`;

    return withIssueLock(lockKey, async () => {
      let linkedRequest: IssueRequest | undefined;
      if (payload.issueRequestId) {
        linkedRequest = database.issueRequests.find(
          (r) => r.schoolId === schoolId && (r.id === payload.issueRequestId || r.requestNumber === payload.issueRequestId)
        );
        if (!linkedRequest) {
          throw new Error(`Linked issue request '${payload.issueRequestId}' not found.`);
        }
        if (linkedRequest.status !== 'APPROVED' && linkedRequest.status !== 'PARTIALLY_ISSUED') {
          throw new Error(
            `Issue request is in '${linkedRequest.status}' status. Only APPROVED or PARTIALLY_ISSUED requests can be fulfilled.`
          );
        }
      }

      // Step 1: Pre-validate all items, remaining quotas, and stock availability BEFORE any mutation
      for (const itemPayload of payload.items) {
        const qty = itemPayload.quantity ?? (itemPayload as any).issueQuantity;
        if (typeof qty !== 'number' || qty <= 0) {
          throw new Error('Issue quantity must be greater than zero.');
        }

        const invItem = database.inventoryItems.find(
          (i) => i.schoolId === schoolId && i.id === itemPayload.itemId
        );
        if (!invItem) {
          throw new Error(`Inventory item '${itemPayload.itemId}' not found.`);
        }

        // Quota check if linked to request
        if (linkedRequest) {
          const reqItem = linkedRequest.items.find((i) => i.itemId === itemPayload.itemId);
          if (!reqItem) {
            throw new Error(`Item '${invItem.name}' was not approved in request ${linkedRequest.requestNumber}.`);
          }
          const remainingApproved = reqItem.approvedQuantity - reqItem.issuedQuantity;
          if (qty > remainingApproved) {
            throw new Error(
              `Cannot issue ${qty} ${invItem.unitShortCode} of '${invItem.name}'. Remaining approved quantity is only ${remainingApproved} ${invItem.unitShortCode}.`
            );
          }
        }

        // Server-side strict negative inventory check
        const balance = database.stockBalances.find(
          (b) =>
            b.schoolId === schoolId &&
            b.itemId === invItem.id &&
            b.locationId === location.id
        );
        const currentQty = balance ? balance.quantity : 0;
        if (currentQty < qty) {
          throw new Error(
            `Insufficient stock for '${invItem.name}' at ${location.name}. Current available stock is ${currentQty} ${invItem.unitShortCode}, but requested to issue ${qty} ${invItem.unitShortCode}.`
          );
        }
      }

      // Step 2: Atomic Execution across lines using authoritative Part 14B Stock Engine
      const issueNumber = generateNextStockIssueNumber(schoolId);
      const now = new Date().toISOString();
      const issueDate = payload.issueDate || now;
      const issueItems: StockIssueItem[] = [];

      for (const itemPayload of payload.items) {
        const qty = itemPayload.quantity ?? (itemPayload as any).issueQuantity;
        const invItem = database.inventoryItems.find((i) => i.id === itemPayload.itemId)!;

        // Authoritatively record stock out (handles mutex, balance deduction, movement, and transaction)
        const stockOutResult = await StockService.recordStockOut(
          schoolId,
          {
            itemId: invItem.id,
            locationId: location.id,
            quantity: qty,
            department: payload.departmentName || linkedRequest?.departmentName,
            recipient: payload.recipientName,
            purpose: payload.purpose || linkedRequest?.purpose,
            referenceNumber: issueNumber,
            date: issueDate,
            notes: `Issue ${issueNumber}: ${itemPayload.notes || payload.notes || ''}`
          },
          user
        );

        const unitCost = stockOutResult.balance.unitPrice || 0;
        const totalCost = unitCost * qty;

        const stockIssueItem: StockIssueItem = {
          id: `sii-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          issueId: '',
          itemId: invItem.id,
          itemName: invItem.name,
          itemCode: invItem.itemCode,
          unitId: invItem.unitId,
          unitShortCode: invItem.unitShortCode,
          quantityIssued: qty,
          returnedQuantity: 0,
          remainingQuantity: qty,
          unitCost,
          totalCost,
          stockTransactionId: stockOutResult.transaction.id,
          stockMovementId: stockOutResult.movement.id
        };

        issueItems.push(stockIssueItem);

        // Update linked request item if applicable
        if (linkedRequest) {
          const reqItem = linkedRequest.items.find((i) => i.itemId === itemPayload.itemId)!;
          reqItem.issuedQuantity += qty;
          reqItem.remainingQuantity = Math.max(0, reqItem.approvedQuantity - reqItem.issuedQuantity);
        }
      }

      const stockIssue: StockIssue = {
        id: `iss-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        schoolId,
        issueNumber,
        issueRequestId: linkedRequest?.id,
        issueRequestNumber: linkedRequest?.requestNumber,
        issueDate,
        status: 'ISSUED',
        locationId: location.id,
        locationName: location.name,
        departmentId: payload.departmentId || linkedRequest?.departmentId,
        departmentName: payload.departmentName || linkedRequest?.departmentName || 'General Administration',
        recipientType: payload.recipientType || linkedRequest?.destinationType || 'DEPARTMENT',
        recipientId: payload.recipientId || linkedRequest?.destinationId,
        recipientName: payload.recipientName || linkedRequest?.destinationName || 'Department Custodian',
        purpose: payload.purpose || linkedRequest?.purpose || 'Stock issue for institutional use',
        notes: payload.notes || linkedRequest?.notes,
        items: issueItems,
        issuedBy: user.id,
        issuedByName: user.name,
        receivedBy: payload.recipientId || linkedRequest?.requestedBy,
        receivedByName: payload.recipientName || linkedRequest?.requestedByName,
        createdAt: now,
        updatedAt: now
      };

      issueItems.forEach((i) => {
        i.issueId = stockIssue.id;
      });

      database.stockIssues.unshift(stockIssue);

      // Update linked request lifecycle status
      if (linkedRequest) {
        const allCompleted = linkedRequest.items.every(
          (i) => i.issuedQuantity >= i.approvedQuantity
        );
        linkedRequest.status = allCompleted ? 'COMPLETED' : 'PARTIALLY_ISSUED';
        linkedRequest.updatedAt = now;

        sendNotification(
          linkedRequest.requestedBy,
          linkedRequest.requestedByRole || 'TEACHER',
          `Items Issued: ${stockIssue.issueNumber}`,
          `Stock issue ${stockIssue.issueNumber} dispatched from ${location.name}. Status: ${linkedRequest.status}.`,
          '/admin/inventory',
          'STOCK_ISSUED'
        );
      }

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockIssue',
        entityId: stockIssue.id,
        details: `Executed stock issue ${stockIssue.issueNumber} with ${issueItems.length} line items to ${stockIssue.recipientName}.`
      });

      return { stockIssue, issueRequest: linkedRequest };
    });
  }

  /**
   * Get Stock Issues with filtering & pagination
   */
  static getStockIssues(
    schoolId: string,
    filters?: {
      search?: string;
      status?: string;
      departmentId?: string;
      locationId?: string;
      recipientId?: string;
      page?: number;
      limit?: number;
    }
  ): { data: StockIssue[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureIssueAllocationCollections();

    let list = database.stockIssues.filter((i) => i.schoolId === schoolId);

    if (filters) {
      if (filters.status && filters.status !== 'ALL') {
        list = list.filter((i) => i.status === filters.status);
      }
      if (filters.departmentId && filters.departmentId !== 'ALL') {
        list = list.filter((i) => i.departmentId === filters.departmentId);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        list = list.filter((i) => i.locationId === filters.locationId);
      }
      if (filters.recipientId) {
        list = list.filter((i) => i.recipientId === filters.recipientId);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.trim().toLowerCase();
        list = list.filter(
          (i) =>
            i.issueNumber.toLowerCase().includes(q) ||
            i.recipientName.toLowerCase().includes(q) ||
            i.departmentName.toLowerCase().includes(q) ||
            (i.issueRequestNumber && i.issueRequestNumber.toLowerCase().includes(q)) ||
            i.items.some((item) => item.itemName.toLowerCase().includes(q) || item.itemCode.toLowerCase().includes(q))
        );
      }
    }

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, filters?.limit || 20);
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const paginated = list.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, pages }
    };
  }

  /**
   * Get single Stock Issue by ID
   */
  static getStockIssueById(schoolId: string, id: string): StockIssue {
    ensureIssueAllocationCollections();
    const issue = database.stockIssues.find(
      (i) => i.schoolId === schoolId && (i.id === id || i.issueNumber === id)
    );
    if (!issue) {
      throw new Error(`Stock issue not found with ID '${id}'.`);
    }
    return issue;
  }

  // ==========================================================================
  // 3. INVENTORY RETURN WORKFLOW
  // ==========================================================================

  /**
   * Process Inventory Return
   *
   * Validates against eligible issued quantity.
   * If condition === 'GOOD', restores usable inventory via Part 14B Stock Return.
   * If condition === 'DAMAGED' or 'UNUSABLE', records quarantine / damaged return explicitly without inflating usable stock.
   */
  static async recordInventoryReturn(
    schoolId: string,
    payload: RecordInventoryReturnPayload,
    userArg: any
  ): Promise<{ inventoryReturn: InventoryReturn; stockIssue: StockIssue }> {
    ensureIssueAllocationCollections();
    const user = normalizeUser(userArg);

    if (!payload.items || payload.items.length === 0) {
      throw new Error('Return payload must contain at least one item.');
    }

    const issueId = payload.issueId || (payload as any).originalIssueId;
    const stockIssue = database.stockIssues.find(
      (i) => i.schoolId === schoolId && (i.id === issueId || i.issueNumber === issueId)
    );
    if (!stockIssue) {
      throw new Error(`Original stock issue '${issueId}' not found.`);
    }

    const returnLocation = database.inventoryLocations.find(
      (l) => l.schoolId === schoolId && (l.id === payload.returnLocationId || l.code === payload.returnLocationId)
    );
    if (!returnLocation) {
      throw new Error('Receiving return location not found.');
    }

    const lockKey = `inventory-return:${schoolId}:${stockIssue.id}`;

    return withIssueLock(lockKey, async () => {
      // Step 1: Pre-validate all returned items against remaining issued balances
      for (const retItemPayload of payload.items) {
        const retQty = retItemPayload.quantity ?? (retItemPayload as any).returnedQuantity;
        if (typeof retQty !== 'number' || retQty <= 0) {
          throw new Error('Return quantity must be greater than zero.');
        }

        const issueItem = stockIssue.items.find(
          (i) => i.id === retItemPayload.issueItemId || i.itemId === (retItemPayload as any).itemId
        );
        if (!issueItem) {
          throw new Error(`Issue line item '${retItemPayload.issueItemId || (retItemPayload as any).itemId}' not found in issue ${stockIssue.issueNumber}.`);
        }

        const maxEligible = issueItem.quantityIssued - issueItem.returnedQuantity;
        if (retQty > maxEligible) {
          throw new Error(
            `Cannot return ${retQty} ${issueItem.unitShortCode} of '${issueItem.itemName}'. Maximum eligible remaining quantity for return is ${maxEligible} ${issueItem.unitShortCode}.`
          );
        }
      }

      // Step 2: Atomic Return Execution
      const returnNumber = generateNextReturnNumber(schoolId);
      const now = new Date().toISOString();
      const returnDate = payload.returnDate || now;
      const returnItems: InventoryReturnItem[] = [];

      for (const retItemPayload of payload.items) {
        const retQty = retItemPayload.quantity ?? (retItemPayload as any).returnedQuantity;
        const condition = retItemPayload.condition || (retItemPayload as any).itemCondition || 'GOOD';
        const issueItem = stockIssue.items.find(
          (i) => i.id === retItemPayload.issueItemId || i.itemId === (retItemPayload as any).itemId
        )!;
        const isGood = condition === 'GOOD';

        if (isGood) {
          // Atomically restore usable stock using authoritative Part 14B Stock Engine
          await StockService.recordStockReturn(
            schoolId,
            {
              itemId: issueItem.itemId,
              locationId: returnLocation.id,
              quantity: retQty,
              returnedBy: payload.returnedByName || payload.returnedBy,
              department: stockIssue.departmentName,
              reason: payload.reason,
              referenceNumber: returnNumber,
              date: returnDate,
              notes: `Return ${returnNumber} against ${stockIssue.issueNumber}: ${retItemPayload.notes || ''}`
            },
            user
          );
        }

        // Deduct remaining and increment returned on issue item
        issueItem.returnedQuantity += retQty;
        issueItem.remainingQuantity = issueItem.quantityIssued - issueItem.returnedQuantity;

        const returnItem: InventoryReturnItem = {
          id: `iri-ret-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          returnId: '',
          issueItemId: issueItem.id,
          itemId: issueItem.itemId,
          itemName: issueItem.itemName,
          itemCode: issueItem.itemCode,
          unitShortCode: issueItem.unitShortCode,
          quantityReturned: retQty,
          returnedQuantity: retQty,
          condition,
          restockedToInventory: isGood,
          restocked: isGood,
          notes: retItemPayload.notes
        };

        returnItems.push(returnItem);
      }

      const inventoryReturn: InventoryReturn = {
        id: `ret-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        schoolId,
        returnNumber,
        issueId: stockIssue.id,
        issueNumber: stockIssue.issueNumber,
        returnDate,
        locationId: returnLocation.id,
        locationName: returnLocation.name,
        departmentName: stockIssue.departmentName,
        returnedBy: payload.returnedBy,
        returnedByName: payload.returnedByName || stockIssue.recipientName,
        receivedBy: user.id,
        receivedByName: user.name,
        reason: payload.reason?.trim() || 'Inventory returned from department or staff',
        notes: payload.notes?.trim(),
        items: returnItems,
        createdAt: now
      };

      returnItems.forEach((r) => {
        r.returnId = inventoryReturn.id;
      });

      database.inventoryReturns.unshift(inventoryReturn);

      // Check whether all items in stock issue are fully returned
      const allFullyReturned = stockIssue.items.every((i) => i.remainingQuantity === 0);
      stockIssue.status = allFullyReturned ? 'FULLY_RETURNED' : 'PARTIALLY_RETURNED';
      stockIssue.updatedAt = now;

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'InventoryReturn',
        entityId: inventoryReturn.id,
        details: `Processed inventory return ${inventoryReturn.returnNumber} (${returnItems.length} items) for issue ${stockIssue.issueNumber}.`
      });

      return { inventoryReturn, stockIssue };
    });
  }

  /**
   * Process Inventory Return alias
   */
  static async processInventoryReturn(
    schoolId: string,
    payload: any,
    userArg: any
  ): Promise<InventoryReturn> {
    const res = await this.recordInventoryReturn(schoolId, payload, userArg);
    return res.inventoryReturn;
  }

  /**
   * Get Inventory Returns with filtering
   */
  static getInventoryReturns(
    schoolId: string,
    filters?: {
      search?: string;
      issueId?: string;
      locationId?: string;
      page?: number;
      limit?: number;
    }
  ): { data: InventoryReturn[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureIssueAllocationCollections();

    let list = database.inventoryReturns.filter((r) => r.schoolId === schoolId);

    if (filters) {
      if (filters.issueId) {
        list = list.filter((r) => r.issueId === filters.issueId);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        list = list.filter((r) => r.locationId === filters.locationId);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.trim().toLowerCase();
        list = list.filter(
          (r) =>
            r.returnNumber.toLowerCase().includes(q) ||
            r.issueNumber.toLowerCase().includes(q) ||
            r.returnedByName.toLowerCase().includes(q) ||
            r.departmentName.toLowerCase().includes(q) ||
            r.reason.toLowerCase().includes(q) ||
            r.items.some((item) => item.itemName.toLowerCase().includes(q) || item.itemCode.toLowerCase().includes(q))
        );
      }
    }

    const page = Math.max(1, filters?.page || 1);
    const limit = Math.max(1, filters?.limit || 20);
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const paginated = list.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, pages }
    };
  }

  // ==========================================================================
  // 4. ASSET ALLOCATION, HANDOVER & BULK ALLOCATION
  // ==========================================================================

  /**
   * Bulk Allocate multiple physical assets
   * Ensures each physical asset retains its individual traceability and serial assignment record.
   */
  static async bulkAllocateAssets(
    schoolId: string,
    payload: BulkAssetAllocationPayload,
    userArg: any
  ): Promise<{ successfulCount: number; results: Array<{ assetId: string; assetTag: string; success: boolean; error?: string }> }> {
    ensureIssueAllocationCollections();
    const user = normalizeUser(userArg);

    if (!payload.assetIds || payload.assetIds.length === 0) {
      throw new Error('Please select at least one asset to allocate.');
    }

    const results: Array<{ assetId: string; assetTag: string; success: boolean; error?: string }> = [];
    let successfulCount = 0;

    for (const assetId of payload.assetIds) {
      const asset = database.assets.find((a) => a.schoolId === schoolId && a.id === assetId);
      if (!asset) {
        results.push({ assetId, assetTag: 'UNKNOWN', success: false, error: 'Asset not found' });
        continue;
      }

      try {
        await AssetService.assignAsset(
          schoolId,
          asset.id,
          {
            assigneeType: payload.assigneeType,
            assigneeId: payload.assigneeId,
            assigneeName: payload.assigneeName,
            department: payload.department || asset.department,
            locationId: payload.locationId || asset.locationId,
            locationName: payload.locationName || asset.locationName,
            assignedDate: payload.assignedDate,
            expectedReturnDate: payload.expectedReturnDate,
            conditionAtHandover: payload.conditionAtHandover || asset.condition || 'GOOD',
            accessories: (payload.accessories || []).map((acc) =>
              typeof acc === 'string'
                ? acc
                : acc.serialNumber
                ? `${acc.name} (S/N: ${acc.serialNumber}) [${acc.status}]`
                : `${acc.name} [${acc.status}]`
            )
          },
          user
        );

        results.push({ assetId: asset.id, assetTag: asset.assetTag, success: true });
        successfulCount++;
      } catch (err: any) {
        results.push({
          assetId: asset.id,
          assetTag: asset.assetTag,
          success: false,
          error: err.message || 'Allocation failed'
        });
      }
    }

    sendNotification(
      payload.assigneeId,
      payload.assigneeType === 'TEACHER' ? 'TEACHER' : 'SUPER_ADMIN',
      `Assets Allocated: ${successfulCount} Items`,
      `${successfulCount} institutional assets have been allocated to ${payload.assigneeName}.`,
      '/admin/inventory',
      'ASSET_ASSIGNED'
    );

    return { successfulCount, results };
  }

  // ==========================================================================
  // 5. DEPARTMENT ALLOCATION & WORKFLOW
  // ==========================================================================

  /**
   * Get Department-level Asset & Inventory breakdown
   */
  static getDepartmentAllocations(
    schoolId: string,
    departmentId?: string
  ): DepartmentAllocationSummary[] {
    ensureIssueAllocationCollections();

    let depts = database.departments;
    if (departmentId && departmentId !== 'ALL') {
      depts = depts.filter((d) => d.id === departmentId);
    }

    const summaries: DepartmentAllocationSummary[] = depts.map((dept) => {
      const deptNameNorm = dept.name.toLowerCase();
      const deptTokens = deptNameNorm.replace(/department of|department|dept|of|&/g, ' ').split(/\s+/).filter((t) => t.length > 2);

      // Find all assets assigned to or owned by this department
      const deptAssets = database.assets.filter((a) => {
        if (a.schoolId !== schoolId) return false;
        const aDept = a.department?.toLowerCase();
        if (aDept === deptNameNorm) return true;
        if (
          a.currentAssigneeType === 'DEPARTMENT' &&
          (a.currentAssigneeId === dept.id || a.currentAssigneeName?.toLowerCase() === deptNameNorm)
        )
          return true;
        if (aDept && deptTokens.some((tok) => aDept.includes(tok))) return true;
        return false;
      });

      const activeAssets = deptAssets.filter((a) => a.status === 'ASSIGNED' || a.status === 'ACTIVE');
      const totalValuation = deptAssets.reduce((sum, a) => sum + (Number(a.purchaseCost) || 0), 0);

      // Find all stock issues dispatched to this department
      const deptIssues = database.stockIssues.filter((i) => {
        if (i.schoolId !== schoolId) return false;
        if (i.departmentId === dept.id) return true;
        const iDept = i.departmentName?.toLowerCase();
        if (iDept === deptNameNorm) return true;
        if (iDept && deptTokens.some((tok) => iDept.includes(tok))) return true;
        return false;
      });

      const totalItemsIssued = deptIssues.reduce(
        (sum, issue) => sum + issue.items.reduce((itemSum, item) => itemSum + item.quantityIssued, 0),
        0
      );

      const pendingReturnsCount = deptIssues.filter(
        (i) => i.status === 'ISSUED' || i.status === 'PARTIALLY_RETURNED'
      ).length;

      // Extract unique active custodians
      const custodiansMap = new Map<string, { id: string; name: string; role?: string; assignedAssetsCount: number }>();
      deptAssets.forEach((a) => {
        if (a.currentAssigneeId && a.currentAssigneeName && a.status === 'ASSIGNED') {
          const existing = custodiansMap.get(a.currentAssigneeId) || {
            id: a.currentAssigneeId,
            name: a.currentAssigneeName,
            role: a.currentAssigneeType,
            assignedAssetsCount: 0
          };
          existing.assignedAssetsCount++;
          custodiansMap.set(a.currentAssigneeId, existing);
        }
      });

      return {
        departmentId: dept.id,
        departmentName: dept.name,
        departmentCode: dept.code,
        location: dept.location,
        totalAssetsCount: deptAssets.length,
        activeAssetsCount: activeAssets.length,
        totalAssetValuation: Math.round(totalValuation * 100) / 100,
        totalAssetValue: Math.round(totalValuation * 100) / 100,
        activeCustodiansCount: custodiansMap.size,
        totalIssuesCount: deptIssues.length,
        totalItemsIssued,
        pendingReturnsCount,
        assets: deptAssets,
        issues: deptIssues,
        custodians: Array.from(custodiansMap.values())
      };
    });

    return summaries;
  }

  // ==========================================================================
  // 6. DASHBOARD METRICS
  // ==========================================================================

  /**
   * Get Issue, Return & Allocation Dashboard KPIs
   */
  static getDashboardKPIs(schoolId: string): IssueAllocationDashboardKPIs {
    ensureIssueAllocationCollections();

    const pendingIssueRequestsCount = database.issueRequests.filter(
      (r) => r.schoolId === schoolId && (r.status === 'SUBMITTED' || r.status === 'UNDER_REVIEW')
    ).length;

    const todayStr = new Date().toISOString().split('T')[0];
    const todayIssuesCount = database.stockIssues.filter(
      (i) => i.schoolId === schoolId && i.issueDate.startsWith(todayStr)
    ).length;

    const pendingReturnsCount = database.stockIssues.filter(
      (i) => i.schoolId === schoolId && (i.status === 'ISSUED' || i.status === 'PARTIALLY_RETURNED')
    ).length;

    const activeAssetAllocationsCount = database.assetAssignments.filter(
      (a) => a.schoolId === schoolId && a.status === 'ACTIVE'
    ).length;

    const totalDepartmentsTracked = database.departments.length;

    return {
      pendingIssueRequestsCount,
      todayIssuesCount,
      pendingReturnsCount,
      activeAssetAllocationsCount,
      totalDepartmentsTracked
    };
  }
}
