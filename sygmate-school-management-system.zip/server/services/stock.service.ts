/**
 * Inventory Stock Management Service (Part 14B)
 * Sygmate School Management System
 *
 * Implements authoritative stock logic, multi-location balances, atomic transfers,
 * immutable stock movements, concurrency control, low-stock notifications, and audit logging.
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import {
  ItemStockBalance,
  StockMovement,
  StockTransaction,
  StockSummary,
  StockStatus,
  StockAdjustmentReason,
  OpeningStockPayload,
  StockInPayload,
  StockOutPayload,
  StockTransferPayload,
  StockReturnPayload,
  StockAdjustmentPayload,
  StockBalanceFilterParams,
  StockMovementFilterParams,
  StockTransactionFilterParams,
  InventoryItem,
  InventoryLocation,
  PaginatedInventoryResponse
} from '../../src/types/index.js';

// ============================================================================
// CONCURRENCY LOCK MECHANISM
// ============================================================================

/**
 * Sequential lock queue per item+location to guarantee atomic transactions
 * and prevent race conditions when concurrent requests arrive.
 */
const lockQueues = new Map<string, Promise<any>>();

async function withStockLock<T>(lockKey: string, fn: () => Promise<T> | T): Promise<T> {
  const currentPromise = lockQueues.get(lockKey) || Promise.resolve();
  let releaseLock: () => void;
  const newPromise = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });

  lockQueues.set(lockKey, currentPromise.then(() => newPromise));

  try {
    await currentPromise;
    return await fn();
  } finally {
    releaseLock!();
    if (lockQueues.get(lockKey) === newPromise) {
      lockQueues.delete(lockKey);
    }
  }
}

// ============================================================================
// DEFENSIVE INITIALIZATION
// ============================================================================

export function ensureStockCollections(): void {
  if (!database.stockBalances) database.stockBalances = [];
  if (!database.stockMovements) database.stockMovements = [];
  if (!database.stockTransactions) database.stockTransactions = [];
  if (!database.inventoryItems) database.inventoryItems = [];
  if (!database.inventoryLocations) database.inventoryLocations = [];
  if (!database.notifications) database.notifications = [];
}

export function normalizeUser(
  userOrId: any,
  userNameArg?: string,
  roleArg?: string
): { id: string; name: string; role: string } {
  if (typeof userOrId === 'object' && userOrId !== null) {
    return {
      id: userOrId.id || 'system',
      name: userOrId.name || 'System User',
      role: userOrId.role || 'ADMIN'
    };
  }
  return {
    id: typeof userOrId === 'string' ? userOrId : 'system',
    name: userNameArg || 'System User',
    role: roleArg || 'ADMIN'
  };
}

// ============================================================================
// STATUS & ALERT HELPERS
// ============================================================================

export function calculateStockStatus(
  quantity: number,
  minStockLevel: number,
  reorderLevel: number
): StockStatus {
  if (quantity <= 0) return 'OUT_OF_STOCK';
  if (quantity <= minStockLevel) return 'LOW_STOCK';
  if (quantity <= reorderLevel) return 'REORDER_REQUIRED';
  return 'IN_STOCK';
}

function checkAndTriggerStockNotification(
  _schoolId: string,
  balance: ItemStockBalance,
  item: InventoryItem,
  location: InventoryLocation
): void {
  ensureStockCollections();
  if (balance.stockStatus !== 'LOW_STOCK' && balance.stockStatus !== 'OUT_OF_STOCK') {
    return;
  }

  const isOutOfStock = balance.stockStatus === 'OUT_OF_STOCK';
  const notifType = isOutOfStock ? 'INVENTORY_OUT_OF_STOCK' : 'INVENTORY_LOW_STOCK';

  // Check if unread notification already exists in last 24 hours to avoid spamming
  const existing = database.notifications.find(
    n => n.type === notifType &&
         n.metadata?.itemId === item.id &&
         n.metadata?.locationId === location.id &&
         !n.isRead
  );

  if (existing) return;

  const title = isOutOfStock
    ? `Out of Stock: ${item.name}`
    : `Low Stock Alert: ${item.name}`;

  const message = isOutOfStock
    ? `Item '${item.name}' (${item.itemCode}) has 0 units remaining at ${location.name}. Please replenish immediately.`
    : `Item '${item.name}' (${item.itemCode}) at ${location.name} is down to ${balance.quantity} ${balance.unitShortCode} (Minimum threshold: ${balance.minStockLevel}).`;

  database.notifications.unshift({
    id: `notif-stock-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userId: 'usr-admin-1', // Default system administrators
    roleTarget: 'SUPER_ADMIN',
    category: 'system',
    type: notifType,
    title,
    message,
    isRead: false,
    link: '/admin/inventory',
    createdAt: new Date().toISOString(),
    metadata: {
      itemId: item.id,
      itemCode: item.itemCode,
      locationId: location.id,
      quantity: balance.quantity,
      minStockLevel: balance.minStockLevel
    }
  });
}

// ============================================================================
// CONCURRENCY-SAFE TRANSACTION NUMBER GENERATORS
// ============================================================================

export function generateTransactionNumber(schoolId: string, prefix: string): string {
  ensureStockCollections();
  const year = new Date().getFullYear();
  const pattern = `STK-${prefix}-${year}-`;
  
  let maxSeq = 0;
  for (const tx of database.stockTransactions) {
    if (tx.schoolId === schoolId && tx.transactionNumber.startsWith(pattern)) {
      const parts = tx.transactionNumber.split('-');
      const seq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(seq) && seq > maxSeq) {
        maxSeq = seq;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return `${pattern}${String(nextSeq).padStart(4, '0')}`;
}

// ============================================================================
// STOCK MANAGEMENT SERVICE
// ============================================================================

export class StockService {
  /**
   * Validates that an item is stockable and active.
   * Throws Error if non-stockable (e.g. SERVICE).
   */
  static validateStockableItem(item: InventoryItem): void {
    if (item.status === 'INACTIVE' || item.status === 'DISCONTINUED') {
      throw new Error(`Item '${item.name}' (${item.itemCode}) is ${item.status} and cannot participate in stock operations.`);
    }

    if (item.itemType === 'SERVICE' || item.isStockable === false) {
      throw new Error(`Item '${item.name}' (${item.itemCode}) is configured as a non-stockable service item and cannot participate in stock operations.`);
    }
  }

  /**
   * Synchronizes global item stock cache across all locations
   */
  static syncItemGlobalStock(schoolId: string, itemId: string): number {
    ensureStockCollections();
    const balances = database.stockBalances.filter(b => b.schoolId === schoolId && b.itemId === itemId);
    const totalQty = balances.reduce((sum, b) => sum + (b.quantity || 0), 0);

    const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === itemId);
    if (item) {
      item.currentStock = totalQty;
      item.updatedAt = new Date().toISOString();
    }

    return totalQty;
  }

  /**
   * Retrieves or initializes an ItemStockBalance record
   */
  static getOrCreateBalance(
    schoolId: string,
    item: InventoryItem,
    location: InventoryLocation
  ): ItemStockBalance {
    ensureStockCollections();
    let balance = database.stockBalances.find(
      b => b.schoolId === schoolId && b.itemId === item.id && b.locationId === location.id
    );

    if (!balance) {
      balance = {
        id: `stk-${item.id}-${location.id}`,
        schoolId,
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        itemType: item.itemType,
        categoryId: item.categoryId,
        categoryName: item.categoryName,
        unitId: item.unitId,
        unitName: item.unitName,
        unitShortCode: item.unitShortCode,
        locationId: location.id,
        locationName: location.name,
        locationCode: location.code,
        quantity: 0,
        openingQuantity: 0,
        totalIn: 0,
        totalOut: 0,
        totalReturned: 0,
        totalAdjusted: 0,
        unitPrice: item.unitPrice || 0,
        minStockLevel: item.minStockLevel || 10,
        reorderLevel: item.reorderLevel || 20,
        maxStockLevel: item.maxStockLevel,
        stockStatus: 'OUT_OF_STOCK',
        lastUpdated: new Date().toISOString()
      };
      database.stockBalances.push(balance);
    }

    return balance;
  }

  /**
   * RECORD OPENING STOCK
   */
  static async recordOpeningStock(
    schoolId: string,
    payload: OpeningStockPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{ balance: ItemStockBalance; transaction: StockTransaction; movement: StockMovement }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);
    const lockKey = `${schoolId}:${payload.itemId}:${payload.locationId}`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const location = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.locationId);
      if (!location) throw new Error('Inventory location not found.');
      if (location.status === 'INACTIVE') throw new Error(`Location '${location.name}' is inactive.`);

      if (typeof payload.quantity !== 'number' || payload.quantity < 0) {
        throw new Error('Opening stock quantity must be a non-negative number.');
      }

      // Check if opening stock was already recorded for this item & location
      const existingTx = database.stockTransactions.find(
        t => t.schoolId === schoolId &&
             t.itemId === item.id &&
             t.locationId === location.id &&
             t.transactionType === 'OPENING_STOCK'
      );

      if (existingTx) {
        throw new Error(`Opening stock for item '${item.name}' at location '${location.name}' has already been recorded (${existingTx.transactionNumber}). Use Stock Adjustment or Stock In to modify quantity.`);
      }

      const balance = this.getOrCreateBalance(schoolId, item, location);
      const prevQty = balance.quantity;
      balance.openingQuantity = payload.quantity;
      balance.quantity = prevQty + payload.quantity;
      balance.stockStatus = calculateStockStatus(balance.quantity, balance.minStockLevel, balance.reorderLevel);
      balance.lastMovementDate = payload.openingDate || new Date().toISOString();
      balance.lastUpdated = new Date().toISOString();

      if (payload.unitCost !== undefined) {
        balance.unitPrice = payload.unitCost;
      }

      const txNumber = generateTransactionNumber(schoolId, 'OPN');
      const now = new Date().toISOString();

      const transaction: StockTransaction = {
        id: `tx-opn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'OPENING_STOCK',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantity: payload.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.openingDate || now,
        referenceNumber: payload.referenceNumber || 'OPENING-STOCK',
        notes: payload.notes || 'Opening stock initialization',
        unitCost: payload.unitCost || balance.unitPrice,
        totalCost: (payload.unitCost || balance.unitPrice || 0) * payload.quantity,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      const movement: StockMovement = {
        id: `mov-opn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'OPENING_STOCK',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantityIn: payload.quantity,
        quantityOut: 0,
        balanceAfter: balance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: transaction.referenceNumber,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: transaction.notes,
        unitCost: transaction.unitCost,
        totalCost: transaction.totalCost
      };
      database.stockMovements.unshift(movement);

      this.syncItemGlobalStock(schoolId, item.id);
      checkAndTriggerStockNotification(schoolId, balance, item, location);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockOpening',
        entityId: transaction.id,
        details: `Recorded opening stock of ${payload.quantity} ${item.unitShortCode} for '${item.name}' at ${location.name} (${txNumber})`
      });

      return { balance, transaction, movement };
    });
  }

  /**
   * RECORD STOCK IN
   */
  static async recordStockIn(
    schoolId: string,
    payload: StockInPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{ balance: ItemStockBalance; transaction: StockTransaction; movement: StockMovement }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);
    const lockKey = `${schoolId}:${payload.itemId}:${payload.locationId}`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const location = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.locationId);
      if (!location) throw new Error('Inventory location not found.');
      if (location.status === 'INACTIVE') throw new Error(`Location '${location.name}' is inactive.`);

      if (typeof payload.quantity !== 'number' || payload.quantity <= 0) {
        throw new Error('Stock in quantity must be greater than zero.');
      }

      let supplierName: string | undefined;
      if (payload.supplierId) {
        const supplier = database.suppliers.find(s => s.schoolId === schoolId && s.id === payload.supplierId);
        if (supplier) supplierName = supplier.name;
      }

      const balance = this.getOrCreateBalance(schoolId, item, location);
      balance.quantity += payload.quantity;
      balance.totalIn += payload.quantity;
      balance.stockStatus = calculateStockStatus(balance.quantity, balance.minStockLevel, balance.reorderLevel);
      balance.lastMovementDate = payload.date || new Date().toISOString();
      balance.lastUpdated = new Date().toISOString();

      if (payload.unitCost !== undefined) {
        balance.unitPrice = payload.unitCost;
      }

      const txNumber = generateTransactionNumber(schoolId, 'IN');
      const now = new Date().toISOString();
      const unitCost = payload.unitCost !== undefined ? payload.unitCost : balance.unitPrice;
      const totalCost = unitCost ? unitCost * payload.quantity : undefined;

      const transaction: StockTransaction = {
        id: `tx-in-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'STOCK_IN',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantity: payload.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.date || now,
        referenceNumber: payload.referenceNumber,
        supplierId: payload.supplierId,
        supplierName,
        unitCost,
        totalCost,
        notes: payload.notes,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      const movement: StockMovement = {
        id: `mov-in-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'STOCK_IN',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantityIn: payload.quantity,
        quantityOut: 0,
        balanceAfter: balance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        supplierId: payload.supplierId,
        supplierName,
        unitCost,
        totalCost,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: payload.notes
      };
      database.stockMovements.unshift(movement);

      this.syncItemGlobalStock(schoolId, item.id);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockIn',
        entityId: transaction.id,
        details: `Stock In: Received ${payload.quantity} ${item.unitShortCode} of '${item.name}' at ${location.name} (${txNumber})`
      });

      return { balance, transaction, movement };
    });
  }

  /**
   * RECORD STOCK OUT (Strict Negative Inventory Prevention)
   */
  static async recordStockOut(
    schoolId: string,
    payload: StockOutPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{ balance: ItemStockBalance; transaction: StockTransaction; movement: StockMovement }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);
    const lockKey = `${schoolId}:${payload.itemId}:${payload.locationId}`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const location = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.locationId);
      if (!location) throw new Error('Inventory location not found.');
      if (location.status === 'INACTIVE') throw new Error(`Location '${location.name}' is inactive.`);

      if (typeof payload.quantity !== 'number' || payload.quantity <= 0) {
        throw new Error('Stock out quantity must be greater than zero.');
      }

      const balance = this.getOrCreateBalance(schoolId, item, location);

      // Strict enforcement: Current Stock >= 0
      if (balance.quantity < payload.quantity) {
        throw new Error(
          `Insufficient stock at ${location.name}. Available balance is ${balance.quantity} ${item.unitShortCode}, but requested ${payload.quantity} ${item.unitShortCode}.`
        );
      }

      balance.quantity -= payload.quantity;
      balance.totalOut += payload.quantity;
      balance.stockStatus = calculateStockStatus(balance.quantity, balance.minStockLevel, balance.reorderLevel);
      balance.lastMovementDate = payload.date || new Date().toISOString();
      balance.lastUpdated = new Date().toISOString();

      const txNumber = generateTransactionNumber(schoolId, 'OUT');
      const now = new Date().toISOString();

      const transaction: StockTransaction = {
        id: `tx-out-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'STOCK_OUT',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantity: payload.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.date || now,
        referenceNumber: payload.referenceNumber,
        department: payload.department,
        recipient: payload.recipient,
        notes: payload.notes || payload.purpose,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      const movement: StockMovement = {
        id: `mov-out-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'STOCK_OUT',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantityIn: 0,
        quantityOut: payload.quantity,
        balanceAfter: balance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        department: payload.department,
        recipient: payload.recipient,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: transaction.notes
      };
      database.stockMovements.unshift(movement);

      this.syncItemGlobalStock(schoolId, item.id);
      checkAndTriggerStockNotification(schoolId, balance, item, location);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockOut',
        entityId: transaction.id,
        details: `Stock Out: Issued ${payload.quantity} ${item.unitShortCode} of '${item.name}' from ${location.name} to ${payload.recipient || payload.department || 'general usage'} (${txNumber})`
      });

      return { balance, transaction, movement };
    });
  }

  /**
   * RECORD STOCK TRANSFER (Atomic source deduction and destination addition)
   */
  static async recordStockTransfer(
    schoolId: string,
    payload: StockTransferPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{
    sourceBalance: ItemStockBalance;
    destBalance: ItemStockBalance;
    transaction: StockTransaction;
    sourceMovement: StockMovement;
    destMovement: StockMovement;
  }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);

    if (payload.sourceLocationId === payload.destinationLocationId) {
      throw new Error('Source location and destination location cannot be the same.');
    }

    if (typeof payload.quantity !== 'number' || payload.quantity <= 0) {
      throw new Error('Transfer quantity must be greater than zero.');
    }

    // Lock composite key of both locations in sorted order to avoid deadlocks
    const lockKey = `${schoolId}:${payload.itemId}:transfer`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const sourceLocation = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.sourceLocationId);
      if (!sourceLocation) throw new Error('Source inventory location not found.');
      if (sourceLocation.status === 'INACTIVE') throw new Error(`Source location '${sourceLocation.name}' is inactive.`);

      const destLocation = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.destinationLocationId);
      if (!destLocation) throw new Error('Destination inventory location not found.');
      if (destLocation.status === 'INACTIVE') throw new Error(`Destination location '${destLocation.name}' is inactive.`);

      const sourceBalance = this.getOrCreateBalance(schoolId, item, sourceLocation);
      if (sourceBalance.quantity < payload.quantity) {
        throw new Error(
          `Insufficient stock at source location '${sourceLocation.name}'. Available: ${sourceBalance.quantity} ${item.unitShortCode}, Requested transfer: ${payload.quantity} ${item.unitShortCode}.`
        );
      }

      const destBalance = this.getOrCreateBalance(schoolId, item, destLocation);

      // Perform atomic balance updates
      sourceBalance.quantity -= payload.quantity;
      sourceBalance.totalOut += payload.quantity;
      sourceBalance.stockStatus = calculateStockStatus(sourceBalance.quantity, sourceBalance.minStockLevel, sourceBalance.reorderLevel);
      sourceBalance.lastMovementDate = payload.transferDate || new Date().toISOString();
      sourceBalance.lastUpdated = new Date().toISOString();

      destBalance.quantity += payload.quantity;
      destBalance.totalIn += payload.quantity;
      destBalance.stockStatus = calculateStockStatus(destBalance.quantity, destBalance.minStockLevel, destBalance.reorderLevel);
      destBalance.lastMovementDate = payload.transferDate || new Date().toISOString();
      destBalance.lastUpdated = new Date().toISOString();

      const txNumber = generateTransactionNumber(schoolId, 'TRF');
      const now = new Date().toISOString();

      const transaction: StockTransaction = {
        id: `tx-trf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'TRANSFER',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: sourceLocation.id,
        locationName: sourceLocation.name,
        sourceLocationId: sourceLocation.id,
        sourceLocationName: sourceLocation.name,
        destinationLocationId: destLocation.id,
        destinationLocationName: destLocation.name,
        quantity: payload.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.transferDate || now,
        referenceNumber: payload.referenceNumber,
        notes: payload.notes || payload.reason,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      // 1. Source Movement (TRANSFER_OUT)
      const sourceMovement: StockMovement = {
        id: `mov-trf-out-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'TRANSFER_OUT',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: sourceLocation.id,
        locationName: sourceLocation.name,
        sourceLocationId: sourceLocation.id,
        sourceLocationName: sourceLocation.name,
        destinationLocationId: destLocation.id,
        destinationLocationName: destLocation.name,
        quantityIn: 0,
        quantityOut: payload.quantity,
        balanceAfter: sourceBalance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: `Transfer out to ${destLocation.name}: ${payload.reason || ''}`
      };
      database.stockMovements.unshift(sourceMovement);

      // 2. Destination Movement (TRANSFER_IN)
      const destMovement: StockMovement = {
        id: `mov-trf-in-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'TRANSFER_IN',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: destLocation.id,
        locationName: destLocation.name,
        sourceLocationId: sourceLocation.id,
        sourceLocationName: sourceLocation.name,
        destinationLocationId: destLocation.id,
        destinationLocationName: destLocation.name,
        quantityIn: payload.quantity,
        quantityOut: 0,
        balanceAfter: destBalance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: `Transfer in from ${sourceLocation.name}: ${payload.reason || ''}`
      };
      database.stockMovements.unshift(destMovement);

      this.syncItemGlobalStock(schoolId, item.id);
      checkAndTriggerStockNotification(schoolId, sourceBalance, item, sourceLocation);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockTransfer',
        entityId: transaction.id,
        details: `Transferred ${payload.quantity} ${item.unitShortCode} of '${item.name}' from ${sourceLocation.name} to ${destLocation.name} (${txNumber})`
      });

      return {
        sourceBalance,
        destBalance,
        transaction,
        sourceMovement,
        destMovement
      };
    });
  }

  /**
   * RECORD STOCK RETURN (Returned unused items from department or staff)
   */
  static async recordStockReturn(
    schoolId: string,
    payload: StockReturnPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{ balance: ItemStockBalance; transaction: StockTransaction; movement: StockMovement }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);
    const lockKey = `${schoolId}:${payload.itemId}:${payload.locationId}`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const location = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.locationId);
      if (!location) throw new Error('Inventory location not found.');
      if (location.status === 'INACTIVE') throw new Error(`Location '${location.name}' is inactive.`);

      if (typeof payload.quantity !== 'number' || payload.quantity <= 0) {
        throw new Error('Stock return quantity must be greater than zero.');
      }

      const balance = this.getOrCreateBalance(schoolId, item, location);
      balance.quantity += payload.quantity;
      balance.totalReturned += payload.quantity;
      balance.stockStatus = calculateStockStatus(balance.quantity, balance.minStockLevel, balance.reorderLevel);
      balance.lastMovementDate = payload.date || new Date().toISOString();
      balance.lastUpdated = new Date().toISOString();

      const txNumber = generateTransactionNumber(schoolId, 'RET');
      const now = new Date().toISOString();

      const transaction: StockTransaction = {
        id: `tx-ret-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'RETURN',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantity: payload.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.date || now,
        referenceNumber: payload.referenceNumber,
        returnedBy: payload.returnedBy,
        department: payload.department,
        notes: payload.notes || payload.reason,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      const movement: StockMovement = {
        id: `mov-ret-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType: 'RETURN',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantityIn: payload.quantity,
        quantityOut: 0,
        balanceAfter: balance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        department: payload.department,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: `Returned by ${payload.returnedBy || 'staff'}: ${payload.reason || ''}`
      };
      database.stockMovements.unshift(movement);

      this.syncItemGlobalStock(schoolId, item.id);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'CREATE',
        entity: 'OTHER',
        entityType: 'StockReturn',
        entityId: transaction.id,
        details: `Stock Return: Accepted return of ${payload.quantity} ${item.unitShortCode} of '${item.name}' at ${location.name} (${txNumber})`
      });

      return { balance, transaction, movement };
    });
  }

  /**
   * RECORD STOCK ADJUSTMENT (Physical count reconciliation / write-off)
   */
  static async recordStockAdjustment(
    schoolId: string,
    payload: StockAdjustmentPayload,
    userOrId: { id: string; name: string; role?: string } | string,
    userNameArg?: string,
    roleArg?: string
  ): Promise<{ balance: ItemStockBalance; transaction: StockTransaction; movement: StockMovement }> {
    ensureStockCollections();
    const user = normalizeUser(userOrId, userNameArg, roleArg);
    const lockKey = `${schoolId}:${payload.itemId}:${payload.locationId}`;

    return withStockLock(lockKey, async () => {
      const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === payload.itemId);
      if (!item) throw new Error('Inventory item not found.');

      this.validateStockableItem(item);

      const location = database.inventoryLocations.find(l => l.schoolId === schoolId && l.id === payload.locationId);
      if (!location) throw new Error('Inventory location not found.');
      if (location.status === 'INACTIVE') throw new Error(`Location '${location.name}' is inactive.`);

      const adjustedQty = typeof payload.adjustedQuantity === 'number'
        ? payload.adjustedQuantity
        : typeof payload.countedQuantity === 'number'
        ? payload.countedQuantity
        : -1;

      if (adjustedQty < 0) {
        throw new Error('Adjusted stock quantity cannot be negative.');
      }

      const reason = payload.reason || payload.adjustmentReason;
      const validReasons: StockAdjustmentReason[] = [
        'COUNT_DIFFERENCE',
        'DAMAGED',
        'LOST',
        'EXPIRED',
        'CORRECTION',
        'OTHER'
      ];
      if (!reason || !validReasons.includes(reason)) {
        throw new Error(`Invalid adjustment reason. Must be one of: ${validReasons.join(', ')}`);
      }

      const balance = this.getOrCreateBalance(schoolId, item, location);
      const previousQuantity = balance.quantity;
      const difference = adjustedQty - previousQuantity;

      if (difference === 0) {
        throw new Error('Adjusted quantity is identical to current stock balance. No adjustment required.');
      }

      balance.quantity = adjustedQty;
      balance.totalAdjusted += difference;
      balance.stockStatus = calculateStockStatus(balance.quantity, balance.minStockLevel, balance.reorderLevel);
      balance.lastMovementDate = payload.date || new Date().toISOString();
      balance.lastUpdated = new Date().toISOString();

      const txNumber = generateTransactionNumber(schoolId, 'ADJ');
      const now = new Date().toISOString();

      const transaction: StockTransaction = {
        id: `tx-adj-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionNumber: txNumber,
        transactionType: 'ADJUSTMENT',
        status: 'COMPLETED',
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantity: adjustedQty,
        previousQuantity,
        adjustedQuantity: adjustedQty,
        difference,
        adjustmentReason: reason,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        date: payload.date || now,
        referenceNumber: payload.referenceNumber,
        notes: payload.notes || `Stock adjusted due to ${reason}`,
        createdBy: user.id,
        createdByName: user.name,
        createdAt: now
      };
      database.stockTransactions.unshift(transaction);

      const movementType = difference > 0 ? 'ADJUSTMENT_INCREASE' : 'ADJUSTMENT_DECREASE';
      const movement: StockMovement = {
        id: `mov-adj-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        transactionId: transaction.id,
        transactionNumber: txNumber,
        movementType,
        itemId: item.id,
        itemName: item.name,
        itemCode: item.itemCode,
        locationId: location.id,
        locationName: location.name,
        quantityIn: difference > 0 ? difference : 0,
        quantityOut: difference < 0 ? Math.abs(difference) : 0,
        balanceAfter: balance.quantity,
        unitId: item.unitId,
        unitShortCode: item.unitShortCode,
        referenceNumber: payload.referenceNumber,
        adjustmentReason: reason,
        date: transaction.date,
        timestamp: now,
        userId: user.id,
        userName: user.name,
        notes: `Adjustment: ${previousQuantity} -> ${adjustedQty} (Diff: ${difference > 0 ? '+' : ''}${difference}) [${reason}]`
      };
      database.stockMovements.unshift(movement);

      this.syncItemGlobalStock(schoolId, item.id);
      checkAndTriggerStockNotification(schoolId, balance, item, location);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role as any,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'StockAdjustment',
        entityId: transaction.id,
        details: `Stock Adjustment on '${item.name}' at ${location.name}: ${previousQuantity} -> ${payload.adjustedQuantity} (${difference > 0 ? '+' : ''}${difference}) Reason: ${payload.reason} (${txNumber})`
      });

      return { balance, transaction, movement };
    });
  }

  /**
   * QUERY STOCK BALANCES (With filters, search, and pagination)
   */
  static getStockBalances(
    schoolId: string,
    params: StockBalanceFilterParams
  ): PaginatedInventoryResponse<ItemStockBalance> {
    ensureStockCollections();

    let list = database.stockBalances.filter(b => b.schoolId === schoolId);

    if (params.search && params.search.trim()) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(b =>
        b.itemName.toLowerCase().includes(q) ||
        b.itemCode.toLowerCase().includes(q) ||
        b.locationName.toLowerCase().includes(q) ||
        b.categoryName.toLowerCase().includes(q)
      );
    }

    if (params.categoryId && params.categoryId !== 'ALL') {
      list = list.filter(b => b.categoryId === params.categoryId);
    }

    if (params.locationId && params.locationId !== 'ALL') {
      list = list.filter(b => b.locationId === params.locationId);
    }

    if (params.stockStatus && params.stockStatus !== 'ALL') {
      list = list.filter(b => b.stockStatus === params.stockStatus);
    }

    if (params.itemType && params.itemType !== 'ALL') {
      list = list.filter(b => b.itemType === params.itemType);
    }

    // Sorting
    const sortBy = params.sortBy || 'itemName';
    const sortOrder = params.sortOrder === 'desc' ? -1 : 1;

    list.sort((a, b) => {
      if (sortBy === 'quantity') return (a.quantity - b.quantity) * sortOrder;
      if (sortBy === 'itemCode') return a.itemCode.localeCompare(b.itemCode) * sortOrder;
      if (sortBy === 'locationName') return a.locationName.localeCompare(b.locationName) * sortOrder;
      return a.itemName.localeCompare(b.itemName) * sortOrder;
    });

    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.max(1, Math.min(100, Number(params.limit) || 20));
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: {
        total,
        page,
        limit,
        pages
      }
    };
  }

  /**
   * GET OVERALL STOCK SUMMARY & KPIS
   */
  static getStockSummary(schoolId: string): StockSummary {
    ensureStockCollections();

    const stockableItems = database.inventoryItems.filter(
      i => i.schoolId === schoolId && i.itemType !== 'SERVICE' && i.isStockable !== false
    );
    const locations = database.inventoryLocations.filter(l => l.schoolId === schoolId);
    const balances = database.stockBalances.filter(b => b.schoolId === schoolId);

    let totalUnitsInStock = 0;
    let inStockCount = 0;
    let lowStockCount = 0;
    let reorderRequiredCount = 0;
    let outOfStockCount = 0;
    let totalStockValuation = 0;

    for (const b of balances) {
      totalUnitsInStock += (b.quantity || 0);
      totalStockValuation += (b.quantity || 0) * (b.unitPrice || 0);

      if (b.stockStatus === 'OUT_OF_STOCK') outOfStockCount++;
      else if (b.stockStatus === 'LOW_STOCK') lowStockCount++;
      else if (b.stockStatus === 'REORDER_REQUIRED') reorderRequiredCount++;
      else inStockCount++;
    }

    const locationBreakdown = locations.map(loc => {
      const locBalances = balances.filter(b => b.locationId === loc.id);
      const totalUnits = locBalances.reduce((sum, b) => sum + (b.quantity || 0), 0);
      const lowStockItems = locBalances.filter(b => b.stockStatus === 'LOW_STOCK' || b.stockStatus === 'REORDER_REQUIRED').length;
      const outOfStockItems = locBalances.filter(b => b.stockStatus === 'OUT_OF_STOCK').length;

      return {
        locationId: loc.id,
        locationName: loc.name,
        locationCode: loc.code,
        totalItems: locBalances.length,
        totalUnits,
        lowStockItems,
        outOfStockItems
      };
    });

    return {
      totalStockableItems: stockableItems.length,
      totalTrackedLocations: locations.length,
      totalUnitsInStock,
      inStockCount,
      lowStockCount,
      reorderRequiredCount,
      outOfStockCount,
      totalStockValuation,
      locationBreakdown
    };
  }

  /**
   * GET ITEM STOCK ACROSS ALL LOCATIONS
   */
  static getItemStockDetail(schoolId: string, itemId: string) {
    ensureStockCollections();

    const item = database.inventoryItems.find(i => i.schoolId === schoolId && i.id === itemId);
    if (!item) throw new Error('Inventory item not found.');

    const balances = database.stockBalances.filter(b => b.schoolId === schoolId && b.itemId === itemId);
    const movements = database.stockMovements
      .filter(m => m.schoolId === schoolId && m.itemId === itemId)
      .slice(0, 50);

    const totalQuantity = balances.reduce((sum, b) => sum + (b.quantity || 0), 0);

    return {
      item,
      totalQuantity,
      locationBalances: balances,
      recentMovements: movements
    };
  }

  /**
   * GET STOCK MOVEMENTS / AUDITABLE LEDGER
   */
  static getStockMovements(
    schoolId: string,
    params: StockMovementFilterParams
  ): PaginatedInventoryResponse<StockMovement> {
    ensureStockCollections();

    let list = database.stockMovements.filter(m => m.schoolId === schoolId);

    if (params.search && params.search.trim()) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(m =>
        m.itemName.toLowerCase().includes(q) ||
        m.itemCode.toLowerCase().includes(q) ||
        m.transactionNumber.toLowerCase().includes(q) ||
        (m.referenceNumber && m.referenceNumber.toLowerCase().includes(q)) ||
        m.locationName.toLowerCase().includes(q) ||
        m.userName.toLowerCase().includes(q)
      );
    }

    if (params.itemId && params.itemId !== 'ALL') {
      list = list.filter(m => m.itemId === params.itemId);
    }

    if (params.locationId && params.locationId !== 'ALL') {
      list = list.filter(m => m.locationId === params.locationId);
    }

    if (params.movementType && params.movementType !== 'ALL') {
      list = list.filter(m => m.movementType === params.movementType);
    }

    if (params.startDate) {
      list = list.filter(m => m.date >= params.startDate!);
    }

    if (params.endDate) {
      list = list.filter(m => m.date <= params.endDate!);
    }

    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.max(1, Math.min(100, Number(params.limit) || 20));
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: {
        total,
        page,
        limit,
        pages
      }
    };
  }

  /**
   * GET STOCK TRANSACTIONS
   */
  static getStockTransactions(
    schoolId: string,
    params: StockTransactionFilterParams
  ): PaginatedInventoryResponse<StockTransaction> {
    ensureStockCollections();

    let list = database.stockTransactions.filter(t => t.schoolId === schoolId);

    if (params.search && params.search.trim()) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(t =>
        t.transactionNumber.toLowerCase().includes(q) ||
        t.itemName.toLowerCase().includes(q) ||
        t.itemCode.toLowerCase().includes(q) ||
        (t.referenceNumber && t.referenceNumber.toLowerCase().includes(q)) ||
        t.locationName.toLowerCase().includes(q) ||
        t.createdByName.toLowerCase().includes(q)
      );
    }

    if (params.itemId && params.itemId !== 'ALL') {
      list = list.filter(t => t.itemId === params.itemId);
    }

    if (params.locationId && params.locationId !== 'ALL') {
      list = list.filter(t => t.locationId === params.locationId);
    }

    if (params.transactionType && params.transactionType !== 'ALL') {
      list = list.filter(t => t.transactionType === params.transactionType);
    }

    if (params.startDate) {
      list = list.filter(t => t.date >= params.startDate!);
    }

    if (params.endDate) {
      list = list.filter(t => t.date <= params.endDate!);
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.max(1, Math.min(100, Number(params.limit) || 20));
    const total = list.length;
    const pages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return {
      data,
      pagination: {
        total,
        page,
        limit,
        pages
      }
    };
  }

  /**
   * GET STOCK TRANSACTION BY ID (With audit traceability)
   */
  static getStockTransactionById(schoolId: string, id: string) {
    ensureStockCollections();

    const transaction = database.stockTransactions.find(t => t.schoolId === schoolId && t.id === id);
    if (!transaction) throw new Error('Stock transaction not found.');

    const movements = database.stockMovements.filter(
      m => m.schoolId === schoolId && m.transactionId === transaction.id
    );

    return {
      transaction,
      movements
    };
  }
}
