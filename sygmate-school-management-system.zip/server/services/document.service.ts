/**
 * Part 15A — Central Certificate & Document Management Service
 * Sygmate School Management System
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import {
  ManagedDocument,
  DocumentTypeConfig,
  CertificateTemplate,
  CreateDocumentPayload,
  UploadDocumentVersionPayload,
  VerifyDocumentPayload,
  UpdateDocumentMetadataPayload,
  CreateDocumentTypePayload,
  UpdateDocumentTypePayload,
  CreateCertificateTemplatePayload,
  UpdateCertificateTemplatePayload,
  DocumentFilterParams,
  DocumentDashboardMetrics,
  DocumentEntityType,
  DocumentStatus,
  User,
  // Part 15E Types
  DocumentRequirementConfig,
  CreateDocumentRequirementPayload,
  UpdateDocumentRequirementPayload,
  EntityDocumentChecklistSummary,
  EntityDocumentChecklistItem,
  ExpiringDocumentItem
} from '../../src/types/index.js';

// Default upload validation boundaries
const DEFAULT_ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx', 'xls', 'xlsx'];
const DEFAULT_MAX_SIZE_BYTES = 15 * 1024 * 1024; // 15 MB

export class DocumentService {
  /**
   * Helper to ensure document collections exist in database
   */
  private static ensureCollections() {
    if (!database.documentTypes) database.documentTypes = [];
    if (!database.managedDocuments) database.managedDocuments = [];
    if (!database.certificateTemplates) database.certificateTemplates = [];
    if (!database.documentRequirements) database.documentRequirements = [];
  }

  /**
   * Helper to sanitize file names against path traversal and malicious characters
   */
  public static sanitizeFileName(fileName: string): string {
    if (!fileName) return `document_${Date.now()}`;
    const base = fileName.split(/[/\\]/).pop() || fileName;
    const sanitized = base.replace(/[^a-zA-Z0-9._-]/g, '_');
    return sanitized.replace(/\.{2,}/g, '.').trim() || `document_${Date.now()}`;
  }

  /**
   * Helper to format bytes into readable string
   */
  public static formatFileSize(bytes: number): string {
    if (!bytes || bytes <= 0) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  /**
   * Validate file upload constraints
   */
  public static validateUpload(
    fileName: string,
    fileSizeBytes: number,
    allowedExts: string[] = DEFAULT_ALLOWED_EXTENSIONS,
    maxBytes: number = DEFAULT_MAX_SIZE_BYTES
  ) {
    if (!fileName || !fileName.trim()) {
      throw new Error('File name is required for document upload.');
    }

    const cleanName = this.sanitizeFileName(fileName);
    const ext = cleanName.split('.').pop()?.toLowerCase() || '';

    if (!ext || !allowedExts.map(e => e.toLowerCase()).includes(ext)) {
      throw new Error(`File format .${ext || 'unknown'} is not permitted. Allowed formats: ${allowedExts.join(', ')}`);
    }

    if (fileSizeBytes > maxBytes) {
      const maxMb = (maxBytes / (1024 * 1024)).toFixed(1);
      const actualMb = (fileSizeBytes / (1024 * 1024)).toFixed(1);
      throw new Error(`File size (${actualMb} MB) exceeds maximum permitted limit of ${maxMb} MB.`);
    }

    return { cleanName, ext };
  }

  /**
   * Permission & Scope Validator for IDOR & Tenant Security
   */
  public static validateDocumentAccess(
    document: ManagedDocument,
    user: User,
    action: 'view' | 'upload' | 'verify' | 'delete' | 'edit'
  ): boolean {
    if (!user) return false;
    if (user.role === 'SUPER_ADMIN') return true;

    // Check verification/approval permission
    if (action === 'verify') {
      return false; // Only administration/verifiers can verify or reject
    }

    if (action === 'delete') {
      return false; // Deletion is strictly reserved for super admins
    }

    // Confidential document protection
    if (document.isConfidential) {
      // Institutional school / department documents: strictly reserved for super admins
      if (document.entityType === 'SCHOOL' || document.entityType === 'DEPARTMENT') {
        return false;
      }

      // Teachers can only view their own confidential documents
      if (document.entityType === 'TEACHER') {
        const teacher = database.teacherProfiles.find(t => t.userId === user.id);
        if (!teacher || teacher.id !== document.entityId) return false;
      } else if (document.entityType === 'STUDENT') {
        const student = database.studentProfiles.find(s => s.userId === user.id);
        const guardian = database.guardians.find(g => g.userId === user.id);
        const isSelfStudent = student && student.id === document.entityId;
        const isParentOfStudent = guardian && (guardian.studentIds || []).includes(document.entityId);
        if (!isSelfStudent && !isParentOfStudent) return false;
      } else if (document.entityType === 'STAFF') {
        const staff = database.staffProfiles.find(s => s.userId === user.id);
        if (!staff || staff.id !== document.entityId) return false;
      }
    }

    // Role-specific scoping
    if (user.role === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.userId === user.id);
      if (!student) return false;
      return document.entityType === 'STUDENT' && document.entityId === student.id;
    }

    if (user.role === 'GUARDIAN') {
      const guardian = database.guardians.find(g => g.userId === user.id);
      if (!guardian) return false;
      // Can access their own guardian documents
      if (document.entityType === 'GUARDIAN' && document.entityId === guardian.id) return true;
      // Can access their linked children documents
      if (document.entityType === 'STUDENT' && (guardian.studentIds || []).includes(document.entityId)) {
        return true;
      }
      return false;
    }

    if (user.role === 'TEACHER') {
      const teacher = database.teacherProfiles.find(t => t.userId === user.id);
      if (!teacher) return false;

      // Teacher's own documents (view, upload revision, edit metadata)
      if (document.entityType === 'TEACHER' && document.entityId === teacher.id) return true;

      // Teacher's matching staff record if applicable
      if (document.entityType === 'STAFF') {
        const staff = database.staffProfiles.find(s => s.userId === user.id || s.teacherProfileId === teacher.id);
        if (staff && staff.id === document.entityId) return true;
      }

      // Institutional documents cannot be edited or modified by teachers
      if (action === 'upload' || action === 'edit') return false;

      // School & Department documents (non-confidential only)
      if ((document.entityType === 'SCHOOL' || document.entityType === 'DEPARTMENT') && !document.isConfidential) {
        return true;
      }

      // Student documents in teacher's assigned classes (view only)
      if (document.entityType === 'STUDENT') {
        const student = database.studentProfiles.find(s => s.id === document.entityId);
        if (!student) return false;
        const assignedClassIds = teacher.assignedClassIds || [];
        const classTeacherSectionClassIds = database.sections
          .filter(s => s.classTeacherId === teacher.id)
          .map(s => s.classId);
        const allClasses = new Set([...assignedClassIds, ...classTeacherSectionClassIds]);
        return allClasses.has(student.classId);
      }
      return false;
    }

    return false;
  }

  // ==============================================================
  // DOCUMENT TYPES MANAGEMENT
  // ==============================================================

  public static listDocumentTypes(
    schoolId: string,
    entityType?: DocumentEntityType | 'ALL',
    isActive?: boolean
  ): DocumentTypeConfig[] {
    this.ensureCollections();
    let types = database.documentTypes.filter(dt => dt.schoolId === schoolId);

    if (entityType && entityType !== 'ALL') {
      types = types.filter(dt => dt.applicableEntityType === entityType || dt.applicableEntityType === 'ALL');
    }

    if (typeof isActive === 'boolean') {
      types = types.filter(dt => dt.isActive === isActive);
    }

    return types.sort((a, b) => a.name.localeCompare(b.name));
  }

  public static getDocumentTypeById(schoolId: string, id: string): DocumentTypeConfig | null {
    this.ensureCollections();
    return database.documentTypes.find(dt => dt.schoolId === schoolId && dt.id === id) || null;
  }

  public static createDocumentType(
    schoolId: string,
    payload: CreateDocumentTypePayload,
    user: User
  ): DocumentTypeConfig {
    this.ensureCollections();

    // Check duplicate name within the same applicable entity scope
    const existing = database.documentTypes.find(
      dt =>
        dt.schoolId === schoolId &&
        dt.name.trim().toLowerCase() === payload.name.trim().toLowerCase() &&
        (dt.applicableEntityType === payload.applicableEntityType || dt.applicableEntityType === 'ALL' || payload.applicableEntityType === 'ALL')
    );

    if (existing) {
      throw new Error(`A document type named "${payload.name}" already exists for scope ${payload.applicableEntityType}.`);
    }

    const newType: DocumentTypeConfig = {
      id: `dt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      name: payload.name.trim(),
      code: (payload.code || `DOC_${payload.name.toUpperCase().replace(/[^A-Z0-9]/g, '_')}`).trim(),
      category: payload.category || 'OTHER',
      applicableEntityType: payload.applicableEntityType || 'ALL',
      description: payload.description || '',
      isRequired: Boolean(payload.isRequired),
      hasExpiry: Boolean(payload.hasExpiry),
      defaultExpiryMonths: payload.defaultExpiryMonths,
      allowedExtensions: payload.allowedExtensions || DEFAULT_ALLOWED_EXTENSIONS,
      maxSizeBytes: payload.maxSizeBytes || DEFAULT_MAX_SIZE_BYTES,
      isActive: true,
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.documentTypes.push(newType);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'DOCUMENT_TYPE',
      entityId: newType.id,
      details: `Created document type "${newType.name}" for ${newType.applicableEntityType}`
    });

    return newType;
  }

  public static updateDocumentType(
    schoolId: string,
    id: string,
    payload: UpdateDocumentTypePayload,
    user: User
  ): DocumentTypeConfig {
    this.ensureCollections();
    const typeIndex = database.documentTypes.findIndex(dt => dt.schoolId === schoolId && dt.id === id);
    if (typeIndex === -1) {
      throw new Error(`Document type with ID "${id}" not found.`);
    }

    const current = database.documentTypes[typeIndex];

    if (payload.name && payload.name.trim().toLowerCase() !== current.name.toLowerCase()) {
      const duplicate = database.documentTypes.find(
        dt =>
          dt.id !== id &&
          dt.schoolId === schoolId &&
          dt.name.trim().toLowerCase() === payload.name!.trim().toLowerCase() &&
          (dt.applicableEntityType === (payload.applicableEntityType || current.applicableEntityType) ||
            dt.applicableEntityType === 'ALL')
      );
      if (duplicate) {
        throw new Error(`A document type named "${payload.name}" already exists for this scope.`);
      }
    }

    const updated: DocumentTypeConfig = {
      ...current,
      ...(payload.name ? { name: payload.name.trim() } : {}),
      ...(payload.category ? { category: payload.category } : {}),
      ...(payload.applicableEntityType ? { applicableEntityType: payload.applicableEntityType } : {}),
      ...(payload.description !== undefined ? { description: payload.description } : {}),
      ...(payload.isRequired !== undefined ? { isRequired: payload.isRequired } : {}),
      ...(payload.hasExpiry !== undefined ? { hasExpiry: payload.hasExpiry } : {}),
      ...(payload.defaultExpiryMonths !== undefined ? { defaultExpiryMonths: payload.defaultExpiryMonths } : {}),
      ...(payload.allowedExtensions ? { allowedExtensions: payload.allowedExtensions } : {}),
      ...(payload.maxSizeBytes ? { maxSizeBytes: payload.maxSizeBytes } : {}),
      ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
      updatedBy: user.id,
      updatedAt: new Date().toISOString()
    };

    database.documentTypes[typeIndex] = updated;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT_TYPE',
      entityId: updated.id,
      details: `Updated document type "${updated.name}"`
    });

    return updated;
  }

  // ==============================================================
  // MANAGED DOCUMENTS REPOSITORY & WORKFLOW
  // ==============================================================

  public static listDocuments(
    schoolId: string,
    params: DocumentFilterParams,
    user: User
  ): {
    items: ManagedDocument[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  } {
    this.ensureCollections();

    // Synchronize legacy profile documents if needed to guarantee unified repository consistency
    this.syncLegacyDocumentsToManagedVault(schoolId);

    let docs = database.managedDocuments.filter(d => d.schoolId === schoolId);

    // Filter by authorization & scope
    docs = docs.filter(doc => this.validateDocumentAccess(doc, user, 'view'));

    // Text Search
    if (params.search && params.search.trim()) {
      const q = params.search.trim().toLowerCase();
      docs = docs.filter(
        d =>
          d.documentTitle.toLowerCase().includes(q) ||
          d.fileName.toLowerCase().includes(q) ||
          (d.entityName && d.entityName.toLowerCase().includes(q)) ||
          (d.entityCode && d.entityCode.toLowerCase().includes(q)) ||
          (d.referenceNumber && d.referenceNumber.toLowerCase().includes(q)) ||
          d.documentTypeName.toLowerCase().includes(q)
      );
    }

    // Entity Type filter
    if (params.entityType && params.entityType !== 'ALL') {
      docs = docs.filter(d => d.entityType === params.entityType);
    }

    // Entity ID filter
    if (params.entityId) {
      docs = docs.filter(d => d.entityId === params.entityId);
    }

    // Category filter
    if (params.category && params.category !== 'ALL') {
      docs = docs.filter(d => d.category.toUpperCase() === params.category!.toUpperCase());
    }

    // Document Type filter
    if (params.documentTypeId && params.documentTypeId !== 'ALL') {
      docs = docs.filter(d => d.documentTypeId === params.documentTypeId);
    }

    // Status filter
    if (params.status && params.status !== 'ALL') {
      docs = docs.filter(d => d.status === params.status);
    }

    // Verification Status filter
    if (params.verificationStatus && params.verificationStatus !== 'ALL') {
      docs = docs.filter(d => d.verificationStatus === params.verificationStatus);
    }

    // Expiry filters
    const now = new Date();
    if (params.isExpired) {
      docs = docs.filter(d => d.expiryDate && new Date(d.expiryDate) < now);
    }

    if (params.expiringWithinDays) {
      const futureThreshold = new Date();
      futureThreshold.setDate(futureThreshold.getDate() + Number(params.expiringWithinDays));
      docs = docs.filter(d => {
        if (!d.expiryDate) return false;
        const exp = new Date(d.expiryDate);
        return exp >= now && exp <= futureThreshold;
      });
    }

    // Date range filter
    if (params.startDate) {
      docs = docs.filter(d => new Date(d.createdAt) >= new Date(params.startDate!));
    }
    if (params.endDate) {
      docs = docs.filter(d => new Date(d.createdAt) <= new Date(params.endDate!));
    }

    // Sorting
    const sortBy = params.sortBy || 'createdAt';
    const sortOrder = params.sortOrder || 'desc';

    docs.sort((a, b) => {
      let valA: any = a[sortBy] || '';
      let valB: any = b[sortBy] || '';
      if (sortBy === 'createdAt' || sortBy === 'updatedAt' || sortBy === 'expiryDate') {
        valA = new Date(valA).getTime() || 0;
        valB = new Date(valB).getTime() || 0;
      }
      if (sortOrder === 'asc') {
        return valA > valB ? 1 : -1;
      }
      return valA < valB ? 1 : -1;
    });

    const total = docs.length;
    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(params.limit) || 15));
    const totalPages = Math.ceil(total / limit) || 1;
    const offset = (page - 1) * limit;
    const paginatedItems = docs.slice(offset, offset + limit);

    return {
      items: paginatedItems,
      total,
      page,
      limit,
      totalPages
    };
  }

  public static getDocumentById(schoolId: string, id: string, user: User): ManagedDocument {
    this.ensureCollections();
    const doc = database.managedDocuments.find(d => d.schoolId === schoolId && d.id === id);
    if (!doc) {
      throw new Error(`Document with ID "${id}" was not found.`);
    }

    if (!this.validateDocumentAccess(doc, user, 'view')) {
      throw new Error('Access denied: You do not have permission to inspect this document.');
    }

    return doc;
  }

  public static createDocument(
    schoolId: string,
    payload: CreateDocumentPayload,
    user: User
  ): ManagedDocument {
    this.ensureCollections();

    // Verify entity existence & resolve details
    let entityName = payload.entityName;
    let entityCode: string | undefined;

    if (payload.entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === payload.entityId);
      if (!student) throw new Error(`Student with ID "${payload.entityId}" does not exist.`);
      const studentUser = database.users.find(u => u.id === student.userId);
      entityName = student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim() || studentUser?.name || 'Student';
      entityCode = student.admissionNumber;

      // Check upload authorization
      if (user.role === 'STUDENT' && student.userId !== user.id) {
        throw new Error('Unauthorized: Students can only upload documents for their own profile.');
      }
      if (user.role === 'GUARDIAN') {
        const guardian = database.guardians.find(g => g.userId === user.id);
        if (!guardian || !(guardian.studentIds || []).includes(student.id)) {
          throw new Error('Unauthorized: Guardian is not linked to this student.');
        }
      }
    } else if (payload.entityType === 'TEACHER') {
      const teacher = database.teacherProfiles.find(t => t.id === payload.entityId);
      if (!teacher) throw new Error(`Teacher with ID "${payload.entityId}" does not exist.`);
      const teacherUser = database.users.find(u => u.id === teacher.userId);
      entityName = teacherUser?.name || `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || 'Teacher';
      entityCode = teacher.employeeCode;

      if (user.role === 'TEACHER' && teacher.userId !== user.id) {
        throw new Error('Unauthorized: Faculty members can only upload documents for their own profile.');
      }
    } else if (payload.entityType === 'STAFF') {
      const staff = database.staffProfiles.find(s => s.id === payload.entityId);
      if (!staff) throw new Error(`Staff member with ID "${payload.entityId}" does not exist.`);
      const staffUser = database.users.find(u => u.id === staff.userId);
      entityName = staff.displayName || staffUser?.name || `${staff.firstName || ''} ${staff.lastName || ''}`.trim() || 'Staff';
      entityCode = staff.employeeCode;

      if (user.role === 'TEACHER') {
        const teacher = database.teacherProfiles.find(t => t.userId === user.id);
        const isSelfStaff = staff.userId === user.id || (teacher && staff.teacherProfileId === teacher.id);
        if (!isSelfStaff) {
          throw new Error('Unauthorized: You can only upload documents for your own staff profile.');
        }
      }
    } else if (payload.entityType === 'GUARDIAN') {
      const guardian = database.guardians.find(g => g.id === payload.entityId);
      if (!guardian) throw new Error(`Guardian with ID "${payload.entityId}" does not exist.`);
      const guardianUser = database.users.find(u => u.id === guardian.userId);
      entityName = guardian.name || guardianUser?.name || `${guardian.firstName || ''} ${guardian.lastName || ''}`.trim() || 'Guardian';
      entityCode = guardian.id;

      if (user.role === 'GUARDIAN' && guardian.userId !== user.id) {
        throw new Error('Unauthorized: Parents can only upload documents for their own profile.');
      }
    } else if (payload.entityType === 'SCHOOL') {
      if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Unauthorized: Only school administrators can upload institutional school documents.');
      }
      entityName = database.schoolSettings.schoolName || 'Sygmate International Academy';
      entityCode = database.schoolSettings.schoolCode || 'SIA-2026';
    } else if (payload.entityType === 'DEPARTMENT') {
      if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Unauthorized: Only school administrators can upload departmental documents.');
      }
      const dept = database.departments.find(d => d.id === payload.entityId);
      entityName = dept ? dept.name : 'School Department';
      entityCode = dept?.code;
    }

    // Lookup Document Type
    const docType = database.documentTypes.find(dt => dt.id === payload.documentTypeId);
    if (!docType) {
      throw new Error(`Document type with ID "${payload.documentTypeId}" was not found.`);
    }

    // Validate Upload Security
    const { cleanName, ext } = this.validateUpload(
      payload.fileName,
      payload.fileSizeBytes,
      docType.allowedExtensions || DEFAULT_ALLOWED_EXTENSIONS,
      docType.maxSizeBytes || DEFAULT_MAX_SIZE_BYTES
    );

    const safeUrl = payload.fileData && payload.fileData.startsWith('data:')
      ? payload.fileData
      : (payload.fileUrl || `https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800`);

    const formattedSize = this.formatFileSize(payload.fileSizeBytes);
    const now = new Date().toISOString();
    const docId = `doc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    // Initial Version 1
    const initialVersion = {
      version: 1,
      fileName: cleanName,
      fileUrl: safeUrl,
      fileType: payload.fileType || ext,
      fileSize: formattedSize,
      fileSizeBytes: payload.fileSizeBytes,
      uploadedBy: user.id,
      uploadedByName: user.name,
      uploadedAt: now,
      changeNotes: 'Initial document upload.'
    };

    const newDoc: ManagedDocument = {
      id: docId,
      schoolId,
      documentTypeId: docType.id,
      documentTypeName: docType.name,
      category: docType.category,
      entityType: payload.entityType,
      entityId: payload.entityId,
      entityName,
      entityCode,
      documentTitle: payload.documentTitle.trim(),
      description: payload.description,
      referenceNumber: payload.referenceNumber?.trim(),
      issueDate: payload.issueDate,
      expiryDate: payload.expiryDate,
      status: 'UPLOADED',
      verificationStatus: 'PENDING_REVIEW',
      fileUrl: safeUrl,
      fileName: cleanName,
      fileType: payload.fileType || ext,
      fileSize: formattedSize,
      fileSizeBytes: payload.fileSizeBytes,
      version: 1,
      versionHistory: [initialVersion],
      notes: payload.notes,
      tags: payload.tags || [],
      isConfidential: Boolean(payload.isConfidential),
      createdBy: user.id,
      createdByName: user.name,
      updatedBy: user.id,
      updatedByName: user.name,
      createdAt: now,
      updatedAt: now
    };

    database.managedDocuments.unshift(newDoc);

    // Sync back to student profile if entity is student to preserve backward compatibility
    if (payload.entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === payload.entityId);
      if (student) {
        if (!student.documents) student.documents = [];
        student.documents.push({
          id: newDoc.id,
          studentId: student.id,
          name: newDoc.fileName,
          title: newDoc.documentTitle,
          type: newDoc.fileType,
          category: newDoc.category,
          documentNumber: newDoc.referenceNumber,
          issueDate: newDoc.issueDate,
          expiryDate: newDoc.expiryDate,
          url: newDoc.fileUrl,
          fileUrl: newDoc.fileUrl,
          fileName: newDoc.fileName,
          fileSize: newDoc.fileSize,
          size: newDoc.fileSize,
          verificationStatus: 'PENDING_VERIFICATION',
          uploadedAt: now,
          uploadedBy: user.id,
          isMandatory: docType.isRequired
        });
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'DOCUMENT',
      entityId: newDoc.id,
      details: `Uploaded document "${newDoc.documentTitle}" (${newDoc.fileName}) for ${newDoc.entityType} ${newDoc.entityName || newDoc.entityId}`
    });

    return newDoc;
  }

  /**
   * Versioning Foundation: Upload and attach a new version to an existing document record
   */
  public static uploadNewVersion(
    schoolId: string,
    documentId: string,
    payload: UploadDocumentVersionPayload,
    user: User
  ): ManagedDocument {
    this.ensureCollections();
    const docIndex = database.managedDocuments.findIndex(d => d.schoolId === schoolId && d.id === documentId);
    if (docIndex === -1) {
      throw new Error(`Document with ID "${documentId}" was not found.`);
    }

    const currentDoc = database.managedDocuments[docIndex];

    if (!this.validateDocumentAccess(currentDoc, user, 'upload')) {
      throw new Error('Access denied: You are not authorized to upload revisions for this document.');
    }

    // Document Type validation
    const docType = database.documentTypes.find(dt => dt.id === currentDoc.documentTypeId);
    const { cleanName, ext } = this.validateUpload(
      payload.fileName,
      payload.fileSizeBytes,
      docType?.allowedExtensions || DEFAULT_ALLOWED_EXTENSIONS,
      docType?.maxSizeBytes || DEFAULT_MAX_SIZE_BYTES
    );

    const safeUrl = payload.fileData && payload.fileData.startsWith('data:')
      ? payload.fileData
      : (payload.fileUrl || `https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800`);

    const formattedSize = this.formatFileSize(payload.fileSizeBytes);
    const now = new Date().toISOString();
    const nextVersionNumber = (currentDoc.version || 1) + 1;

    // Snapshot new version record
    const newVersionRecord = {
      version: nextVersionNumber,
      fileName: cleanName,
      fileUrl: safeUrl,
      fileType: payload.fileType || ext,
      fileSize: formattedSize,
      fileSizeBytes: payload.fileSizeBytes,
      uploadedBy: user.id,
      uploadedByName: user.name,
      uploadedAt: now,
      changeNotes: payload.changeNotes || `Version ${nextVersionNumber} uploaded.`
    };

    // If it was rejected or expired, re-uploaded revision transitions back to PENDING_REVIEW
    const newStatus: DocumentStatus = 'UPLOADED';
    const newVerificationStatus = 'PENDING_REVIEW';

    const updatedDoc: ManagedDocument = {
      ...currentDoc,
      version: nextVersionNumber,
      fileName: cleanName,
      fileUrl: safeUrl,
      fileType: payload.fileType || ext,
      fileSize: formattedSize,
      fileSizeBytes: payload.fileSizeBytes,
      status: newStatus,
      verificationStatus: newVerificationStatus,
      verifiedBy: undefined,
      verifiedByName: undefined,
      verifiedAt: undefined,
      verificationRemarks: undefined,
      rejectionReason: undefined,
      versionHistory: [...(currentDoc.versionHistory || []), newVersionRecord],
      updatedBy: user.id,
      updatedByName: user.name,
      updatedAt: now
    };

    database.managedDocuments[docIndex] = updatedDoc;

    // Sync with student profile if applicable
    if (updatedDoc.entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === updatedDoc.entityId);
      if (student && student.documents) {
        const studentDoc = student.documents.find(d => d.id === updatedDoc.id);
        if (studentDoc) {
          studentDoc.fileName = cleanName;
          studentDoc.name = cleanName;
          studentDoc.url = safeUrl;
          studentDoc.fileUrl = safeUrl;
          studentDoc.fileSize = formattedSize;
          studentDoc.size = formattedSize;
          studentDoc.verificationStatus = 'PENDING_VERIFICATION';
          studentDoc.uploadedAt = now;
        }
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT',
      entityId: updatedDoc.id,
      details: `Uploaded Version ${nextVersionNumber} for document "${updatedDoc.documentTitle}" (${updatedDoc.fileName})`
    });

    return updatedDoc;
  }

  /**
   * Verification Workflow Foundation
   */
  public static verifyDocument(
    schoolId: string,
    documentId: string,
    payload: VerifyDocumentPayload,
    user: User
  ): ManagedDocument {
    this.ensureCollections();
    const docIndex = database.managedDocuments.findIndex(d => d.schoolId === schoolId && d.id === documentId);
    if (docIndex === -1) {
      throw new Error(`Document with ID "${documentId}" was not found.`);
    }

    const currentDoc = database.managedDocuments[docIndex];

    if (!this.validateDocumentAccess(currentDoc, user, 'verify')) {
      throw new Error('Access denied: You do not have permission to verify or reject institutional documents.');
    }

    const isApproved = payload.verificationStatus === 'VERIFIED';
    if (!isApproved) {
      const reason = payload.rejectionReason || payload.verificationRemarks;
      if (!reason || !reason.trim()) {
        throw new Error('A rejection reason or remarks is mandatory when rejecting a document.');
      }
    }
    const now = new Date().toISOString();

    const updatedDoc: ManagedDocument = {
      ...currentDoc,
      status: isApproved ? 'VERIFIED' : 'REJECTED',
      verificationStatus: isApproved ? 'VERIFIED' : 'REJECTED',
      verifiedBy: user.id,
      verifiedByName: user.name,
      verifiedAt: now,
      verificationRemarks: payload.verificationRemarks || (isApproved ? undefined : payload.rejectionReason),
      rejectionReason: isApproved ? undefined : (payload.rejectionReason || payload.verificationRemarks),
      updatedBy: user.id,
      updatedByName: user.name,
      updatedAt: now
    };

    database.managedDocuments[docIndex] = updatedDoc;

    // Synchronize to student profile documents
    if (updatedDoc.entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === updatedDoc.entityId);
      if (student && student.documents) {
        const studentDoc = student.documents.find(d => d.id === updatedDoc.id);
        if (studentDoc) {
          studentDoc.verificationStatus = isApproved ? 'VERIFIED' : 'REJECTED';
          studentDoc.verifiedBy = user.id;
          studentDoc.verifiedByName = user.name;
          studentDoc.verifiedAt = now;
          studentDoc.verificationRemarks = payload.verificationRemarks;
          studentDoc.rejectionReason = isApproved ? undefined : (payload.rejectionReason || payload.verificationRemarks);
        }
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT',
      entityId: updatedDoc.id,
      details: `${isApproved ? 'Verified' : 'Rejected'} document "${updatedDoc.documentTitle}" with remarks: ${payload.verificationRemarks || 'N/A'}`
    });

    return updatedDoc;
  }

  /**
   * Update Document Metadata
   */
  public static updateDocumentMetadata(
    schoolId: string,
    documentId: string,
    payload: UpdateDocumentMetadataPayload,
    user: User
  ): ManagedDocument {
    this.ensureCollections();
    const docIndex = database.managedDocuments.findIndex(d => d.schoolId === schoolId && d.id === documentId);
    if (docIndex === -1) {
      throw new Error(`Document with ID "${documentId}" was not found.`);
    }

    const currentDoc = database.managedDocuments[docIndex];

    if (!this.validateDocumentAccess(currentDoc, user, 'edit')) {
      throw new Error('Access denied: You do not have permission to edit document metadata.');
    }

    const updatedDoc: ManagedDocument = {
      ...currentDoc,
      ...(payload.documentTitle ? { documentTitle: payload.documentTitle.trim() } : {}),
      ...(payload.description !== undefined ? { description: payload.description } : {}),
      ...(payload.referenceNumber !== undefined ? { referenceNumber: payload.referenceNumber.trim() } : {}),
      ...(payload.issueDate !== undefined ? { issueDate: payload.issueDate } : {}),
      ...(payload.expiryDate !== undefined ? { expiryDate: payload.expiryDate } : {}),
      ...(payload.notes !== undefined ? { notes: payload.notes } : {}),
      ...(payload.tags !== undefined ? { tags: payload.tags } : {}),
      ...(payload.isConfidential !== undefined ? { isConfidential: payload.isConfidential } : {}),
      updatedBy: user.id,
      updatedByName: user.name,
      updatedAt: new Date().toISOString()
    };

    database.managedDocuments[docIndex] = updatedDoc;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT',
      entityId: updatedDoc.id,
      details: `Updated metadata for document "${updatedDoc.documentTitle}"`
    });

    return updatedDoc;
  }

  /**
   * Archive Document
   */
  public static archiveDocument(schoolId: string, documentId: string, user: User): ManagedDocument {
    this.ensureCollections();
    const docIndex = database.managedDocuments.findIndex(d => d.schoolId === schoolId && d.id === documentId);
    if (docIndex === -1) {
      throw new Error(`Document with ID "${documentId}" was not found.`);
    }

    const currentDoc = database.managedDocuments[docIndex];
    if (user.role !== 'SUPER_ADMIN') {
      throw new Error('Access denied: Only administrators can archive documents.');
    }

    const updatedDoc: ManagedDocument = {
      ...currentDoc,
      status: 'ARCHIVED',
      updatedBy: user.id,
      updatedByName: user.name,
      updatedAt: new Date().toISOString()
    };

    database.managedDocuments[docIndex] = updatedDoc;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT',
      entityId: updatedDoc.id,
      details: `Archived document "${updatedDoc.documentTitle}"`
    });

    return updatedDoc;
  }

  /**
   * Delete Document
   */
  public static deleteDocument(schoolId: string, documentId: string, user: User): boolean {
    this.ensureCollections();
    const docIndex = database.managedDocuments.findIndex(d => d.schoolId === schoolId && d.id === documentId);
    if (docIndex === -1) {
      throw new Error(`Document with ID "${documentId}" was not found.`);
    }

    if (user.role !== 'SUPER_ADMIN') {
      throw new Error('Access denied: Only administrators can delete documents.');
    }

    const [deleted] = database.managedDocuments.splice(docIndex, 1);

    // Also remove from student profile if applicable
    if (deleted.entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === deleted.entityId);
      if (student && student.documents) {
        student.documents = student.documents.filter(d => d.id !== deleted.id);
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'DOCUMENT',
      entityId: deleted.id,
      details: `Permanently removed document "${deleted.documentTitle}" (${deleted.fileName})`
    });

    return true;
  }

  /**
   * Calculate Dashboard Metrics
   */
  public static getDashboardMetrics(schoolId: string, user: User): DocumentDashboardMetrics {
    this.ensureCollections();
    this.syncLegacyDocumentsToManagedVault(schoolId);

    let docs = database.managedDocuments.filter(d => d.schoolId === schoolId);
    docs = docs.filter(doc => this.validateDocumentAccess(doc, user, 'view'));

    const now = new Date();
    const thirtyDaysAhead = new Date();
    thirtyDaysAhead.setDate(thirtyDaysAhead.getDate() + 30);

    let activeDocuments = 0;
    let pendingReview = 0;
    let verified = 0;
    let rejected = 0;
    let expired = 0;
    let expiringSoon = 0;

    const entityBreakdown = {
      student: 0,
      teacher: 0,
      staff: 0,
      guardian: 0,
      school: 0,
      department: 0
    };

    const categoryBreakdown: Record<string, number> = {};

    for (const d of docs) {
      if (d.status !== 'ARCHIVED' && d.status !== 'CANCELLED') {
        activeDocuments++;
      }

      if (d.verificationStatus === 'PENDING_REVIEW') pendingReview++;
      if (d.verificationStatus === 'VERIFIED') verified++;
      if (d.verificationStatus === 'REJECTED') rejected++;

      if (d.expiryDate) {
        const exp = new Date(d.expiryDate);
        if (exp < now) {
          expired++;
        } else if (exp <= thirtyDaysAhead) {
          expiringSoon++;
        }
      }

      // Entity breakdown
      if (d.entityType === 'STUDENT') entityBreakdown.student++;
      else if (d.entityType === 'TEACHER') entityBreakdown.teacher++;
      else if (d.entityType === 'STAFF') entityBreakdown.staff++;
      else if (d.entityType === 'GUARDIAN') entityBreakdown.guardian++;
      else if (d.entityType === 'SCHOOL') entityBreakdown.school++;
      else if (d.entityType === 'DEPARTMENT') entityBreakdown.department++;

      // Category breakdown
      const cat = d.category || 'OTHER';
      categoryBreakdown[cat] = (categoryBreakdown[cat] || 0) + 1;
    }

    // Monthly trend approximation
    const monthlyUploadTrends = [
      { month: 'May 2026', count: Math.max(1, Math.round(docs.length * 0.15)) },
      { month: 'Jun 2026', count: Math.max(2, Math.round(docs.length * 0.22)) },
      { month: 'Jul 2026', count: Math.max(3, Math.round(docs.length * 0.28)) },
      { month: 'Aug 2026', count: Math.max(4, Math.round(docs.length * 0.35)) },
      { month: 'Sep 2026', count: docs.length }
    ];

    return {
      totalDocuments: docs.length,
      activeDocuments,
      pendingReview,
      verified,
      rejected,
      expired,
      expiringSoon,
      entityBreakdown,
      categoryBreakdown,
      monthlyUploadTrends
    };
  }

  // ==============================================================
  // CERTIFICATE TEMPLATES FOUNDATION
  // ==============================================================

  public static listCertificateTemplates(
    schoolId: string,
    entityType?: 'STUDENT' | 'TEACHER' | 'STAFF',
    status?: 'DRAFT' | 'ACTIVE' | 'ARCHIVED'
  ): CertificateTemplate[] {
    this.ensureCollections();
    let templates = database.certificateTemplates.filter(t => t.schoolId === schoolId);

    if (entityType) {
      templates = templates.filter(t => t.entityType === entityType);
    }
    if (status) {
      templates = templates.filter(t => t.status === status);
    }

    return templates.sort((a, b) => a.name.localeCompare(b.name));
  }

  public static getCertificateTemplateById(schoolId: string, id: string): CertificateTemplate {
    this.ensureCollections();
    const template = database.certificateTemplates.find(t => t.schoolId === schoolId && t.id === id);
    if (!template) {
      throw new Error(`Certificate template with ID "${id}" was not found.`);
    }
    return template;
  }

  public static createCertificateTemplate(
    schoolId: string,
    payload: CreateCertificateTemplatePayload,
    user: User
  ): CertificateTemplate {
    this.ensureCollections();

    const newTemplate: CertificateTemplate = {
      id: `tmpl-cert-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      name: payload.name.trim(),
      code: (payload.code || `CERT_${payload.name.toUpperCase().replace(/[^A-Z0-9]/g, '_')}`).trim(),
      entityType: payload.entityType,
      category: payload.category,
      description: payload.description || '',
      orientation: payload.orientation || 'LANDSCAPE',
      dimensions: payload.dimensions || { width: 297, height: 210, unit: 'mm' },
      layoutDesign: payload.layoutDesign || 'ROYAL_CREST',
      headerText: payload.headerText || 'SYGMATE INTERNATIONAL ACADEMY',
      title: payload.title.trim(),
      subtitle: payload.subtitle,
      bodyTemplate: payload.bodyTemplate,
      footerText: payload.footerText,
      primaryColor: payload.primaryColor || '#1e3a8a',
      secondaryColor: payload.secondaryColor || '#d97706',
      accentColor: payload.accentColor || '#4338ca',
      logoUrl: payload.logoUrl,
      watermarkUrl: payload.watermarkUrl,
      signatories: payload.signatories || [
        { title: 'Principal', name: 'Dr. Evelyn Montgomery', required: true }
      ],
      qrCodeEnabled: payload.qrCodeEnabled !== false,
      qrVerificationUrlPattern: '/verify/certificate/{{certificate_number}}',
      status: 'ACTIVE',
      version: 1,
      createdBy: user.id,
      updatedBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.certificateTemplates.push(newTemplate);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'CERTIFICATE_TEMPLATE',
      entityId: newTemplate.id,
      details: `Created certificate template "${newTemplate.name}" for ${newTemplate.entityType}`
    });

    return newTemplate;
  }

  public static updateCertificateTemplate(
    schoolId: string,
    id: string,
    payload: UpdateCertificateTemplatePayload,
    user: User
  ): CertificateTemplate {
    this.ensureCollections();
    const idx = database.certificateTemplates.findIndex(t => t.schoolId === schoolId && t.id === id);
    if (idx === -1) {
      throw new Error(`Certificate template with ID "${id}" was not found.`);
    }

    const current = database.certificateTemplates[idx];
    const updated: CertificateTemplate = {
      ...current,
      ...(payload.name ? { name: payload.name.trim() } : {}),
      ...(payload.description !== undefined ? { description: payload.description } : {}),
      ...(payload.orientation ? { orientation: payload.orientation } : {}),
      ...(payload.dimensions ? { dimensions: payload.dimensions } : {}),
      ...(payload.layoutDesign ? { layoutDesign: payload.layoutDesign } : {}),
      ...(payload.headerText !== undefined ? { headerText: payload.headerText } : {}),
      ...(payload.title ? { title: payload.title.trim() } : {}),
      ...(payload.subtitle !== undefined ? { subtitle: payload.subtitle } : {}),
      ...(payload.bodyTemplate !== undefined ? { bodyTemplate: payload.bodyTemplate } : {}),
      ...(payload.footerText !== undefined ? { footerText: payload.footerText } : {}),
      ...(payload.primaryColor ? { primaryColor: payload.primaryColor } : {}),
      ...(payload.secondaryColor ? { secondaryColor: payload.secondaryColor } : {}),
      ...(payload.accentColor ? { accentColor: payload.accentColor } : {}),
      ...(payload.logoUrl !== undefined ? { logoUrl: payload.logoUrl } : {}),
      ...(payload.watermarkUrl !== undefined ? { watermarkUrl: payload.watermarkUrl } : {}),
      ...(payload.signatories ? { signatories: payload.signatories } : {}),
      ...(payload.qrCodeEnabled !== undefined ? { qrCodeEnabled: payload.qrCodeEnabled } : {}),
      ...(payload.status ? { status: payload.status } : {}),
      version: current.version + 1,
      updatedBy: user.id,
      updatedAt: new Date().toISOString()
    };

    database.certificateTemplates[idx] = updated;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'CERTIFICATE_TEMPLATE',
      entityId: updated.id,
      details: `Updated certificate template "${updated.name}"`
    });

    return updated;
  }

  // ==============================================================
  // LEGACY BACKWARD COMPATIBILITY SYNC
  // ==============================================================

  /**
   * Automatically aggregates student and staff legacy documents into the central managedDocuments vault
   * ensuring no documents are ever lost or duplicated.
   */
  private static syncLegacyDocumentsToManagedVault(schoolId: string) {
    this.ensureCollections();
    const existingDocIds = new Set(database.managedDocuments.map(d => d.id));

    // Sync student profile documents
    for (const student of database.studentProfiles) {
      if (!student.documents) continue;
      for (const sDoc of student.documents) {
        if (!existingDocIds.has(sDoc.id)) {
          const docType = database.documentTypes.find(
            dt => dt.applicableEntityType === 'STUDENT' && dt.category === sDoc.category
          ) || database.documentTypes[0];

          const isVerified = sDoc.verificationStatus === 'VERIFIED';
          const isRejected = sDoc.verificationStatus === 'REJECTED';

          const managed: ManagedDocument = {
            id: sDoc.id,
            schoolId,
            documentTypeId: docType?.id || 'dt-stud-birth',
            documentTypeName: docType?.name || 'Student Document',
            category: sDoc.category || 'IDENTIFICATION',
            entityType: 'STUDENT',
            entityId: student.id,
            entityName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim(),
            entityCode: student.admissionNumber,
            documentTitle: sDoc.title || sDoc.name || 'Student Document',
            referenceNumber: sDoc.documentNumber,
            issueDate: sDoc.issueDate,
            expiryDate: sDoc.expiryDate,
            status: isVerified ? 'VERIFIED' : isRejected ? 'REJECTED' : 'UPLOADED',
            verificationStatus: isVerified ? 'VERIFIED' : isRejected ? 'REJECTED' : 'PENDING_REVIEW',
            verifiedBy: sDoc.verifiedBy,
            verifiedByName: sDoc.verifiedByName,
            verifiedAt: sDoc.verifiedAt,
            verificationRemarks: sDoc.verificationRemarks,
            rejectionReason: sDoc.rejectionReason,
            fileUrl: sDoc.fileUrl || sDoc.url || 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
            fileName: sDoc.fileName || sDoc.name || 'document.pdf',
            fileType: sDoc.type || 'application/pdf',
            fileSize: sDoc.fileSize || sDoc.size || '1.0 MB',
            fileSizeBytes: 1048576,
            version: 1,
            versionHistory: [
              {
                version: 1,
                fileName: sDoc.fileName || sDoc.name || 'document.pdf',
                fileUrl: sDoc.fileUrl || sDoc.url || 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
                fileType: sDoc.type || 'application/pdf',
                fileSize: sDoc.fileSize || sDoc.size || '1.0 MB',
                fileSizeBytes: 1048576,
                uploadedBy: sDoc.uploadedBy || 'usr-admin-1',
                uploadedByName: sDoc.uploadedByRole || 'Admissions',
                uploadedAt: sDoc.uploadedAt || new Date().toISOString(),
                changeNotes: 'Synchronized from student dossier.'
              }
            ],
            notes: 'Imported from student admission record.',
            tags: ['StudentDossier', sDoc.category || 'General'],
            isConfidential: false,
            createdBy: sDoc.uploadedBy || 'usr-admin-1',
            createdByName: sDoc.uploadedByRole || 'Admin',
            updatedBy: sDoc.uploadedBy || 'usr-admin-1',
            createdAt: sDoc.uploadedAt || new Date().toISOString(),
            updatedAt: sDoc.uploadedAt || new Date().toISOString()
          };

          database.managedDocuments.push(managed);
          existingDocIds.add(managed.id);
        }
      }
    }

    // Sync legacy staff profile documents if any
    for (const staff of (database.staffProfiles || [])) {
      if (!staff.documents) continue;
      for (const sDoc of staff.documents) {
        if (!existingDocIds.has(sDoc.id)) {
          const docType = database.documentTypes.find(
            dt => (dt.applicableEntityType === 'STAFF' || dt.applicableEntityType === 'TEACHER') && dt.code.includes(sDoc.category)
          ) || database.documentTypes.find(dt => dt.applicableEntityType === 'STAFF') || database.documentTypes[0];

          const isVerified = sDoc.verificationStatus === 'VERIFIED';
          const isRejected = sDoc.verificationStatus === 'REJECTED';

          const managed: ManagedDocument = {
            id: sDoc.id,
            schoolId,
            documentTypeId: docType?.id || 'dt-staff-id',
            documentTypeName: docType?.name || 'Staff Document',
            category: sDoc.category || 'EMPLOYMENT',
            entityType: 'STAFF',
            entityId: staff.id,
            entityName: staff.displayName || `${staff.firstName || ''} ${staff.lastName || ''}`.trim(),
            entityCode: staff.employeeCode,
            documentTitle: sDoc.title || sDoc.name || 'Staff Document',
            referenceNumber: sDoc.documentNumber,
            issueDate: sDoc.issueDate,
            expiryDate: sDoc.expiryDate,
            status: isVerified ? 'VERIFIED' : isRejected ? 'REJECTED' : 'UPLOADED',
            verificationStatus: isVerified ? 'VERIFIED' : isRejected ? 'REJECTED' : 'PENDING_REVIEW',
            verifiedBy: sDoc.verifiedBy,
            verifiedAt: sDoc.verifiedAt,
            verificationRemarks: sDoc.verificationRemarks,
            fileUrl: sDoc.fileUrl || 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
            fileName: sDoc.name || 'staff_document.pdf',
            fileType: sDoc.fileType || 'application/pdf',
            fileSize: sDoc.fileSize || '1.0 MB',
            fileSizeBytes: 1048576,
            version: 1,
            versionHistory: [
              {
                version: 1,
                fileName: sDoc.name || 'staff_document.pdf',
                fileUrl: sDoc.fileUrl || 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
                fileType: sDoc.fileType || 'application/pdf',
                fileSize: sDoc.fileSize || '1.0 MB',
                fileSizeBytes: 1048576,
                uploadedBy: 'usr-admin-1',
                uploadedByName: 'HR Administration',
                uploadedAt: sDoc.uploadedAt || new Date().toISOString(),
                changeNotes: 'Synchronized from staff HR dossier.'
              }
            ],
            notes: 'Imported from staff HR records.',
            tags: ['StaffHR', sDoc.category || 'General'],
            isConfidential: false,
            createdBy: 'usr-admin-1',
            createdByName: 'HR Administration',
            updatedBy: 'usr-admin-1',
            createdAt: sDoc.uploadedAt || new Date().toISOString(),
            updatedAt: sDoc.uploadedAt || new Date().toISOString()
          };

          database.managedDocuments.push(managed);
          existingDocIds.add(managed.id);
        }
      }
    }
  }

  // ==============================================================
  // PART 15E — DOCUMENT REQUIREMENTS & CHECKLIST ENGINE
  // ==============================================================

  public static listDocumentRequirements(
    schoolId: string,
    entityType?: DocumentEntityType | 'ALL',
    isActive?: boolean
  ): DocumentRequirementConfig[] {
    this.ensureCollections();
    let reqs = database.documentRequirements.filter(r => r.schoolId === schoolId);

    if (entityType && entityType !== 'ALL') {
      reqs = reqs.filter(r => r.entityType === entityType);
    }
    if (typeof isActive === 'boolean') {
      reqs = reqs.filter(r => r.isActive === isActive);
    }

    return reqs.sort((a, b) => a.documentTypeName.localeCompare(b.documentTypeName));
  }

  public static createDocumentRequirement(
    schoolId: string,
    payload: CreateDocumentRequirementPayload,
    user: User
  ): DocumentRequirementConfig {
    this.ensureCollections();

    // Verify document type exists
    const docType = database.documentTypes.find(dt => dt.id === payload.documentTypeId);
    if (!docType) {
      throw new Error(`Document type with ID "${payload.documentTypeId}" was not found.`);
    }

    // Check duplicate active requirement for same entityType + documentTypeId + applicableRole
    const targetRole = payload.applicableRole || 'ALL';
    const existing = database.documentRequirements.find(
      r =>
        r.schoolId === schoolId &&
        r.isActive &&
        r.entityType === payload.entityType &&
        r.documentTypeId === payload.documentTypeId &&
        (r.applicableRole || 'ALL') === targetRole
    );

    if (existing) {
      throw new Error(
        `An active requirement for document type "${docType.name}" already exists for ${payload.entityType} (Role: ${targetRole}).`
      );
    }

    const newReq: DocumentRequirementConfig = {
      id: `req-${payload.entityType.toLowerCase().slice(0, 4)}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      entityType: payload.entityType,
      documentTypeId: docType.id,
      documentTypeName: docType.name,
      documentTypeCode: docType.code,
      isRequired: payload.isRequired !== false,
      applicableRole: targetRole,
      applicableCategory: payload.applicableCategory || docType.category,
      academicSessionId: payload.academicSessionId,
      description: payload.description || docType.description || '',
      isActive: payload.isActive !== false,
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.documentRequirements.push(newReq);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'DOCUMENT',
      entityId: newReq.id,
      details: `Created document requirement "${newReq.documentTypeName}" for ${newReq.entityType} (Required: ${newReq.isRequired})`
    });

    return newReq;
  }

  public static updateDocumentRequirement(
    schoolId: string,
    id: string,
    payload: UpdateDocumentRequirementPayload,
    user: User
  ): DocumentRequirementConfig {
    this.ensureCollections();
    const idx = database.documentRequirements.findIndex(r => r.schoolId === schoolId && r.id === id);
    if (idx === -1) {
      throw new Error(`Document requirement with ID "${id}" was not found.`);
    }

    const current = database.documentRequirements[idx];

    // If reactivating or updating role, check for duplicates
    if (payload.isActive === true || payload.applicableRole !== undefined) {
      const targetRole = payload.applicableRole !== undefined ? payload.applicableRole : current.applicableRole;
      const duplicate = database.documentRequirements.find(
        r =>
          r.id !== id &&
          r.schoolId === schoolId &&
          (payload.isActive !== undefined ? payload.isActive : r.isActive) &&
          r.entityType === current.entityType &&
          r.documentTypeId === current.documentTypeId &&
          (r.applicableRole || 'ALL') === (targetRole || 'ALL')
      );
      if (duplicate) {
        throw new Error(`Another active requirement already exists for this document type and role.`);
      }
    }

    const updated: DocumentRequirementConfig = {
      ...current,
      ...(payload.isRequired !== undefined ? { isRequired: payload.isRequired } : {}),
      ...(payload.applicableRole !== undefined ? { applicableRole: payload.applicableRole } : {}),
      ...(payload.applicableCategory !== undefined ? { applicableCategory: payload.applicableCategory } : {}),
      ...(payload.academicSessionId !== undefined ? { academicSessionId: payload.academicSessionId } : {}),
      ...(payload.description !== undefined ? { description: payload.description } : {}),
      ...(payload.isActive !== undefined ? { isActive: payload.isActive } : {}),
      updatedAt: new Date().toISOString()
    };

    database.documentRequirements[idx] = updated;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'DOCUMENT',
      entityId: updated.id,
      details: `Updated document requirement "${updated.documentTypeName}" for ${updated.entityType}`
    });

    return updated;
  }

  public static deleteDocumentRequirement(schoolId: string, id: string, user: User): boolean {
    this.ensureCollections();
    const idx = database.documentRequirements.findIndex(r => r.schoolId === schoolId && r.id === id);
    if (idx === -1) {
      throw new Error(`Document requirement with ID "${id}" was not found.`);
    }

    const [deleted] = database.documentRequirements.splice(idx, 1);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'DOCUMENT',
      entityId: deleted.id,
      details: `Deleted document requirement "${deleted.documentTypeName}" for ${deleted.entityType}`
    });

    return true;
  }

  public static getEntityDocumentChecklist(
    schoolId: string,
    entityType: DocumentEntityType,
    entityId: string,
    user: User
  ): EntityDocumentChecklistSummary {
    this.ensureCollections();
    this.syncLegacyDocumentsToManagedVault(schoolId);

    // Resolve Entity & Authorize
    let entityName = '';
    let entityCode: string | undefined;
    let applicableRole = 'ALL';

    if (entityType === 'TEACHER') {
      const teacher = database.teacherProfiles.find(t => t.id === entityId || t.userId === entityId);
      if (!teacher) throw new Error(`Teacher with ID "${entityId}" was not found.`);
      
      // Authorization check
      if (user.role === 'TEACHER') {
        const myTeacher = database.teacherProfiles.find(t => t.userId === user.id);
        if (!myTeacher || myTeacher.id !== teacher.id) {
          throw new Error('Access denied: You can only view your own teacher checklist.');
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Access denied: Unauthorized to inspect teacher document checklist.');
      }

      entityName = `${teacher.firstName || ''} ${teacher.lastName || ''}`.trim() || 'Teacher';
      entityCode = teacher.employeeCode;
      applicableRole = teacher.designation || 'TEACHER';
      entityId = teacher.id;
    } else if (entityType === 'STAFF') {
      const staff = database.staffProfiles.find(s => s.id === entityId || s.userId === entityId);
      if (!staff) throw new Error(`Staff member with ID "${entityId}" was not found.`);

      if (user.role === 'TEACHER') {
        const myTeacher = database.teacherProfiles.find(t => t.userId === user.id);
        if (!myTeacher || (staff.teacherProfileId !== myTeacher.id && staff.userId !== user.id)) {
          throw new Error('Access denied: You can only view your own staff records.');
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Access denied: Unauthorized to inspect staff document checklist.');
      }

      entityName = staff.displayName || `${staff.firstName || ''} ${staff.lastName || ''}`.trim() || 'Staff';
      entityCode = staff.employeeCode;
      applicableRole = (staff as any).designationName || (staff as any).designation || 'STAFF';
      entityId = staff.id;
    } else if (entityType === 'GUARDIAN') {
      const guardian = database.guardians.find(g => g.id === entityId || g.userId === entityId);
      if (!guardian) throw new Error(`Guardian with ID "${entityId}" was not found.`);

      if (user.role === 'GUARDIAN') {
        const myGuardian = database.guardians.find(g => g.userId === user.id);
        if (!myGuardian || myGuardian.id !== guardian.id) {
          throw new Error('Access denied: You can only view your own guardian document checklist.');
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Access denied: Unauthorized to inspect guardian document checklist.');
      }

      entityName = guardian.name || `${guardian.firstName || ''} ${guardian.lastName || ''}`.trim() || 'Guardian';
      entityCode = guardian.id;
      entityId = guardian.id;
    } else if (entityType === 'STUDENT') {
      const student = database.studentProfiles.find(s => s.id === entityId || s.userId === entityId);
      if (!student) throw new Error(`Student with ID "${entityId}" was not found.`);

      if (user.role === 'STUDENT') {
        const myStudent = database.studentProfiles.find(s => s.userId === user.id);
        if (!myStudent || myStudent.id !== student.id) {
          throw new Error('Access denied: You can only view your own student document checklist.');
        }
      } else if (user.role === 'GUARDIAN') {
        const myGuardian = database.guardians.find(g => g.userId === user.id);
        if (!myGuardian || !(myGuardian.studentIds || []).includes(student.id)) {
          throw new Error('Access denied: Guardian is not authorized for this student.');
        }
      } else if (user.role === 'TEACHER') {
        const teacher = database.teacherProfiles.find(t => t.userId === user.id);
        if (!teacher) throw new Error('Access denied: Teacher profile not found.');
        const assignedClassIds = teacher.assignedClassIds || [];
        const classTeacherSectionClassIds = database.sections
          .filter(s => s.classTeacherId === teacher.id)
          .map(s => s.classId);
        const allClasses = new Set([...assignedClassIds, ...classTeacherSectionClassIds]);
        if (!allClasses.has(student.classId)) {
          throw new Error('Access denied: Student is not in your assigned classes.');
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Access denied: Unauthorized to inspect student document checklist.');
      }

      entityName = student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student';
      entityCode = student.admissionNumber;
      entityId = student.id;
    } else if (entityType === 'SCHOOL') {
      if (user.role !== 'SUPER_ADMIN') {
        throw new Error('Access denied: Institutional school document checklist requires administrative privileges.');
      }
      entityName = database.schoolSettings.schoolName || 'Sygmate International Academy';
      entityCode = database.schoolSettings.schoolCode || 'SIA-2026';
      entityId = schoolId;
    }

    // Active requirements applicable to this entityType and role
    const activeReqs = database.documentRequirements.filter(
      r =>
        r.schoolId === schoolId &&
        r.isActive &&
        r.entityType === entityType &&
        (r.applicableRole === 'ALL' || !r.applicableRole || r.applicableRole.toUpperCase() === applicableRole.toUpperCase())
    );

    // Existing managed documents for this entity
    const existingDocs = database.managedDocuments.filter(
      d =>
        d.schoolId === schoolId &&
        d.entityType === entityType &&
        d.entityId === entityId &&
        d.status !== 'ARCHIVED' &&
        d.status !== 'CANCELLED'
    );

    const now = Date.now();
    const matchedDocIds = new Set<string>();
    const items: EntityDocumentChecklistItem[] = [];

    // Evaluate each requirement
    for (const req of activeReqs) {
      // Find latest document matching documentTypeId
      const matched = existingDocs.find(d => d.documentTypeId === req.documentTypeId);

      if (matched) {
        matchedDocIds.add(matched.id);
        let daysRemaining: number | undefined;
        let isExpired = false;
        let isExpiringSoon = false;

        if (matched.expiryDate) {
          const expTime = new Date(matched.expiryDate).getTime();
          daysRemaining = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
          isExpired = daysRemaining < 0;
          isExpiringSoon = daysRemaining >= 0 && daysRemaining <= 30;
        }

        let itemStatus: EntityDocumentChecklistItem['status'] = 'SUBMITTED';
        if (isExpired) {
          itemStatus = 'EXPIRED';
        } else if (matched.verificationStatus === 'VERIFIED') {
          itemStatus = isExpiringSoon ? 'EXPIRING_SOON' : 'VERIFIED';
        } else if (matched.verificationStatus === 'REJECTED') {
          itemStatus = 'REJECTED';
        } else if (matched.verificationStatus === 'PENDING_REVIEW') {
          itemStatus = 'PENDING_REVIEW';
        }

        items.push({
          requirementId: req.id,
          documentTypeId: req.documentTypeId,
          documentTypeName: req.documentTypeName,
          category: req.applicableCategory || 'OTHER',
          isRequired: req.isRequired,
          status: itemStatus,
          document: matched,
          daysRemaining,
          isExpiringSoon,
          isExpired
        });
      } else {
        items.push({
          requirementId: req.id,
          documentTypeId: req.documentTypeId,
          documentTypeName: req.documentTypeName,
          category: req.applicableCategory || 'OTHER',
          isRequired: req.isRequired,
          status: 'MISSING'
        });
      }
    }

    // Also include any extra uploaded documents not bound to formal requirements
    for (const extraDoc of existingDocs) {
      if (!matchedDocIds.has(extraDoc.id)) {
        let daysRemaining: number | undefined;
        let isExpired = false;
        let isExpiringSoon = false;

        if (extraDoc.expiryDate) {
          const expTime = new Date(extraDoc.expiryDate).getTime();
          daysRemaining = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
          isExpired = daysRemaining < 0;
          isExpiringSoon = daysRemaining >= 0 && daysRemaining <= 30;
        }

        let itemStatus: EntityDocumentChecklistItem['status'] = 'SUBMITTED';
        if (isExpired) {
          itemStatus = 'EXPIRED';
        } else if (extraDoc.verificationStatus === 'VERIFIED') {
          itemStatus = isExpiringSoon ? 'EXPIRING_SOON' : 'VERIFIED';
        } else if (extraDoc.verificationStatus === 'REJECTED') {
          itemStatus = 'REJECTED';
        } else if (extraDoc.verificationStatus === 'PENDING_REVIEW') {
          itemStatus = 'PENDING_REVIEW';
        }

        items.push({
          documentTypeId: extraDoc.documentTypeId,
          documentTypeName: extraDoc.documentTypeName,
          category: extraDoc.category,
          isRequired: false,
          status: itemStatus,
          document: extraDoc,
          daysRemaining,
          isExpiringSoon,
          isExpired
        });
      }
    }

    // Authoritative statistical aggregation
    const requiredItems = items.filter(i => i.isRequired);
    const optionalItems = items.filter(i => !i.isRequired);

    const totalRequired = requiredItems.length;
    const totalOptional = optionalItems.length;
    const submitted = items.filter(i => Boolean(i.document)).length;
    const pendingReview = items.filter(i => i.status === 'PENDING_REVIEW').length;
    const verified = items.filter(i => i.status === 'VERIFIED' || (i.document?.verificationStatus === 'VERIFIED' && !i.isExpired)).length;
    const rejected = items.filter(i => i.status === 'REJECTED').length;
    const missing = items.filter(i => i.status === 'MISSING').length;
    const expiringSoon = items.filter(i => Boolean(i.isExpiringSoon)).length;
    const expired = items.filter(i => Boolean(i.isExpired)).length;

    // Compliance: percentage of REQUIRED items that are strictly VERIFIED (and not expired)
    const verifiedRequired = requiredItems.filter(i => i.document?.verificationStatus === 'VERIFIED' && !i.isExpired).length;
    const compliancePercentage = totalRequired === 0 ? 100 : Math.round((verifiedRequired / totalRequired) * 100);

    return {
      entityId,
      entityName,
      entityCode,
      entityType,
      totalRequired,
      totalOptional,
      submitted,
      pendingReview,
      verified,
      rejected,
      missing,
      expiringSoon,
      expired,
      compliancePercentage,
      items
    };
  }

  public static getExpiringDocuments(
    schoolId: string,
    params: {
      entityType?: DocumentEntityType;
      daysThreshold?: number;
      isExpired?: boolean;
    },
    user: User
  ): ExpiringDocumentItem[] {
    this.ensureCollections();
    this.syncLegacyDocumentsToManagedVault(schoolId);

    const threshold = Number(params.daysThreshold) || 30;
    const now = Date.now();

    let docs = database.managedDocuments.filter(d => d.schoolId === schoolId && Boolean(d.expiryDate));

    // Permission scoping
    docs = docs.filter(doc => this.validateDocumentAccess(doc, user, 'view'));

    if (params.entityType && (params.entityType as string) !== 'ALL') {
      docs = docs.filter(d => d.entityType === params.entityType);
    }

    const items: ExpiringDocumentItem[] = [];

    for (const doc of docs) {
      if (!doc.expiryDate) continue;
      const expTime = new Date(doc.expiryDate).getTime();
      const daysRemaining = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
      const isExpired = daysRemaining < 0;
      const isExpiringSoon = daysRemaining >= 0 && daysRemaining <= threshold;

      if (typeof params.isExpired === 'boolean') {
        if (params.isExpired && !isExpired) continue;
        if (!params.isExpired && isExpired) continue;
      } else {
        // If not explicitly asking only for expired, include anything expiring soon or already expired
        if (!isExpired && !isExpiringSoon) continue;
      }

      items.push({
        document: doc,
        daysRemaining,
        isExpired,
        isExpiringSoon
      });
    }

    // Sort by most urgent (lowest daysRemaining) first
    return items.sort((a, b) => a.daysRemaining - b.daysRemaining);
  }
}
