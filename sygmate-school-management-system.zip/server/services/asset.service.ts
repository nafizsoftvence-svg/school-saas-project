/**
 * Inventory Asset Lifecycle & Management Service (Part 14C)
 * Sygmate School Management System
 */

import { database } from '../db/database.js';
import { logAudit } from '../security/audit.js';
import {
  Asset,
  AssetCategory,
  AssetAssignment,
  AssetTransfer,
  AssetReturn,
  AssetTimelineEvent,
  AssetDocument,
  AssetStatus,
  AssetCondition,
  AssetWarrantyStatus,
  AssigneeType,
  CreateAssetPayload,
  UpdateAssetPayload,
  AssignAssetPayload,
  ReturnAssetPayload,
  TransferAssetPayload,
  SendForRepairPayload,
  CompleteRepairPayload,
  MarkDamagedPayload,
  MarkLostPayload,
  MarkRecoveredPayload,
  RetireAssetPayload,
  DisposeAssetPayload,
  AssetLifecycleSummary,
  UserRole
} from '../../src/types/index.js';
import { ensureInventoryCollections } from '../routes/inventory.routes.js';

// ============================================================================
// CONCURRENCY & MUTEX LOCKING
// ============================================================================

type MutexTask<T> = () => Promise<T> | T;
const assetLockQueues = new Map<string, Promise<any>>();

/**
 * Serializes operations on a specific asset ID to prevent race conditions
 * such as double assignment or concurrent status mutations.
 */
export async function withAssetLock<T>(assetId: string, task: MutexTask<T>): Promise<T> {
  const currentLock = assetLockQueues.get(assetId) || Promise.resolve();
  let releaseLock: () => void;
  const newLock = new Promise<void>((resolve) => {
    releaseLock = resolve;
  });
  assetLockQueues.set(assetId, newLock);

  try {
    await currentLock;
    return await task();
  } finally {
    releaseLock!();
    if (assetLockQueues.get(assetId) === newLock) {
      assetLockQueues.delete(assetId);
    }
  }
}

// ============================================================================
// USER NORMALIZATION HELPER
// ============================================================================

export interface NormalizedUser {
  id: string;
  name: string;
  role: UserRole;
}

export function normalizeUser(rawUser: any): NormalizedUser {
  return {
    id: rawUser?.id || 'usr-admin-1',
    name: rawUser?.name || 'Administrator',
    role: rawUser?.role || 'SUPER_ADMIN'
  };
}

// ============================================================================
// WARRANTY COMPUTATION HELPER
// ============================================================================

export function computeWarrantyStatus(warrantyEnd?: string): AssetWarrantyStatus {
  if (!warrantyEnd) return 'NOT_APPLICABLE';
  const now = new Date();
  const end = new Date(warrantyEnd);
  if (isNaN(end.getTime())) return 'NOT_APPLICABLE';

  const diffMs = end.getTime() - now.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return 'EXPIRED';
  if (diffDays <= 30) return 'EXPIRING_SOON';
  return 'ACTIVE';
}

// ============================================================================
// CODE GENERATOR
// ============================================================================

function generateNextAssetTag(schoolId: string): string {
  ensureInventoryCollections();
  const year = new Date().getFullYear();
  let counter = database.assets.filter((a) => a.schoolId === schoolId).length + 1;
  let tag = `AST-${year}-${String(counter).padStart(4, '0')}`;
  while (
    database.assets.some(
      (a) => a.schoolId === schoolId && a.assetTag.toUpperCase() === tag.toUpperCase()
    )
  ) {
    counter++;
    tag = `AST-${year}-${String(counter).padStart(4, '0')}`;
  }
  return tag;
}

// ============================================================================
// ASSET SERVICE
// ============================================================================

export class AssetService {
  /**
   * List assets with multifaceted filters and pagination
   */
  static getAssets(
    schoolId: string,
    filters?: {
      search?: string;
      categoryId?: string;
      status?: AssetStatus | 'ALL';
      condition?: AssetCondition | 'ALL';
      locationId?: string;
      supplierId?: string;
      assigneeId?: string;
      assigneeType?: AssigneeType | 'ALL';
      warrantyStatus?: AssetWarrantyStatus | 'ALL';
      page?: number;
      limit?: number;
      sortBy?: string;
      sortOrder?: 'asc' | 'desc';
    }
  ): { data: Asset[]; pagination: { total: number; page: number; limit: number; pages: number } } {
    ensureInventoryCollections();

    let result = database.assets.filter((a) => a.schoolId === schoolId);

    // Decorate with dynamic computed warranty status
    result = result.map((a) => ({
      ...a,
      warrantyStatus: computeWarrantyStatus(a.warrantyEnd)
    }));

    if (filters) {
      if (filters.categoryId && filters.categoryId !== 'ALL') {
        result = result.filter((a) => a.categoryId === filters.categoryId);
      }
      if (filters.status && filters.status !== 'ALL') {
        result = result.filter((a) => a.status === filters.status);
      }
      if (filters.condition && filters.condition !== 'ALL') {
        result = result.filter((a) => a.condition === filters.condition);
      }
      if (filters.locationId && filters.locationId !== 'ALL') {
        result = result.filter((a) => a.locationId === filters.locationId);
      }
      if (filters.supplierId && filters.supplierId !== 'ALL') {
        result = result.filter((a) => a.supplierId === filters.supplierId);
      }
      if (filters.assigneeId) {
        result = result.filter((a) => a.currentAssigneeId === filters.assigneeId);
      }
      if (filters.assigneeType && filters.assigneeType !== 'ALL') {
        result = result.filter((a) => a.currentAssigneeType === filters.assigneeType);
      }
      if (filters.warrantyStatus && filters.warrantyStatus !== 'ALL') {
        result = result.filter((a) => a.warrantyStatus === filters.warrantyStatus);
      }
      if (filters.search && filters.search.trim()) {
        const q = filters.search.trim().toLowerCase();
        result = result.filter(
          (a) =>
            a.name.toLowerCase().includes(q) ||
            a.assetTag.toLowerCase().includes(q) ||
            (a.serialNumber && a.serialNumber.toLowerCase().includes(q)) ||
            (a.brand && a.brand.toLowerCase().includes(q)) ||
            (a.model && a.model.toLowerCase().includes(q)) ||
            (a.categoryName && a.categoryName.toLowerCase().includes(q)) ||
            (a.locationName && a.locationName.toLowerCase().includes(q)) ||
            (a.currentAssigneeName && a.currentAssigneeName.toLowerCase().includes(q))
        );
      }
    }

    const total = result.length;
    const page = Math.max(1, Number(filters?.page) || 1);
    const limit = Math.max(1, Math.min(100, Number(filters?.limit) || 50));
    const pages = Math.ceil(total / limit) || 1;

    // Sorting
    const sortBy = filters?.sortBy || 'createdAt';
    const sortOrder = filters?.sortOrder === 'asc' ? 1 : -1;
    result.sort((a: any, b: any) => {
      const valA = a[sortBy] ?? '';
      const valB = b[sortBy] ?? '';
      if (valA < valB) return -1 * sortOrder;
      if (valA > valB) return 1 * sortOrder;
      return 0;
    });

    const paginated = result.slice((page - 1) * limit, page * limit);

    return {
      data: paginated,
      pagination: { total, page, limit, pages }
    };
  }

  /**
   * Get single asset by ID with enriched active assignment
   */
  static getAssetById(
    schoolId: string,
    assetId: string
  ): {
    asset: Asset;
    activeAssignment?: AssetAssignment;
    recentAssignments: AssetAssignment[];
    timeline: AssetTimelineEvent[];
  } {
    ensureInventoryCollections();
    const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
    if (!asset) {
      throw new Error(`Asset not found with ID '${assetId}'`);
    }

    const activeAssignment = database.assetAssignments.find(
      (asgn) => asgn.assetId === assetId && asgn.schoolId === schoolId && asgn.status === 'ACTIVE'
    );

    const recentAssignments = database.assetAssignments
      .filter((asgn) => asgn.assetId === assetId && asgn.schoolId === schoolId)
      .sort((a, b) => new Date(b.assignedDate).getTime() - new Date(a.assignedDate).getTime())
      .slice(0, 10);

    const timeline = database.assetTimelineEvents
      .filter((t) => t.assetId === assetId && t.schoolId === schoolId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 20);

    return {
      asset: {
        ...asset,
        warrantyStatus: computeWarrantyStatus(asset.warrantyEnd)
      },
      activeAssignment,
      recentAssignments,
      timeline
    };
  }

  /**
   * Lookup asset by tag (e.g. for QR / barcode scans)
   */
  static getAssetByTag(schoolId: string, assetTag: string): Asset {
    ensureInventoryCollections();
    const asset = database.assets.find(
      (a) =>
        a.schoolId === schoolId &&
        a.assetTag.trim().toUpperCase() === assetTag.trim().toUpperCase()
    );
    if (!asset) {
      throw new Error(`Asset not found with tag '${assetTag}'`);
    }
    return {
      ...asset,
      warrantyStatus: computeWarrantyStatus(asset.warrantyEnd)
    };
  }

  /**
   * Register a new Asset in the Institutional Register
   */
  static createAsset(schoolId: string, payload: CreateAssetPayload, user: any): Asset {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    if (!payload.name || !payload.name.trim()) {
      throw new Error('Asset name is required.');
    }
    if (!payload.categoryId || !payload.categoryId.trim()) {
      throw new Error('Asset category is required.');
    }
    if (!payload.locationId || !payload.locationId.trim()) {
      throw new Error('Location is required.');
    }

    const category = database.assetCategories.find(
      (c) => c.id === payload.categoryId && c.schoolId === schoolId
    );
    if (!category) {
      throw new Error(`Invalid asset category '${payload.categoryId}'.`);
    }

    const location = database.inventoryLocations.find(
      (l) => l.id === payload.locationId && l.schoolId === schoolId
    );
    if (!location) {
      throw new Error(`Invalid location '${payload.locationId}'.`);
    }

    let supplierName: string | undefined;
    if (payload.supplierId) {
      const supplier = database.suppliers.find(
        (s) => s.id === payload.supplierId && s.schoolId === schoolId
      );
      if (supplier) supplierName = supplier.name;
    }

    // Asset Tag Generation / Validation
    let assetTag = payload.assetTag?.trim().toUpperCase();
    if (assetTag) {
      const exists = database.assets.some(
        (a) => a.schoolId === schoolId && a.assetTag.toUpperCase() === assetTag
      );
      if (exists) {
        throw new Error(`Asset tag '${assetTag}' is already registered in this institution.`);
      }
    } else {
      assetTag = generateNextAssetTag(schoolId);
    }

    // Serial Number uniqueness check if supplied
    if (payload.serialNumber && payload.serialNumber.trim()) {
      const sn = payload.serialNumber.trim().toUpperCase();
      const existingSn = database.assets.find(
        (a) =>
          a.schoolId === schoolId &&
          a.serialNumber &&
          a.serialNumber.trim().toUpperCase() === sn &&
          a.status !== 'DISPOSED'
      );
      if (existingSn) {
        throw new Error(
          `Serial number '${payload.serialNumber}' is already associated with asset '${existingSn.name}' (${existingSn.assetTag}).`
        );
      }
    }

    const now = new Date().toISOString();
    const initialStatus = payload.status || 'AVAILABLE';
    const initialCondition = payload.condition || 'NEW';

    const newAsset: Asset = {
      id: `ast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      assetTag,
      name: payload.name.trim(),
      categoryId: category.id,
      categoryName: category.name,
      brand: payload.brand?.trim(),
      model: payload.model?.trim(),
      serialNumber: payload.serialNumber?.trim(),
      purchaseDate: payload.purchaseDate || now.substring(0, 10),
      purchaseCost: Number(payload.purchaseCost) || 0,
      supplierId: payload.supplierId,
      supplierName,
      warrantyStart: payload.warrantyStart,
      warrantyEnd: payload.warrantyEnd,
      warrantyStatus: computeWarrantyStatus(payload.warrantyEnd),
      locationId: location.id,
      locationName: location.name,
      department: payload.department?.trim() || location.department || 'General Administration',
      status: initialStatus,
      condition: initialCondition,
      description: payload.description?.trim(),
      notes: payload.notes?.trim(),
      imageUrl: payload.imageUrl,
      documents: [],
      history: [
        {
          id: `hist-${Date.now()}-reg`,
          assetId: '',
          action: 'Asset Registered',
          toStatus: initialStatus,
          remarks: `Commissioned into service with condition ${initialCondition}.`,
          performedBy: normalizedUser.id,
          performedByName: normalizedUser.name,
          timestamp: now
        }
      ],
      createdBy: normalizedUser.id,
      createdByName: normalizedUser.name,
      createdAt: now,
      updatedBy: normalizedUser.id,
      updatedByName: normalizedUser.name,
      updatedAt: now
    };
    newAsset.history[0].assetId = newAsset.id;

    database.assets.unshift(newAsset);

    // Timeline event
    database.assetTimelineEvents.unshift({
      id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      assetId: newAsset.id,
      eventType: 'REGISTERED',
      title: 'Asset Commissioned & Tagged',
      description: `Asset '${newAsset.name}' registered with tag ${newAsset.assetTag}. Condition: ${initialCondition}.`,
      toStatus: initialStatus,
      performedBy: normalizedUser.id,
      performedByName: normalizedUser.name,
      performedByRole: normalizedUser.role,
      timestamp: now
    });

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'CREATE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: newAsset.id,
      details: `Registered asset '${newAsset.name}' (${newAsset.assetTag}) at location '${location.name}'.`,
      metadata: { assetTag: newAsset.assetTag, categoryId: category.id, cost: newAsset.purchaseCost }
    });

    return newAsset;
  }

  /**
   * Update an Asset Master specification
   */
  static updateAsset(
    schoolId: string,
    assetId: string,
    payload: UpdateAssetPayload,
    user: any
  ): Asset {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
    if (!asset) {
      throw new Error(`Asset not found with ID '${assetId}'.`);
    }

    if (asset.status === 'DISPOSED') {
      throw new Error('Disposed assets are archived and cannot be modified.');
    }

    // Category check
    if (payload.categoryId && payload.categoryId !== asset.categoryId) {
      const cat = database.assetCategories.find(
        (c) => c.id === payload.categoryId && c.schoolId === schoolId
      );
      if (!cat) throw new Error(`Invalid category '${payload.categoryId}'.`);
      asset.categoryId = cat.id;
      asset.categoryName = cat.name;
    }

    // Location check
    if (payload.locationId && payload.locationId !== asset.locationId) {
      const loc = database.inventoryLocations.find(
        (l) => l.id === payload.locationId && l.schoolId === schoolId
      );
      if (!loc) throw new Error(`Invalid location '${payload.locationId}'.`);
      asset.locationId = loc.id;
      asset.locationName = loc.name;
    }

    // Supplier check
    if (payload.supplierId !== undefined) {
      if (payload.supplierId) {
        const sup = database.suppliers.find(
          (s) => s.id === payload.supplierId && s.schoolId === schoolId
        );
        if (sup) {
          asset.supplierId = sup.id;
          asset.supplierName = sup.name;
        }
      } else {
        asset.supplierId = undefined;
        asset.supplierName = undefined;
      }
    }

    // Asset tag check
    if (payload.assetTag && payload.assetTag.toUpperCase() !== asset.assetTag.toUpperCase()) {
      const exists = database.assets.some(
        (a) =>
          a.schoolId === schoolId &&
          a.id !== assetId &&
          a.assetTag.toUpperCase() === payload.assetTag!.toUpperCase()
      );
      if (exists) {
        throw new Error(`Asset tag '${payload.assetTag}' is already registered to another asset.`);
      }
      asset.assetTag = payload.assetTag.trim().toUpperCase();
    }

    if (payload.name) asset.name = payload.name.trim();
    if (payload.brand !== undefined) asset.brand = payload.brand?.trim();
    if (payload.model !== undefined) asset.model = payload.model?.trim();
    if (payload.serialNumber !== undefined) asset.serialNumber = payload.serialNumber?.trim();
    if (payload.purchaseDate !== undefined) asset.purchaseDate = payload.purchaseDate;
    if (payload.purchaseCost !== undefined) asset.purchaseCost = Number(payload.purchaseCost) || 0;
    if (payload.warrantyStart !== undefined) asset.warrantyStart = payload.warrantyStart;
    if (payload.warrantyEnd !== undefined) {
      asset.warrantyEnd = payload.warrantyEnd;
      asset.warrantyStatus = computeWarrantyStatus(payload.warrantyEnd);
    }
    if (payload.department !== undefined) asset.department = payload.department?.trim();
    if (payload.description !== undefined) asset.description = payload.description?.trim();
    if (payload.notes !== undefined) asset.notes = payload.notes?.trim();
    if (payload.imageUrl !== undefined) asset.imageUrl = payload.imageUrl;
    if (payload.condition) asset.condition = payload.condition;

    const now = new Date().toISOString();
    asset.updatedBy = normalizedUser.id;
    asset.updatedByName = normalizedUser.name;
    asset.updatedAt = now;

    // Timeline event
    database.assetTimelineEvents.unshift({
      id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      assetId: asset.id,
      eventType: 'DETAILS_UPDATED',
      title: 'Asset Specifications Updated',
      description: `Asset master records updated by ${normalizedUser.name}.`,
      performedBy: normalizedUser.id,
      performedByName: normalizedUser.name,
      performedByRole: normalizedUser.role,
      timestamp: now
    });

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: asset.id,
      details: `Updated asset '${asset.name}' (${asset.assetTag}).`
    });

    return asset;
  }

  /**
   * Delete an Asset (Safe removal guard)
   */
  static deleteAsset(schoolId: string, assetId: string, user: any): { success: boolean; message: string } {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    const index = database.assets.findIndex((a) => a.id === assetId && a.schoolId === schoolId);
    if (index === -1) {
      throw new Error(`Asset not found with ID '${assetId}'.`);
    }

    const asset = database.assets[index];

    // Cannot delete if actively assigned
    if (asset.status === 'ASSIGNED') {
      throw new Error(
        `Cannot delete asset '${asset.name}' (${asset.assetTag}) because it is actively assigned to ${asset.currentAssigneeName || 'a custodian'}. You must process a return first.`
      );
    }

    const removed = database.assets.splice(index, 1)[0];

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'DELETE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: removed.id,
      details: `Deleted asset '${removed.name}' (${removed.assetTag}).`
    });

    return {
      success: true,
      message: `Asset '${removed.name}' (${removed.assetTag}) deleted successfully.`
    };
  }

  // ==========================================================================
  // ASSET LIFECYCLE WORKFLOWS
  // ==========================================================================

  /**
   * Assign an Asset to a Staff, Teacher, Department, Location, or Student.
   * Concurrency-safe: Wrapped in withAssetLock to prevent double assignment.
   */
  static async assignAsset(
    schoolId: string,
    assetId: string,
    payload: AssignAssetPayload,
    user: any
  ): Promise<{ asset: Asset; assignment: AssetAssignment }> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) {
        throw new Error(`Asset not found with ID '${assetId}'.`);
      }

      // Concurrency check: Ensure asset is available for assignment
      if (asset.status !== 'AVAILABLE' && asset.status !== 'ACTIVE') {
        throw new Error(
          `Asset '${asset.name}' (${asset.assetTag}) cannot be assigned because its current status is '${asset.status}'. Only AVAILABLE assets can be assigned.`
        );
      }

      // Check active assignment existence defensively
      const existingActive = database.assetAssignments.find(
        (asgn) => asgn.assetId === assetId && asgn.schoolId === schoolId && asgn.status === 'ACTIVE'
      );
      if (existingActive) {
        throw new Error(
          `Asset is already actively assigned to '${existingActive.assigneeName}'. Please return or transfer it first.`
        );
      }

      if (!payload.assigneeId || !payload.assigneeId.trim()) {
        throw new Error('Assignee ID is required.');
      }
      if (!payload.assigneeName || !payload.assigneeName.trim()) {
        throw new Error('Assignee Name is required.');
      }

      const now = new Date().toISOString();
      const assignedDate = payload.assignedDate || now;
      const handoverCondition: AssetCondition =
        payload.conditionAtHandover || asset.condition || 'GOOD';

      // Create new Assignment Record
      const assignment: AssetAssignment = {
        id: `asgn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        assetTag: asset.assetTag,
        assetName: asset.name,
        assigneeType: payload.assigneeType,
        assigneeId: payload.assigneeId.trim(),
        assigneeName: payload.assigneeName.trim(),
        department: payload.department?.trim() || asset.department,
        locationId: payload.locationId || asset.locationId,
        locationName: payload.locationName || asset.locationName,
        assignedDate,
        expectedReturnDate: payload.expectedReturnDate,
        conditionAtHandover: handoverCondition,
        status: 'ACTIVE',
        handoverNotes: payload.handoverNotes?.trim(),
        assignedBy: normalizedUser.id,
        assignedByName: normalizedUser.name,
        accessories: payload.accessories || [],
        createdAt: now,
        updatedAt: now
      };

      database.assetAssignments.unshift(assignment);

      // Atomically update Asset state
      const fromStatus = asset.status;
      asset.status = 'ASSIGNED';
      asset.condition = handoverCondition;
      asset.currentAssigneeType = payload.assigneeType;
      asset.currentAssigneeId = assignment.assigneeId;
      asset.currentAssigneeName = assignment.assigneeName;
      asset.currentAssignmentId = assignment.id;
      asset.assignedDate = assignedDate;
      asset.expectedReturnDate = payload.expectedReturnDate;

      if (payload.locationId) {
        asset.locationId = payload.locationId;
        if (payload.locationName) asset.locationName = payload.locationName;
      }
      if (payload.department) {
        asset.department = payload.department;
      }

      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      // History entry on asset
      const historyEntry = {
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: `Assigned to ${assignment.assigneeName} (${payload.assigneeType})`,
        fromStatus,
        toStatus: 'ASSIGNED' as AssetStatus,
        remarks:
          payload.handoverNotes ||
          `Handed over in ${handoverCondition} condition by ${normalizedUser.name}.`,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      };
      if (!asset.history) asset.history = [];
      asset.history.unshift(historyEntry);

      // Timeline event
      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'ASSIGNED',
        title: `Assigned to ${assignment.assigneeName}`,
        description: `Handed over in ${handoverCondition} condition (${payload.assigneeType}). Expected return: ${payload.expectedReturnDate || 'Indefinite'}.`,
        fromStatus,
        toStatus: 'ASSIGNED',
        toAssigneeName: assignment.assigneeName,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: {
          assignmentId: assignment.id,
          condition: handoverCondition,
          accessories: payload.accessories
        }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Assigned asset '${asset.name}' (${asset.assetTag}) to ${assignment.assigneeName} (${payload.assigneeType}).`,
        metadata: { assignmentId: assignment.id, assigneeId: assignment.assigneeId }
      });

      return { asset, assignment };
    });
  }

  /**
   * Return an assigned Asset back to inventory.
   * Concurrency-safe: Wrapped in withAssetLock.
   */
  static async returnAsset(
    schoolId: string,
    assetId: string,
    payload: ReturnAssetPayload,
    user: any
  ): Promise<{ asset: Asset; returnRecord: AssetReturn }> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) {
        throw new Error(`Asset not found with ID '${assetId}'.`);
      }

      if (asset.status !== 'ASSIGNED') {
        throw new Error(
          `Asset '${asset.name}' (${asset.assetTag}) is not currently ASSIGNED (current status: ${asset.status}).`
        );
      }

      const activeAssignment = database.assetAssignments.find(
        (asgn) =>
          asgn.assetId === assetId && asgn.schoolId === schoolId && asgn.status === 'ACTIVE'
      );
      if (!activeAssignment) {
        throw new Error(`No active assignment record found for asset '${asset.name}'.`);
      }

      const now = new Date().toISOString();
      const returnDate = payload.returnDate || now;
      const returnCondition = payload.returnCondition || 'GOOD';

      // Check return location
      const returnLocation = database.inventoryLocations.find(
        (l) => l.id === payload.locationId && l.schoolId === schoolId
      );
      const locationName =
        payload.locationName || returnLocation?.name || asset.locationName || 'Central Warehouse';

      // Resulting status: If returned damaged or critical, mark DAMAGED. Otherwise, AVAILABLE.
      const resultingStatus: AssetStatus =
        returnCondition === 'DAMAGED' || returnCondition === 'CRITICAL' ? 'DAMAGED' : 'AVAILABLE';

      // Update active assignment
      activeAssignment.status = 'RETURNED';
      activeAssignment.actualReturnDate = returnDate;
      activeAssignment.conditionAtReturn = returnCondition;
      activeAssignment.returnNotes = payload.returnNotes?.trim();
      activeAssignment.receivedBy = normalizedUser.id;
      activeAssignment.receivedByName = normalizedUser.name;
      activeAssignment.updatedAt = now;

      // Create Return Record
      const returnRecord: AssetReturn = {
        id: `ret-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        assignmentId: activeAssignment.id,
        returnDate,
        returnCondition,
        resultingStatus,
        locationId: payload.locationId,
        locationName,
        returnedByAssigneeId: activeAssignment.assigneeId,
        returnedByAssigneeName: activeAssignment.assigneeName,
        receivedByUserId: normalizedUser.id,
        receivedByUserName: normalizedUser.name,
        remarks: payload.returnNotes?.trim(),
        createdAt: now
      };
      database.assetReturns.unshift(returnRecord);

      // Reset Asset custody fields
      const previousAssigneeName = asset.currentAssigneeName;
      asset.status = resultingStatus;
      asset.condition = returnCondition;
      asset.currentAssigneeType = undefined;
      asset.currentAssigneeId = undefined;
      asset.currentAssigneeName = undefined;
      asset.currentAssignmentId = undefined;
      asset.assignedDate = undefined;
      asset.expectedReturnDate = undefined;
      asset.locationId = payload.locationId;
      asset.locationName = locationName;
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      // History entry
      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: `Returned from ${activeAssignment.assigneeName}`,
        fromStatus: 'ASSIGNED',
        toStatus: resultingStatus,
        remarks:
          payload.returnNotes ||
          `Returned in ${returnCondition} condition to ${locationName}. Received by ${normalizedUser.name}.`,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      // Timeline event
      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'RETURNED',
        title: `Returned by ${activeAssignment.assigneeName}`,
        description: `Returned into ${locationName} with condition ${returnCondition}. Resulting status: ${resultingStatus}.`,
        fromStatus: 'ASSIGNED',
        toStatus: resultingStatus,
        fromAssigneeName: previousAssigneeName,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: {
          assignmentId: activeAssignment.id,
          returnCondition,
          resultingStatus
        }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Processed return of asset '${asset.name}' (${asset.assetTag}) from ${activeAssignment.assigneeName}. Resulting status: ${resultingStatus}.`
      });

      return { asset, returnRecord };
    });
  }

  /**
   * Transfer / Reassign an Asset directly from one custodian to another.
   * Concurrency-safe: Wrapped in withAssetLock.
   */
  static async transferAsset(
    schoolId: string,
    assetId: string,
    payload: TransferAssetPayload,
    user: any
  ): Promise<{ asset: Asset; transferRecord: AssetTransfer; newAssignment: AssetAssignment }> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) {
        throw new Error(`Asset not found with ID '${assetId}'.`);
      }

      if (asset.status !== 'ASSIGNED') {
        throw new Error(
          `Asset '${asset.name}' is not currently ASSIGNED. Cannot transfer an unassigned asset.`
        );
      }

      const currentAssignment = database.assetAssignments.find(
        (asgn) =>
          asgn.assetId === assetId && asgn.schoolId === schoolId && asgn.status === 'ACTIVE'
      );
      if (!currentAssignment) {
        throw new Error('No active assignment record found to transfer.');
      }

      if (!payload.toAssigneeId || !payload.toAssigneeName) {
        throw new Error('Target assignee information is required.');
      }

      const now = new Date().toISOString();
      const transferDate = payload.transferDate || now;
      const transferCondition = payload.condition || asset.condition || 'GOOD';

      // 1. Mark current assignment as TRANSFERRED
      currentAssignment.status = 'TRANSFERRED';
      currentAssignment.actualReturnDate = transferDate;
      currentAssignment.returnNotes = `Transferred to ${payload.toAssigneeName}: ${payload.reason || 'Reassignment'}`;
      currentAssignment.updatedAt = now;

      // 2. Create new assignment
      const newAssignment: AssetAssignment = {
        id: `asgn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        assetTag: asset.assetTag,
        assetName: asset.name,
        assigneeType: payload.toAssigneeType,
        assigneeId: payload.toAssigneeId.trim(),
        assigneeName: payload.toAssigneeName.trim(),
        department: payload.toDepartment || asset.department,
        locationId: payload.toLocationId || asset.locationId,
        locationName: payload.toLocationName || asset.locationName,
        assignedDate: transferDate,
        conditionAtHandover: transferCondition,
        status: 'ACTIVE',
        handoverNotes: `Transferred from ${currentAssignment.assigneeName}. Reason: ${payload.reason}. Notes: ${payload.notes || 'None'}`,
        assignedBy: normalizedUser.id,
        assignedByName: normalizedUser.name,
        createdAt: now,
        updatedAt: now
      };
      database.assetAssignments.unshift(newAssignment);

      // 3. Create Transfer Record
      const transferRecord: AssetTransfer = {
        id: `xfer-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        assetTag: asset.assetTag,
        fromAssignmentId: currentAssignment.id,
        toAssignmentId: newAssignment.id,
        fromAssigneeType: currentAssignment.assigneeType,
        fromAssigneeId: currentAssignment.assigneeId,
        fromAssigneeName: currentAssignment.assigneeName,
        toAssigneeType: payload.toAssigneeType,
        toAssigneeId: payload.toAssigneeId.trim(),
        toAssigneeName: payload.toAssigneeName.trim(),
        fromLocationId: currentAssignment.locationId,
        toLocationId: payload.toLocationId,
        transferDate,
        reason: payload.reason,
        condition: transferCondition,
        transferredBy: normalizedUser.id,
        transferredByName: normalizedUser.name,
        notes: payload.notes,
        createdAt: now
      };
      database.assetTransfers.unshift(transferRecord);

      // 4. Update Asset state
      const fromAssigneeName = currentAssignment.assigneeName;
      asset.currentAssigneeType = payload.toAssigneeType;
      asset.currentAssigneeId = newAssignment.assigneeId;
      asset.currentAssigneeName = newAssignment.assigneeName;
      asset.currentAssignmentId = newAssignment.id;
      asset.assignedDate = transferDate;
      asset.condition = transferCondition;
      if (payload.toLocationId) {
        asset.locationId = payload.toLocationId;
        if (payload.toLocationName) asset.locationName = payload.toLocationName;
      }
      if (payload.toDepartment) {
        asset.department = payload.toDepartment;
      }
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      // History entry
      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: `Transferred to ${newAssignment.assigneeName}`,
        fromStatus: 'ASSIGNED',
        toStatus: 'ASSIGNED',
        remarks: `Custody transferred from ${fromAssigneeName} to ${newAssignment.assigneeName}. Reason: ${payload.reason}`,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      // Timeline event
      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'TRANSFERRED',
        title: `Transferred to ${newAssignment.assigneeName}`,
        description: `Transferred from ${fromAssigneeName} to ${newAssignment.assigneeName}. Reason: ${payload.reason}`,
        fromStatus: 'ASSIGNED',
        toStatus: 'ASSIGNED',
        fromAssigneeName,
        toAssigneeName: newAssignment.assigneeName,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: { transferId: transferRecord.id, reason: payload.reason }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'UPDATE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Transferred asset '${asset.name}' (${asset.assetTag}) from ${fromAssigneeName} to ${newAssignment.assigneeName}.`
      });

      return { asset, transferRecord, newAssignment };
    });
  }

  /**
   * Send an Asset for Maintenance / Repair
   */
  static async sendForRepair(
    schoolId: string,
    assetId: string,
    payload: SendForRepairPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'ASSIGNED') {
        throw new Error(
          'Asset is currently assigned. Custodian must return the asset before sending it for maintenance.'
        );
      }
      if (asset.status === 'DISPOSED') {
        throw new Error('Disposed assets cannot be sent for repair.');
      }

      const fromStatus = asset.status;
      asset.status = 'UNDER_REPAIR';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Sent for repair. Problem: ${payload.problemDescription}. Vendor: ${payload.vendorOrServiceProvider || 'Internal Service'}. Est. Cost: $${payload.estimatedCost || 0}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Sent for Repair / Service',
        fromStatus,
        toStatus: 'UNDER_REPAIR',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'SENT_FOR_REPAIR',
        title: 'Sent for Maintenance & Repair',
        description: remarks,
        fromStatus,
        toStatus: 'UNDER_REPAIR',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: {
          vendor: payload.vendorOrServiceProvider,
          estimatedCost: payload.estimatedCost,
          completionEstimate: payload.estimatedCompletionDate
        }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Sent asset '${asset.name}' (${asset.assetTag}) for repair: ${payload.problemDescription}`
      });

      return asset;
    });
  }

  /**
   * Complete Maintenance / Return from Repair
   */
  static async completeRepair(
    schoolId: string,
    assetId: string,
    payload: CompleteRepairPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status !== 'UNDER_REPAIR') {
        throw new Error(`Asset is not UNDER_REPAIR (current status: ${asset.status}).`);
      }

      const returnLoc = database.inventoryLocations.find(
        (l) => l.id === payload.returnLocationId && l.schoolId === schoolId
      );
      if (returnLoc) {
        asset.locationId = returnLoc.id;
        asset.locationName = returnLoc.name;
      }

      asset.status = 'AVAILABLE';
      asset.condition = payload.resultingCondition || 'GOOD';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Repair completed. Resulting condition: ${asset.condition}. Notes: ${payload.repairNotes}. Actual Cost: $${payload.actualCost || 0}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Repair Completed',
        fromStatus: 'UNDER_REPAIR',
        toStatus: 'AVAILABLE',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'REPAIRED',
        title: 'Repair Completed',
        description: remarks,
        fromStatus: 'UNDER_REPAIR',
        toStatus: 'AVAILABLE',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: { actualCost: payload.actualCost, repairNotes: payload.repairNotes }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Completed repair on asset '${asset.name}' (${asset.assetTag}). Returned to AVAILABLE.`
      });

      return asset;
    });
  }

  /**
   * Mark Asset as Damaged
   */
  static async markDamaged(
    schoolId: string,
    assetId: string,
    payload: MarkDamagedPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'DISPOSED') {
        throw new Error('Disposed assets cannot be altered.');
      }

      const fromStatus = asset.status;
      asset.status = 'DAMAGED';
      asset.condition = payload.condition || 'DAMAGED';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Marked as Damaged: ${payload.damageDescription}. Repairable: ${payload.canBeRepaired ? 'Yes' : 'No'}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Marked as Damaged',
        fromStatus,
        toStatus: 'DAMAGED',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'DAMAGED',
        title: 'Asset Condition: Damaged',
        description: remarks,
        fromStatus,
        toStatus: 'DAMAGED',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Marked asset '${asset.name}' (${asset.assetTag}) as DAMAGED: ${payload.damageDescription}`
      });

      return asset;
    });
  }

  /**
   * Mark Asset as Lost
   */
  static async markLost(
    schoolId: string,
    assetId: string,
    payload: MarkLostPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'DISPOSED') {
        throw new Error('Disposed assets cannot be altered.');
      }

      // If asset was assigned, close the assignment as lost
      const activeAsgn = database.assetAssignments.find(
        (a) => a.assetId === assetId && a.schoolId === schoolId && a.status === 'ACTIVE'
      );
      if (activeAsgn) {
        activeAsgn.status = 'RETURNED';
        activeAsgn.returnNotes = `Asset reported lost on ${payload.incidentDate || 'today'}. Incident: ${payload.incidentReport}`;
        activeAsgn.actualReturnDate = new Date().toISOString();
      }

      const fromStatus = asset.status;
      asset.status = 'LOST';
      asset.currentAssigneeType = undefined;
      asset.currentAssigneeId = undefined;
      asset.currentAssigneeName = undefined;
      asset.currentAssignmentId = undefined;
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Incident Report: ${payload.incidentReport}. Incident Date: ${payload.incidentDate || now}. Reported By: ${payload.reportedBy || normalizedUser.name}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Marked as Lost',
        fromStatus,
        toStatus: 'LOST',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'LOST',
        title: 'Asset Reported Lost',
        description: remarks,
        fromStatus,
        toStatus: 'LOST',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Marked asset '${asset.name}' (${asset.assetTag}) as LOST: ${payload.incidentReport}`
      });

      return asset;
    });
  }

  /**
   * Recover a previously Lost Asset
   */
  static async recoverAsset(
    schoolId: string,
    assetId: string,
    payload: MarkRecoveredPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status !== 'LOST') {
        throw new Error(`Asset is not in LOST status (current status: ${asset.status}).`);
      }

      const loc = database.inventoryLocations.find(
        (l) => l.id === payload.locationId && l.schoolId === schoolId
      );
      if (loc) {
        asset.locationId = loc.id;
        asset.locationName = loc.name;
      }

      asset.status = 'AVAILABLE';
      asset.condition = payload.condition || 'GOOD';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Asset recovered on ${payload.recoveryDate || 'today'}. Condition assessed: ${asset.condition}. Notes: ${payload.notes || 'Reinstated into inventory.'}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Asset Recovered',
        fromStatus: 'LOST',
        toStatus: 'AVAILABLE',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'RECOVERED',
        title: 'Asset Recovered',
        description: remarks,
        fromStatus: 'LOST',
        toStatus: 'AVAILABLE',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Recovered lost asset '${asset.name}' (${asset.assetTag}). Restored to AVAILABLE in ${loc?.name || 'Warehouse'}.`
      });

      return asset;
    });
  }

  /**
   * Retire an Asset (Decommission from active institutional use)
   */
  static async retireAsset(
    schoolId: string,
    assetId: string,
    payload: RetireAssetPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'ASSIGNED') {
        throw new Error(
          'Asset is currently assigned. Please return the asset before retiring it.'
        );
      }
      if (asset.status === 'DISPOSED') {
        throw new Error('Asset is already disposed.');
      }

      const fromStatus = asset.status;
      asset.status = 'RETIRED';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Asset Retired. Reason: ${payload.reason}. Notes: ${payload.notes || 'None'}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: 'Asset Retired',
        fromStatus,
        toStatus: 'RETIRED',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'RETIRED',
        title: 'Asset Decommissioned & Retired',
        description: remarks,
        fromStatus,
        toStatus: 'RETIRED',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Retired asset '${asset.name}' (${asset.assetTag}): ${payload.reason}`
      });

      return asset;
    });
  }

  /**
   * Dispose an Asset (Permanent terminal state: Sold, Scrapped, Donated, Recycled, E-Waste)
   */
  static async disposeAsset(
    schoolId: string,
    assetId: string,
    payload: DisposeAssetPayload,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'ASSIGNED') {
        throw new Error(
          'Asset is currently assigned. You must process a return before disposing an asset.'
        );
      }
      if (asset.status === 'DISPOSED') {
        throw new Error('Asset is already marked as DISPOSED.');
      }

      const fromStatus = asset.status;
      asset.status = 'DISPOSED';
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      const remarks = `Disposed via ${payload.disposalMethod}. Recipient/Vendor: ${payload.recipientOrVendor || 'N/A'}. Disposal Value: $${payload.disposalValue || 0}. Certificate Ref: ${payload.certificateReference || 'None'}. Notes: ${payload.notes || 'None'}`;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: `Disposed (${payload.disposalMethod})`,
        fromStatus,
        toStatus: 'DISPOSED',
        remarks,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'DISPOSED',
        title: `Asset Disposed: ${payload.disposalMethod}`,
        description: remarks,
        fromStatus,
        toStatus: 'DISPOSED',
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now,
        metadata: {
          disposalMethod: payload.disposalMethod,
          disposalValue: payload.disposalValue,
          recipient: payload.recipientOrVendor
        }
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Disposed asset '${asset.name}' (${asset.assetTag}) via ${payload.disposalMethod}.`
      });

      return asset;
    });
  }

  /**
   * Update Status directly with business validation
   */
  static async updateStatus(
    schoolId: string,
    assetId: string,
    status: AssetStatus,
    remarks: string,
    user: any
  ): Promise<Asset> {
    return withAssetLock(assetId, async () => {
      ensureInventoryCollections();
      const normalizedUser = normalizeUser(user);

      const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
      if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

      if (asset.status === 'DISPOSED' && status !== 'DISPOSED') {
        throw new Error('Disposed assets are permanently terminal and cannot change status.');
      }

      if (asset.status === 'ASSIGNED' && status !== 'ASSIGNED') {
        throw new Error(
          'Assigned assets must be processed through Return or Transfer workflow to clear custodian custody.'
        );
      }

      if (status === 'ASSIGNED' && asset.status !== 'ASSIGNED') {
        throw new Error(
          'To assign an asset, please use the dedicated Assignment workflow to record custodian details.'
        );
      }

      const fromStatus = asset.status;
      asset.status = status;
      const now = new Date().toISOString();
      asset.updatedBy = normalizedUser.id;
      asset.updatedByName = normalizedUser.name;
      asset.updatedAt = now;

      if (!asset.history) asset.history = [];
      asset.history.unshift({
        id: `hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        assetId: asset.id,
        action: `Status Changed to ${status}`,
        fromStatus,
        toStatus: status,
        remarks: remarks || `Transitioned status from ${fromStatus} to ${status}.`,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        timestamp: now
      });

      database.assetTimelineEvents.unshift({
        id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        schoolId,
        assetId: asset.id,
        eventType: 'STATUS_CHANGED',
        title: `Status Changed to ${status}`,
        description: remarks || `Transitioned from ${fromStatus} to ${status}.`,
        fromStatus,
        toStatus: status,
        performedBy: normalizedUser.id,
        performedByName: normalizedUser.name,
        performedByRole: normalizedUser.role,
        timestamp: now
      });

      logAudit({
        userId: normalizedUser.id,
        userName: normalizedUser.name,
        userRole: normalizedUser.role,
        action: 'STATUS_CHANGE',
        entity: 'OTHER',
        entityType: 'Asset',
        entityId: asset.id,
        details: `Updated asset '${asset.name}' status from ${fromStatus} to ${status}.`
      });

      return asset;
    });
  }

  // ==========================================================================
  // DOCUMENT & FILE MANAGEMENT
  // ==========================================================================

  /**
   * Attach Document to an Asset
   */
  static attachDocument(
    schoolId: string,
    assetId: string,
    doc: {
      title: string;
      fileName: string;
      fileUrl?: string;
      fileType?: string;
      fileSize?: string;
      documentType?: string;
    },
    user: any
  ): { asset: Asset; document: AssetDocument } {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
    if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

    if (!doc.title || !doc.title.trim()) throw new Error('Document title is required.');
    if (!doc.fileName || !doc.fileName.trim()) throw new Error('File name is required.');

    const now = new Date().toISOString();
    const newDoc: AssetDocument = {
      id: `doc-ast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: doc.title.trim(),
      fileName: doc.fileName.trim(),
      fileUrl:
        doc.fileUrl ||
        `https://storage.sygmate.edu/assets/${asset.assetTag.toLowerCase()}_${Date.now()}.pdf`,
      fileType: doc.fileType || 'application/pdf',
      fileSize: doc.fileSize || '250 KB',
      documentType: doc.documentType || 'WARRANTY',
      uploadedAt: now,
      uploadedBy: normalizedUser.id
    };

    if (!asset.documents) asset.documents = [];
    asset.documents.unshift(newDoc);
    asset.updatedAt = now;

    database.assetTimelineEvents.unshift({
      id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      assetId: asset.id,
      eventType: 'DOCUMENT_ATTACHED',
      title: `Document Attached: ${newDoc.title}`,
      description: `Attached ${newDoc.fileName} (${newDoc.documentType || 'File'}).`,
      performedBy: normalizedUser.id,
      performedByName: normalizedUser.name,
      performedByRole: normalizedUser.role,
      timestamp: now
    });

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: asset.id,
      details: `Attached document '${newDoc.title}' to asset '${asset.name}' (${asset.assetTag}).`
    });

    return { asset, document: newDoc };
  }

  /**
   * Delete Document from an Asset
   */
  static deleteDocument(
    schoolId: string,
    assetId: string,
    docId: string,
    user: any
  ): { asset: Asset; message: string } {
    ensureInventoryCollections();
    const normalizedUser = normalizeUser(user);

    const asset = database.assets.find((a) => a.id === assetId && a.schoolId === schoolId);
    if (!asset) throw new Error(`Asset not found with ID '${assetId}'.`);

    if (!asset.documents) asset.documents = [];
    const index = asset.documents.findIndex((d) => d.id === docId);
    if (index === -1) {
      throw new Error('Document not found on this asset.');
    }

    const removed = asset.documents.splice(index, 1)[0];
    const now = new Date().toISOString();
    asset.updatedAt = now;

    database.assetTimelineEvents.unshift({
      id: `tl-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      schoolId,
      assetId: asset.id,
      eventType: 'DOCUMENT_REMOVED',
      title: `Document Removed: ${removed.title}`,
      description: `Removed document ${removed.fileName}.`,
      performedBy: normalizedUser.id,
      performedByName: normalizedUser.name,
      performedByRole: normalizedUser.role,
      timestamp: now
    });

    logAudit({
      userId: normalizedUser.id,
      userName: normalizedUser.name,
      userRole: normalizedUser.role,
      action: 'UPDATE',
      entity: 'OTHER',
      entityType: 'Asset',
      entityId: asset.id,
      details: `Removed document '${removed.title}' from asset '${asset.name}' (${asset.assetTag}).`
    });

    return { asset, message: 'Document removed successfully.' };
  }

  // ==========================================================================
  // TIMELINE & METRICS
  // ==========================================================================

  /**
   * Get complete timeline events for an asset
   */
  static getAssetTimeline(schoolId: string, assetId: string): AssetTimelineEvent[] {
    ensureInventoryCollections();
    return database.assetTimelineEvents
      .filter((t) => t.assetId === assetId && t.schoolId === schoolId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  /**
   * Get assignment history for an asset
   */
  static getAssetAssignments(schoolId: string, assetId: string): AssetAssignment[] {
    ensureInventoryCollections();
    return database.assetAssignments
      .filter((a) => a.assetId === assetId && a.schoolId === schoolId)
      .sort((a, b) => new Date(b.assignedDate).getTime() - new Date(a.assignedDate).getTime());
  }

  /**
   * Asset Lifecycle KPIs and Summary
   */
  static getAssetLifecycleSummary(schoolId: string): AssetLifecycleSummary {
    ensureInventoryCollections();
    const assets = database.assets.filter((a) => a.schoolId === schoolId);

    let availableAssets = 0;
    let assignedAssets = 0;
    let underRepairAssets = 0;
    let damagedAssets = 0;
    let lostAssets = 0;
    let retiredAssets = 0;
    let disposedAssets = 0;
    let activeWarranties = 0;
    let expiringWarranties = 0;
    let expiredWarranties = 0;
    let totalAssetValuation = 0;

    for (const a of assets) {
      totalAssetValuation += Number(a.purchaseCost) || 0;
      switch (a.status) {
        case 'AVAILABLE':
        case 'ACTIVE':
          availableAssets++;
          break;
        case 'ASSIGNED':
          assignedAssets++;
          break;
        case 'UNDER_REPAIR':
          underRepairAssets++;
          break;
        case 'DAMAGED':
          damagedAssets++;
          break;
        case 'LOST':
          lostAssets++;
          break;
        case 'RETIRED':
          retiredAssets++;
          break;
        case 'DISPOSED':
          disposedAssets++;
          break;
      }

      const wStatus = computeWarrantyStatus(a.warrantyEnd);
      if (wStatus === 'ACTIVE') activeWarranties++;
      else if (wStatus === 'EXPIRING_SOON') expiringWarranties++;
      else if (wStatus === 'EXPIRED') expiredWarranties++;
    }

    return {
      totalAssets: assets.length,
      availableAssets,
      assignedAssets,
      underRepairAssets,
      damagedAssets,
      lostAssets,
      retiredAssets,
      disposedAssets,
      activeWarranties,
      expiringWarranties,
      expiredWarranties,
      totalAssetValuation
    };
  }
}
