import { database } from '../db/database.js';
import {
  Conversation,
  MessageItem,
  MessageReport,
  ConversationParticipant,
  ConversationCategory,
  ConversationFilterParams,
  EligibleRecipient,
  UserRole,
  StudentProfile,
  Guardian,
  TeacherProfile,
  User
} from '../../src/types/index.js';
import { CommunicationService } from './communication.service.js';
import { logAudit } from '../security/audit.js';

export interface CreateConversationInput {
  recipientId: string;
  studentId?: string;
  subject: string;
  message: string;
  category?: ConversationCategory;
  attachments?: Array<{
    id?: string;
    name: string;
    size: string;
    sizeBytes?: number;
    type: string;
    url: string;
  }>;
  isDraft?: boolean;
}

export interface ReplyMessageInput {
  message: string;
  attachments?: Array<{
    id?: string;
    name: string;
    size: string;
    sizeBytes?: number;
    type: string;
    url: string;
  }>;
  idempotencyKey?: string;
}

export interface AuthenticatedUserContext {
  id: string;
  name: string;
  role: UserRole;
  email?: string;
  avatarUrl?: string;
}

export class MessagingService {
  /**
   * Strip dangerous HTML tags, attributes, and script protocols (XSS Defense)
   */
  public static sanitizeHtml(input: string): string {
    if (!input) return '';
    let sanitized = input;

    // Remove script tags and contents
    sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
    // Remove iframes, objects, embeds, applets, frames
    sanitized = sanitized.replace(/<(iframe|object|embed|applet|meta|link|base|form|input|button)\b[^>]*>/gi, '');
    sanitized = sanitized.replace(/<\/(iframe|object|embed|applet|meta|link|base|form|input|button)>/gi, '');
    // Remove javascript: and data: urls in href/src
    sanitized = sanitized.replace(/(href|src|action)\s*=\s*['"]\s*(javascript|data|vbscript):[^'"]*['"]/gi, '');
    // Strip on* event handlers (e.g. onload=, onerror=, onclick=)
    sanitized = sanitized.replace(/\son[a-zA-Z]+\s*=\s*(?:'[^']*'|"[^"]*"|[^\s>]+)/gi, '');

    // Trim and cap maximum character length to 10,000
    if (sanitized.length > 10000) {
      sanitized = sanitized.slice(0, 10000);
    }

    return sanitized.trim();
  }

  /**
   * Validate uploaded attachments for file size, extension, and allowed formats
   */
  public static validateAttachments(attachments?: any[]): Array<{
    id: string;
    name: string;
    size: string;
    sizeBytes?: number;
    type: string;
    url: string;
  }> {
    if (!attachments || !Array.isArray(attachments)) return [];

    const allowedExtensions = ['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'txt', 'csv', 'xls', 'xlsx'];
    const maxSizeBytes = 10 * 1024 * 1024; // 10MB
    const maxFiles = 5;

    if (attachments.length > maxFiles) {
      throw new Error(`Maximum ${maxFiles} attachments allowed per message.`);
    }

    return attachments.map((att, idx) => {
      const name = String(att.name || `attachment_${idx + 1}`).trim();
      const ext = name.split('.').pop()?.toLowerCase() || '';

      if (!allowedExtensions.includes(ext)) {
        throw new Error(`File type .${ext} is not permitted. Allowed: ${allowedExtensions.join(', ')}`);
      }

      const sizeBytes = Number(att.sizeBytes || 0);
      if (sizeBytes > maxSizeBytes) {
        throw new Error(`Attachment ${name} exceeds the maximum limit of 10MB.`);
      }

      return {
        id: att.id || `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name,
        size: att.size || (sizeBytes ? `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB` : '1.0 MB'),
        sizeBytes,
        type: att.type || 'application/octet-stream',
        url: att.url || ''
      };
    });
  }

  /**
   * Get authorized children for a parent/guardian user
   */
  public static getAuthorizedStudentsForGuardian(guardianUserId: string): Array<{
    student: StudentProfile;
    className: string;
    sectionName: string;
    relationshipType: string;
  }> {
    const guardian = database.guardians.find((g) => g.userId === guardianUserId);
    if (!guardian) return [];

    const studentIds = guardian.studentIds || [];
    const results: Array<{
      student: StudentProfile;
      className: string;
      sectionName: string;
      relationshipType: string;
    }> = [];

    for (const sid of studentIds) {
      const student = database.studentProfiles.find((s) => s.id === sid);
      if (!student) continue;

      // Check if communication is permitted via parentStudentRelationships
      const rel = database.parentStudentRelationships.find(
        (r) => r.guardianId === guardian.id && r.studentId === student.id
      );

      if (rel && rel.isAuthorizedCommunication === false) {
        continue; // Parent is explicitly restricted from communication for this child
      }

      const schoolClass = database.classes.find((c) => c.id === student.classId);
      const section = database.sections.find((sec) => sec.id === student.sectionId);

      results.push({
        student,
        className: schoolClass?.name || student.className || 'General Class',
        sectionName: section?.name || student.sectionName || 'Section',
        relationshipType: rel?.relationshipType || guardian.relationship || 'Guardian'
      });
    }

    return results;
  }

  /**
   * Get teachers authorized to communicate regarding a specific student
   */
  public static getAuthorizedTeachersForStudent(studentId: string): Array<{
    teacher: TeacherProfile;
    user: User;
    designation: string;
    context: string;
  }> {
    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) return [];

    const classId = student.classId;
    const sectionId = student.sectionId;
    const matchedTeachers = new Map<string, { teacher: TeacherProfile; user: User; designation: string; context: string }>();

    for (const teacher of database.teacherProfiles) {
      const user = database.users.find((u) => u.id === teacher.userId);
      if (!user || user.status !== 'active') continue;

      let isAssigned = false;
      let context = 'Assigned Faculty';

      // 1. Direct assigned class/section
      if (teacher.assignedClassIds?.includes(classId)) {
        isAssigned = true;
        context = `Class Faculty (${student.className || 'Class'})`;
      }

      // 2. Section / Class teacher
      const section = database.sections.find((sec) => sec.id === sectionId);
      if (section?.classTeacherId === teacher.id) {
        isAssigned = true;
        context = `Section Teacher (${section.name})`;
      } else if (database.sections.some((sec) => sec.classId === classId && sec.classTeacherId === teacher.id)) {
        isAssigned = true;
        context = `Faculty Advisor (${student.className || 'Class'})`;
      }

      // 3. Subject teacher for this class
      const subjects = database.subjects.filter(
        (sub) => sub.classId === classId && sub.teacherId === teacher.id
      );
      if (subjects.length > 0) {
        isAssigned = true;
        context = `Subject Teacher (${subjects.map((s) => s.name).join(', ')})`;
      }

      if (isAssigned) {
        matchedTeachers.set(user.id, {
          teacher,
          user,
          designation: teacher.designation || 'Teacher',
          context
        });
      }
    }

    return Array.from(matchedTeachers.values());
  }

  /**
   * Retrieve list of eligible recipients based on strict server-side relationship rules
   */
  public static getEligibleRecipients(
    currentUser: AuthenticatedUserContext,
    filterStudentId?: string
  ): EligibleRecipient[] {
    const recipients: EligibleRecipient[] = [];
    const seenUserIds = new Set<string>();

    if (currentUser.role === 'GUARDIAN') {
      const authorizedChildren = this.getAuthorizedStudentsForGuardian(currentUser.id);

      // If specific child requested, restrict to that child
      const targetChildren = filterStudentId
        ? authorizedChildren.filter((c) => c.student.id === filterStudentId)
        : authorizedChildren;

      for (const child of targetChildren) {
        const teachers = this.getAuthorizedTeachersForStudent(child.student.id);
        for (const t of teachers) {
          const key = `${t.user.id}:${child.student.id}`;
          if (!seenUserIds.has(key)) {
            seenUserIds.add(key);
            recipients.push({
              userId: t.user.id,
              name: t.user.name,
              role: 'TEACHER',
              email: t.user.email,
              avatarUrl: t.user.avatarUrl,
              designation: t.designation,
              relationshipContext: `${t.context} • ${child.student.firstName} ${child.student.lastName} (${child.className})`,
              studentId: child.student.id,
              studentName: `${child.student.firstName} ${child.student.lastName}`.trim(),
              className: child.className,
              sectionName: child.sectionName
            });
          }
        }
      }

      // Guardians can also contact School Administrators
      const admins = database.users.filter((u) => u.role === 'SUPER_ADMIN' && u.status === 'active');
      for (const admin of admins) {
        if (!seenUserIds.has(admin.id)) {
          seenUserIds.add(admin.id);
          recipients.push({
            userId: admin.id,
            name: admin.name,
            role: 'SUPER_ADMIN',
            email: admin.email,
            avatarUrl: admin.avatarUrl,
            designation: 'School Administration & Support',
            relationshipContext: 'Institutional Administrative Office'
          });
        }
      }
    } else if (currentUser.role === 'TEACHER') {
      const teacherProfile = database.teacherProfiles.find((t) => t.userId === currentUser.id);
      const assignedClassIds = teacherProfile?.assignedClassIds || [];

      // 1. Guardians of students enrolled in teacher's assigned classes
      const assignedStudents = database.studentProfiles.filter(
        (s) => assignedClassIds.includes(s.classId) && s.status !== 'archived'
      );

      for (const student of assignedStudents) {
        const studentGuardians = database.guardians.filter((g) => g.studentIds?.includes(student.id));
        for (const guard of studentGuardians) {
          const gUser = database.users.find((u) => u.id === guard.userId);
          if (gUser && gUser.status === 'active') {
            const key = `${gUser.id}:${student.id}`;
            if (!seenUserIds.has(key)) {
              seenUserIds.add(key);
              recipients.push({
                userId: gUser.id,
                name: gUser.name,
                role: 'GUARDIAN',
                email: gUser.email,
                avatarUrl: gUser.avatarUrl,
                designation: guard.relationship || 'Parent / Guardian',
                relationshipContext: `Parent of ${student.firstName} ${student.lastName} (${student.className || 'Class'})`,
                studentId: student.id,
                studentName: `${student.firstName} ${student.lastName}`.trim(),
                className: student.className,
                sectionName: student.sectionName
              });
            }
          }
        }
      }

      // 2. Colleague Teachers (Internal Staff Messaging)
      const colleagueUsers = database.users.filter(
        (u) => u.role === 'TEACHER' && u.id !== currentUser.id && u.status === 'active'
      );
      for (const colleague of colleagueUsers) {
        if (!seenUserIds.has(colleague.id)) {
          seenUserIds.add(colleague.id);
          const cProf = database.teacherProfiles.find((tp) => tp.userId === colleague.id);
          recipients.push({
            userId: colleague.id,
            name: colleague.name,
            role: 'TEACHER',
            email: colleague.email,
            avatarUrl: colleague.avatarUrl,
            designation: cProf?.designation || 'Faculty Colleague',
            relationshipContext: cProf?.departmentName || 'Academic Staff'
          });
        }
      }

      // 3. School Administrators
      const admins = database.users.filter((u) => u.role === 'SUPER_ADMIN' && u.status === 'active');
      for (const admin of admins) {
        if (!seenUserIds.has(admin.id)) {
          seenUserIds.add(admin.id);
          recipients.push({
            userId: admin.id,
            name: admin.name,
            role: 'SUPER_ADMIN',
            email: admin.email,
            avatarUrl: admin.avatarUrl,
            designation: 'School Administration & Principal',
            relationshipContext: 'Institutional Management'
          });
        }
      }
    } else if (currentUser.role === 'SUPER_ADMIN') {
      // Super Admin has oversight: can message any active teacher, guardian, or student
      const allUsers = database.users.filter((u) => u.id !== currentUser.id && u.status === 'active');
      for (const u of allUsers) {
        let designation = 'School Member';
        let relationshipContext = 'Institutional Directory';

        if (u.role === 'TEACHER') {
          const tp = database.teacherProfiles.find((t) => t.userId === u.id);
          designation = tp?.designation || 'Teacher';
          relationshipContext = tp?.departmentName || 'Academic Department';
        } else if (u.role === 'GUARDIAN') {
          const g = database.guardians.find((guard) => guard.userId === u.id);
          designation = 'Parent / Guardian';
          const childNames = database.studentProfiles
            .filter((s) => g?.studentIds?.includes(s.id))
            .map((s) => `${s.firstName} ${s.lastName}`)
            .join(', ');
          relationshipContext = childNames ? `Parent of ${childNames}` : 'Guardian Directory';
        } else if (u.role === 'STUDENT') {
          const s = database.studentProfiles.find((stud) => stud.userId === u.id);
          designation = `Student (${s?.className || 'Class'})`;
          relationshipContext = `Roll: ${s?.rollNumber || 'N/A'}`;
        }

        recipients.push({
          userId: u.id,
          name: u.name,
          role: u.role,
          email: u.email,
          avatarUrl: u.avatarUrl,
          designation,
          relationshipContext
        });
      }
    } else if (currentUser.role === 'STUDENT') {
      // Student can only message assigned teachers of their class/section or school admin
      const studentProfile = database.studentProfiles.find((s) => s.userId === currentUser.id);
      if (studentProfile) {
        const teachers = this.getAuthorizedTeachersForStudent(studentProfile.id);
        for (const t of teachers) {
          if (!seenUserIds.has(t.user.id)) {
            seenUserIds.add(t.user.id);
            recipients.push({
              userId: t.user.id,
              name: t.user.name,
              role: 'TEACHER',
              email: t.user.email,
              avatarUrl: t.user.avatarUrl,
              designation: t.designation,
              relationshipContext: t.context
            });
          }
        }
      }

      // Administrators
      const admins = database.users.filter((u) => u.role === 'SUPER_ADMIN' && u.status === 'active');
      for (const admin of admins) {
        if (!seenUserIds.has(admin.id)) {
          seenUserIds.add(admin.id);
          recipients.push({
            userId: admin.id,
            name: admin.name,
            role: 'SUPER_ADMIN',
            email: admin.email,
            avatarUrl: admin.avatarUrl,
            designation: 'School Administration',
            relationshipContext: 'Support & Guidance'
          });
        }
      }
    }

    return recipients;
  }

  /**
   * Strict server-side verification that recipient is legally authorized for communication
   */
  public static validateRecipientAuthorization(
    sender: AuthenticatedUserContext,
    recipientUserId: string,
    studentId?: string
  ): {
    recipientUser: User;
    studentProfile?: StudentProfile;
    category: ConversationCategory;
  } {
    const recipientUser = database.users.find((u) => u.id === recipientUserId);
    if (!recipientUser || recipientUser.status !== 'active') {
      throw new Error('Selected recipient does not exist or is inactive.');
    }

    if (sender.id === recipientUserId) {
      throw new Error('You cannot start a conversation with yourself.');
    }

    // Super Admin can communicate with any active user
    if (sender.role === 'SUPER_ADMIN' || recipientUser.role === 'SUPER_ADMIN') {
      let cat: ConversationCategory = 'administrative';
      if (sender.role === 'GUARDIAN' || recipientUser.role === 'GUARDIAN') {
        cat = 'parent_teacher';
      }
      return { recipientUser, category: cat };
    }

    // 1. GUARDIAN SENDER
    if (sender.role === 'GUARDIAN') {
      const authorizedChildren = this.getAuthorizedStudentsForGuardian(sender.id);
      if (authorizedChildren.length === 0) {
        throw new Error('No authorized children linked to your parent account.');
      }

      let matchedChild = studentId
        ? authorizedChildren.find((c) => c.student.id === studentId)
        : authorizedChildren[0];

      if (!matchedChild) {
        throw new Error('Invalid student context: Child is not linked to your parent account.');
      }

      // Verify recipient is an authorized teacher for this child
      const eligibleTeachers = this.getAuthorizedTeachersForStudent(matchedChild.student.id);
      const isEligible = eligibleTeachers.some((t) => t.user.id === recipientUserId);

      if (!isEligible) {
        throw new Error(
          'Unauthorized: You may only message teachers assigned to your child or authorized school administrators.'
        );
      }

      return {
        recipientUser,
        studentProfile: matchedChild.student,
        category: 'parent_teacher'
      };
    }

    // 2. TEACHER SENDER
    if (sender.role === 'TEACHER') {
      if (recipientUser.role === 'TEACHER') {
        return { recipientUser, category: 'staff_internal' };
      }

      if (recipientUser.role === 'GUARDIAN') {
        const guardian = database.guardians.find((g) => g.userId === recipientUserId);
        if (!guardian) {
          throw new Error('Guardian profile not found for recipient.');
        }

        const teacherProfile = database.teacherProfiles.find((t) => t.userId === sender.id);
        const assignedClassIds = teacherProfile?.assignedClassIds || [];

        // Verify that guardian's children are in one of teacher's assigned classes
        let studentProfile: StudentProfile | undefined;
        if (studentId) {
          studentProfile = database.studentProfiles.find(
            (s) => s.id === studentId && guardian.studentIds?.includes(s.id) && assignedClassIds.includes(s.classId)
          );
        } else {
          studentProfile = database.studentProfiles.find(
            (s) => guardian.studentIds?.includes(s.id) && assignedClassIds.includes(s.classId)
          );
        }

        if (!studentProfile) {
          throw new Error(
            'Unauthorized: You may only message parents of students currently enrolled in your assigned classes.'
          );
        }

        return {
          recipientUser,
          studentProfile,
          category: 'parent_teacher'
        };
      }
    }

    // 3. STUDENT SENDER
    if (sender.role === 'STUDENT') {
      const studentProfile = database.studentProfiles.find((s) => s.userId === sender.id);
      if (!studentProfile) {
        throw new Error('Student profile not found.');
      }

      const eligibleTeachers = this.getAuthorizedTeachersForStudent(studentProfile.id);
      const isEligible = eligibleTeachers.some((t) => t.user.id === recipientUserId);

      if (!isEligible) {
        throw new Error('Unauthorized: Students may only message teachers assigned to their class or section.');
      }

      return {
        recipientUser,
        studentProfile,
        category: 'student_teacher'
      };
    }

    throw new Error('Unauthorized communication relationship.');
  }

  /**
   * List conversations for the authenticated user with folder views and filters
   */
  public static listConversations(
    user: AuthenticatedUserContext,
    params: ConversationFilterParams = {}
  ): {
    data: Conversation[];
    unreadCount: number;
    pagination: { page: number; limit: number; total: number; totalPages: number };
  } {
    const { folder = 'inbox', category, search, studentId, unreadOnly, page = 1, limit = 20 } = params;

    let filtered = database.conversations.filter((conv) => {
      // Must be a participant (or super admin reviewing reports)
      const isParticipant = conv.participantIds.includes(user.id);
      if (!isParticipant) {
        if (folder === 'reported' && user.role === 'SUPER_ADMIN' && conv.isReported) {
          return true;
        }
        return false;
      }

      const participantInfo = conv.participants.find((p) => p.userId === user.id);
      if (!participantInfo || participantInfo.isDeleted) return false;

      // Handle Folders
      switch (folder) {
        case 'drafts':
          return conv.isDraft === true && conv.createdBy === user.id;
        case 'archived':
          return participantInfo.isArchived === true && !conv.isDraft;
        case 'starred':
          return participantInfo.isStarred === true && !conv.isDraft;
        case 'sent':
          return conv.createdBy === user.id && !conv.isDraft && !participantInfo.isArchived;
        case 'reported':
          return conv.isReported === true;
        case 'inbox':
        default:
          return !conv.isDraft && !participantInfo.isArchived;
      }
    });

    // Filter by studentId if specified
    if (studentId) {
      filtered = filtered.filter((c) => c.studentId === studentId);
    }

    // Filter by category
    if (category) {
      filtered = filtered.filter((c) => c.category === category);
    }

    // Filter by search query (subject, preview, participant name, child name)
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(
        (c) =>
          c.subject.toLowerCase().includes(q) ||
          c.lastMessagePreview.toLowerCase().includes(q) ||
          c.participants.some((p) => p.name.toLowerCase().includes(q)) ||
          (c.studentName && c.studentName.toLowerCase().includes(q))
      );
    }

    // Enrich conversations with per-user dynamic properties
    let enriched = filtered.map((c) => {
      const myPart = c.participants.find((p) => p.userId === user.id);
      const otherPart = c.participants.find((p) => p.userId !== user.id);

      // Compute unread count for current user
      let unread = 0;
      if (myPart) {
        const lastReadAt = myPart.lastReadAt ? new Date(myPart.lastReadAt).getTime() : 0;
        const msgs = database.messages.filter((m) => m.conversationId === c.id && m.senderId !== user.id);
        unread = msgs.filter((m) => new Date(m.createdAt).getTime() > lastReadAt).length;
      }

      return {
        ...c,
        unreadCount: unread,
        isArchivedForMe: !!myPart?.isArchived,
        isStarredForMe: !!myPart?.isStarred,
        otherParticipant: otherPart
      };
    });

    if (unreadOnly) {
      enriched = enriched.filter((c) => (c.unreadCount || 0) > 0);
    }

    // Sort by latest message date descending
    enriched.sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());

    // Calculate total unread count across all inbox items for this user
    const totalInboxUnread = database.conversations
      .filter((c) => c.participantIds.includes(user.id) && !c.isDraft)
      .reduce((sum, c) => {
        const myPart = c.participants.find((p) => p.userId === user.id);
        if (myPart?.isArchived) return sum;
        const lastReadAt = myPart?.lastReadAt ? new Date(myPart.lastReadAt).getTime() : 0;
        const unreadMsgs = database.messages.filter(
          (m) => m.conversationId === c.id && m.senderId !== user.id && new Date(m.createdAt).getTime() > lastReadAt
        ).length;
        return sum + (unreadMsgs > 0 ? 1 : 0);
      }, 0);

    const total = enriched.length;
    const startIndex = (page - 1) * limit;
    const paginated = enriched.slice(startIndex, startIndex + limit);

    return {
      data: paginated,
      unreadCount: totalInboxUnread,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1
      }
    };
  }

  /**
   * Get single conversation with full message thread, enforcing IDOR authorization
   */
  public static getConversationById(
    conversationId: string,
    user: AuthenticatedUserContext
  ): {
    conversation: Conversation;
    messages: MessageItem[];
  } {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) {
      throw new Error('Conversation not found.');
    }

    // IDOR Protection: Must be a participant, or Super Admin reviewing reports
    const isParticipant = conversation.participantIds.includes(user.id);
    const isAuthorized = isParticipant || (user.role === 'SUPER_ADMIN' && conversation.isReported);

    if (!isAuthorized) {
      throw new Error('Forbidden: You do not have permission to access this conversation thread.');
    }

    // Fetch messages for thread
    const threadMessages = database.messages
      .filter((m) => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    // Auto-mark as read for this participant if messages exist
    if (isParticipant && threadMessages.length > 0) {
      const myParticipant = conversation.participants.find((p) => p.userId === user.id);
      if (myParticipant) {
        const latestMsg = threadMessages[threadMessages.length - 1];
        myParticipant.lastReadMessageId = latestMsg.id;
        myParticipant.lastReadAt = new Date().toISOString();
      }
    }

    const otherPart = conversation.participants.find((p) => p.userId !== user.id);
    const myPart = conversation.participants.find((p) => p.userId === user.id);

    return {
      conversation: {
        ...conversation,
        isArchivedForMe: !!myPart?.isArchived,
        isStarredForMe: !!myPart?.isStarred,
        otherParticipant: otherPart
      },
      messages: threadMessages
    };
  }

  /**
   * Create a new conversation and send initial message
   */
  public static async createConversation(
    sender: AuthenticatedUserContext,
    input: CreateConversationInput
  ): Promise<{
    conversation: Conversation;
    message?: MessageItem;
  }> {
    const { recipientId, studentId, subject, message, isDraft = false } = input;

    if (!recipientId) {
      throw new Error('Recipient is required.');
    }

    const cleanSubject = this.sanitizeHtml(subject);
    if (!cleanSubject) {
      throw new Error('Subject cannot be empty.');
    }

    const cleanBody = this.sanitizeHtml(message);
    if (!cleanBody && !isDraft) {
      throw new Error('Message body cannot be empty.');
    }

    // Validate recipient authorization server-side
    const { recipientUser, studentProfile, category } = this.validateRecipientAuthorization(
      sender,
      recipientId,
      studentId
    );

    const now = new Date().toISOString();
    const convId = `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    // Prepare participants
    const participants: ConversationParticipant[] = [
      {
        userId: sender.id,
        name: sender.name,
        role: sender.role,
        email: sender.email,
        avatarUrl: sender.avatarUrl,
        isArchived: false,
        isStarred: false,
        lastReadAt: now
      },
      {
        userId: recipientUser.id,
        name: recipientUser.name,
        role: recipientUser.role,
        email: recipientUser.email,
        avatarUrl: recipientUser.avatarUrl,
        isArchived: false,
        isStarred: false
      }
    ];

    const validatedAttachments = this.validateAttachments(input.attachments);

    // If draft, store draft metadata
    if (isDraft) {
      const draftConv: Conversation = {
        id: convId,
        subject: cleanSubject,
        category,
        participants,
        participantIds: [sender.id, recipientUser.id],
        studentId: studentProfile?.id,
        studentName: studentProfile ? `${studentProfile.firstName} ${studentProfile.lastName}`.trim() : undefined,
        classId: studentProfile?.classId,
        className: studentProfile?.className,
        sectionId: studentProfile?.sectionId,
        sectionName: studentProfile?.sectionName,
        academicSessionId: studentProfile?.academicSessionId,
        academicSessionName: studentProfile?.academicSessionName,
        lastMessageAt: now,
        lastMessagePreview: `Draft: ${cleanSubject}`,
        isDraft: true,
        draftBody: cleanBody,
        draftRecipientId: recipientUser.id,
        status: 'active',
        createdBy: sender.id,
        createdByName: sender.name,
        createdByRole: sender.role,
        createdAt: now,
        updatedAt: now
      };

      database.conversations.unshift(draftConv);
      return { conversation: draftConv };
    }

    // Normal message creation
    const msgId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const initialMsg: MessageItem = {
      id: msgId,
      conversationId: convId,
      senderId: sender.id,
      senderName: sender.name,
      senderRole: sender.role,
      senderAvatarUrl: sender.avatarUrl,
      body: cleanBody,
      attachments: validatedAttachments,
      status: 'sent',
      createdAt: now
    };

    // Update sender's last read to this initial message
    participants[0].lastReadMessageId = msgId;
    participants[0].lastReadAt = now;

    const newConv: Conversation = {
      id: convId,
      subject: cleanSubject,
      category,
      participants,
      participantIds: [sender.id, recipientUser.id],
      studentId: studentProfile?.id,
      studentName: studentProfile ? `${studentProfile.firstName} ${studentProfile.lastName}`.trim() : undefined,
      classId: studentProfile?.classId,
      className: studentProfile?.className,
      sectionId: studentProfile?.sectionId,
      sectionName: studentProfile?.sectionName,
      academicSessionId: studentProfile?.academicSessionId,
      academicSessionName: studentProfile?.academicSessionName,
      lastMessageAt: now,
      lastMessagePreview: cleanBody.slice(0, 120),
      lastMessageId: msgId,
      lastSenderId: sender.id,
      lastSenderName: sender.name,
      status: 'active',
      createdBy: sender.id,
      createdByName: sender.name,
      createdByRole: sender.role,
      createdAt: now,
      updatedAt: now
    };

    database.conversations.unshift(newConv);
    database.messages.push(initialMsg);

    // Audit Log
    logAudit({
      userId: sender.id,
      userName: sender.name,
      userRole: sender.role,
      action: 'CONVERSATION_CREATE',
      entity: 'Conversation',
      entityType: 'Conversation',
      entityId: convId,
      details: `Created conversation "${cleanSubject}" with ${recipientUser.name} (${recipientUser.role})`
    });

    // Part 11A Notification Integration: Notify recipient
    try {
      await CommunicationService.dispatch({
        eventType: 'MESSAGE_RECEIVED',
        entityId: convId,
        entityType: 'Conversation',
        studentId: studentProfile?.id,
        variables: {
          sender_name: sender.name,
          sender_role: sender.role,
          subject: cleanSubject,
          preview: cleanBody.slice(0, 100),
          student_name: studentProfile ? `${studentProfile.firstName} ${studentProfile.lastName}`.trim() : ''
        },
        customRecipients: [
          {
            id: recipientUser.id,
            userId: recipientUser.id,
            name: recipientUser.name,
            role: recipientUser.role,
            contact: recipientUser.email
          }
        ],
        actorUser: {
          id: sender.id,
          name: sender.name,
          role: sender.role
        }
      });
    } catch (notifErr) {
      console.warn('Failed to dispatch notification alert for new message:', notifErr);
    }

    return { conversation: newConv, message: initialMsg };
  }

  /**
   * Reply to an existing conversation thread
   */
  public static async reply(
    conversationId: string,
    sender: AuthenticatedUserContext,
    input: ReplyMessageInput
  ): Promise<{
    message: MessageItem;
    conversation: Conversation;
  }> {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) {
      throw new Error('Conversation not found.');
    }

    // IDOR check: Sender must be a participant
    if (!conversation.participantIds.includes(sender.id)) {
      throw new Error('Forbidden: You are not a participant in this conversation.');
    }

    if (conversation.status === 'closed') {
      throw new Error('This conversation has been closed and cannot accept new replies.');
    }

    const cleanBody = this.sanitizeHtml(input.message);
    if (!cleanBody && (!input.attachments || input.attachments.length === 0)) {
      throw new Error('Reply body cannot be empty.');
    }

    // Duplicate message protection: reject identical message within 5 seconds
    const fiveSecondsAgo = Date.now() - 5000;
    const recentDuplicate = database.messages.find(
      (m) =>
        m.conversationId === conversationId &&
        m.senderId === sender.id &&
        m.body === cleanBody &&
        new Date(m.createdAt).getTime() > fiveSecondsAgo
    );
    if (recentDuplicate) {
      throw new Error('Duplicate message detected. Please wait before resubmitting.');
    }

    const validatedAttachments = this.validateAttachments(input.attachments);
    const now = new Date().toISOString();
    const msgId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const newMsg: MessageItem = {
      id: msgId,
      conversationId,
      senderId: sender.id,
      senderName: sender.name,
      senderRole: sender.role,
      senderAvatarUrl: sender.avatarUrl,
      body: cleanBody,
      attachments: validatedAttachments,
      status: 'sent',
      createdAt: now
    };

    database.messages.push(newMsg);

    // Update conversation metadata
    conversation.lastMessageAt = now;
    conversation.lastMessagePreview = cleanBody.slice(0, 120);
    conversation.lastMessageId = msgId;
    conversation.lastSenderId = sender.id;
    conversation.lastSenderName = sender.name;
    conversation.updatedAt = now;

    // Update sender's read status & unarchive for other participants
    for (const p of conversation.participants) {
      if (p.userId === sender.id) {
        p.lastReadMessageId = msgId;
        p.lastReadAt = now;
      } else {
        // Automatically bring back to active inbox if other participant had archived it
        p.isArchived = false;
      }
    }

    // Audit Log
    logAudit({
      userId: sender.id,
      userName: sender.name,
      userRole: sender.role,
      action: 'MESSAGE_SEND',
      entity: 'Message',
      entityType: 'Message',
      entityId: msgId,
      details: `Sent reply in conversation "${conversation.subject}"`
    });

    // Notify other participants via Part 11A
    const otherParticipants = conversation.participants.filter((p) => p.userId !== sender.id);
    try {
      await CommunicationService.dispatch({
        eventType: 'MESSAGE_RECEIVED',
        entityId: conversation.id,
        entityType: 'Conversation',
        studentId: conversation.studentId,
        variables: {
          sender_name: sender.name,
          sender_role: sender.role,
          subject: conversation.subject,
          preview: cleanBody.slice(0, 100),
          student_name: conversation.studentName || ''
        },
        customRecipients: otherParticipants.map((p) => ({
          id: p.userId,
          userId: p.userId,
          name: p.name,
          role: p.role,
          contact: p.email
        })),
        actorUser: {
          id: sender.id,
          name: sender.name,
          role: sender.role
        }
      });
    } catch (err) {
      console.warn('Failed to dispatch notification for reply:', err);
    }

    return { message: newMsg, conversation };
  }

  /**
   * Mark conversation as read for the requesting user
   */
  public static markAsRead(conversationId: string, userId: string): boolean {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) return false;

    const participant = conversation.participants.find((p) => p.userId === userId);
    if (!participant) return false;

    const msgs = database.messages.filter((m) => m.conversationId === conversationId);
    if (msgs.length > 0) {
      const latest = msgs[msgs.length - 1];
      participant.lastReadMessageId = latest.id;
      participant.lastReadAt = new Date().toISOString();
    }
    return true;
  }

  /**
   * Mark conversation as unread for the requesting user
   */
  public static markAsUnread(conversationId: string, userId: string): boolean {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) return false;

    const participant = conversation.participants.find((p) => p.userId === userId);
    if (!participant) return false;

    participant.lastReadMessageId = undefined;
    participant.lastReadAt = new Date(0).toISOString();
    return true;
  }

  /**
   * Toggle archive state of a conversation for the requesting user
   */
  public static toggleArchive(conversationId: string, userId: string): boolean {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) return false;

    const participant = conversation.participants.find((p) => p.userId === userId);
    if (!participant) return false;

    participant.isArchived = !participant.isArchived;

    logAudit({
      userId,
      userName: participant.name,
      userRole: participant.role,
      action: 'CONVERSATION_ARCHIVE',
      entity: 'Conversation',
      entityType: 'Conversation',
      entityId: conversationId,
      details: `${participant.isArchived ? 'Archived' : 'Unarchived'} conversation "${conversation.subject}"`
    });

    return !!participant.isArchived;
  }

  /**
   * Toggle star state of a conversation for the requesting user
   */
  public static toggleStar(conversationId: string, userId: string): boolean {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) return false;

    const participant = conversation.participants.find((p) => p.userId === userId);
    if (!participant) return false;

    participant.isStarred = !participant.isStarred;
    return !!participant.isStarred;
  }

  /**
   * Report an inappropriate conversation/message to administration
   */
  public static reportConversation(
    conversationId: string,
    reporter: AuthenticatedUserContext,
    reason: MessageReport['reason'],
    details?: string
  ): MessageReport {
    const conversation = database.conversations.find((c) => c.id === conversationId);
    if (!conversation) {
      throw new Error('Conversation not found.');
    }

    if (!conversation.participantIds.includes(reporter.id) && reporter.role !== 'SUPER_ADMIN') {
      throw new Error('Forbidden: You can only report conversations you participate in.');
    }

    conversation.isReported = true;
    conversation.reportReason = reason;
    conversation.reportedBy = reporter.id;
    conversation.reportedAt = new Date().toISOString();

    const report: MessageReport = {
      id: `rep-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      conversationId,
      reporterUserId: reporter.id,
      reporterName: reporter.name,
      reporterRole: reporter.role,
      reason,
      details: this.sanitizeHtml(details || ''),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    database.messageReports.unshift(report);

    logAudit({
      userId: reporter.id,
      userName: reporter.name,
      userRole: reporter.role,
      action: 'MESSAGE_REPORT',
      entity: 'Conversation',
      entityType: 'Conversation',
      entityId: conversationId,
      details: `Reported conversation "${conversation.subject}" for ${reason}`
    });

    return report;
  }

  /**
   * Get moderation reports (Admin only)
   */
  public static getReports(): MessageReport[] {
    return database.messageReports;
  }

  /**
   * Resolve moderation report (Admin only)
   */
  public static resolveReport(
    reportId: string,
    adminUser: AuthenticatedUserContext,
    status: 'reviewed' | 'dismissed' | 'action_taken',
    resolutionNotes?: string
  ): MessageReport {
    const report = database.messageReports.find((r) => r.id === reportId);
    if (!report) {
      throw new Error('Report not found.');
    }

    report.status = status;
    report.resolutionNotes = this.sanitizeHtml(resolutionNotes || '');
    report.resolvedAt = new Date().toISOString();
    report.resolvedBy = adminUser.id;

    logAudit({
      userId: adminUser.id,
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'REPORT_RESOLVE',
      entity: 'MessageReport',
      entityType: 'MessageReport',
      entityId: reportId,
      details: `Resolved report with status ${status}`
    });

    return report;
  }

  /**
   * Get total unread count for user badge
   */
  public static getUnreadCount(userId: string): number {
    return database.conversations
      .filter((c) => c.participantIds.includes(userId) && !c.isDraft)
      .reduce((sum, c) => {
        const myPart = c.participants.find((p) => p.userId === userId);
        if (myPart?.isArchived) return sum;
        const lastReadAt = myPart?.lastReadAt ? new Date(myPart.lastReadAt).getTime() : 0;
        const unreadMsgs = database.messages.filter(
          (m) => m.conversationId === c.id && m.senderId !== userId && new Date(m.createdAt).getTime() > lastReadAt
        ).length;
        return sum + (unreadMsgs > 0 ? 1 : 0);
      }, 0);
  }
}
