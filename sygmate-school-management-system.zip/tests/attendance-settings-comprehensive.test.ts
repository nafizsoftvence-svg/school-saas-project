import assert from 'node:assert';
import { database } from '../server/db/database.js';
import { getRolePermissions, hasPermission } from '../server/security/rbac.js';
import { AttendanceNotificationService } from '../server/services/attendance-notifications.service.js';

console.log('================================================================');
console.log('--- COMPREHENSIVE ATTENDANCE SETTINGS & TEACHER RULES TESTS ---');
console.log('================================================================');

// -----------------------------------------------------------------------------
// TEST 1: System Authoritative Academic Session & School Context
// -----------------------------------------------------------------------------
console.log('\n[TEST 1] Verifying System Academic Session & School Context...');
const activeSession = database.academicSessions.find((s) => s.isActive);
assert(activeSession, 'Active academic session must be defined');
assert.strictEqual(activeSession.id, 'session-2026-2027');
assert.strictEqual(activeSession.sessionName, '2026-2027 Academic Year');

const schoolSettings = database.schoolSettings;
assert(schoolSettings, 'School settings must exist');
assert.strictEqual(schoolSettings.academicSessionId, 'session-2026-2027');
console.log('✓ Academic Session 2026-2027 and School Context authoritative and verified.');

// -----------------------------------------------------------------------------
// TEST 2: Attendance Settings Data Model & Teacher Attendance Rules
// -----------------------------------------------------------------------------
console.log('\n[TEST 2] Verifying Attendance Settings & Teacher Attendance Rules Structure...');
const attSettings = database.attendanceSettings;
assert(attSettings, 'Attendance settings must exist');
assert(attSettings.teacherAttendance, 'Teacher attendance rules must be configured');
assert.strictEqual(typeof attSettings.teacherAttendance.enabled, 'boolean');
assert.strictEqual(typeof attSettings.teacherAttendance.checkInStartTime, 'string');
assert.strictEqual(typeof attSettings.teacherAttendance.cutoffTime, 'string');
assert.strictEqual(typeof attSettings.teacherAttendance.lateThresholdMinutes, 'number');
assert.strictEqual(typeof attSettings.teacherAttendance.halfDayThresholdMinutes, 'number');
assert(attSettings.workingDays.length >= 5, 'Working days must include standard week');
assert(attSettings.weekendDays.length >= 2, 'Weekend days must be defined');
assert(attSettings.attendanceStatuses.length >= 4, 'Core attendance statuses must exist');
console.log('✓ Teacher attendance rules and settings verified.');

// -----------------------------------------------------------------------------
// TEST 3: RBAC Roles and Permissions
// -----------------------------------------------------------------------------
console.log('\n[TEST 3] Verifying RBAC Boundaries and Normalization...');
assert(hasPermission('SUPER_ADMIN', 'attendance.view'), 'SUPER_ADMIN has attendance.view');
assert(hasPermission('SUPER_ADMIN', 'attendance.manage'), 'SUPER_ADMIN has attendance.manage');
assert(hasPermission('SUPER_ADMIN', 'teacher.attendance.manage'), 'SUPER_ADMIN has teacher.attendance.manage');

// Verify normalization for ADMIN alias
assert(hasPermission('ADMIN' as any, 'attendance.view'), 'ADMIN alias has attendance.view');
assert(hasPermission('ADMIN' as any, 'attendance.manage'), 'ADMIN alias has attendance.manage');
assert(hasPermission('ADMIN' as any, 'teacher.attendance.manage'), 'ADMIN alias has teacher.attendance.manage');

// Unauthorized roles check
assert(!hasPermission('STUDENT', 'attendance.manage'), 'STUDENT must NOT have attendance.manage');
assert(!hasPermission('GUARDIAN', 'attendance.manage'), 'GUARDIAN must NOT have attendance.manage');
assert(!hasPermission('STUDENT', 'teacher.attendance.manage'), 'STUDENT must NOT have teacher.attendance.manage');
console.log('✓ RBAC boundaries and ADMIN normalization confirmed.');

// -----------------------------------------------------------------------------
// TEST 4: Attendance Notification Settings & Templates (Subtabs 6, 7, 8)
// -----------------------------------------------------------------------------
console.log('\n[TEST 4] Verifying Notification Subtabs Integration...');
const notifSettings = AttendanceNotificationService.getSettings();
assert(notifSettings, 'Attendance notification settings must be available');
assert(notifSettings.studentAbsentAlert, 'Student absent alert configuration must exist');
assert.strictEqual(typeof notifSettings.studentAbsentAlert.enabled, 'boolean');

const templates = AttendanceNotificationService.getTemplates();
assert(Array.isArray(templates) && templates.length > 0, 'Notification templates must exist');

const logs = AttendanceNotificationService.getLogs();
assert(Array.isArray(logs), 'Notification logs queue must be an array');
console.log('✓ Notification settings, templates, and logs operational.');

// -----------------------------------------------------------------------------
// TEST 5: Academic Calendar & Holiday Rosters
// -----------------------------------------------------------------------------
console.log('\n[TEST 5] Verifying Academic Calendar & Holiday Roster...');
const holidays = database.holidays || [];
assert(Array.isArray(holidays), 'Holidays array must exist');
const specialWorkingDays = database.specialWorkingDays || [];
assert(Array.isArray(specialWorkingDays), 'Special working days array must exist');
console.log('✓ Calendar and holiday roster data collections verified.');

console.log('\n================================================================');
console.log('--- ALL ATTENDANCE SETTINGS COMPREHENSIVE TESTS PASSED! ---');
console.log('================================================================\n');
