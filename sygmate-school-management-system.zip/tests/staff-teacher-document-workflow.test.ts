/**
 * Part 15E — Staff, Teacher, Parent & School Document Management Test Suite
 * Sygmate School Management System
 * Validates:
 * 1. Unified central document ownership model (Teacher, Staff, Parent, School)
 * 2. Teacher Document Management & authoritative checklist compliance calculation
 * 3. Teacher document verification with mandatory rejection reason enforcement
 * 4. Staff / HR document lifecycle (Required -> Submitted -> Pending -> Verified -> Expired -> Replaced)
 * 5. Expiring Staff / Teacher documents tracking (days remaining, expiring soon, expired)
 * 6. Parent / Guardian document management with strict cross-family IDOR isolation
 * 7. School / Administrative documents with strict RBAC & confidentiality protection
 * 8. Configurable Document Requirements with duplicate active prevention
 */

import { database } from '../server/db/database.js';
import { DocumentService } from '../server/services/document.service.js';
import { User, DocumentRequirementConfig } from '../src/types/index.js';

const mockAdminUser: User = {
  id: 'usr-admin-1',
  name: 'System Admin',
  email: 'admin@sygmate.edu',
  username: 'admin',
  role: 'SUPER_ADMIN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockTeacherUser: User = {
  id: 'usr-teacher-1',
  name: 'Sarah Jenkins',
  email: 'sarah.jenkins@sygmate.edu',
  username: 'sarah.jenkins',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockOtherTeacherUser: User = {
  id: 'usr-teacher-2',
  name: 'Marcus Brody',
  email: 'marcus.brody@sygmate.edu',
  username: 'marcus.brody',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockGuardianUserA: User = {
  id: 'usr-guardian-1',
  name: 'Mark Johnson',
  email: 'mark.johnson@example.com',
  username: 'mark.johnson',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockGuardianUserB: User = {
  id: 'usr-guardian-2',
  name: 'Elena Rostova',
  email: 'elena.rostova@example.com',
  username: 'elena.rostova',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockStudentUser: User = {
  id: 'usr-student-1',
  name: 'Liam Johnson',
  email: 'liam@sygmate.edu',
  username: 'liam.johnson',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const schoolId = 'school-main';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[ASSERTION FAILED]: ${message}`);
  }
}

async function runPart15ETests() {
  console.log('--- STARTING PART 15E STAFF, TEACHER, PARENT & SCHOOL DOCUMENT TESTS ---');

  // Find demo entities
  const teacherProfile = database.teacherProfiles.find(t => t.userId === mockTeacherUser.id) || database.teacherProfiles[0];
  const otherTeacherProfile = database.teacherProfiles.find(t => t.id !== teacherProfile.id) || database.teacherProfiles[1];
  const staffProfile = database.staffProfiles[0];
  const guardianProfileA = database.guardians.find(g => g.userId === mockGuardianUserA.id) || database.guardians[0];
  const guardianProfileB = database.guardians.find(g => g.id !== guardianProfileA.id) || database.guardians[1];

  console.log(`Using Teacher: ${teacherProfile.id} (${teacherProfile.firstName} ${teacherProfile.lastName})`);
  console.log(`Using Staff: ${staffProfile.id} (${staffProfile.displayName})`);
  console.log(`Using Guardian A: ${guardianProfileA.id} (${guardianProfileA.name})`);
  console.log(`Using Guardian B: ${guardianProfileB.id} (${guardianProfileB.name})`);

  // ==============================================================
  // TEST 1: Document Requirement Management & Duplicate Prevention
  // ==============================================================
  console.log('\n[TEST 1] Testing Document Requirement Configuration & Duplicate Prevention...');

  const licenseDocType = database.documentTypes.find(dt => dt.code === 'DOC_TEACHING_LICENSE') || database.documentTypes[0];

  // Try creating a duplicate requirement that already exists in seed for TEACHER + DOC_TEACHING_LICENSE + ALL
  let duplicatePrevented = false;
  try {
    DocumentService.createDocumentRequirement(
      schoolId,
      {
        entityType: 'TEACHER',
        documentTypeId: licenseDocType.id,
        isRequired: true,
        applicableRole: 'ALL',
        description: 'Duplicate should fail'
      },
      mockAdminUser
    );
  } catch (err: any) {
    duplicatePrevented = true;
    console.log(`✓ Duplicate active requirement correctly blocked: "${err.message}"`);
  }
  assert(duplicatePrevented, 'Duplicate active document requirement must be prevented server-side.');

  // Create valid distinct requirement for specific role
  const customReq = DocumentService.createDocumentRequirement(
    schoolId,
    {
      entityType: 'TEACHER',
      documentTypeId: licenseDocType.id,
      isRequired: true,
      applicableRole: 'HEAD_OF_DEPARTMENT',
      description: 'Department Head Board Certification'
    },
    mockAdminUser
  );
  assert(customReq.applicableRole === 'HEAD_OF_DEPARTMENT', 'Requirement should be created with role scoping.');
  console.log(`✓ Custom requirement successfully created: ${customReq.documentTypeName} (Role: ${customReq.applicableRole})`);

  // ==============================================================
  // TEST 2: Teacher Document Upload & Checklist Compliance
  // ==============================================================
  console.log('\n[TEST 2] Testing Teacher Document Upload & Checklist Compliance...');

  const degreeDocType = database.documentTypes.find(dt => dt.code === 'DOC_DEGREE_DIPLOMA') || database.documentTypes[0];

  const teacherDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: degreeDocType.id,
      entityType: 'TEACHER',
      entityId: teacherProfile.id,
      documentTitle: 'Master of Science in Mathematics Diploma',
      referenceNumber: 'MIT-DEG-2018-994',
      fileName: 'msc_mathematics_diploma.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '1.8 MB'
    },
    mockAdminUser
  );

  assert(teacherDoc.entityType === 'TEACHER', 'Entity type must be TEACHER.');
  assert(teacherDoc.entityId === teacherProfile.id, 'Entity ID must match teacher profile.');
  assert(teacherDoc.status === 'UPLOADED', 'New document status must be UPLOADED.');
  console.log(`✓ Teacher document uploaded: "${teacherDoc.documentTitle}" (${teacherDoc.status})`);

  // Calculate teacher checklist
  const teacherChecklist = DocumentService.getEntityDocumentChecklist(
    schoolId,
    'TEACHER',
    teacherProfile.id,
    mockAdminUser
  );

  assert(teacherChecklist.totalRequired >= 5, 'Teacher should have configured required documents.');
  assert(teacherChecklist.submitted >= 1, 'Submitted count should reflect newly uploaded document.');
  assert(teacherChecklist.compliancePercentage === 0, 'Compliance should be 0% when documents are not yet verified.');
  console.log(`✓ Teacher checklist calculated: ${teacherChecklist.items.length} items, Compliance: ${teacherChecklist.compliancePercentage}%, Missing: ${teacherChecklist.missing}`);

  const degreeItem = teacherChecklist.items.find(i => i.documentTypeId === degreeDocType.id);
  assert(degreeItem?.status === 'PENDING_REVIEW', 'Newly uploaded unverified document should be PENDING_REVIEW in checklist.');
  console.log(`✓ Degree certificate checklist state verified: ${degreeItem.status}`);

  // ==============================================================
  // TEST 3: Verification Review & Mandatory Rejection Reason
  // ==============================================================
  console.log('\n[TEST 3] Testing Verification Review & Mandatory Rejection Reason...');

  let rejectionWithoutReasonBlocked = false;
  try {
    DocumentService.verifyDocument(
      schoolId,
      teacherDoc.id,
      {
        verificationStatus: 'REJECTED',
        rejectionReason: '   ' // empty reason
      },
      mockAdminUser
    );
  } catch (err: any) {
    rejectionWithoutReasonBlocked = true;
    console.log(`✓ Rejection without reason correctly blocked: "${err.message}"`);
  }
  assert(rejectionWithoutReasonBlocked, 'Rejecting a document without a mandatory reason must be rejected server-side.');

  // Reject with valid reason
  const rejectedDoc = DocumentService.verifyDocument(
    schoolId,
    teacherDoc.id,
    {
      verificationStatus: 'REJECTED',
      rejectionReason: 'The university seal on page 1 is illegible in this scan.'
    },
    mockAdminUser
  );
  assert(rejectedDoc.verificationStatus === 'REJECTED', 'Status must be REJECTED.');
  assert(rejectedDoc.verificationRemarks?.includes('illegible'), 'Remarks must record rejection reason.');
  console.log(`✓ Teacher document rejected with reason: "${rejectedDoc.verificationRemarks}"`);

  // Teacher re-uploads new version (v2)
  const reuploadedDoc = DocumentService.uploadNewVersion(
    schoolId,
    rejectedDoc.id,
    {
      fileName: 'msc_mathematics_diploma_highres.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '2.4 MB',
      changeNotes: 'Re-scanned at 600 DPI with clear registrar seal.'
    },
    mockAdminUser
  );
  assert(reuploadedDoc.version === 2, 'Version must be incremented to 2.');
  assert(reuploadedDoc.verificationStatus === 'PENDING_REVIEW', 'Re-uploaded document must reset to PENDING_REVIEW.');
  assert(reuploadedDoc.status === 'UPLOADED', 'Document status must reset to UPLOADED.');
  console.log(`✓ Teacher document re-uploaded (v2), reset to ${reuploadedDoc.status}`);

  // Admin approves & verifies v2
  const verifiedDoc = DocumentService.verifyDocument(
    schoolId,
    reuploadedDoc.id,
    {
      verificationStatus: 'VERIFIED',
      verificationRemarks: 'Authenticated against University Registrar records.'
    },
    mockAdminUser
  );
  assert(verifiedDoc.verificationStatus === 'VERIFIED', 'Status must be VERIFIED.');
  assert(verifiedDoc.status === 'VERIFIED', 'Document state must be VERIFIED.');
  console.log(`✓ Teacher document verified by ${mockAdminUser.name}`);

  // Re-check checklist compliance
  const updatedChecklist = DocumentService.getEntityDocumentChecklist(
    schoolId,
    'TEACHER',
    teacherProfile.id,
    mockAdminUser
  );
  assert(updatedChecklist.verified >= 1, 'Verified count must increase.');
  assert(updatedChecklist.compliancePercentage > 0, 'Compliance percentage must be > 0% after verification.');
  console.log(`✓ Updated compliance: Verified items=${updatedChecklist.verified}, Compliance=${updatedChecklist.compliancePercentage}%`);

  // ==============================================================
  // TEST 4: Staff / HR Document Management & Lifecycle
  // ==============================================================
  console.log('\n[TEST 4] Testing Staff / HR Document Management & Lifecycle...');

  const contractDocType = database.documentTypes.find(dt => dt.code === 'DOC_EMPLOYMENT_CONTRACT') || database.documentTypes[0];

  const staffDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: contractDocType.id,
      entityType: 'STAFF',
      entityId: staffProfile.id,
      documentTitle: 'Annual Faculty Employment Contract 2026-2027',
      referenceNumber: 'EMP-ADM-1001',
      fileName: 'employment_contract_2026.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '1.1 MB'
    },
    mockAdminUser
  );
  assert(staffDoc.entityType === 'STAFF', 'Document must belong to STAFF entity.');
  assert(staffDoc.entityId === staffProfile.id, 'Document entityId must match staff profile ID.');
  console.log(`✓ Staff HR document attached: "${staffDoc.documentTitle}" (${staffDoc.referenceNumber})`);

  // Verify staff document
  const verifiedStaffDoc = DocumentService.verifyDocument(
    schoolId,
    staffDoc.id,
    {
      verificationStatus: 'VERIFIED',
      verificationRemarks: 'Approved by School HR Director.'
    },
    mockAdminUser
  );
  assert(verifiedStaffDoc.verificationStatus === 'VERIFIED', 'Staff document must be verified.');
  console.log(`✓ Staff HR document verified.`);

  // ==============================================================
  // TEST 5: Expiring Staff / Teacher Documents Tracking
  // ==============================================================
  console.log('\n[TEST 5] Testing Expiring Document Tracking & Horizon Calculations...');

  const now = new Date();
  const expiringDate = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; // in 15 days
  const expiredDate = new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; // 10 days ago

  // Create an expiring document
  const expiringDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: licenseDocType.id,
      entityType: 'TEACHER',
      entityId: teacherProfile.id,
      documentTitle: 'State Teaching Credential (Expiring Soon)',
      expiryDate: expiringDate,
      fileName: 'state_teaching_credential.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '950 KB'
    },
    mockAdminUser
  );

  // Create an already expired document
  const expiredDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: database.documentTypes.find(dt => dt.code === 'DOC_FIRST_AID')?.id || licenseDocType.id,
      entityType: 'STAFF',
      entityId: staffProfile.id,
      documentTitle: 'Safety First-Aid Certificate (Expired)',
      expiryDate: expiredDate,
      fileName: 'first_aid_certificate.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '820 KB'
    },
    mockAdminUser
  );

  // Retrieve expiring documents within 30-day horizon
  const expiringList = DocumentService.getExpiringDocuments(
    schoolId,
    { daysThreshold: 30 },
    mockAdminUser
  );

  const foundExpiring = expiringList.find(e => e.document.id === expiringDoc.id);
  assert(Boolean(foundExpiring), 'Expiring document within 15 days must appear in expiring documents query.');
  assert(foundExpiring!.isExpiringSoon === true, 'isExpiringSoon must be true.');
  assert(foundExpiring!.isExpired === false, 'isExpired must be false.');
  console.log(`✓ Expiring Soon detected: "${foundExpiring!.document.documentTitle}" (${foundExpiring!.daysRemaining} days remaining)`);

  const foundExpired = expiringList.find(e => e.document.id === expiredDoc.id);
  assert(Boolean(foundExpired), 'Overdue expired document must appear in expiring documents query.');
  assert(foundExpired!.isExpired === true, 'isExpired must be true for overdue document.');
  console.log(`✓ Expired document detected: "${foundExpired!.document.documentTitle}" (${foundExpired!.daysRemaining} days overdue)`);

  // ==============================================================
  // TEST 6: Parent / Guardian Document Management & Access Control
  // ==============================================================
  console.log('\n[TEST 6] Testing Guardian Document Management & Cross-Family Isolation...');

  const guardianIdDocType = database.documentTypes.find(dt => dt.code === 'DOC_GUARDIAN_ID') || database.documentTypes[0];

  // Admin attaches ID to Guardian A
  const guardianDocA = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: guardianIdDocType.id,
      entityType: 'GUARDIAN',
      entityId: guardianProfileA.id,
      documentTitle: `Parent National Passport (${guardianProfileA.name})`,
      referenceNumber: 'PASS-USA-88902',
      fileName: 'guardian_passport.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '1.5 MB'
    },
    mockAdminUser
  );
  assert(guardianDocA.entityType === 'GUARDIAN', 'Entity type must be GUARDIAN.');
  assert(guardianDocA.entityId === guardianProfileA.id, 'Entity ID must be Guardian A ID.');
  console.log(`✓ Guardian document created: "${guardianDocA.documentTitle}"`);

  // Verify Guardian B CANNOT view Guardian A's document (IDOR protection)
  const canGuardianBAccess = DocumentService.validateDocumentAccess(
    guardianDocA,
    mockGuardianUserB,
    'view'
  );
  assert(!canGuardianBAccess, 'Cross-family access must be strictly forbidden! Guardian B cannot inspect Guardian A documents.');
  console.log(`✓ Cross-family IDOR protection confirmed: Guardian B blocked from Guardian A document.`);

  // Verify Guardian B CANNOT upload document claiming to be Guardian A
  let guardianBAttackingGuardianABlocked = false;
  try {
    DocumentService.createDocument(
      schoolId,
      {
        documentTypeId: guardianIdDocType.id,
        entityType: 'GUARDIAN',
        entityId: guardianProfileA.id, // trying to upload into Guardian A
        documentTitle: 'Malicious Parent Document',
        fileName: 'malicious.pdf',
        fileUrl: 'https://example.com/malicious.pdf',
        fileType: 'application/pdf',
        fileSize: '1.0 MB'
      },
      mockGuardianUserB
    );
  } catch (err: any) {
    guardianBAttackingGuardianABlocked = true;
    console.log(`✓ Guardian upload IDOR blocked: "${err.message}"`);
  }
  assert(guardianBAttackingGuardianABlocked, 'Guardian must not be allowed to attach documents to other families/guardians.');

  // ==============================================================
  // TEST 7: School / Administrative Documents & Strict Confidentiality
  // ==============================================================
  console.log('\n[TEST 7] Testing School Institutional Documents & Strict Confidentiality...');

  const schoolLicDocType = database.documentTypes.find(dt => dt.code === 'DOC_SCHOOL_LICENSE') || database.documentTypes[0];

  const schoolDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: schoolLicDocType.id,
      entityType: 'SCHOOL',
      entityId: schoolId,
      documentTitle: 'State Ministry Educational Charter & Operating License 2026-2030',
      referenceNumber: 'MIN-CHARTER-2026-A1',
      fileName: 'ministry_operating_charter.pdf',
      fileUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
      fileType: 'application/pdf',
      fileSize: '3.2 MB',
      isConfidential: true
    },
    mockAdminUser
  );
  assert(schoolDoc.entityType === 'SCHOOL', 'Entity type must be SCHOOL.');
  assert(schoolDoc.isConfidential === true, 'Confidentiality flag must be respected.');
  console.log(`✓ Institutional school document registered: "${schoolDoc.documentTitle}" (Confidential: ${schoolDoc.isConfidential})`);

  // Verify non-admin users cannot upload school-level documents
  let teacherUploadSchoolBlocked = false;
  try {
    DocumentService.createDocument(
      schoolId,
      {
        documentTypeId: schoolLicDocType.id,
        entityType: 'SCHOOL',
        entityId: schoolId,
        documentTitle: 'Unauthorized Faculty School Policy',
        fileName: 'policy.pdf',
        fileUrl: 'https://example.com/policy.pdf',
        fileType: 'application/pdf',
        fileSize: '1.0 MB'
      },
      mockTeacherUser
    );
  } catch (err: any) {
    teacherUploadSchoolBlocked = true;
    console.log(`✓ Non-admin school document upload blocked: "${err.message}"`);
  }
  assert(teacherUploadSchoolBlocked, 'Only administrators can create institutional school records.');

  // Verify confidential school documents are protected from student and teacher access
  const teacherAccessConfidentialSchool = DocumentService.validateDocumentAccess(schoolDoc, mockTeacherUser, 'view');
  assert(!teacherAccessConfidentialSchool, 'Teachers must NOT have access to confidential administrative school documents.');

  const studentAccessSchool = DocumentService.validateDocumentAccess(schoolDoc, mockStudentUser, 'view');
  assert(!studentAccessSchool, 'Students must NOT have access to confidential administrative school documents.');

  const adminAccessSchool = DocumentService.validateDocumentAccess(schoolDoc, mockAdminUser, 'view');
  assert(adminAccessSchool, 'Super Admin must have access to school administrative documents.');
  console.log(`✓ Strict RBAC & confidentiality protection confirmed for school administrative records.`);

  // ==============================================================
  // TEST 8: Teacher Privacy & Cross-Teacher Isolation
  // ==============================================================
  console.log('\n[TEST 8] Testing Teacher Privacy & Cross-Teacher Isolation...');

  const canOtherTeacherViewJenkins = DocumentService.validateDocumentAccess(
    teacherDoc,
    mockOtherTeacherUser,
    'view'
  );
  assert(!canOtherTeacherViewJenkins, 'Faculty members must not be able to inspect private documents of other faculty members.');
  console.log(`✓ Teacher isolation verified: Faculty members cannot inspect other teachers private records.`);

  console.log('\n======================================================');
  console.log(' ALL PART 15E STAFF, TEACHER, PARENT & SCHOOL TESTS PASSED! ');
  console.log('======================================================\n');
}

runPart15ETests().catch((err) => {
  console.error('\n❌ TEST FAILURE:', err);
  process.exit(1);
});
