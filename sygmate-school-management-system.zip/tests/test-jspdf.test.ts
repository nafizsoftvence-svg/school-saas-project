import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

console.log('jsPDF type:', typeof jsPDF);
console.log('html2canvas type:', typeof html2canvas);

const doc = new jsPDF({
  orientation: 'landscape',
  unit: 'mm',
  format: 'a4'
});
doc.text('Test PDF Generation', 10, 10);
const blob = doc.output('blob');
console.log('Generated PDF blob size:', blob.size);
console.log('✓ jsPDF functions correctly.');
