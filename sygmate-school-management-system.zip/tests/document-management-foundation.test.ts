/**
 * Part 15A — Certificate & Document Management Foundation Test Suite
 * Validates:
 * 1. Document Category & Type Configuration with duplicate prevention
 * 2. Universal Document Record creation across Student, Staff, Guardian, and School
 * 3. File Upload Security (extensions, size, sanitization)
 * 4. Immutable Version History & Revision chaining (v1 -> v2 -> v3)
 * 5. Lifecycle State Transitions (Uploaded -> Verified / Rejected / Expired)
 * 6. Access Control, Tenant Isolation & IDOR Protection
 * 7. Document Dashboard Metrics calculations
 * 8. Foundational Certificate Template schemas
 */

import { database } from '../server/db/database.js';
import { DocumentService } from '../server/services/document.service.js';
import { User } from '../src/types/index.js';

const mockAdminUser: User = {
  id: 'usr-admin-1',
  name: 'System Admin',
  email: 'admin@sygmate.edu',
  username: 'admin',
  role: 'SUPER_ADMIN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockStudentUser: User = {
  id: 'usr-student-1',
  name: 'Liam Johnson',
  email: 'liam@sygmate.edu',
  username: 'liam.johnson',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockUnrelatedStudentUser: User = {
  id: 'usr-student-99',
  name: 'Stranger Student',
  email: 'stranger@sygmate.edu',
  username: 'stranger',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockGuardianUser: User = {
  id: 'usr-guardian-1',
  name: 'Mark Johnson',
  email: 'mark.johnson@example.com',
  username: 'mark.guardian',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const schoolId = 'school-main';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[ASSERTION FAILED]: ${message}`);
  }
}

async function runDocumentFoundationTests() {
  console.log('--- STARTING PART 15A CERTIFICATE & DOCUMENT MANAGEMENT FOUNDATION TESTS ---');

  // TEST 1: Configurable Document Types Creation
  console.log('\n[TEST 1] Creating a new configurable document type...');
  const newType = DocumentService.createDocumentType(
    schoolId,
    {
      name: 'Specialized STEM Olympiad Certification',
      code: 'DOC_STEM_OLYMPIAD',
      category: 'ACADEMIC',
      applicableEntityType: 'STUDENT',
      description: 'National and international math/physics competition credentials.',
      isRequired: false,
      hasExpiry: false,
      allowedExtensions: ['pdf', 'png', 'jpg'],
      maxSizeBytes: 10 * 1024 * 1024
    },
    mockAdminUser
  );

  assert(Boolean(newType.id), 'Document Type ID must be generated.');
  assert(newType.name === 'Specialized STEM Olympiad Certification', 'Name must match.');
  assert(newType.applicableEntityType === 'STUDENT', 'Scope must be STUDENT.');
  console.log(`✓ Document Type created: ${newType.name} (${newType.code})`);

  // TEST 2: Duplicate Type Prevention
  console.log('\n[TEST 2] Testing duplicate document type rejection in same scope...');
  let duplicatePrevented = false;
  try {
    DocumentService.createDocumentType(
      schoolId,
      {
        name: 'Specialized STEM Olympiad Certification', // Exact duplicate
        category: 'ACADEMIC',
        applicableEntityType: 'STUDENT',
        description: 'Duplicate attempt'
      },
      mockAdminUser
    );
  } catch (err: any) {
    duplicatePrevented = true;
    assert(err.message.includes('already exists'), 'Error message should indicate duplicate.');
  }
  assert(duplicatePrevented, 'Duplicate document type must be rejected.');
  console.log('✓ Duplicate document type correctly rejected.');

  // TEST 3: File Upload Validation & Security
  console.log('\n[TEST 3] Testing file upload security rules...');
  let disallowedExtRejected = false;
  try {
    DocumentService.validateUpload('exploit_script.php', 1024, ['pdf', 'jpg'], 5000000);
  } catch (err: any) {
    disallowedExtRejected = true;
    assert(err.message.includes('not permitted'), 'Should reject unauthorized script extension.');
  }
  assert(disallowedExtRejected, 'Disallowed extension must be rejected.');

  let oversizedFileRejected = false;
  try {
    DocumentService.validateUpload('huge_scan.pdf', 25 * 1024 * 1024, ['pdf'], 10 * 1024 * 1024);
  } catch (err: any) {
    oversizedFileRejected = true;
    assert(err.message.includes('exceeds maximum permitted limit'), 'Should reject oversized files.');
  }
  assert(oversizedFileRejected, 'Oversized file must be rejected.');

  const sanitized = DocumentService.sanitizeFileName('../../../etc/passwd.pdf');
  assert(!sanitized.includes('..') && !sanitized.includes('/'), 'Path traversal characters must be sanitized.');
  console.log(`✓ Upload security validated: path traversal sanitized to "${sanitized}".`);

  // TEST 4: Universal Document Creation & Association
  console.log('\n[TEST 4] Creating document records for different entities...');

  // 4a: Student document
  const studentDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: newType.id,
      entityType: 'STUDENT',
      entityId: 'stud-prof-1',
      documentTitle: 'Alex Rivera Gold Medal Olympiad Certificate',
      referenceNumber: 'OLYMP-2026-GOLD-01',
      fileName: 'Liam_Olympiad_Certificate_Gold.pdf',
      fileType: 'application/pdf',
      fileSizeBytes: 2 * 1024 * 1024,
      issueDate: '2026-05-15'
    },
    mockAdminUser
  );
  assert(studentDoc.version === 1, 'Initial version must be 1.');
  assert(studentDoc.status === 'UPLOADED', 'Initial status should be UPLOADED.');
  assert(studentDoc.verificationStatus === 'PENDING_REVIEW', 'Initial verificationStatus should be PENDING_REVIEW.');
  assert(studentDoc.versionHistory.length === 1, 'Initial version history must have 1 entry.');
  console.log(`✓ Student document created: ${studentDoc.documentTitle} (v${studentDoc.version})`);

  // 4b: School document
  const schoolDoc = DocumentService.createDocument(
    schoolId,
    {
      documentTypeId: database.documentTypes.find(dt => dt.code === 'DOC_FIRE_SAFETY')?.id || newType.id,
      entityType: 'SCHOOL',
      entityId: schoolId,
      documentTitle: 'Sygmate Academy 2026 Electrical Safety Audit',
      referenceNumber: 'ELEC-SAFE-2026-88',
      fileName: 'Campus_Electrical_Audit_2026.pdf',
      fileType: 'application/pdf',
      fileSizeBytes: 3 * 1024 * 1024,
      issueDate: '2026-02-01',
      expiryDate: '2027-02-01'
    },
    mockAdminUser
  );
  assert(schoolDoc.entityType === 'SCHOOL', 'Entity type must be SCHOOL.');
  console.log(`✓ Institutional school document created: ${schoolDoc.documentTitle}`);

  // TEST 5: Document Versioning & Revision History Chaining
  console.log('\n[TEST 5] Testing document versioning and revision history...');
  const v2Doc = DocumentService.uploadNewVersion(
    schoolId,
    studentDoc.id,
    {
      fileName: 'Liam_Olympiad_Certificate_Gold_Certified.pdf',
      fileType: 'application/pdf',
      fileSizeBytes: 2400000,
      changeNotes: 'Replaced preliminary certificate with official signed national board parchment.'
    },
    mockAdminUser
  );

  assert(v2Doc.version === 2, `Active version must now be 2, got ${v2Doc.version}`);
  assert(v2Doc.fileName === 'Liam_Olympiad_Certificate_Gold_Certified.pdf', 'Active file name must be updated.');
  assert(v2Doc.versionHistory.length === 2, `Version history should have 2 entries, got ${v2Doc.versionHistory.length}`);
  assert(v2Doc.versionHistory[0].version === 1, 'Version 1 must remain preserved in history.');
  assert(v2Doc.versionHistory[1].version === 2, 'Version 2 must be recorded in history.');
  console.log(`✓ Document upgraded to v2. History length: ${v2Doc.versionHistory.length}`);

  // TEST 6: Lifecycle State Transitions (Verify & Reject)
  console.log('\n[TEST 6] Testing verification workflow state transitions...');
  const verifiedDoc = DocumentService.verifyDocument(
    schoolId,
    v2Doc.id,
    {
      verificationStatus: 'VERIFIED',
      verificationRemarks: 'Official Olympiad committee seal confirmed.'
    },
    mockAdminUser
  );

  assert(verifiedDoc.status === 'VERIFIED', `Status must be VERIFIED, got ${verifiedDoc.status}`);
  assert(verifiedDoc.verificationStatus === 'VERIFIED', 'verificationStatus must be VERIFIED.');
  assert(verifiedDoc.verifiedBy === mockAdminUser.id, 'verifiedBy must record admin user.');
  console.log(`✓ Document verification transition verified: status=${verifiedDoc.status}`);

  // Test rejection and subsequent re-upload recovery
  console.log('Testing rejection transition and re-upload reset...');
  const rejectedDoc = DocumentService.verifyDocument(
    schoolId,
    v2Doc.id,
    {
      verificationStatus: 'REJECTED',
      rejectionReason: 'Scan edge is clipped.'
    },
    mockAdminUser
  );
  assert(rejectedDoc.status === 'REJECTED', 'Status must be REJECTED.');

  // Re-uploading a new version should reset status back to UPLOADED / PENDING_REVIEW
  const v3Doc = DocumentService.uploadNewVersion(
    schoolId,
    v2Doc.id,
    {
      fileName: 'Liam_Olympiad_Certificate_Gold_Rescanned.pdf',
      fileType: 'application/pdf',
      fileSizeBytes: 2500000,
      changeNotes: 'Full unclipped rescan submitted.'
    },
    mockAdminUser
  );
  assert(v3Doc.version === 3, 'Version must be 3.');
  assert(v3Doc.status === 'UPLOADED', 'Re-uploaded document should transition to UPLOADED.');
  assert(v3Doc.verificationStatus === 'PENDING_REVIEW', 'Re-uploaded document must queue for PENDING_REVIEW.');
  console.log(`✓ Re-upload correctly resets status to UPLOADED/PENDING_REVIEW (v3)`);

  // TEST 7: Access Control, Tenant Isolation & IDOR Protection
  console.log('\n[TEST 7] Testing IDOR and access control scoping...');

  // Student Liam should be allowed to view his own document
  const canStudentViewOwn = DocumentService.validateDocumentAccess(studentDoc, mockStudentUser, 'view');
  assert(canStudentViewOwn, 'Student must be able to view their own document.');

  // Unrelated student should NOT be allowed to view Liam's document
  const canStrangerView = DocumentService.validateDocumentAccess(studentDoc, mockUnrelatedStudentUser, 'view');
  assert(!canStrangerView, 'Unrelated student must NOT be able to view another student document.');

  // Guardian Mark (linked to Liam) should be allowed to view
  const canGuardianViewChild = DocumentService.validateDocumentAccess(studentDoc, mockGuardianUser, 'view');
  assert(canGuardianViewChild, 'Linked guardian must be able to view their child document.');

  // Student should NOT be permitted to verify documents
  const canStudentVerify = DocumentService.validateDocumentAccess(studentDoc, mockStudentUser, 'verify');
  assert(!canStudentVerify, 'Students must NOT be permitted to verify documents.');

  console.log('✓ IDOR and role-based access control policies strictly enforced.');

  // TEST 8: Dashboard Metrics
  console.log('\n[TEST 8] Validating dashboard metrics calculation...');
  const metrics = DocumentService.getDashboardMetrics(schoolId, mockAdminUser);
  assert(metrics.totalDocuments > 0, 'Total documents must be > 0.');
  assert(metrics.activeDocuments > 0, 'Active documents must be > 0.');
  assert(metrics.entityBreakdown.student > 0, 'Student entity breakdown should be > 0.');
  assert(metrics.entityBreakdown.school > 0, 'School entity breakdown should be > 0.');
  console.log(`✓ Metrics validated: Total=${metrics.totalDocuments}, Active=${metrics.activeDocuments}, Verified=${metrics.verified}, Expired=${metrics.expired}`);

  // TEST 9: Foundational Certificate Templates
  console.log('\n[TEST 9] Validating foundational certificate templates...');
  const templates = DocumentService.listCertificateTemplates(schoolId);
  assert(templates.length >= 4, `Expected at least 4 seeded certificate templates, found ${templates.length}.`);
  const meritTemplate = templates.find(t => t.code === 'CERT_ACADEMIC_MERIT');
  assert(Boolean(meritTemplate), 'Academic Merit Certificate template must exist.');
  assert(meritTemplate?.qrCodeEnabled === true, 'Merit certificate template must support QR verification.');
  assert(meritTemplate?.signatories.length >= 2, 'Merit certificate template must specify signatories.');
  console.log(`✓ Foundational certificate template confirmed: "${meritTemplate?.name}" with ${meritTemplate?.signatories.length} signatories.`);

  console.log('\n======================================================');
  console.log(' ALL PART 15A CERTIFICATE & DOCUMENT TESTS PASSED! ');
  console.log('======================================================\n');
}

runDocumentFoundationTests().catch((err) => {
  console.error('[TEST FAILED]:', err);
  process.exit(1);
});
