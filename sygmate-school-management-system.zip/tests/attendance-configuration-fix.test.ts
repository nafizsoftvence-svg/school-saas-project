import assert from 'node:assert';
import { database } from '../server/db/database.js';
import { getRolePermissions, hasPermission } from '../server/security/rbac.js';

console.log('--- STARTING ATTENDANCE CONFIGURATION & TEACHER RULES TEST ---');

// 1. Verify Attendance Configuration exists and has Teacher Attendance Rules
assert(database.attendanceSettings, 'Attendance settings must exist in database');
assert(database.attendanceSettings.teacherAttendance, 'Teacher attendance rules must exist in settings');
assert.strictEqual(typeof database.attendanceSettings.teacherAttendance.enabled, 'boolean');
assert.strictEqual(typeof database.attendanceSettings.teacherAttendance.checkInStartTime, 'string');
assert.strictEqual(typeof database.attendanceSettings.teacherAttendance.cutoffTime, 'string');
assert.strictEqual(typeof database.attendanceSettings.teacherAttendance.lateThresholdMinutes, 'number');
assert.strictEqual(typeof database.attendanceSettings.teacherAttendance.halfDayThresholdMinutes, 'number');
console.log('✓ Attendance Settings & Teacher Attendance Rules properly structured.');

// 2. Verify Academic Session & School Scope
const activeSession = database.academicSessions.find((s) => s.isActive);
assert(activeSession, 'Active academic session must exist');
assert.strictEqual(activeSession.sessionName, '2026-2027 Academic Year');
console.log('✓ Active Academic Session 2026-2027 verified.');

// 3. Verify RBAC permissions for SUPER_ADMIN and ADMIN
assert(hasPermission('SUPER_ADMIN', 'attendance.view'), 'SUPER_ADMIN must have attendance.view');
assert(hasPermission('SUPER_ADMIN', 'attendance.manage'), 'SUPER_ADMIN must have attendance.manage');
assert(hasPermission('SUPER_ADMIN', 'teacher.attendance.manage'), 'SUPER_ADMIN must have teacher.attendance.manage');
// Normalization of ADMIN
assert(hasPermission('ADMIN' as any, 'attendance.view'), 'ADMIN must be recognized as having attendance.view');
assert(hasPermission('ADMIN' as any, 'attendance.manage'), 'ADMIN must be recognized as having attendance.manage');
console.log('✓ RBAC permissions for Super Admin & Admin properly configured.');

// 4. Verify all 8 subtabs data sources are configured
assert(database.attendanceSettings.workingDays.length > 0, 'Working days must be configured');
assert(database.attendanceSettings.weekendDays.length > 0, 'Weekend days must be configured');
assert(database.attendanceSettings.studentAttendance, 'Student attendance rules must exist');
assert(database.attendanceSettings.attendanceStatuses.length > 0, 'Attendance statuses must exist');
assert(database.attendanceSettings.holidayRules, 'Holiday rules must exist');
assert(database.attendanceSettings.leaveRules, 'Leave rules must exist');
console.log('✓ All 8 Attendance Settings modules validated.');

console.log('--- ALL ATTENDANCE CONFIGURATION & TEACHER RULES TESTS PASSED! ---');
