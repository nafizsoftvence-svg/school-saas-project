/**
 * End-to-End Tests for PART 14E: Issue, Return, Allocation & Department Workflow
 * Sygmate School Management System
 */

import { database } from '../server/db/database.js';
import { IssueService } from '../server/services/issue.service.js';
import { StockService } from '../server/services/stock.service.js';
import { AssetService } from '../server/services/asset.service.js';
import { ensureInventoryCollections } from '../server/routes/inventory.routes.js';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[AssertionFailed] ${message}`);
  }
}

async function runTests() {
  console.log('=== Starting Part 14E Verification Suite ===');

  ensureInventoryCollections();
  const schoolId = 'school-main';
  const mockUser = {
    id: 'usr-admin-1',
    name: 'Admin Officer',
    email: 'admin@sygmate.school',
    role: 'ADMIN',
    schoolId
  };

  // 1. Prepare test location and stockable item
  const testLocation = database.inventoryLocations.find((l: any) => l.schoolId === schoolId) || {
    id: 'loc-test-main',
    schoolId,
    name: 'Main Campus Central Store',
    code: 'MCS-01'
  };

  const testItem = database.inventoryItems.find((i: any) => i.schoolId === schoolId && i.isActive) || {
    id: 'item-test-a4',
    schoolId,
    name: 'A4 Printing Paper Ream',
    itemCode: 'PAP-A4-01',
    status: 'ACTIVE',
    isActive: true,
    unitPrice: 5.5,
    unitId: 'unit-ream',
    unitShortCode: 'REAM'
  };

  // Ensure balance exists
  const getBal = (locId: string, itemId: string) => {
    const bal = database.stockBalances.find((b: any) => b.schoolId === schoolId && b.itemId === itemId && b.locationId === locId);
    return bal ? bal.quantity : 0;
  };

  const initialBal = getBal(testLocation.id, testItem.id);
  if (initialBal < 50) {
    await StockService.recordStockIn(
      schoolId,
      {
        itemId: testItem.id,
        locationId: testLocation.id,
        quantity: 100,
        sourceType: 'DONATION',
        notes: 'Test seeding for Part 14E verification'
      },
      mockUser
    );
  }

  const stockBefore = getBal(testLocation.id, testItem.id);
  console.log(`[Setup] Current initial stock of ${testItem.name}: ${stockBefore}`);

  // =========================================================================
  // TEST 1: ISSUE REQUISITION LIFECYCLE (Draft -> Submitted -> Approved)
  // =========================================================================
  console.log('\n[Test 1] Testing Requisition Submission & Approval Workflow...');
  const req = await IssueService.createIssueRequest(
    schoolId,
    {
      recipientType: 'DEPARTMENT',
      recipientId: 'dept-sci',
      recipientName: 'Science Department',
      departmentId: 'dept-sci',
      departmentName: 'Science Department',
      sourceLocationId: testLocation.id,
      purpose: 'End of term science exams stationery',
      priority: 'HIGH',
      items: [
        {
          itemId: testItem.id,
          quantityRequested: 20,
          notes: 'Standard 80gsm white'
        }
      ]
    },
    mockUser
  );

  assert(req.status === 'SUBMITTED', `Requisition status must be SUBMITTED, got ${req.status}`);
  assert(req.items[0].quantityRequested === 20, 'Requested quantity must be 20');
  console.log(`  ✓ Requisition ${req.requestNumber} created with status ${req.status}`);

  // Approve Requisition
  const reviewedReq = await IssueService.reviewIssueRequest(
    schoolId,
    req.id,
    {
      decision: 'APPROVE',
      items: [
        {
          itemId: testItem.id,
          quantityApproved: 15,
          notes: 'Approved 15 packs based on quota'
        }
      ]
    },
    mockUser
  );

  assert(reviewedReq.status === 'APPROVED', `Status must be APPROVED, got ${reviewedReq.status}`);
  assert(reviewedReq.items[0].quantityApproved === 15, 'Approved quantity must be 15');
  console.log(`  ✓ Requisition ${reviewedReq.requestNumber} approved with approvedQty = 15`);

  // =========================================================================
  // TEST 2: NEGATIVE STOCK & OVER-ISSUE PREVENTION
  // =========================================================================
  console.log('\n[Test 2] Testing Negative Stock & Over-issue Prevention...');
  let overIssueThrew = false;
  try {
    await IssueService.executeStockIssue(
      schoolId,
      {
        issueRequestId: reviewedReq.id,
        sourceLocationId: testLocation.id,
        recipientType: 'DEPARTMENT',
        recipientId: 'dept-sci',
        recipientName: 'Science Department',
        items: [
          {
            itemId: testItem.id,
            quantityToIssue: 999999 // Excessively large quantity
          }
        ]
      },
      mockUser
    );
  } catch (err: any) {
    overIssueThrew = true;
    console.log(`  ✓ Over-issue blocked as expected: "${err.message}"`);
  }
  assert(overIssueThrew, 'System must forbid issue exceeding approved quantity and available stock');

  // =========================================================================
  // TEST 3: PARTIAL STOCK DISPATCH (ATOMIC DEDUCTION)
  // =========================================================================
  console.log('\n[Test 3] Testing Atomic Partial Stock Dispatch...');
  const firstIssue = await IssueService.executeStockIssue(
    schoolId,
    {
      issueRequestId: reviewedReq.id,
      sourceLocationId: testLocation.id,
      recipientType: 'DEPARTMENT',
      recipientId: 'dept-sci',
      recipientName: 'Science Department',
      items: [
        {
          itemId: testItem.id,
          quantityToIssue: 10
        }
      ]
    },
    mockUser
  );

  assert(firstIssue.items[0].quantityIssued === 10, 'Issued quantity must be 10');
  const stockAfterFirst = getBal(testLocation.id, testItem.id);
  assert(
    stockAfterFirst === stockBefore - 10,
    `Stock must be deducted by 10. Expected ${stockBefore - 10}, got ${stockAfterFirst}`
  );

  // Check request updated state
  const reqAfterFirst = IssueService.getIssueRequestById(schoolId, reviewedReq.id);
  assert(
    reqAfterFirst.status === 'PARTIALLY_ISSUED',
    `Request status must be PARTIALLY_ISSUED, got ${reqAfterFirst.status}`
  );
  assert(
    reqAfterFirst.items[0].quantityIssued === 10,
    `Request item quantityIssued must be 10, got ${reqAfterFirst.items[0].quantityIssued}`
  );
  console.log(`  ✓ Dispatched Issue #${firstIssue.issueNumber}. Request transitioned to PARTIALLY_ISSUED.`);
  console.log(`  ✓ Warehouse stock atomically reduced from ${stockBefore} to ${stockAfterFirst}.`);

  // Second issue to complete remaining 5
  const secondIssue = await IssueService.executeStockIssue(
    schoolId,
    {
      issueRequestId: reviewedReq.id,
      sourceLocationId: testLocation.id,
      recipientType: 'DEPARTMENT',
      recipientId: 'dept-sci',
      recipientName: 'Science Department',
      items: [
        {
          itemId: testItem.id,
          quantityToIssue: 5
        }
      ]
    },
    mockUser
  );
  const reqAfterSecond = IssueService.getIssueRequestById(schoolId, reviewedReq.id);
  assert(
    reqAfterSecond.status === 'FULLY_ISSUED',
    `Request status must be FULLY_ISSUED, got ${reqAfterSecond.status}`
  );
  console.log(`  ✓ Dispatched remaining 5 units under Issue #${secondIssue.issueNumber}. Request is now FULLY_ISSUED.`);

  // =========================================================================
  // TEST 4: INVENTORY RETURN (ATOMIC STOCK RESTOCK)
  // =========================================================================
  console.log('\n[Test 4] Testing Inventory Return & Atomic Restock...');
  const stockBeforeReturn = getBal(testLocation.id, testItem.id);

  const invReturn = await IssueService.createInventoryReturn(
    schoolId,
    {
      originalIssueId: firstIssue.id,
      returnLocationId: testLocation.id,
      returnedByType: 'DEPARTMENT',
      returnedById: 'dept-sci',
      returnedByName: 'Science Department',
      reason: '3 reams unused after examination completed',
      items: [
        {
          itemId: testItem.id,
          quantity: 3,
          condition: 'GOOD',
          reason: 'Surplus un-opened packs'
        }
      ]
    },
    mockUser
  );

  assert(invReturn.items[0].quantityReturned === 3, 'Quantity returned must be 3');
  const stockAfterReturn = getBal(testLocation.id, testItem.id);
  assert(
    stockAfterReturn === stockBeforeReturn + 3,
    `Stock must be incremented by 3. Expected ${stockBeforeReturn + 3}, got ${stockAfterReturn}`
  );

  // Verify Issue record updated return tally
  const issuesList = IssueService.getStockIssues(schoolId, {});
  const updatedFirstIssue = issuesList.data.find((i) => i.id === firstIssue.id);
  assert(
    updatedFirstIssue?.items[0].quantityReturned === 3,
    `Issue quantityReturned must be 3, got ${updatedFirstIssue?.items[0].quantityReturned}`
  );
  console.log(`  ✓ Logged Return #${invReturn.returnNumber}. Warehouse stock atomically restored from ${stockBeforeReturn} to ${stockAfterReturn}.`);

  // =========================================================================
  // TEST 5: BULK ASSET ALLOCATION & CUSTODY HANDOVER
  // =========================================================================
  console.log('\n[Test 5] Testing Bulk Asset Allocation & Custodian Handover...');
  const availableAssets = database.assets.filter((a: any) => a.schoolId === schoolId && a.status === 'AVAILABLE');
  if (availableAssets.length > 0) {
    const targetAsset = availableAssets[0];
    const allocResult = await IssueService.bulkAllocateAssets(
      schoolId,
      {
        assetIds: [targetAsset.id],
        assigneeType: 'TEACHER',
        assigneeId: 'tch-smith',
        assigneeName: 'Dr. John Smith',
        department: 'Physics & Computing',
        conditionAtHandover: 'GOOD',
        handoverNotes: 'Allocated for senior lab demonstrations'
      },
      mockUser
    );

    assert(allocResult.assignedCount === 1, `Assigned count must be 1, got ${allocResult.assignedCount}`);
    const refreshedAsset = database.assets.find((a: any) => a.id === targetAsset.id);
    assert(
      refreshedAsset.status === 'ASSIGNED',
      `Asset status must be ASSIGNED, got ${refreshedAsset.status}`
    );
    assert(
      refreshedAsset.currentAssigneeName === 'Dr. John Smith',
      `Assignee must be Dr. John Smith, got ${refreshedAsset.currentAssigneeName}`
    );
    console.log(`  ✓ Asset ${refreshedAsset.assetTag} successfully transitioned to ASSIGNED with custodian Dr. John Smith.`);
  } else {
    console.log('  (Skipped asset test: no asset currently in AVAILABLE status)');
  }

  // =========================================================================
  // TEST 6: DEPARTMENT ALLOCATION SUMMARY
  // =========================================================================
  console.log('\n[Test 6] Testing Department Allocation Summary Aggregation...');
  const deptSummaries = IssueService.getDepartmentAllocations(schoolId);
  assert(Array.isArray(deptSummaries), 'Department summaries must return an array');
  assert(deptSummaries.length > 0, 'Should have at least one department summary');
  console.log(`  ✓ Successfully aggregated allocation summaries across ${deptSummaries.length} departments.`);

  console.log('\n=== ALL PART 14E VERIFICATION TESTS PASSED SUCCESSFULLY! ===\n');
}

runTests().catch((err) => {
  console.error('\n❌ Test Suite Failed with error:', err);
  process.exit(1);
});
