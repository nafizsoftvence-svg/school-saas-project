/**
 * Part 14C — Asset Lifecycle Test Suite
 * Validates State Transitions, Concurrency Locks, Assignments, Transfers,
 * Maintenance, Damage/Loss, Disposal, and Timeline Integrity.
 */

import { database } from '../server/db/database.js';
import { AssetService } from '../server/services/asset.service.js';
import { ensureInventoryCollections } from '../server/routes/inventory.routes.js';

const mockUser = {
  id: 'usr-admin-1',
  name: 'System Admin',
  role: 'SUPER_ADMIN'
};

const schoolId = 'school-main';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[ASSERTION FAILED]: ${message}`);
  }
}

async function runTests() {
  console.log('--- STARTING PART 14C ASSET LIFECYCLE TESTS ---');
  ensureInventoryCollections();

  // 1. Asset Registration
  console.log('\n[TEST 1] Registering a new asset...');
  const testTag = `TEST-TAG-${Date.now()}`;
  const asset = AssetService.createAsset(
    schoolId,
    {
      assetTag: testTag,
      name: 'MacBook Pro 16 M3 Lab Workstation',
      categoryId: database.assetCategories[0]?.id || 'cat-it',
      locationId: database.inventoryLocations[0]?.id || 'loc-it',
      purchaseDate: '2026-01-15',
      purchaseCost: 2899,
      serialNumber: `SN-${Date.now()}`,
      brand: 'Apple',
      model: 'MacBook Pro 16',
      warrantyEnd: '2029-01-15',
      department: 'Computer Science'
    },
    mockUser
  );

  assert(asset.id !== undefined, 'Asset ID must be defined');
  assert(asset.status === 'AVAILABLE' || asset.status === 'ACTIVE', `Initial status should be ACTIVE/AVAILABLE, got: ${asset.status}`);
  console.log(`✓ Asset registered: ${asset.name} (${asset.assetTag}) - Status: ${asset.status}`);

  // 2. Duplicate Tag Check
  console.log('\n[TEST 2] Duplicate Asset Tag rejection...');
  let duplicateThrew = false;
  try {
    AssetService.createAsset(
      schoolId,
      {
        assetTag: testTag,
        name: 'Duplicate Tag Attempt',
        categoryId: asset.categoryId,
        locationId: asset.locationId
      },
      mockUser
    );
  } catch (err: any) {
    duplicateThrew = true;
    assert(err.message.includes('already registered') || err.message.includes('already in use'), 'Error should mention duplicate tag');
  }
  assert(duplicateThrew, 'Duplicate tag registration must throw error');
  console.log('✓ Duplicate asset tag correctly rejected.');

  // 3. Custody Assignment
  console.log('\n[TEST 3] Assigning asset to staff member...');
  const assignResult = await AssetService.assignAsset(
    schoolId,
    asset.id,
    {
      assigneeType: 'STAFF',
      assigneeId: 'usr-prof-1',
      assigneeName: 'Dr. Sarah Connor',
      department: 'Computer Science',
      conditionAtHandover: 'EXCELLENT',
      expectedReturnDate: '2026-12-20',
      accessories: ['MagSafe 140W Charger', 'Laptop Sleeve', 'USB-C Hub'],
      handoverNotes: 'Issued for Advanced Systems Research Laboratory'
    },
    mockUser
  );

  assert(assignResult.asset.status === 'ASSIGNED', `Asset status must be ASSIGNED, got: ${assignResult.asset.status}`);
  assert(assignResult.assignment.status === 'ACTIVE', 'Assignment record must be active');
  assert(assignResult.assignment.assigneeName === 'Dr. Sarah Connor', 'Assignee name mismatch');
  console.log(`✓ Asset successfully assigned to ${assignResult.assignment.assigneeName}`);

  // 4. Invalid State Transition: Cannot assign an already ASSIGNED asset
  console.log('\n[TEST 4] Preventing double assignment...');
  let doubleAssignThrew = false;
  try {
    await AssetService.assignAsset(
      schoolId,
      asset.id,
      {
        assigneeType: 'TEACHER',
        assigneeId: 'usr-teacher-2',
        assigneeName: 'Mr. John Smith'
      },
      mockUser
    );
  } catch (err: any) {
    doubleAssignThrew = true;
    assert(
      err.message.includes('cannot be assigned') ||
      err.message.includes('already assigned') ||
      err.message.includes('active assignment'),
      'Error should reject double assignment'
    );
  }
  assert(doubleAssignThrew, 'Double assignment must throw');
  console.log('✓ Double assignment prevented.');

  // 5. Concurrency Race Condition Protection
  console.log('\n[TEST 5] Testing concurrency lock on concurrent assignments...');
  // First return asset to make available
  await AssetService.returnAsset(
    schoolId,
    asset.id,
    {
      returnCondition: 'EXCELLENT',
      locationId: asset.locationId,
      returnNotes: 'Temporary return before concurrency test'
    },
    mockUser
  );
  assert(asset.status === 'AVAILABLE', 'Asset should be available for concurrency test');

  // Launch two assignment operations simultaneously
  const results = await Promise.allSettled([
    AssetService.assignAsset(
      schoolId,
      asset.id,
      {
        assigneeType: 'STAFF',
        assigneeId: 'agent-1',
        assigneeName: 'Concurrent Agent 1'
      },
      mockUser
    ),
    AssetService.assignAsset(
      schoolId,
      asset.id,
      {
        assigneeType: 'STAFF',
        assigneeId: 'agent-2',
        assigneeName: 'Concurrent Agent 2'
      },
      mockUser
    )
  ]);

  const fulfilledCount = results.filter(r => r.status === 'fulfilled').length;
  const rejectedCount = results.filter(r => r.status === 'rejected').length;

  assert(fulfilledCount === 1, `Exactly 1 assignment must succeed under race conditions, got ${fulfilledCount}`);
  assert(rejectedCount === 1, `Exactly 1 assignment must be rejected under race conditions, got ${rejectedCount}`);
  console.log('✓ Concurrency serialized successfully: exactly one winner, one rejected.');

  // 6. Direct Custody Transfer
  console.log('\n[TEST 6] Transferring custody directly to new custodian...');
  const transferResult = await AssetService.transferAsset(
    schoolId,
    asset.id,
    {
      toAssigneeType: 'DEPARTMENT',
      toAssigneeId: 'dept-eng',
      toAssigneeName: 'Robotics Department',
      toDepartment: 'Robotics',
      reason: 'Reassigned for Autonomous Systems Project',
      condition: 'GOOD',
      notes: 'Hardware in pristine condition'
    },
    mockUser
  );

  assert(transferResult.asset.status === 'ASSIGNED', 'Status should remain ASSIGNED');
  assert(transferResult.newAssignment.assigneeName === 'Robotics Department', 'New assignee mismatch');
  assert(transferResult.transferRecord !== undefined, 'Transfer record must exist');
  console.log(`✓ Custody transferred to ${transferResult.newAssignment.assigneeName}`);

  // 7. Return Asset to Inventory
  console.log('\n[TEST 7] Returning asset to central inventory...');
  const returnResult = await AssetService.returnAsset(
    schoolId,
    asset.id,
    {
      returnCondition: 'GOOD',
      locationId: asset.locationId,
      returnNotes: 'Returned at end of project cycle'
    },
    mockUser
  );

  assert(returnResult.asset.status === 'AVAILABLE', 'Asset must be AVAILABLE after return');
  assert(returnResult.returnRecord.returnCondition === 'GOOD', 'Return condition mismatch');
  console.log(`✓ Asset returned. Status: ${returnResult.asset.status}`);

  // 8. Maintenance / Repair Workflow
  console.log('\n[TEST 8] Sending asset for maintenance/repair...');
  await AssetService.sendForRepair(
    schoolId,
    asset.id,
    {
      problemDescription: 'Trackpad responsiveness degraded and thermal throttling',
      vendorOrServiceProvider: 'Apple Authorized Service Center',
      estimatedCost: 250,
      estimatedCompletionDate: '2026-03-30'
    },
    mockUser
  );
  assert(asset.status === 'UNDER_REPAIR', `Status must be UNDER_REPAIR, got ${asset.status}`);

  // Complete repair
  console.log('Completing repair and restoring to inventory...');
  await AssetService.completeRepair(
    schoolId,
    asset.id,
    {
      actualCost: 210,
      repairNotes: 'Thermal paste reapplied and trackpad sensor calibrated',
      resultingCondition: 'EXCELLENT',
      returnLocationId: asset.locationId
    },
    mockUser
  );
  assert(asset.status === 'AVAILABLE', `Status must be AVAILABLE, got ${asset.status}`);
  console.log('✓ Repair workflow completed successfully.');

  // 9. Loss and Recovery Workflow
  console.log('\n[TEST 9] Reporting asset lost and subsequent recovery...');
  await AssetService.markLost(
    schoolId,
    asset.id,
    {
      incidentDate: '2026-04-01',
      incidentReport: 'Left in Seminar Room 4B after evening conference'
    },
    mockUser
  );
  assert(asset.status === 'LOST', `Status must be LOST, got ${asset.status}`);

  // Recover
  await AssetService.recoverAsset(
    schoolId,
    asset.id,
    {
      condition: 'GOOD',
      locationId: asset.locationId,
      notes: 'Turned in to Campus Security lost & found'
    },
    mockUser
  );
  assert(asset.status === 'AVAILABLE', `Status must be AVAILABLE after recovery, got ${asset.status}`);
  console.log('✓ Loss and recovery workflow verified.');

  // 10. Damage Lifecycle
  console.log('\n[TEST 10] Marking asset damaged...');
  await AssetService.markDamaged(
    schoolId,
    asset.id,
    {
      damageDescription: 'Cracked outer display glass from transit drop',
      condition: 'DAMAGED',
      canBeRepaired: false
    },
    mockUser
  );
  assert(asset.status === 'DAMAGED', `Status must be DAMAGED, got ${asset.status}`);
  console.log('✓ Damage state recorded.');

  // 11. Retirement & Terminal Disposal
  console.log('\n[TEST 11] Decommissioning and disposing asset...');
  await AssetService.retireAsset(
    schoolId,
    asset.id,
    {
      reason: 'Beyond economical repair due to glass crack and age',
      notes: 'Approved by Assets Committee'
    },
    mockUser
  );
  assert(asset.status === 'RETIRED', `Status must be RETIRED, got ${asset.status}`);

  await AssetService.disposeAsset(
    schoolId,
    asset.id,
    {
      disposalMethod: 'SCRAPPED',
      disposalDate: '2026-04-10',
      salvageValue: 200,
      certificateReference: 'DISP-CERT-2026-099',
      disposalReason: 'Scrapped for parts through certified e-waste partner'
    },
    mockUser
  );
  assert(asset.status === 'DISPOSED', `Status must be DISPOSED, got ${asset.status}`);

  // Verify terminal state rejects further operations
  let terminalThrew = false;
  try {
    await AssetService.assignAsset(
      schoolId,
      asset.id,
      {
        assigneeType: 'STAFF',
        assigneeId: 'usr-1',
        assigneeName: 'Test'
      },
      mockUser
    );
  } catch (err: any) {
    terminalThrew = true;
    assert(err.message.includes('DISPOSED') || err.message.includes('terminal'), 'Should prohibit assigning disposed asset');
  }
  assert(terminalThrew, 'Disposed asset must reject assignment');
  console.log('✓ Disposed terminal state enforced.');

  // 12. Timeline & Audit Integrity
  console.log('\n[TEST 12] Verifying chronological timeline events...');
  const timeline = AssetService.getAssetTimeline(schoolId, asset.id);
  assert(timeline.length >= 7, `Timeline should have at least 7 events, got ${timeline.length}`);
  console.log(`✓ Timeline generated with ${timeline.length} distinct events in chronological order.`);

  // 13. Summary Metrics
  console.log('\n[TEST 13] Verifying asset lifecycle summary metrics...');
  const summary = AssetService.getAssetLifecycleSummary(schoolId);
  assert(summary.totalAssets > 0, 'Total assets must be > 0');
  assert(summary.disposedAssets >= 1, 'Disposed count should reflect disposed asset');
  console.log(`✓ Summary validated: ${summary.totalAssets} total assets, ${summary.disposedAssets} disposed.`);

  console.log('\n========================================');
  console.log(' ALL PART 14C ASSET LIFECYCLE TESTS PASSED! ');
  console.log('========================================\n');
}

runTests().catch(err => {
  console.error('\n❌ TEST RUN FAILED:\n', err);
  process.exit(1);
});
