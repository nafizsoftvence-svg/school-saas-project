/**
 * Part 14D — Purchase, Supplier & Procurement Workflow Test Suite
 *
 * Validates:
 * 1. Purchase Request lifecycle (Draft -> Submitted -> Approved / Rejected -> Converted to PO)
 * 2. Purchase Order creation, validation, approval, and supplier dispatch
 * 3. Crucial Rule: Approved PO DOES NOT automatically increase inventory stock
 * 4. Goods Receiving: Physical stock increases ONLY on successful goods receipt
 * 5. Partial Receiving: Correctly tracking remaining quantities, statuses (PARTIALLY_RECEIVED -> FULLY_RECEIVED)
 * 6. Over-receiving prevention (Attempt to receive more than remaining ordered is strictly blocked)
 * 7. Discrepancy & Rejection handling (Damaged items rejected with reason do NOT increase usable stock)
 * 8. Capital Asset Creation from received items
 * 9. Supplier procurement history & fulfillment metrics
 * 10. Concurrency mutex locking on PO receiving operations
 */

import { database } from '../server/db/database.js';
import { ProcurementService } from '../server/services/procurement.service.js';
import { StockService } from '../server/services/stock.service.js';
import { ensureInventoryCollections } from '../server/routes/inventory.routes.js';

const mockAdmin = {
  id: 'usr-admin-1',
  name: 'System Admin',
  role: 'SUPER_ADMIN' as const
};

const schoolId = 'school-main';

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`[ASSERTION FAILED]: ${message}`);
  }
}

async function runTests() {
  console.log('--- STARTING PART 14D PROCUREMENT WORKFLOW TESTS ---');
  ensureInventoryCollections();

  const testSupplier = database.suppliers.find(s => s.schoolId === schoolId) || database.suppliers[0];
  const testItem = database.inventoryItems.find(i => i.schoolId === schoolId && i.isStockable) || database.inventoryItems[0];
  const testLocation = database.inventoryLocations.find(l => l.schoolId === schoolId) || database.inventoryLocations[0];

  assert(!!testSupplier, 'Test supplier must exist');
  assert(!!testItem, 'Test inventory item must exist');
  assert(!!testLocation, 'Test inventory location must exist');

  // Record initial stock level
  const initialStock = StockService.getOrCreateBalance(schoolId, testItem, testLocation).quantity;
  console.log(`Initial stock for '${testItem.name}' at '${testLocation.name}': ${initialStock}`);

  // =========================================================================
  // TEST 1: Create Purchase Request
  // =========================================================================
  console.log('\n[TEST 1] Creating a new Purchase Request...');
  const pr = ProcurementService.createPurchaseRequest(
    schoolId,
    {
      purpose: 'Urgent departmental replenishment for midterm tests',
      priority: 'HIGH',
      targetLocationId: testLocation.id,
      departmentName: 'Testing Department',
      items: [
        {
          itemId: testItem.id,
          quantity: 50,
          estimatedUnitCost: 10,
          preferredSupplierId: testSupplier.id,
          notes: 'Test Line 1'
        }
      ]
    },
    mockAdmin
  );

  assert(pr.id !== undefined, 'PR ID must be defined');
  assert(pr.status === 'SUBMITTED', `PR should start in SUBMITTED status, got ${pr.status}`);
  assert(pr.items.length === 1, 'PR should have 1 item');
  assert(pr.totalEstimatedAmount === 500, `PR total should be 500, got ${pr.totalEstimatedAmount}`);
  console.log(`✓ Purchase Request created: ${pr.requestNumber} (Status: ${pr.status})`);

  // =========================================================================
  // TEST 2: Review Purchase Request (Approve)
  // =========================================================================
  console.log('\n[TEST 2] Approving Purchase Request...');
  const approvedPr = ProcurementService.reviewPurchaseRequest(
    schoolId,
    pr.id,
    { decision: 'APPROVE', reviewNotes: 'Budget verified' },
    mockAdmin
  );
  assert(approvedPr.status === 'APPROVED', `PR should be APPROVED, got ${approvedPr.status}`);
  console.log(`✓ Purchase Request ${approvedPr.requestNumber} approved successfully`);

  // =========================================================================
  // TEST 3: Convert Approved PR to Purchase Order
  // =========================================================================
  console.log('\n[TEST 3] Converting Approved PR to Purchase Order...');
  const poFromPr = await ProcurementService.convertRequestToPurchaseOrder(
    schoolId,
    approvedPr.id,
    {
      supplierId: testSupplier.id,
      expectedDeliveryDate: '2026-03-15',
      paymentTerms: 'NET 30'
    },
    mockAdmin
  );

  assert(poFromPr.id !== undefined, 'PO ID must be defined');
  assert(poFromPr.items.length === 1, 'PO should have 1 item transferred from PR');
  assert(poFromPr.items[0].quantityOrdered === 50, 'PO quantityOrdered should be 50');
  assert(poFromPr.items[0].quantityRemaining === 50, 'PO quantityRemaining should be 50');
  assert(approvedPr.status === 'CONVERTED_TO_PO', `PR status should update to CONVERTED_TO_PO, got ${approvedPr.status}`);
  console.log(`✓ PO created: ${poFromPr.poNumber} (Status: ${poFromPr.status})`);

  // =========================================================================
  // TEST 4: Prevent Duplicate Conversion of the Same PR
  // =========================================================================
  console.log('\n[TEST 4] Preventing duplicate PR conversion...');
  let dupPrThrew = false;
  try {
    await ProcurementService.convertRequestToPurchaseOrder(
      schoolId,
      approvedPr.id,
      { supplierId: testSupplier.id },
      mockAdmin
    );
  } catch (err: any) {
    dupPrThrew = true;
  }
  assert(dupPrThrew, 'Attempting to re-convert already converted PR must throw error');
  console.log('✓ Prevented duplicate conversion of already converted PR');

  // =========================================================================
  // TEST 5: Direct PO Creation, Validation & Approval
  // =========================================================================
  console.log('\n[TEST 5] Direct Purchase Order Creation...');
  const directPo = await ProcurementService.createPurchaseOrder(
    schoolId,
    {
      supplierId: testSupplier.id,
      deliveryLocationId: testLocation.id,
      departmentName: 'Logistics',
      expectedDeliveryDate: '2026-03-20',
      items: [
        {
          itemId: testItem.id,
          quantityOrdered: 100,
          unitPrice: 15,
          discountPercentage: 10,
          taxPercentage: 5,
          notes: 'Standard stock replen'
        }
      ]
    },
    mockAdmin
  );

  assert(directPo.status === 'PENDING_APPROVAL', `Direct PO status should be PENDING_APPROVAL, got ${directPo.status}`);
  console.log(`✓ Direct PO created: ${directPo.poNumber} (Grand total: $${directPo.grandTotal})`);

  // Approve the direct PO
  const approvedDirectPo = await ProcurementService.reviewPurchaseOrder(
    schoolId,
    directPo.id,
    { decision: 'APPROVE' },
    mockAdmin
  );
  assert(approvedDirectPo.status === 'APPROVED', `PO status should be APPROVED, got ${approvedDirectPo.status}`);

  // =========================================================================
  // TEST 6: CRUCIAL DIRECTIVE CHECK
  // "An approved Purchase Order MUST NOT automatically increase inventory stock."
  // =========================================================================
  console.log('\n[TEST 6] CRITICAL VERIFICATION: Approved PO does NOT increase stock...');
  const currentStockAfterApproval = StockService.getOrCreateBalance(schoolId, testItem, testLocation).quantity;
  assert(
    currentStockAfterApproval === initialStock,
    `CRITICAL FAILURE: Stock increased upon PO approval! Initial was ${initialStock}, current is ${currentStockAfterApproval}.`
  );
  console.log(`✓ VERIFIED: Stock remains exactly ${currentStockAfterApproval} after PO approval.`);

  // Mark PO as Sent to Supplier
  ProcurementService.markPurchaseOrderSent(schoolId, approvedDirectPo.id, mockAdmin);
  assert(approvedDirectPo.status === 'SENT_TO_SUPPLIER', 'PO status should be SENT_TO_SUPPLIER');
  console.log(`✓ PO marked sent to supplier: ${approvedDirectPo.poNumber}`);

  // =========================================================================
  // TEST 7: Partial Goods Receiving with Discrepancy / Rejection
  // Order: 100 units. Receive: 60 units (50 accepted, 10 damaged/rejected).
  // =========================================================================
  console.log('\n[TEST 7] Partial Goods Receiving (60 received: 50 accepted, 10 rejected)...');
  const poItemId = approvedDirectPo.items[0].id;
  const receiptResult1 = await ProcurementService.receiveGoods(
    schoolId,
    approvedDirectPo.id,
    {
      receivingLocationId: testLocation.id,
      receiptDate: new Date().toISOString(),
      referenceNumber: 'DELIV-NOTE-001',
      items: [
        {
          poItemId,
          quantityReceived: 60,
          quantityAccepted: 50,
          quantityRejected: 10,
          rejectionReason: 'Broken packaging during freight handling',
          itemCondition: 'GOOD'
        }
      ]
    },
    mockAdmin
  );

  const grn1 = receiptResult1.goodsReceipt;
  const updatedPo1 = receiptResult1.purchaseOrder;

  assert(grn1.totalReceivedQty === 60, `GRN total received should be 60, got ${grn1.totalReceivedQty}`);
  assert(grn1.totalAcceptedQty === 50, `GRN total accepted should be 50, got ${grn1.totalAcceptedQty}`);
  assert(grn1.totalRejectedQty === 10, `GRN total rejected should be 10, got ${grn1.totalRejectedQty}`);
  assert(updatedPo1.status === 'PARTIALLY_RECEIVED', `PO status should be PARTIALLY_RECEIVED, got ${updatedPo1.status}`);
  assert(updatedPo1.items[0].quantityReceived === 60, `PO received qty should be 60, got ${updatedPo1.items[0].quantityReceived}`);
  assert(updatedPo1.items[0].quantityRemaining === 40, `PO remaining qty should be 40, got ${updatedPo1.items[0].quantityRemaining}`);

  // VERIFY STOCK INCREASE: ONLY ACCEPTED UNITS (50) SHOULD INCREASE STOCK
  const stockAfterGrn1 = StockService.getOrCreateBalance(schoolId, testItem, testLocation).quantity;
  assert(
    stockAfterGrn1 === initialStock + 50,
    `Stock after GRN1 should be ${initialStock + 50}, got ${stockAfterGrn1}`
  );
  console.log(`✓ VERIFIED: Stock increased by exactly 50 accepted units (current stock: ${stockAfterGrn1}). Rejected 10 units safely excluded.`);

  // =========================================================================
  // TEST 8: Over-receiving Protection
  // Remaining on PO is 40 units. Attempt to receive 41 units must fail.
  // =========================================================================
  console.log('\n[TEST 8] Preventing Over-receiving...');
  let overReceiveThrew = false;
  try {
    await ProcurementService.receiveGoods(
      schoolId,
      approvedDirectPo.id,
      {
        receivingLocationId: testLocation.id,
        items: [
          {
            poItemId,
            quantityReceived: 41,
            quantityAccepted: 41
          }
        ]
      },
      mockAdmin
    );
  } catch (err: any) {
    overReceiveThrew = true;
  }
  assert(overReceiveThrew, 'Attempting to receive more than remaining ordered quantity must throw error');
  console.log('✓ Over-receiving strictly blocked by service');

  // =========================================================================
  // TEST 9: Final Receiving - Fulfill Remaining Balance (40 units)
  // =========================================================================
  console.log('\n[TEST 9] Receiving Final Balance (40 units accepted)...');
  const receiptResult2 = await ProcurementService.receiveGoods(
    schoolId,
    approvedDirectPo.id,
    {
      receivingLocationId: testLocation.id,
      items: [
        {
          poItemId,
          quantityReceived: 40,
          quantityAccepted: 40
        }
      ]
    },
    mockAdmin
  );

  const updatedPo2 = receiptResult2.purchaseOrder;
  assert(updatedPo2.status === 'FULLY_RECEIVED', `PO status should transition to FULLY_RECEIVED, got ${updatedPo2.status}`);
  assert(updatedPo2.items[0].quantityRemaining === 0, `PO item remaining should be 0, got ${updatedPo2.items[0].quantityRemaining}`);

  const stockAfterGrn2 = StockService.getOrCreateBalance(schoolId, testItem, testLocation).quantity;
  assert(
    stockAfterGrn2 === initialStock + 50 + 40,
    `Stock after second GRN should be ${initialStock + 90}, got ${stockAfterGrn2}`
  );
  console.log(`✓ PO fully received! Final stock: ${stockAfterGrn2} (increased by total 90 accepted units across batches).`);

  // =========================================================================
  // TEST 10: Capital Asset Integration from Goods Receipt
  // =========================================================================
  console.log('\n[TEST 10] Capital Asset Creation from Goods Receipt...');
  const assetCategory = database.assetCategories[0];
  const createdAsset = ProcurementService.createAssetFromReceiptLine(
    schoolId,
    {
      goodsReceiptId: receiptResult2.goodsReceipt.id,
      goodsReceiptItemId: receiptResult2.goodsReceipt.items[0].id,
      name: 'High Precision Lab Digital Balance',
      categoryId: assetCategory.id,
      locationId: testLocation.id,
      serialNumber: `SN-LAB-${Date.now()}`
    },
    mockAdmin
  );

  assert(createdAsset.id !== undefined, 'Created asset must have an ID');
  assert(createdAsset.supplierId === testSupplier.id, 'Asset supplier must match PO supplier');
  assert(createdAsset.status === 'AVAILABLE', 'Newly received asset must be AVAILABLE');
  console.log(`✓ Capital Asset created: ${createdAsset.name} (${createdAsset.assetTag}) linked to supplier ${testSupplier.name}`);

  // =========================================================================
  // TEST 11: Supplier Procurement Analytics & History
  // =========================================================================
  console.log('\n[TEST 11] Supplier Procurement Analytics...');
  const supplierHistory = ProcurementService.getSupplierProcurementHistory(schoolId, testSupplier.id);
  assert(supplierHistory.metrics.totalOrders >= 1, 'Supplier should have at least 1 order');
  assert(supplierHistory.metrics.fulfillmentRatePercentage > 0, 'Fulfillment percentage should be > 0%');
  console.log(`✓ Supplier metrics: Total Orders: ${supplierHistory.metrics.totalOrders}, Fulfillment: ${supplierHistory.metrics.fulfillmentRatePercentage}%, Spent: $${supplierHistory.metrics.totalOrderValue}`);

  // =========================================================================
  // TEST 12: Procurement Dashboard Summary KPI aggregation
  // =========================================================================
  console.log('\n[TEST 12] Procurement Dashboard KPI Summary...');
  const dashboard = ProcurementService.getDashboardSummary(schoolId);
  assert(dashboard.completedPoCount >= 1, 'Dashboard completed PO count should be >= 1');
  assert(dashboard.recentGoodsReceiptsCount >= 2, 'Dashboard recent GRN count should be >= 2');
  console.log(`✓ Dashboard Summary: Completed POs: ${dashboard.completedPoCount}, Recent GRNs: ${dashboard.recentGoodsReceiptsCount}, Total Spent: $${dashboard.totalProcurementSpent}`);

  console.log('\n===============================================================');
  console.log('ALL PART 14D PROCUREMENT TESTS PASSED SUCCESSFULLY! ✓');
  console.log('===============================================================');
}

runTests().catch(err => {
  console.error('\nTEST SUITE RUNNER FAILED:');
  console.error(err);
  process.exit(1);
});
