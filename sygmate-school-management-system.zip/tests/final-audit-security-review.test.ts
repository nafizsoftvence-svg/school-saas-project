/**
 * Part 15G — Final Audit, Security Review & Production Readiness Test Suite
 * Sygmate School Management System
 *
 * Exhaustive End-to-End Validation:
 * 1. Architecture & Authoritative Storage
 * 2. File Upload Security, MIME/Extension Validation & Path Traversal
 * 3. Role-Based Access Control (RBAC) & Permission Enforcement
 * 4. Insecure Direct Object References (IDOR) & Parameter Tampering
 * 5. Concurrency-Safe Unique Certificate Numbering & Sequential Allocation
 * 6. Issued Certificate Data Snapshot Immutability
 * 7. Verification & Approval Workflow Separation of Duties
 * 8. Digital Verification, Privacy Shielding & Anti-Enumeration
 * 9. Cross-Tenant School Isolation
 * 10. Data Reconciliation Engine (Zero Variances)
 * 11. RFC 4180 CSV Export Security & Audit Logging
 * 12. Document Expiry Horizons & Compliance Percentage Formula Precision
 */

import { database } from '../server/db/database.js';
import { DocumentService } from '../server/services/document.service.js';
import { CertificateService } from '../server/services/certificate.service.js';
import { DocumentReportService } from '../server/services/document-report.service.js';
import { User, DocumentEntityType, DocumentTypeConfig } from '../src/types/index.js';

// Setup Mock Users across all roles
const adminUser: User = {
  id: 'usr-admin-1',
  name: 'System Administrator',
  email: 'admin@sygmate.edu',
  username: 'admin',
  role: 'SUPER_ADMIN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const teacherA: User = {
  id: 'usr-teacher-1',
  name: 'Sarah Jenkins',
  email: 'sarah.jenkins@sygmate.edu',
  username: 'sarah.jenkins',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const teacherB: User = {
  id: 'usr-teacher-2',
  name: 'Marcus Brody',
  email: 'marcus.brody@sygmate.edu',
  username: 'marcus.brody',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const studentUserA: User = {
  id: 'usr-student-1',
  name: 'Alex Rivera',
  email: 'alex.rivera@student.sygmate.edu',
  username: 'alex.rivera',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const studentUserB: User = {
  id: 'usr-student-2',
  name: 'Chloe Bennett',
  email: 'chloe.bennett@student.sygmate.edu',
  username: 'chloe.bennett',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const guardianUserA: User = {
  id: 'usr-guardian-1',
  name: 'Carlos Rivera',
  email: 'carlos.rivera@example.com',
  username: 'carlos.rivera',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const guardianUserB: User = {
  id: 'usr-guardian-2',
  name: 'Dmitri Rostov',
  email: 'dmitri.rostov@example.com',
  username: 'dmitri.rostov',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const schoolId = 'school-main';

console.log('================================================================');
console.log('--- STARTING PART 15G FINAL AUDIT & SECURITY REVIEW TESTS ---');
console.log('================================================================\n');

// --------------------------------------------------------------
// [AUDIT TEST 1] Architecture & Single Source of Truth
// --------------------------------------------------------------
console.log('[AUDIT 1] Verifying Architecture & Single Source of Truth in Database...');
if (!Array.isArray(database.managedDocuments)) {
  throw new Error('AUDIT 1 FAILED: database.managedDocuments is missing or not an array.');
}
if (!Array.isArray(database.issuedCertificates)) {
  throw new Error('AUDIT 1 FAILED: database.issuedCertificates is missing or not an array.');
}
if (!Array.isArray(database.documentTypes) || !Array.isArray(database.certificateTypes)) {
  throw new Error('AUDIT 1 FAILED: documentTypes or certificateTypes collections missing.');
}
if (!Array.isArray(database.documentRequirements)) {
  throw new Error('AUDIT 1 FAILED: database.documentRequirements is missing.');
}
if (!Array.isArray(database.auditLogs)) {
  throw new Error('AUDIT 1 FAILED: database.auditLogs is missing.');
}
console.log('✓ Architecture verified: Central authoritative collections operational without silos.');

// --------------------------------------------------------------
// [AUDIT TEST 2] File Upload Security, MIME Validation & Path Traversal
// --------------------------------------------------------------
console.log('\n[AUDIT 2] Testing File Security, MIME Extensions & Path Traversal Sanitation...');

// A. Path traversal sanitation
const maliciousFilenames = [
  '../../../../etc/passwd.pdf',
  '..\\..\\windows\\system32\\cmd.exe.pdf',
  '/var/log/secrets.pdf',
  '../../../var/www/shell.pdf'
];
for (const badName of maliciousFilenames) {
  const sanitized = DocumentService.sanitizeFileName(badName);
  if (sanitized.includes('..') || sanitized.startsWith('/') || sanitized.startsWith('\\')) {
    throw new Error(`AUDIT 2 FAILED: Path traversal not stripped from "${badName}". Got: "${sanitized}"`);
  }
}
console.log('✓ Path traversal attacks neutralized: all filenames safely stripped of directory paths.');

// B. Executable extension rejection
const dangerousFiles = ['malware.exe', 'script.sh', 'webshell.php', 'exploit.bat', 'hack.js', 'app.apk'];
for (const badFile of dangerousFiles) {
  let blocked = false;
  try {
    DocumentService.validateUpload(badFile, 1024);
  } catch (err: any) {
    if (err.message.includes('not permitted')) blocked = true;
  }
  if (!blocked) {
    throw new Error(`AUDIT 2 FAILED: Dangerous executable file "${badFile}" was not blocked!`);
  }
}
console.log('✓ File extension policy enforced: Executable and dangerous script files strictly blocked.');

// C. File size boundary enforcement (Max 15MB)
let oversizedBlocked = false;
try {
  DocumentService.validateUpload('massive_archive.pdf', 20 * 1024 * 1024); // 20 MB
} catch (err: any) {
  if (err.message.includes('exceeds maximum permitted limit')) oversizedBlocked = true;
}
if (!oversizedBlocked) {
  throw new Error('AUDIT 2 FAILED: Oversized file upload (>15MB) was not rejected.');
}
console.log('✓ File size limit enforced: Oversized payloads rejected before processing.');

// --------------------------------------------------------------
// [AUDIT TEST 3] Role-Based Access Control (RBAC) & Scope Validation
// --------------------------------------------------------------
console.log('\n[AUDIT 3] Testing Role-Based Access Control (RBAC) & Scope Validation...');

// Create a confidential institutional school document
const confidentialSchoolDoc = DocumentService.createDocument(
  schoolId,
  {
    documentTypeId: 'dt-sch-accreditation',
    entityType: 'SCHOOL',
    entityId: schoolId,
    documentTitle: 'Institutional State Accreditation Secret Review 2026',
    fileName: 'accreditation_review_2026.pdf',
    fileType: 'application/pdf',
    fileSizeBytes: 1024 * 500,
    isConfidential: true
  },
  adminUser
);

// Verify student cannot access confidential school doc
const studentAccess = DocumentService.validateDocumentAccess(confidentialSchoolDoc, studentUserA, 'view');
if (studentAccess) {
  throw new Error('AUDIT 3 FAILED: Student was granted view access to confidential school document.');
}

// Verify teacher cannot access confidential school doc
const teacherAccess = DocumentService.validateDocumentAccess(confidentialSchoolDoc, teacherA, 'view');
if (teacherAccess) {
  throw new Error('AUDIT 3 FAILED: Teacher was granted view access to confidential school document.');
}

// Verify student cannot delete documents
const studentDelete = DocumentService.validateDocumentAccess(confidentialSchoolDoc, studentUserA, 'delete');
if (studentDelete) {
  throw new Error('AUDIT 3 FAILED: Student was permitted delete action.');
}

// Verify teacher cannot verify documents without super admin or reviewer assignment
const teacherVerify = DocumentService.validateDocumentAccess(confidentialSchoolDoc, teacherA, 'verify');
if (teacherVerify) {
  throw new Error('AUDIT 3 FAILED: Non-superadmin cannot unilaterally verify confidential documents.');
}

console.log('✓ RBAC access boundaries verified: Strict scoping across admin, teacher, student, and guardian.');

// --------------------------------------------------------------
// [AUDIT TEST 4] Insecure Direct Object References (IDOR) & Parameter Tampering
// --------------------------------------------------------------
console.log('\n[AUDIT 4] Testing IDOR & Parameter Tampering Protections...');

// Upload Student A document
const studentADoc = DocumentService.createDocument(
  schoolId,
  {
    documentTypeId: 'dt-stud-birth',
    entityType: 'STUDENT',
    entityId: 'stud-prof-1', // Alex Rivera
    documentTitle: 'Alex Rivera Birth Certificate Original Scan',
    fileName: 'alex_birth_cert.pdf',
    fileType: 'application/pdf',
    fileSizeBytes: 1024 * 300
  },
  adminUser
);

// Student B attempts to access Student A's document
let studentBBlocked = false;
try {
  DocumentService.getDocumentById(schoolId, studentADoc.id, studentUserB);
} catch (err: any) {
  if (err.message.includes('Access denied')) studentBBlocked = true;
}
if (!studentBBlocked) {
  throw new Error('AUDIT 4 FAILED: IDOR vulnerability detected! Student B accessed Student A document.');
}

// Guardian B attempts to access Student A's document
let guardianBBlocked = false;
try {
  DocumentService.getDocumentById(schoolId, studentADoc.id, guardianUserB);
} catch (err: any) {
  if (err.message.includes('Access denied')) guardianBBlocked = true;
}
if (!guardianBBlocked) {
  throw new Error('AUDIT 4 FAILED: IDOR vulnerability detected! Guardian B accessed Student A document.');
}

// Teacher B attempts to view Teacher A's confidential employment contract
const teacherADoc = DocumentService.createDocument(
  schoolId,
  {
    documentTypeId: 'dt-staff-contract',
    entityType: 'TEACHER',
    entityId: 'teacher-prof-1',
    documentTitle: 'Sarah Jenkins Private Salary Agreement',
    fileName: 'salary_jenkins_2026.pdf',
    fileType: 'application/pdf',
    fileSizeBytes: 1024 * 200,
    isConfidential: true
  },
  adminUser
);

let teacherBBlocked = false;
try {
  DocumentService.getDocumentById(schoolId, teacherADoc.id, teacherB);
} catch (err: any) {
  if (err.message.includes('Access denied')) teacherBBlocked = true;
}
if (!teacherBBlocked) {
  throw new Error('AUDIT 4 FAILED: IDOR vulnerability detected! Teacher B accessed Teacher A private document.');
}

console.log('✓ IDOR protections verified: Cross-student, cross-family, and cross-teacher access blocked.');

// --------------------------------------------------------------
// [AUDIT TEST 5] Concurrency-Safe Unique Certificate Numbering
// --------------------------------------------------------------
console.log('\n[AUDIT 5] Testing Concurrency-Safe Unique Certificate Numbering...');

const meritType = database.certificateTypes.find(t => t.code === 'ACADEMIC_MERIT_CERT') || database.certificateTypes[0];
const generatedNumbers = new Set<string>();
const concurrentRuns = 20;

for (let i = 0; i < concurrentRuns; i++) {
  const certNumber = CertificateService.generateCertificateNumber(schoolId, meritType, '2026');
  if (generatedNumbers.has(certNumber)) {
    throw new Error(`AUDIT 5 FAILED: Collision detected! Duplicate certificate number generated: ${certNumber}`);
  }
  generatedNumbers.add(certNumber);
}
console.log(`✓ Concurrency safety verified: Generated ${concurrentRuns} unique, sequential certificate numbers without collision.`);

// --------------------------------------------------------------
// [AUDIT TEST 6] Issued Certificate Data Snapshot Immutability
// --------------------------------------------------------------
console.log('\n[AUDIT 6] Testing Issued Certificate Data Snapshot Immutability...');

// Generate a certificate
const newCert = CertificateService.generateCertificate(
  schoolId,
  {
    certificateTypeId: meritType.id,
    studentId: 'stud-prof-1',
    remarks: 'Honors Academic Distinction'
  },
  adminUser
);

const initialSnapshotName = newCert.dataSnapshot.student.fullName;
const initialSnapshotAdm = newCert.dataSnapshot.student.admissionNumber;

// Mutate student profile in database
const studentProfile = database.studentProfiles.find(s => s.id === 'stud-prof-1');
if (studentProfile) {
  studentProfile.admissionNumber = 'ADM-MUTATED-9999';
}
const userRecord = database.users.find(u => u.id === studentProfile?.userId);
if (userRecord) {
  userRecord.name = 'Mutated Hacker Name';
}

// Verify certificate snapshot was NOT changed
const certAfterProfileMutation = CertificateService.getIssuedCertificateById(schoolId, newCert.id, adminUser);
if (
  certAfterProfileMutation.dataSnapshot.student.fullName !== initialSnapshotName ||
  certAfterProfileMutation.dataSnapshot.student.admissionNumber !== initialSnapshotAdm
) {
  throw new Error('AUDIT 6 FAILED: Immutability breach! Modifying student profile altered issued certificate snapshot.');
}
console.log('✓ Immutability verified: Changes to underlying profile records do NOT alter historical certificate snapshots.');

// Restore student profile
if (studentProfile) studentProfile.admissionNumber = 'ADM-2026-0842';
if (userRecord) userRecord.name = 'Alex Rivera';

// --------------------------------------------------------------
// [AUDIT TEST 7] Verification & Approval Separation of Duties
// --------------------------------------------------------------
console.log('\n[AUDIT 7] Testing Verification & Approval Separation of Duties...');

// Teacher generates a certificate
const teacherCert = CertificateService.generateCertificate(
  schoolId,
  {
    certificateTypeId: meritType.id,
    studentId: 'stud-prof-1',
    remarks: 'Physics Distinction'
  },
  teacherA
);

// Generator (teacherA) attempts to verify their own certificate
let selfVerificationBlocked = false;
try {
  CertificateService.verifyCertificate(
    schoolId,
    teacherCert.id,
    { decision: 'VERIFY', notes: 'Self verifying' },
    teacherA
  );
} catch (err: any) {
  if (err.message.includes('Separation of duties violation')) selfVerificationBlocked = true;
}
if (!selfVerificationBlocked) {
  throw new Error('AUDIT 7 FAILED: Generator was able to verify their own certificate! Separation of duties breached.');
}

// Independent reviewer verifies certificate
const verifiedCert = CertificateService.verifyCertificate(
  schoolId,
  teacherCert.id,
  { decision: 'VERIFY', notes: 'All grade records verified against official exam ledger' },
  adminUser
);
if (verifiedCert.verificationStatus !== 'VERIFIED') {
  throw new Error('AUDIT 7 FAILED: Certificate could not be verified by authorized verifier.');
}

// Generator (teacherA) attempts to approve their own certificate
let selfApprovalBlocked = false;
try {
  CertificateService.approveCertificate(
    schoolId,
    teacherCert.id,
    { decision: 'APPROVE', notes: 'Self approving' },
    teacherA
  );
} catch (err: any) {
  if (err.message.includes('Separation of duties violation')) selfApprovalBlocked = true;
}
if (!selfApprovalBlocked) {
  throw new Error('AUDIT 7 FAILED: Generator was able to approve their own certificate! Separation of duties breached.');
}

// Attempting to issue without leadership approval
let unapprovedIssuanceBlocked = false;
try {
  CertificateService.issueCertificate(schoolId, teacherCert.id, {}, teacherB);
} catch (err: any) {
  if (err.message.includes('Leadership approval is mandatory')) unapprovedIssuanceBlocked = true;
}
if (!unapprovedIssuanceBlocked) {
  throw new Error('AUDIT 7 FAILED: Certificate issued without prerequisite approval!');
}

console.log('✓ Separation of duties verified: Self-verification and self-approval strictly blocked.');

// --------------------------------------------------------------
// [AUDIT TEST 8] Digital Verification, Privacy Shielding & Anti-Enumeration
// --------------------------------------------------------------
console.log('\n[AUDIT 8] Testing Digital Verification, Privacy Shielding & Anti-Enumeration...');

// Formally approve and issue certificate
CertificateService.approveCertificate(
  schoolId,
  teacherCert.id,
  { decision: 'APPROVE', notes: 'Dean board approved' },
  adminUser
);
const officiallyIssued = CertificateService.issueCertificate(schoolId, teacherCert.id, {}, adminUser);

// Public verification check
const publicResult = CertificateService.publicVerifyCertificate(officiallyIssued.digitalVerificationReference);
if (!publicResult.isAuthentic || publicResult.status !== 'VALID') {
  throw new Error('AUDIT 8 FAILED: Legitimate certificate failed public verification.');
}

// Privacy data minimization checks
const pCert = publicResult.certificate!;
if (!pCert.maskedStudentName.includes('*')) {
  throw new Error(`AUDIT 8 FAILED: Student name was not masked: ${pCert.maskedStudentName}`);
}
if ((pCert as any).email || (pCert as any).phone || (pCert as any).studentId || (pCert as any).fileUrl) {
  throw new Error('AUDIT 8 FAILED: Sensitive data (email, phone, studentId, fileUrl) leaked in public response.');
}

// Anti-enumeration: bogus token returns generic NOT_FOUND
const fakeResult = CertificateService.publicVerifyCertificate('SEC-VER-FAKE-0000-0000-0000');
if (fakeResult.status !== 'NOT_FOUND' || fakeResult.isAuthentic) {
  throw new Error('AUDIT 8 FAILED: Fake reference did not return standard NOT_FOUND response.');
}

// Revocation lifecycle test
CertificateService.revokeCertificate(
  schoolId,
  officiallyIssued.id,
  { reason: 'Discovered exam grading error' },
  adminUser
);
const revokedPublicResult = CertificateService.publicVerifyCertificate(officiallyIssued.digitalVerificationReference);
if (revokedPublicResult.status !== 'REVOKED' || revokedPublicResult.isAuthentic) {
  throw new Error('AUDIT 8 FAILED: Revoked certificate still shows as authentic in public verification.');
}

console.log('✓ Public verification verified: Privacy shielding active, anti-enumeration confirmed, revocation state synced.');

// --------------------------------------------------------------
// [AUDIT TEST 9] Cross-Tenant School Isolation
// --------------------------------------------------------------
console.log('\n[AUDIT 9] Testing Cross-Tenant School Isolation...');

const schoolOtherAnalytics = DocumentReportService.getDocumentAnalytics('school-beta', 'LAST_30_DAYS', undefined, undefined, adminUser);
if (schoolOtherAnalytics.currentState.totalDocuments !== 0) {
  throw new Error('AUDIT 9 FAILED: School isolation breached! Cross-school document records leaked.');
}

const schoolOtherCerts = CertificateService.listIssuedCertificates('school-beta', {}, adminUser);
if (schoolOtherCerts.total !== 0) {
  throw new Error('AUDIT 9 FAILED: School isolation breached! Cross-school certificate records leaked.');
}

console.log('✓ Tenant isolation verified: Zero data leakage across different school tenants.');

// --------------------------------------------------------------
// [AUDIT TEST 10] Authoritative Data Reconciliation Engine
// --------------------------------------------------------------
console.log('\n[AUDIT 10] Testing Authoritative Data Reconciliation Engine (Zero Variances)...');

const reconciliation = DocumentReportService.reconcileData(schoolId, adminUser);
if (!reconciliation.isReconciled) {
  throw new Error(
    `AUDIT 10 FAILED: Reconciliation detected variance: docs=${reconciliation.documents.variance}, certs=${reconciliation.certificates.variance}, exp=${reconciliation.expiries.variance}`
  );
}
if (reconciliation.documents.variance !== 0 || reconciliation.certificates.variance !== 0) {
  throw new Error('AUDIT 10 FAILED: Variance must be strictly zero.');
}
console.log(
  `✓ Data Reconciliation PASSED: Document variance=${reconciliation.documents.variance}, Certificate variance=${reconciliation.certificates.variance}, Expiry variance=${reconciliation.expiries.variance}. 100% Reconciled.`
);

// --------------------------------------------------------------
// [AUDIT TEST 11] RFC 4180 CSV Export Security & Audit Logging
// --------------------------------------------------------------
console.log('\n[AUDIT 11] Testing RFC 4180 CSV Export Security & Audit Logging...');

const exportRes = DocumentReportService.exportToCSV(schoolId, 'compliance', {}, adminUser);
if (!exportRes.csvContent.includes('"Entity Name"') || !exportRes.csvContent.includes('"Compliance %"')) {
  throw new Error('AUDIT 11 FAILED: Export content missing RFC 4180 standard quoted headers.');
}

// Verify audit logging of export
const lastAudit = database.auditLogs[0];
if (lastAudit.action !== 'REPORT_EXPORTED') {
  throw new Error(`AUDIT 11 FAILED: Expected last audit action to be REPORT_EXPORTED, got ${lastAudit.action}`);
}
console.log(`✓ CSV Export & Audit verified: ${exportRes.fileName} generated and logged in database.auditLogs.`);

// --------------------------------------------------------------
// [AUDIT TEST 12] Document Compliance Formula Precision
// --------------------------------------------------------------
console.log('\n[AUDIT 12] Testing Document Compliance Formula Precision...');

const complianceReport = DocumentReportService.getDocumentComplianceReport(schoolId, { limit: 100 }, adminUser);
for (const ent of complianceReport.items) {
  const expected =
    ent.totalApplicableRequired > 0
      ? Math.round((ent.verifiedCount / ent.totalApplicableRequired) * 100)
      : 100;
  if (ent.compliancePercentage !== expected) {
    throw new Error(`AUDIT 12 FAILED: Formula calculation mismatch for ${ent.entityName}. Expected ${expected}%, got ${ent.compliancePercentage}%`);
  }
}
console.log(`✓ Compliance formula verified: Verified Required / Total Applicable Required × 100 confirmed on all ${complianceReport.items.length} entities.`);

console.log('\n================================================================');
console.log(' ALL 12 PART 15G FINAL AUDIT & SECURITY REVIEW TESTS PASSED! ');
console.log('================================================================\n');
