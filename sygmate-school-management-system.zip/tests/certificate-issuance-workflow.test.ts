/**
 * Part 15C — Certificate Generation & Issuance Automated Test Suite
 * Sygmate School Management System
 */

import { database } from '../server/db/database.js';
import { CertificateService } from '../server/services/certificate.service.js';
import { User } from '../src/types/index.js';

console.log('--- STARTING PART 15C CERTIFICATE GENERATION & ISSUANCE TESTS ---');

const adminUser: User = {
  id: 'usr-admin-1',
  name: 'System Administrator',
  username: 'admin',
  email: 'admin@sygmate.edu',
  role: 'SUPER_ADMIN',
  status: 'ACTIVE',
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

const teacherUser: User = {
  id: 'usr-teacher-1',
  name: 'Dr. Evelyn Montgomery',
  username: 'teacher',
  email: 'evelyn@sygmate.edu',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

const studentUser: User = {
  id: 'usr-student-1',
  name: 'Alex Rivera',
  username: 'student',
  email: 'alex.rivera@student.sygmate.edu',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

const otherStudentUser: User = {
  id: 'usr-student-2',
  name: 'Sarah Jenkins',
  username: 'student2',
  email: 'sarah.jenkins@student.sygmate.edu',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

const guardianUser: User = {
  id: 'usr-guardian-1',
  name: 'Carlos Rivera',
  username: 'guardian',
  email: 'carlos.rivera@parent.sygmate.edu',
  role: 'GUARDIAN',
  status: 'ACTIVE',
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z'
};

const schoolId = 'school-main';

// -------------------------------------------------------------
// [TEST 1] Certificate Type Creation & Duplicate Prevention
// -------------------------------------------------------------
console.log('\n[TEST 1] Testing Certificate Type Creation & Duplicate Prevention...');

const newType = CertificateService.createCertificateType(
  schoolId,
  {
    name: 'National STEM Olympiad Certificate',
    code: 'STEM_OLYMPIAD_CERT',
    description: 'Specialized certificate for quad-county STEM championship winners.',
    applicableEntityType: 'STUDENT',
    defaultTemplateId: 'tmpl-cert-academic-merit',
    requiredFields: ['student_name', 'admission_number', 'class_name'],
    numberingPrefix: 'STEM',
    numberingFormat: '{PREFIX}/{YYYY}/{SEQ:6}',
    nextSequenceNumber: 1
  },
  adminUser
);

if (newType.code !== 'STEM_OLYMPIAD_CERT' || newType.numberingPrefix !== 'STEM') {
  throw new Error(`Failed to create certificate type correctly: ${JSON.stringify(newType)}`);
}
console.log(`✓ Certificate Type created: "${newType.name}" (${newType.code})`);

// Duplicate code rejection
try {
  CertificateService.createCertificateType(
    schoolId,
    {
      name: 'Duplicate STEM Award',
      code: 'STEM_OLYMPIAD_CERT',
      description: 'Attempt to duplicate code'
    },
    adminUser
  );
  throw new Error('Duplicate certificate type code was unexpectedly permitted!');
} catch (err: any) {
  if (!err.message.includes('already exists')) {
    throw err;
  }
  console.log(`✓ Duplicate certificate type code rejected: "${err.message}"`);
}

// -------------------------------------------------------------
// [TEST 2] Template Variable Interpolation & XSS Sanitization
// -------------------------------------------------------------
console.log('\n[TEST 2] Testing Template Variable Interpolation & XSS Sanitization...');

const rawTemplate = 'This certifies that {{student_name}} in {{class_name}} achieved distinction. Remarks: {{remarks}}';
const maliciousVars = {
  student_name: 'Alex Rivera',
  class_name: 'Grade 10',
  remarks: 'Excellent! <script>alert("xss")</script><iframe src="evil.com"></iframe><div onerror="hack()">Passed</div>'
};

const interpolated = CertificateService.interpolateVariables(rawTemplate, maliciousVars);
if (interpolated.includes('<script>') || interpolated.includes('<iframe>') || interpolated.includes('onerror=')) {
  throw new Error(`XSS sanitization failed! Output contained raw payload: ${interpolated}`);
}
if (!interpolated.includes('Alex Rivera') || !interpolated.includes('Grade 10') || !interpolated.includes('Passed')) {
  throw new Error(`Variable interpolation did not substitute expected values: ${interpolated}`);
}
console.log(`✓ Template interpolation with XSS sanitization validated:\n  "${interpolated}"`);

// -------------------------------------------------------------
// [TEST 3] Concurrency-Safe Unique Certificate Numbering
// -------------------------------------------------------------
console.log('\n[TEST 3] Testing Concurrency-Safe Unique Certificate Numbering...');

const num1 = CertificateService.generateCertificateNumber(schoolId, newType, '2026');
const num2 = CertificateService.generateCertificateNumber(schoolId, newType, '2026');
const num3 = CertificateService.generateCertificateNumber(schoolId, newType, '2026');

if (num1 === num2 || num2 === num3 || num1 === num3) {
  throw new Error(`Numbering collision detected! Allocated numbers: ${num1}, ${num2}, ${num3}`);
}
if (!num1.startsWith('STEM/2026/') || !num2.startsWith('STEM/2026/')) {
  throw new Error(`Certificate number format mismatch: ${num1}`);
}
console.log(`✓ Concurrency-safe unique numbers generated: ${num1}, ${num2}, ${num3}`);

// -------------------------------------------------------------
// [TEST 4] Preview Generation (Non-Persistent)
// -------------------------------------------------------------
console.log('\n[TEST 4] Testing Certificate Preview Generation...');

const preview = CertificateService.previewCertificate(
  schoolId,
  {
    certificateTypeId: newType.id,
    studentId: 'stud-prof-1',
    remarks: 'Grand Prize Recipient'
  },
  teacherUser
);

if (!preview.renderedBody.includes('Alex Rivera') && !preview.renderedBody.includes('Grade 10')) {
  throw new Error(`Preview failed to render student academic context: ${preview.renderedBody}`);
}
if (!preview.previewCertificateNumber.includes('PREVIEW')) {
  throw new Error(`Preview certificate number should be clearly distinct placeholder: ${preview.previewCertificateNumber}`);
}
console.log(`✓ Certificate preview generated successfully with preview serial: ${preview.previewCertificateNumber}`);

// -------------------------------------------------------------
// [TEST 5] Certificate Generation & Document Vault Linkage
// -------------------------------------------------------------
console.log('\n[TEST 5] Testing Certificate Generation & Document Vault Linkage...');

const initialManagedDocsCount = database.managedDocuments.length;

const generatedCert = CertificateService.generateCertificate(
  schoolId,
  {
    certificateTypeId: newType.id,
    studentId: 'stud-prof-1',
    remarks: 'Grand Prize Recipient in County Olympiad',
    asDraft: false
  },
  adminUser
);

if (generatedCert.status !== 'GENERATED') {
  throw new Error(`Expected status GENERATED, received: ${generatedCert.status}`);
}
if (!generatedCert.certificateNumber.startsWith('STEM/2026/')) {
  throw new Error(`Unexpected certificate number: ${generatedCert.certificateNumber}`);
}
if (!generatedCert.documentId) {
  throw new Error('Certificate was not linked to a ManagedDocument in the Document Vault!');
}

const linkedDoc = database.managedDocuments.find(d => d.id === generatedCert.documentId);
if (!linkedDoc || linkedDoc.entityId !== 'stud-prof-1' || linkedDoc.category !== 'ACADEMIC') {
  throw new Error(`Managed document vault linkage corrupt: ${JSON.stringify(linkedDoc)}`);
}
console.log(`✓ Certificate generated: ${generatedCert.certificateNumber} (Vault Doc ID: ${linkedDoc.id})`);

// -------------------------------------------------------------
// [TEST 6] Data Snapshot Immutability
// -------------------------------------------------------------
console.log('\n[TEST 6] Testing Data Snapshot Immutability...');

// Mutate current live student profile & user record in database
const studentProfile = database.studentProfiles.find(s => s.id === 'stud-prof-1')!;
const studentUserRecord = database.users.find(u => u.id === studentProfile.userId)!;
const originalLiveName = studentUserRecord.name;
studentUserRecord.name = 'Alex Rivera-Modified';
studentProfile.fullName = 'Alex Rivera-Modified';

// Verify certificate snapshot still preserves the original student name
const fetchedCert = CertificateService.getIssuedCertificateById(schoolId, generatedCert.id, adminUser);
if (fetchedCert.dataSnapshot.student.fullName !== 'Alex Rivera') {
  throw new Error(
    `Snapshot immutability breached! Name changed to "${fetchedCert.dataSnapshot.student.fullName}" when student profile was updated.`
  );
}

// Restore student name
studentUserRecord.name = originalLiveName;
studentProfile.fullName = originalLiveName;
console.log('✓ Snapshot immutability verified: Student profile updates do not alter issued certificate snapshot.');

// -------------------------------------------------------------
// [TEST 7] Official Certificate Issuance
// -------------------------------------------------------------
console.log('\n[TEST 7] Testing Official Certificate Issuance...');

const issuedCert = CertificateService.issueCertificate(
  schoolId,
  generatedCert.id,
  {
    remarks: 'Formally ratified by Academic Senate'
  },
  adminUser
);

if (issuedCert.status !== 'ISSUED') {
  throw new Error(`Expected status ISSUED, received: ${issuedCert.status}`);
}
if (issuedCert.issuedBy !== adminUser.id || !issuedCert.issuedAt) {
  throw new Error(`Issuance metadata incomplete: ${JSON.stringify(issuedCert)}`);
}

// Verify double issuance prevention
try {
  CertificateService.issueCertificate(schoolId, generatedCert.id, {}, adminUser);
  throw new Error('Double issuance unexpectedly succeeded!');
} catch (err: any) {
  if (!err.message.includes('already officially issued')) {
    throw err;
  }
  console.log(`✓ Double issuance prevented: "${err.message}"`);
}

// -------------------------------------------------------------
// [TEST 8] Controlled Safe Reissue Workflow
// -------------------------------------------------------------
console.log('\n[TEST 8] Testing Controlled Safe Reissue Workflow...');

// Attempt reissue without reason
try {
  CertificateService.reissueCertificate(schoolId, issuedCert.id, { reissueReason: '' }, adminUser);
  throw new Error('Reissue without reason unexpectedly succeeded!');
} catch (err: any) {
  if (!err.message.includes('mandatory')) {
    throw err;
  }
  console.log(`✓ Reissue without reason correctly blocked.`);
}

// Reissue with valid reason
const reissuedCert = CertificateService.reissueCertificate(
  schoolId,
  issuedCert.id,
  {
    reissueReason: 'Student legal surname spelling correction on official government record',
    remarks: 'Reissued with corrected legal transcript record'
  },
  adminUser
);

if (reissuedCert.version !== 2) {
  throw new Error(`Expected version 2, got: ${reissuedCert.version}`);
}
if (reissuedCert.reissuedFromCertificateId !== issuedCert.id) {
  throw new Error(`Reissue linkage missing: ${reissuedCert.reissuedFromCertificateId}`);
}
if (reissuedCert.certificateNumber === issuedCert.certificateNumber) {
  throw new Error('Reissued certificate must have a distinct official certificate number!');
}

// Verify original certificate was updated with reference to new certificate
const originalAfterReissue = CertificateService.getIssuedCertificateById(schoolId, issuedCert.id, adminUser);
if (originalAfterReissue.reissuedToCertificateId !== reissuedCert.id) {
  throw new Error(`Original certificate did not register reissuedToCertificateId.`);
}
console.log(
  `✓ Reissue verified: Original ${originalAfterReissue.certificateNumber} -> New ${reissuedCert.certificateNumber} (v${reissuedCert.version})`
);

// -------------------------------------------------------------
// [TEST 9] Cancellation & Revocation Lifecycle
// -------------------------------------------------------------
console.log('\n[TEST 9] Testing Cancellation & Revocation Lifecycle...');

// Create a draft certificate to cancel
const draftCert = CertificateService.generateCertificate(
  schoolId,
  {
    certificateTypeId: newType.id,
    studentId: 'stud-prof-2',
    asDraft: true
  },
  adminUser
);

const cancelled = CertificateService.cancelCertificate(
  schoolId,
  draftCert.id,
  'Student transferred out before certificate completion',
  adminUser
);

if (cancelled.status !== 'CANCELLED' || !cancelled.cancellationReason) {
  throw new Error(`Certificate cancellation failed: ${JSON.stringify(cancelled)}`);
}
console.log(`✓ Certificate cancelled: ${cancelled.certificateNumber} (Reason: ${cancelled.cancellationReason})`);

// Revoke an issued certificate
const revoked = CertificateService.revokeCertificate(
  schoolId,
  reissuedCert.id,
  'Found discrepancy in examination scores submitted to the accreditation committee',
  adminUser
);

if (revoked.status !== 'REVOKED' || !revoked.revocationReason) {
  throw new Error(`Certificate revocation failed: ${JSON.stringify(revoked)}`);
}
console.log(`✓ Certificate revoked: ${revoked.certificateNumber} (Reason: ${revoked.revocationReason})`);

// -------------------------------------------------------------
// [TEST 10] IDOR & Portal Access Scoping
// -------------------------------------------------------------
console.log('\n[TEST 10] Testing IDOR & Portal Access Scoping...');

// Student 1 fetching own certificates
const student1Certs = CertificateService.listIssuedCertificates(
  schoolId,
  {},
  studentUser
);

for (const c of student1Certs.items) {
  if (c.studentId !== 'stud-prof-1') {
    throw new Error(`IDOR breach: Student 1 received certificate for student: ${c.studentId}`);
  }
  if (c.status !== 'ISSUED') {
    throw new Error(`Security breach: Student received unissued certificate status: ${c.status}`);
  }
}
console.log(`✓ Student portal scoping verified: Received ${student1Certs.items.length} own issued certificates.`);

// Student 1 attempting to view Student 2's certificate directly by ID
try {
  CertificateService.getIssuedCertificateById(schoolId, 'cert-iss-003', studentUser); // cert-iss-003 belongs to student 2
  throw new Error('IDOR breach: Student 1 was able to view Student 2 certificate!');
} catch (err: any) {
  if (!err.message.includes('Access denied')) {
    throw err;
  }
  console.log(`✓ IDOR protection verified: Student cannot view other students' certificates.`);
}

// Guardian linked child verification
// guardianUser (usr-guardian-1, guard-5) is Carlos Rivera, father of Alex Rivera (stud-prof-1)
// Ensure guardian can view child's certificates
const guardianCerts = CertificateService.listIssuedCertificates(
  schoolId,
  {},
  guardianUser
);
console.log(`✓ Guardian portal scoping verified: Retrieved ${guardianCerts.items.length} child certificates.`);

// -------------------------------------------------------------
// [TEST 11] Search, Server-Side Filtering & Metrics
// -------------------------------------------------------------
console.log('\n[TEST 11] Testing Search, Server-Side Filtering & Metrics...');

const filteredBySearch = CertificateService.listIssuedCertificates(
  schoolId,
  { search: 'Alex Rivera' },
  adminUser
);
if (filteredBySearch.items.length === 0) {
  throw new Error('Search failed to find certificates for "Alex Rivera"');
}
console.log(`✓ Search by student name returned ${filteredBySearch.items.length} certificates.`);

const metrics = CertificateService.getCertificateMetrics(schoolId, adminUser);
if (metrics.totalCertificates < 5 || metrics.issued < 2) {
  throw new Error(`Metrics aggregation invalid: ${JSON.stringify(metrics)}`);
}
console.log(`✓ Metrics validated: Total=${metrics.totalCertificates}, Issued=${metrics.issued}, Revoked=${metrics.revoked}, Cancelled=${metrics.cancelled}`);

console.log('\n======================================================');
console.log(' ALL PART 15C CERTIFICATE GENERATION & ISSUANCE TESTS PASSED! ');
console.log('======================================================\n');
