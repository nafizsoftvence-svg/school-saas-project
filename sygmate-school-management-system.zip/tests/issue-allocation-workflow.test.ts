/**
 * PART 14E — Comprehensive Issue, Return, Allocation & Department Workflow Tests
 * Sygmate School Management System
 */

import assert from 'assert';
import { IssueAllocationService } from '../server/services/issue-allocation.service.js';
import { StockService } from '../server/services/stock.service.js';
import { AssetService } from '../server/services/asset.service.js';
import { database } from '../server/db/database.js';
import { ensureInventoryCollections } from '../server/routes/inventory.routes.js';
import {
  CreateIssueRequestPayload,
  ReviewIssueRequestPayload,
  ExecuteStockIssuePayload,
  CreateInventoryReturnPayload,
  BulkAssetAllocationPayload
} from '../src/types/index.js';

const mockAdminUser = {
  id: 'usr-admin-001',
  name: 'Marcus Sterling (Administrator)',
  role: 'SUPER_ADMIN' as const,
  schoolId: 'school-main'
};

const schoolId = 'school-main';

async function runPart14ETests() {
  console.log('--- STARTING PART 14E ISSUE, RETURN, ALLOCATION & DEPARTMENT TESTS ---');
  ensureInventoryCollections();

  // Find a test inventory item and location
  const markersItem = database.inventoryItems.find(
    i => i.schoolId === schoolId && i.itemCode === 'ITM-PAP-001'
  ) || database.inventoryItems.find(i => i.schoolId === schoolId) || database.inventoryItems[0];
  const warehouse = database.inventoryLocations.find(
    l => l.schoolId === schoolId && l.code === 'LOC-CENTRAL'
  ) || database.inventoryLocations.find(l => l.schoolId === schoolId) || database.inventoryLocations[0];

  assert(markersItem, 'Must have a test inventory item');
  assert(warehouse, 'Must have a test inventory location');

  const getStock = () => StockService.getOrCreateBalance(schoolId, markersItem, warehouse).quantity;
  const initialStock = getStock();
  console.log(`Starting stock for '${markersItem.name}' at '${warehouse.name}': ${initialStock}`);

  // =========================================================================
  // TEST 1: Create Issue Request
  // =========================================================================
  console.log('\n[TEST 1] Creating an Issue Request...');
  const createReqPayload: CreateIssueRequestPayload = {
    requestingDepartment: 'Science & Robotics',
    departmentId: 'dept-sci-001',
    priority: 'HIGH',
    targetLocationId: warehouse.id,
    purpose: 'Senior robotics laboratory competition preparation',
    notes: 'Require markers and writing pads for session',
    items: [
      {
        itemId: markersItem.id,
        requestedQuantity: 20,
        notes: 'For whiteboard strategy sessions'
      }
    ]
  };

  const createdRequest = await IssueAllocationService.createIssueRequest(
    schoolId,
    createReqPayload,
    mockAdminUser
  );

  assert(createdRequest.id, 'Issue request must have an ID');
  assert(createdRequest.requestNumber.startsWith('IR-') || createdRequest.requestNumber.startsWith('REQ-'), 'Request number must follow IR- or REQ- prefix');
  assert(createdRequest.status === 'SUBMITTED', 'Initial status must be SUBMITTED');
  assert(createdRequest.items.length === 1, 'Must have 1 item');
  assert(createdRequest.items[0].requestedQuantity === 20, 'Requested qty must be 20');
  console.log(`✓ Issue Request created: ${createdRequest.requestNumber} (Status: ${createdRequest.status})`);

  // Verify stock has NOT changed at request time
  const stockAfterReq = getStock();
  assert(stockAfterReq === initialStock, `Stock must remain ${initialStock} during request, got ${stockAfterReq}`);
  console.log(`✓ VERIFIED: Stock unchanged during request stage (${stockAfterReq} units).`);

  // =========================================================================
  // TEST 2: Approve Issue Request
  // =========================================================================
  console.log('\n[TEST 2] Approving Issue Request...');
  const approvalPayload: ReviewIssueRequestPayload = {
    decision: 'APPROVE',
    reviewNotes: 'Approved for robotics competition with 15 units granted',
    itemApprovals: [
      {
        itemId: markersItem.id,
        approvedQuantity: 15 // Partial approval of 15 out of 20
      }
    ]
  };

  const approvedRequest = await IssueAllocationService.reviewIssueRequest(
    schoolId,
    createdRequest.id,
    approvalPayload,
    mockAdminUser
  );

  assert(approvedRequest.status === 'APPROVED', 'Status must transition to APPROVED');
  assert(approvedRequest.items[0].approvedQuantity === 15, 'Approved qty must be 15');
  assert(approvedRequest.items[0].remainingQuantity === 15, 'Remaining qty must be 15');
  console.log(`✓ Request ${approvedRequest.requestNumber} approved for 15 units.`);

  // Verify stock STILL untouched
  const stockAfterApproval = getStock();
  assert(stockAfterApproval === initialStock, 'Stock must not deduct at approval time');
  console.log(`✓ VERIFIED: Stock untouched at approval (${stockAfterApproval} units).`);

  // =========================================================================
  // TEST 3: Negative Stock / Over-stock Prevention
  // =========================================================================
  console.log('\n[TEST 3] Testing negative stock / over-stock execution rejection...');
  let overIssueThrew = false;
  try {
    await IssueAllocationService.executeStockIssue(
      schoolId,
      {
        issueRequestId: approvedRequest.id,
        recipientType: 'DEPARTMENT',
        recipientName: 'Science & Robotics',
        sourceLocationId: warehouse.id,
        items: [
          {
            itemId: markersItem.id,
            issueQuantity: 999999 // Ridiculous amount
          }
        ]
      },
      mockAdminUser
    );
  } catch (err: any) {
    overIssueThrew = true;
    console.log(`✓ Excess stock request rejected: ${err.message}`);
  }
  assert(overIssueThrew, 'Excess stock request must fail');

  // =========================================================================
  // TEST 4: Partial Stock Issue Execution
  // =========================================================================
  console.log('\n[TEST 4] Executing first partial Stock Issue (Batch 1: 5 units)...');
  const batch1Payload: ExecuteStockIssuePayload = {
    issueRequestId: approvedRequest.id,
    recipientType: 'TEACHER',
    recipientId: 'tch-001',
    recipientName: 'Dr. Sarah Connor',
    departmentId: 'dept-sci-001',
    departmentName: 'Science & Robotics',
    sourceLocationId: warehouse.id,
    notes: 'Batch 1 for workshop kick-off',
    items: [
      {
        itemId: markersItem.id,
        issueQuantity: 5
      }
    ]
  };

  const res1 = await IssueAllocationService.executeStockIssue(
    schoolId,
    batch1Payload,
    mockAdminUser
  );
  const issue1 = (res1 as any).stockIssue || res1;

  assert(issue1.id, 'Issue must have an ID');
  assert(issue1.issueNumber.startsWith('ISS-'), 'Issue number must start with ISS-');
  assert(issue1.items[0].quantityIssued === 5, 'Issued quantity must be 5');

  // Verify stock ledger deducted exactly 5
  const stockAfterBatch1 = getStock();
  assert(
    stockAfterBatch1 === initialStock - 5,
    `Stock must be ${initialStock - 5}, got ${stockAfterBatch1}`
  );
  console.log(`✓ VERIFIED: Authoritative stock deducted by 5 (Now: ${stockAfterBatch1}).`);

  // Verify request updated to PARTIALLY_ISSUED
  const reqAfterBatch1 = IssueAllocationService.getIssueRequestById(schoolId, approvedRequest.id);
  assert(reqAfterBatch1?.status === 'PARTIALLY_ISSUED', 'Status must be PARTIALLY_ISSUED');
  assert(reqAfterBatch1?.items[0].issuedQuantity === 5, 'Issued qty must be 5');
  assert(reqAfterBatch1?.items[0].remainingQuantity === 10, 'Remaining qty must be 10');
  console.log(`✓ Request updated: Status PARTIALLY_ISSUED, Remaining: 10 units.`);

  // =========================================================================
  // TEST 5: Over-Approved Quantity Prevention
  // =========================================================================
  console.log('\n[TEST 5] Preventing issue exceeding approved remaining quantity...');
  let overApprovedThrew = false;
  try {
    await IssueAllocationService.executeStockIssue(
      schoolId,
      {
        issueRequestId: approvedRequest.id,
        recipientType: 'TEACHER',
        recipientId: 'tch-001',
        recipientName: 'Dr. Sarah Connor',
        sourceLocationId: warehouse.id,
        items: [
          {
            itemId: markersItem.id,
            issueQuantity: 12 // Remaining is only 10
          }
        ]
      },
      mockAdminUser
    );
  } catch (err: any) {
    overApprovedThrew = true;
    console.log(`✓ Over-approved issue rejected: ${err.message}`);
  }
  assert(overApprovedThrew, 'Issue quantity exceeding remaining approved must fail');

  // =========================================================================
  // TEST 6: Complete Remaining Issue
  // =========================================================================
  console.log('\n[TEST 6] Executing second Stock Issue (Batch 2: remaining 10 units)...');
  const batch2Payload: ExecuteStockIssuePayload = {
    issueRequestId: approvedRequest.id,
    recipientType: 'DEPARTMENT',
    recipientName: 'Science & Robotics',
    departmentName: 'Science & Robotics',
    sourceLocationId: warehouse.id,
    notes: 'Batch 2 completion',
    items: [
      {
        itemId: markersItem.id,
        issueQuantity: 10
      }
    ]
  };

  const res2 = await IssueAllocationService.executeStockIssue(
    schoolId,
    batch2Payload,
    mockAdminUser
  );
  const issue2 = (res2 as any).stockIssue || res2;

  const stockAfterBatch2 = getStock();
  assert(
    stockAfterBatch2 === initialStock - 15,
    `Stock must be ${initialStock - 15}, got ${stockAfterBatch2}`
  );
  console.log(`✓ VERIFIED: Authoritative stock deducted by additional 10 (Now: ${stockAfterBatch2}).`);

  const reqAfterBatch2 = IssueAllocationService.getIssueRequestById(schoolId, approvedRequest.id);
  assert(reqAfterBatch2?.status === 'COMPLETED', `Request status must be COMPLETED, got ${reqAfterBatch2?.status}`);
  assert(reqAfterBatch2?.items[0].remainingQuantity === 0, 'Remaining quantity must be 0');
  console.log(`✓ Request fully fulfilled! Status: COMPLETED, Remaining: 0.`);

  // =========================================================================
  // TEST 7: Inventory Return Workflow
  // =========================================================================
  console.log('\n[TEST 7] Testing Inventory Return (Return 3 unused units from Batch 1)...');
  const returnPayload: CreateInventoryReturnPayload = {
    originalIssueId: issue1.id,
    returnLocationId: warehouse.id,
    returnedByType: 'TEACHER',
    returnedById: 'tch-001',
    returnedByName: 'Dr. Sarah Connor',
    departmentName: 'Science & Robotics',
    reason: 'Unused surplus markers returned after competition',
    items: [
      {
        itemId: markersItem.id,
        returnedQuantity: 3,
        itemCondition: 'GOOD',
        notes: 'Original packaging unopened'
      }
    ]
  };

  const invReturn = await IssueAllocationService.processInventoryReturn(
    schoolId,
    returnPayload,
    mockAdminUser
  );

  assert(invReturn.id, 'Return record must exist');
  assert(invReturn.returnNumber.startsWith('RET-'), 'Return number must start with RET-');
  assert(invReturn.items[0].returnedQuantity === 3, 'Returned quantity must be 3');
  assert(invReturn.items[0].restocked === true, 'GOOD condition item must be restocked');

  // Verify stock ledger was credited by 3 atomically
  const stockAfterReturn = getStock();
  assert(
    stockAfterReturn === stockAfterBatch2 + 3,
    `Stock must increase to ${stockAfterBatch2 + 3}, got ${stockAfterReturn}`
  );
  console.log(`✓ VERIFIED: Stock ledger atomically increased by 3 (Current stock: ${stockAfterReturn}).`);

  // =========================================================================
  // TEST 8: Damaged Return Does NOT Restock to Available
  // =========================================================================
  console.log('\n[TEST 8] Testing Damaged Return isolation (Damaged items do not inflate usable stock)...');
  const damagedReturnPayload: CreateInventoryReturnPayload = {
    originalIssueId: issue1.id,
    returnLocationId: warehouse.id,
    returnedByName: 'Dr. Sarah Connor',
    reason: 'Broken marker tips',
    items: [
      {
        itemId: markersItem.id,
        returnedQuantity: 1,
        itemCondition: 'DAMAGED',
        notes: 'Crushed casing during lab move'
      }
    ]
  };

  const damagedReturn = await IssueAllocationService.processInventoryReturn(
    schoolId,
    damagedReturnPayload,
    mockAdminUser
  );

  assert(damagedReturn.items[0].restocked === false, 'Damaged items must NOT be restocked to available stock');
  const stockAfterDamagedReturn = getStock();
  assert(
    stockAfterDamagedReturn === stockAfterReturn,
    'Available stock must NOT increase when damaged goods are returned'
  );
  console.log(`✓ VERIFIED: Usable stock untouched for DAMAGED condition item (${stockAfterDamagedReturn} units).`);

  // =========================================================================
  // TEST 9: Preventing Excess Return
  // =========================================================================
  console.log('\n[TEST 9] Preventing return exceeding issued quantity...');
  let excessReturnThrew = false;
  try {
    await IssueAllocationService.processInventoryReturn(
      schoolId,
      {
        originalIssueId: issue1.id, // Only had 5 issued originally, 3 already returned
        returnLocationId: warehouse.id,
        returnedByName: 'Dr. Sarah Connor',
        items: [
          {
            itemId: markersItem.id,
            returnedQuantity: 10 // Impossible, only 1 returnable remaining
          }
        ]
      },
      mockAdminUser
    );
  } catch (err: any) {
    excessReturnThrew = true;
    console.log(`✓ Excess return blocked: ${err.message}`);
  }
  assert(excessReturnThrew, 'Excess return must be rejected');

  // =========================================================================
  // TEST 10: Multi-Asset / Bulk Asset Allocation Workflow
  // =========================================================================
  console.log('\n[TEST 10] Testing Multi-Asset / Bulk Asset Allocation...');
  
  // Register 2 test assets to bulk allocate
  const asset1 = await AssetService.createAsset(
    schoolId,
    {
      name: 'Test Dell Latitude Laptop 1',
      assetTag: `TEST-DELL-${Date.now()}-1`,
      categoryId: database.assetCategories[0].id,
      locationId: warehouse.id,
      purchaseCost: 850
    },
    mockAdminUser
  );

  const asset2 = await AssetService.createAsset(
    schoolId,
    {
      name: 'Test Dell Latitude Laptop 2',
      assetTag: `TEST-DELL-${Date.now()}-2`,
      categoryId: database.assetCategories[0].id,
      locationId: warehouse.id,
      purchaseCost: 850
    },
    mockAdminUser
  );

  assert(asset1.status === 'AVAILABLE', 'Asset 1 must be AVAILABLE');
  assert(asset2.status === 'AVAILABLE', 'Asset 2 must be AVAILABLE');

  const bulkAllocPayload: BulkAssetAllocationPayload = {
    assetIds: [asset1.id, asset2.id],
    assigneeType: 'TEACHER',
    assigneeId: 'tch-002',
    assigneeName: 'Prof. Alan Turing',
    department: 'Mathematics & Computer Science',
    conditionAtHandover: 'EXCELLENT',
    handoverNotes: 'Issued for faculty AI lab setup',
    accessories: [
      { name: 'Power Adapter 65W USB-C', serialNumber: 'PA-9921', status: 'INCLUDED' },
      { name: 'Protective Laptop Sleeve', status: 'INCLUDED' }
    ]
  };

  const bulkResult = await IssueAllocationService.bulkAllocateAssets(
    schoolId,
    bulkAllocPayload,
    mockAdminUser
  );
  console.log('bulkResult:', JSON.stringify(bulkResult, null, 2));

  assert(bulkResult.successfulCount === 2, `Both assets must allocate, got ${bulkResult.successfulCount}`);
  
  // Verify assets are now ASSIGNED
  const updatedAsset1 = AssetService.getAssetById(schoolId, asset1.id).asset;
  const updatedAsset2 = AssetService.getAssetById(schoolId, asset2.id).asset;
  assert(updatedAsset1?.status === 'ASSIGNED', 'Asset 1 must be ASSIGNED');
  assert(updatedAsset2?.status === 'ASSIGNED', 'Asset 2 must be ASSIGNED');
  assert(updatedAsset1?.currentAssigneeName === 'Prof. Alan Turing', 'Assignee must be Alan Turing');
  console.log(`✓ Multi-asset bulk allocation verified: 2 assets assigned to Prof. Alan Turing.`);

  // =========================================================================
  // TEST 11: Single Active Primary Custodian Rule
  // =========================================================================
  console.log('\n[TEST 11] Enforcing Single Active Primary Custodian rule...');
  let doubleAllocThrew = false;
  try {
    await AssetService.assignAsset(
      schoolId,
      asset1.id,
      {
        assigneeType: 'STAFF',
        assigneeId: 'stf-009',
        assigneeName: 'Jane Smith'
      },
      mockAdminUser
    );
  } catch (err: any) {
    doubleAllocThrew = true;
    console.log(`✓ Second allocation blocked: ${err.message}`);
  }
  assert(doubleAllocThrew, 'Assigning an already assigned asset must fail');

  // =========================================================================
  // TEST 12: Department Allocation Analytics & Summary
  // =========================================================================
  console.log('\n[TEST 12] Verifying Department Allocation Analytics...');
  const deptSummaries = IssueAllocationService.getDepartmentAllocations(schoolId);
  assert(deptSummaries.length > 0, 'Must produce department summaries');
  
  const mathDept = deptSummaries.find(d => d.departmentName.includes('Mathematics') || d.departmentName.includes('Computer'));
  assert(mathDept, 'Mathematics department summary must be present');
  assert(mathDept.activeAssetsCount >= 2, `Math dept must have at least 2 active assets, found ${mathDept.activeAssetsCount}`);
  console.log(`✓ Department summary validated: '${mathDept.departmentName}' has ${mathDept.activeAssetsCount} active assets valued at $${mathDept.totalAssetValue}.`);

  console.log('\n===============================================================');
  console.log('ALL PART 14E ISSUE, RETURN & ALLOCATION TESTS PASSED! ✓');
  console.log('===============================================================');
}

runPart14ETests().catch(err => {
  console.error('PART 14E TEST FAILED:', err);
  process.exit(1);
});
