/**
 * LOGIN ROLE DISTINCTION & MULTI-TENANT RBAC VERIFICATION SUITE
 *
 * Verifies:
 * 1. Platform Super Admin vs. School Admin credential authentication
 * 2. Role-based redirects for all portals
 * 3. Server-side tenant context resolution and unauthorized cross-school rejection
 * 4. Immunity to client-supplied school ID / role tampering
 * 5. Quick Demo Personas resolution for all 5 roles:
 *    - Platform Super Admin (Dr. Arthur Sterling)
 *    - School Admin (Elena Rostova)
 *    - Teacher (Prof. Sarah Jenkins)
 *    - Student (Alex Rivera)
 *    - Guardian/Parent (Carlos Rivera)
 * 6. Environment-based gating of Quick Demo Personas in production
 */

import { database } from '../server/db/database.js';
import {
  verifyPassword,
  createSession,
  AuthenticatedRequest
} from '../server/security/auth.js';
import {
  getUserMemberships,
  getUserSchools,
  verifySchoolAccess,
  resolveTenantContext,
  requirePlatformAdmin
} from '../server/security/tenant.js';
import {
  hasPermission,
  getRolePermissions,
  getDefaultRedirectForRole
} from '../server/security/rbac.js';

let passed = 0;
let total = 0;

function assert(condition: boolean, testName: string) {
  total++;
  if (condition) {
    console.log(`✓ [PASSED] ${testName}`);
    passed++;
  } else {
    console.error(`✗ [FAILED] ${testName}`);
    throw new Error(`Test assertion failed: ${testName}`);
  }
}

async function runLoginRoleDistinctionTests() {
  console.log('================================================================');
  console.log('--- SYGMATE LOGIN ROLE DISTINCTION & MULTI-TENANT RBAC AUDIT ---');
  console.log('================================================================\n');

  // --------------------------------------------------------------------------
  // TEST SECTION 1: CREDENTIAL AUTHENTICATION FOR BOTH ADMIN TIERS
  // --------------------------------------------------------------------------
  console.log('--- 1. CREDENTIAL AUTHENTICATION: SUPER ADMIN VS SCHOOL ADMIN ---');

  const superAdminUser = database.users.find((u) => u.username === 'superadmin' || u.email === 'admin@sygmate.edu');
  assert(!!superAdminUser, 'Platform Super Admin test account exists');
  assert(superAdminUser?.role === 'SUPER_ADMIN', 'Platform Super Admin has role SUPER_ADMIN');
  assert(superAdminUser?.name === 'Dr. Arthur Sterling', 'Platform Super Admin name is Dr. Arthur Sterling');

  const schoolAdminUser = database.users.find((u) => u.username === 'schooladmin' || u.email === 'schooladmin@sygmate.edu');
  assert(!!schoolAdminUser, 'School Admin test account exists');
  assert(schoolAdminUser?.role === 'ADMIN', 'School Admin has role ADMIN');
  assert(schoolAdminUser?.name === 'Elena Rostova', 'School Admin name is Elena Rostova');

  // Verify passwords authenticate against cryptographic PBKDF2 hash & salt
  const isSuperAdminPasswordValid = verifyPassword('Admin@123', superAdminUser!.passwordHash, superAdminUser!.passwordSalt);
  assert(isSuperAdminPasswordValid, 'Platform Super Admin password successfully verified with PBKDF2');

  const isSchoolAdminPasswordValid = verifyPassword('Admin@123', schoolAdminUser!.passwordHash, schoolAdminUser!.passwordSalt);
  assert(isSchoolAdminPasswordValid, 'School Admin password successfully verified with PBKDF2');

  const isWrongPasswordBlocked = !verifyPassword('WrongPass123', schoolAdminUser!.passwordHash, schoolAdminUser!.passwordSalt);
  assert(isWrongPasswordBlocked, 'Invalid password is fundamentally rejected');

  // --------------------------------------------------------------------------
  // TEST SECTION 2: SERVER-SIDE ROLE-BASED REDIRECTS
  // --------------------------------------------------------------------------
  console.log('\n--- 2. ROLE-BASED PORTAL REDIRECT RESOLUTION ---');

  assert(getDefaultRedirectForRole('SUPER_ADMIN') === '/admin', 'Platform Super Admin resolves redirect to /admin');
  assert(getDefaultRedirectForRole('ADMIN') === '/admin', 'School Admin resolves redirect to /admin');
  assert(getDefaultRedirectForRole('TEACHER') === '/teacher', 'Teacher resolves redirect to /teacher');
  assert(getDefaultRedirectForRole('STUDENT') === '/student', 'Student resolves redirect to /student');
  assert(getDefaultRedirectForRole('GUARDIAN') === '/guardian', 'Guardian resolves redirect to /guardian');

  // --------------------------------------------------------------------------
  // TEST SECTION 3: MEMBERSHIP VALIDATION & CROSS-SCHOOL ISOLATION
  // --------------------------------------------------------------------------
  console.log('\n--- 3. MEMBERSHIP VALIDATION & TENANT AUTHORIZATION BOUNDARIES ---');

  // Platform Super Admin multi-school scope
  const superAdminSchools = getUserSchools(superAdminUser!.id);
  assert(superAdminSchools.length >= 2, 'Platform Super Admin has access across multiple schools');
  assert(verifySchoolAccess(superAdminUser!, 'school-main'), 'Super Admin can access school-main');
  assert(verifySchoolAccess(superAdminUser!, 'school-oakridge'), 'Super Admin can access school-oakridge');

  // School Admin single-school scope
  const schoolAdminSchools = getUserSchools(schoolAdminUser!.id);
  assert(schoolAdminSchools.length === 1 && schoolAdminSchools[0].id === 'school-main',
    'School Admin is strictly restricted to authorized school "school-main"');
  assert(verifySchoolAccess(schoolAdminUser!, 'school-main'), 'School Admin can access school-main');
  assert(!verifySchoolAccess(schoolAdminUser!, 'school-oakridge'),
    'School Admin is strictly denied access to school-oakridge');

  // --------------------------------------------------------------------------
  // TEST SECTION 4: CLIENT-SUPPLIED SCHOOL ID / ROLE TAMPERING DEFENSE
  // --------------------------------------------------------------------------
  console.log('\n--- 4. ANTI-TAMPERING & FORGED HEADER DEFENSE ---');

  // School Admin attempting to access school-main (authorized)
  const reqAuthorized: AuthenticatedRequest = {
    user: schoolAdminUser!,
    headers: { 'x-school-id': 'school-main' },
    query: {},
    body: {}
  } as any;
  const resAuthorized = resolveTenantContext(reqAuthorized);
  assert(resAuthorized.context !== null, 'School Admin successfully resolves context for authorized school-main');
  assert(resAuthorized.context?.isPlatformAdmin === false, 'isPlatformAdmin is false for School Admin context');

  // School Admin attempting IDOR / tampering by sending 'school-oakridge' in header, query, and body
  const reqForged: AuthenticatedRequest = {
    user: schoolAdminUser!,
    headers: { 'x-school-id': 'school-oakridge' },
    query: { schoolId: 'school-oakridge' },
    body: { schoolId: 'school-oakridge' }
  } as any;
  const resForged = resolveTenantContext(reqForged);
  assert(resForged.context === null, 'Forged client school ID attempt is strictly blocked by server');
  assert(resForged.status === 403, 'Tampering attempt returns HTTP status 403');
  assert(resForged.code === 'FORBIDDEN_TENANT_ACCESS', 'Tampering attempt returns FORBIDDEN_TENANT_ACCESS');

  // --------------------------------------------------------------------------
  // TEST SECTION 5: PLATFORM ENDPOINT RESTRICTION
  // --------------------------------------------------------------------------
  console.log('\n--- 5. PLATFORM ADMINISTRATIVE ENDPOINT RESTRICTION ---');

  // Platform Super Admin permissions
  assert(hasPermission('SUPER_ADMIN', 'platform.schools.view'), 'Platform Super Admin has "platform.schools.view"');
  assert(hasPermission('SUPER_ADMIN', 'platform.schools.manage'), 'Platform Super Admin has "platform.schools.manage"');
  assert(hasPermission('SUPER_ADMIN', 'platform.subscriptions.manage'), 'Platform Super Admin has "platform.subscriptions.manage"');

  // School Admin MUST NOT have platform management permissions
  assert(!hasPermission('ADMIN', 'platform.schools.manage'), 'School Admin is blocked from "platform.schools.manage"');
  assert(!hasPermission('ADMIN', 'platform.subscriptions.manage'), 'School Admin is blocked from "platform.subscriptions.manage"');
  assert(!hasPermission('ADMIN', 'platform.schools.view'), 'School Admin is blocked from "platform.schools.view"');

  // Mock test of requirePlatformAdmin middleware for both admin roles
  let superAdminAllowed = false;
  requirePlatformAdmin(
    { user: superAdminUser } as any,
    {} as any,
    () => { superAdminAllowed = true; }
  );
  assert(superAdminAllowed, 'requirePlatformAdmin allows Platform Super Admin');

  let schoolAdminBlocked = false;
  let schoolAdminStatusCode = 0;
  requirePlatformAdmin(
    { user: schoolAdminUser } as any,
    {
      status: (code: number) => {
        schoolAdminStatusCode = code;
        return {
          json: (payload: any) => {
            if (code === 403 && payload.code === 'FORBIDDEN_PLATFORM_ADMIN') {
              schoolAdminBlocked = true;
            }
          }
        };
      }
    } as any,
    () => { /* next should not be called */ }
  );
  assert(schoolAdminBlocked && schoolAdminStatusCode === 403,
    'requirePlatformAdmin strictly blocks School Admin with 403 FORBIDDEN_PLATFORM_ADMIN');

  // --------------------------------------------------------------------------
  // TEST SECTION 6: QUICK DEMO PERSONAS RESOLUTION ACROSS ALL 5 ROLES
  // --------------------------------------------------------------------------
  console.log('\n--- 6. QUICK DEMO PERSONAS ACCOUNT RESOLUTION ---');

  // 1. Platform Super Admin
  const demoSuperAdmin = database.users.find((u) => u.role === 'SUPER_ADMIN' && u.status === 'active');
  assert(!!demoSuperAdmin && demoSuperAdmin.username === 'superadmin' && demoSuperAdmin.name === 'Dr. Arthur Sterling',
    'Platform Super Admin demo maps to Dr. Arthur Sterling (superadmin)');

  // 2. School Admin
  const demoSchoolAdmin = database.users.find((u) => u.role === 'ADMIN' && u.schoolId === 'school-main' && u.status === 'active');
  assert(!!demoSchoolAdmin && demoSchoolAdmin.username === 'schooladmin' && demoSchoolAdmin.name === 'Elena Rostova',
    'School Admin demo maps to Elena Rostova (schooladmin)');

  // 3. Teacher
  const demoTeacher = database.users.find((u) => u.role === 'TEACHER' && u.status === 'active');
  assert(!!demoTeacher && demoTeacher.username === 'sjenkins' && demoTeacher.name === 'Prof. Sarah Jenkins',
    'Teacher demo maps to Prof. Sarah Jenkins (sjenkins)');

  // 4. Student
  const demoStudent = database.users.find((u) => u.role === 'STUDENT' && u.status === 'active');
  assert(!!demoStudent && demoStudent.username === 'arivera' && demoStudent.name === 'Alex Rivera',
    'Student demo maps to Alex Rivera (arivera)');

  // 5. Guardian / Parent
  const demoGuardian = database.users.find((u) => u.role === 'GUARDIAN' && u.status === 'active');
  assert(!!demoGuardian && demoGuardian.username === 'crivera' && demoGuardian.name === 'Carlos Rivera',
    'Guardian demo maps to Carlos Rivera (crivera)');

  // --------------------------------------------------------------------------
  // TEST SECTION 7: PRODUCTION ENVIRONMENT GATING
  // --------------------------------------------------------------------------
  console.log('\n--- 7. PRODUCTION ENVIRONMENT DEMO GATING ---');

  // Simulate production environment
  const originalNodeEnv = process.env.NODE_ENV;
  const originalEnableDemo = process.env.ENABLE_DEMO_PERSONAS;

  try {
    process.env.NODE_ENV = 'production';
    delete process.env.ENABLE_DEMO_PERSONAS;

    const isProdDemoEnabled = !(process.env.NODE_ENV === 'production' && process.env.ENABLE_DEMO_PERSONAS !== 'true');
    assert(isProdDemoEnabled === false, 'Quick Demo Personas are strictly disabled when NODE_ENV is production');

    // Simulate explicit override in production
    process.env.ENABLE_DEMO_PERSONAS = 'true';
    const isOverrideDemoEnabled = !(process.env.NODE_ENV === 'production' && process.env.ENABLE_DEMO_PERSONAS !== 'true');
    assert(isOverrideDemoEnabled === true, 'Quick Demo Personas only enabled in production when ENABLE_DEMO_PERSONAS is true');
  } finally {
    // Restore original env
    if (originalNodeEnv !== undefined) {
      process.env.NODE_ENV = originalNodeEnv;
    } else {
      delete process.env.NODE_ENV;
    }
    if (originalEnableDemo !== undefined) {
      process.env.ENABLE_DEMO_PERSONAS = originalEnableDemo;
    } else {
      delete process.env.ENABLE_DEMO_PERSONAS;
    }
  }

  // --------------------------------------------------------------------------
  // TEST SECTION 8: ALL OTHER CORE LOGIN FLOWS PRESERVED
  // --------------------------------------------------------------------------
  console.log('\n--- 8. PRESERVATION OF EXISTING USER LOGINS ---');

  const teacherUser = database.users.find((u) => u.username === 'sjenkins');
  assert(verifyPassword('Teacher@123', teacherUser!.passwordHash, teacherUser!.passwordSalt),
    'Teacher account authenticates with existing credentials');

  const studentUser = database.users.find((u) => u.username === 'arivera');
  assert(verifyPassword('Student@123', studentUser!.passwordHash, studentUser!.passwordSalt),
    'Student account authenticates with existing credentials');

  const guardianUser = database.users.find((u) => u.username === 'crivera');
  assert(verifyPassword('Guardian@123', guardianUser!.passwordHash, guardianUser!.passwordSalt),
    'Guardian account authenticates with existing credentials');

  console.log('\n================================================================');
  console.log(`ALL LOGIN ROLE DISTINCTION AUDIT CHECKS PASSED: ${passed}/${total}`);
  console.log('STATUS: LOGIN ROLE DISTINCTION & MULTI-TENANT ISOLATION FULLY VERIFIED');
  console.log('================================================================');
}

runLoginRoleDistinctionTests().catch((err) => {
  console.error('\nTest suite failed with error:', err);
  process.exit(1);
});
