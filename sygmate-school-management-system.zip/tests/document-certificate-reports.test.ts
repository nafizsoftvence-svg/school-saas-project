/**
 * Part 15F — Document & Certificate Reports, Analytics & Compliance Test Suite
 * Sygmate School Management System
 *
 * Tests:
 * 1. Document Analytics Dashboard (Current-state vs Historical Period metrics)
 * 2. Document Compliance Report & Exact Formula ("Verified Required / Total Applicable Required * 100")
 * 3. Document Expiry & Renewal Report (Already Expired, Expiring Today, Horizons, Urgency levels)
 * 4. Certificate Analytics & Lifecycle Funnel (Generated -> Verified -> Approved -> Issued)
 * 5. Measured Processing Durations (derived from recorded timestamps in workflow histories)
 * 6. Certificate Issuance & Workflow Review Ledger (rejection reasons, verifier, approver)
 * 7. Digital Verification Report (privacy shielding, masked student names)
 * 8. Authoritative Data Reconciliation (zero variance between dashboard and core tables)
 * 9. RFC 4180 CSV Export Generation & Audit Trail Logging
 * 10. Security, RBAC & Tenant Isolation (Unauthorized role rejection, School isolation)
 */

import { database } from '../server/db/database.js';
import { DocumentReportService } from '../server/services/document-report.service.js';
import { DocumentService } from '../server/services/document.service.js';
import { CertificateService } from '../server/services/certificate.service.js';
import { User } from '../src/types/index.js';

const mockAdminUser: User = {
  id: 'usr-admin-1',
  name: 'System Administrator',
  email: 'admin@sygmate.edu',
  username: 'admin',
  role: 'SUPER_ADMIN',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockTeacherUser: User = {
  id: 'usr-teacher-1',
  name: 'Sarah Jenkins',
  email: 'sarah.jenkins@sygmate.edu',
  username: 'sarah.jenkins',
  role: 'TEACHER',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const mockStudentUser: User = {
  id: 'usr-student-1',
  name: 'Alex Rivera',
  email: 'alex.rivera@student.sygmate.edu',
  username: 'alex.rivera',
  role: 'STUDENT',
  status: 'ACTIVE',
  createdAt: '2026-01-01',
  updatedAt: '2026-01-01'
};

const schoolId = 'school-main';

console.log('--- STARTING PART 15F DOCUMENT & CERTIFICATE REPORTS & COMPLIANCE TESTS ---');

// [TEST 1] Document Analytics Dashboard
console.log('\n[TEST 1] Testing Document Analytics Dashboard (Current-State vs Period)...');
const docAnalytics = DocumentReportService.getDocumentAnalytics(
  schoolId,
  'LAST_30_DAYS',
  undefined,
  undefined,
  mockAdminUser
);

if (typeof docAnalytics.currentState.totalDocuments !== 'number' || docAnalytics.currentState.totalDocuments < 0) {
  throw new Error('TEST 1 FAILED: Invalid totalDocuments in current state.');
}
if (typeof docAnalytics.currentState.verified !== 'number') {
  throw new Error('TEST 1 FAILED: Missing verified count in current state.');
}
if (!Array.isArray(docAnalytics.timeline) || docAnalytics.timeline.length === 0) {
  throw new Error('TEST 1 FAILED: Timeline should contain interval points.');
}
if (!Array.isArray(docAnalytics.categoryBreakdown)) {
  throw new Error('TEST 1 FAILED: Missing category breakdown.');
}
console.log(
  `✓ Document Analytics verified: Total Active Docs=${docAnalytics.currentState.totalDocuments}, Verified=${docAnalytics.currentState.verified}, Expired=${docAnalytics.currentState.expiredDocuments}, Uploaded in Period=${docAnalytics.periodMetrics.documentsUploaded}`
);

// [TEST 2] Document Compliance Report & Strict Calculation
console.log('\n[TEST 2] Testing Document Compliance Report & Percentage Calculation...');
const complianceRes = DocumentReportService.getDocumentComplianceReport(
  schoolId,
  { limit: 50 },
  mockAdminUser
);

if (!Array.isArray(complianceRes.items) || complianceRes.items.length === 0) {
  throw new Error('TEST 2 FAILED: Compliance report should return evaluated entities.');
}
if (typeof complianceRes.summary.averageComplianceRate !== 'number') {
  throw new Error('TEST 2 FAILED: Compliance summary missing averageComplianceRate.');
}

// Check formula compliance on each entity
for (const item of complianceRes.items) {
  const expectedPct =
    item.totalApplicableRequired > 0
      ? Math.round((item.verifiedCount / item.totalApplicableRequired) * 100)
      : 100;
  if (item.compliancePercentage !== expectedPct) {
    throw new Error(
      `TEST 2 FAILED: Formula mismatch for ${item.entityName}. Expected ${expectedPct}%, got ${item.compliancePercentage}%`
    );
  }
}
console.log(
  `✓ Compliance calculation verified across ${complianceRes.items.length} entities. Average compliance rate: ${complianceRes.summary.averageComplianceRate}%, Fully Compliant: ${complianceRes.summary.fullyCompliantCount}, Non-Compliant: ${complianceRes.summary.nonCompliantCount}.`
);

// [TEST 3] Document Expiry & Renewal Report
console.log('\n[TEST 3] Testing Document Expiry & Renewal Report with Urgency...');
const expiryRes = DocumentReportService.getDocumentExpiryReport(
  schoolId,
  { horizonDays: 90, limit: 50 },
  mockAdminUser
);

if (!Array.isArray(expiryRes.items)) {
  throw new Error('TEST 3 FAILED: Expiry report should return items array.');
}
for (const exp of expiryRes.items) {
  if (exp.daysRemaining < 0 && exp.urgency !== 'CRITICAL') {
    throw new Error(`TEST 3 FAILED: Overdue document ${exp.documentTitle} must have CRITICAL urgency.`);
  }
}
console.log(
  `✓ Expiry report verified: Monitored Documents=${expiryRes.summary.totalMonitored}, Already Expired=${expiryRes.summary.alreadyExpired}, Expiring in ≤30d=${expiryRes.summary.expiringIn30Days}`
);

// [TEST 4] Certificate Analytics Dashboard
console.log('\n[TEST 4] Testing Certificate Dashboard & Lifecycle Funnel...');
const certAnalytics = DocumentReportService.getCertificateAnalytics(
  schoolId,
  'LAST_30_DAYS',
  undefined,
  undefined,
  mockAdminUser
);

if (typeof certAnalytics.currentState.totalCertificates !== 'number') {
  throw new Error('TEST 4 FAILED: Missing totalCertificates in certificate analytics.');
}
if (!Array.isArray(certAnalytics.byType)) {
  throw new Error('TEST 4 FAILED: Missing byType breakdown.');
}
console.log(
  `✓ Certificate Analytics verified: Total Certificates=${certAnalytics.currentState.totalCertificates}, Officially Issued=${certAnalytics.currentState.issued}, Approved=${certAnalytics.currentState.approved}, Verified=${certAnalytics.currentState.verified}`
);

// [TEST 5] Certificate Lifecycle Durations from Recorded Timestamps
console.log('\n[TEST 5] Testing Certificate Lifecycle Durations & Drop-off Rates...');
const lifecycle = DocumentReportService.getCertificateLifecycleAnalytics(schoolId, mockAdminUser);

if (lifecycle.funnel.generatedCount < 0 || lifecycle.funnel.issuedCount < 0) {
  throw new Error('TEST 5 FAILED: Invalid funnel counts.');
}
if (typeof lifecycle.durations.avgGenerationToVerificationHours !== 'number') {
  throw new Error('TEST 5 FAILED: Missing avgGenerationToVerificationHours.');
}
console.log(
  `✓ Measured Durations verified: Gen→Ver: ${lifecycle.durations.avgGenerationToVerificationHours}h, Ver→App: ${lifecycle.durations.avgVerificationToApprovalHours}h, App→Iss: ${lifecycle.durations.avgApprovalToIssuanceHours}h, Avg Total Cycle: ${lifecycle.durations.avgTotalCycleDays} days.`
);

// [TEST 6] Certificate Issuance & Workflow Review Reports
console.log('\n[TEST 6] Testing Certificate Issuance & Workflow Ledger Reports...');
const issuanceRes = DocumentReportService.getCertificateIssuanceReport(schoolId, { limit: 25 }, mockAdminUser);
const workflowRes = DocumentReportService.getCertificateWorkflowReport(schoolId, { limit: 25 }, mockAdminUser);

if (!Array.isArray(issuanceRes.items) || issuanceRes.items.length === 0) {
  throw new Error('TEST 6 FAILED: Issuance report returned no records.');
}
if (!Array.isArray(workflowRes.items)) {
  throw new Error('TEST 6 FAILED: Workflow report returned no records.');
}
const sampleCert = issuanceRes.items[0];
if (!sampleCert.certificateNumber || !sampleCert.digitalVerificationReference) {
  throw new Error('TEST 6 FAILED: Certificate missing certificateNumber or digitalVerificationReference.');
}
console.log(
  `✓ Issuance Ledger verified: Sample cert #${sampleCert.certificateNumber} (${sampleCert.certificateTypeName}), Status: ${sampleCert.status}, Ref: ${sampleCert.digitalVerificationReference}`
);

// [TEST 7] Digital Verification Report (Privacy Shielding)
console.log('\n[TEST 7] Testing Digital Verification Report & Privacy Protection...');
const digitalRes = DocumentReportService.getDigitalVerificationReport(schoolId, { limit: 25 }, mockAdminUser);

for (const d of digitalRes.items) {
  // Ensure student name is masked (e.g. contains asterisk or initials, not full unmasked name)
  if (!d.maskedStudentName.includes('*')) {
    throw new Error(`TEST 7 FAILED: Student name was not properly masked in verification report: ${d.maskedStudentName}`);
  }
  // Ensure no internal DB ID or private phone/email is in the record
  if ((d as any).phone || (d as any).email || (d as any).studentId) {
    throw new Error('TEST 7 FAILED: Sensitive personal data leaked in public digital verification report.');
  }
}
console.log(
  `✓ Privacy Shielding verified: ${digitalRes.items.length} digital certificates checked. Student names masked (e.g. "${digitalRes.items[0]?.maskedStudentName}").`
);

// [TEST 8] Authoritative Data Reconciliation
console.log('\n[TEST 8] Testing Authoritative Data Reconciliation (Zero Variance)...');
const reconciliation = DocumentReportService.reconcileData(schoolId, mockAdminUser);

if (!reconciliation.isReconciled) {
  throw new Error(
    `TEST 8 FAILED: Reconciliation detected unexpected variance: docVariance=${reconciliation.documents.variance}, certVariance=${reconciliation.certificates.variance}, expiryVariance=${reconciliation.expiries.variance}`
  );
}
if (reconciliation.documents.variance !== 0 || reconciliation.certificates.variance !== 0) {
  throw new Error('TEST 8 FAILED: Variance must be 0.');
}
console.log(
  `✓ Data Reconciliation PASSED: 100% Reconciled. Document variance=0, Certificate variance=0, Expiry variance=0.`
);

// [TEST 9] RFC 4180 CSV Export & Audit Logging
console.log('\n[TEST 9] Testing RFC 4180 CSV Export Generation & Audit Trail...');
const exportResult = DocumentReportService.exportToCSV(schoolId, 'compliance', {}, mockAdminUser);

if (!exportResult.fileName.endsWith('.csv')) {
  throw new Error('TEST 9 FAILED: Invalid export file name.');
}
if (!exportResult.csvContent.includes('"Entity Name"') || !exportResult.csvContent.includes('"Compliance %"')) {
  throw new Error('TEST 9 FAILED: CSV content missing standard quoted headers.');
}

// Verify audit entry was logged in database.auditLogs
const exportAudit = database.auditLogs.find(l => l.action === 'REPORT_EXPORTED');
if (!exportAudit) {
  throw new Error('TEST 9 FAILED: Report export action was not recorded in audit log.');
}
console.log(
  `✓ CSV Export verified: File="${exportResult.fileName}", Content Size=${exportResult.csvContent.length} bytes, Audited in database.auditLogs (ID: ${exportAudit.id}).`
);

// [TEST 10] Security, RBAC & Tenant Isolation
console.log('\n[TEST 10] Testing Security, RBAC & Tenant Isolation...');

// A. Unauthorized role rejection
let unauthorizedBlocked = false;
try {
  DocumentReportService.getDocumentAnalytics(schoolId, 'LAST_30_DAYS', undefined, undefined, mockStudentUser);
} catch (err: any) {
  if (err.message.includes('Access denied')) {
    unauthorizedBlocked = true;
  }
}
if (!unauthorizedBlocked) {
  throw new Error('TEST 10 FAILED: Student role was not blocked from administrative report.');
}

// B. Tenant isolation (School A vs School B)
const schoolBAnalytics = DocumentReportService.getDocumentAnalytics('school-other', 'LAST_30_DAYS', undefined, undefined, mockAdminUser);
if (schoolBAnalytics.currentState.totalDocuments !== 0) {
  throw new Error('TEST 10 FAILED: School isolation breached; documents leaked across tenant boundaries.');
}

console.log('✓ Security checks passed: Unauthorized roles strictly blocked, tenant boundaries isolated.');

console.log('\n======================================================');
console.log(' ALL PART 15F REPORTS, ANALYTICS & COMPLIANCE TESTS PASSED!');
console.log('======================================================\n');
