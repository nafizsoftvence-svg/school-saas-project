/**
 * Comprehensive Automated Audit & Test Script for Part 11E:
 * Communication Analytics, Delivery Reports, Privacy Masking & Scheduler Controls
 */
import { database } from '../server/db/database.js';
import { CommunicationAnalyticsService } from '../server/services/communication-analytics.service.js';
import { BulkCampaignService } from '../server/services/bulk-campaign.service.js';
import { AnnouncementService } from '../server/services/announcement.service.js';
import { CommunicationService } from '../server/services/communication.service.js';
import { UserRole } from '../src/types/index.js';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    console.log(`✅ [PASS] ${testName}`);
    passed++;
  } else {
    console.error(`❌ [FAIL] ${testName}${detail ? ` - ${detail}` : ''}`);
    failed++;
  }
}

async function runTests() {
  console.log('===============================================================');
  console.log('PART 11E AUDIT: Communication Analytics & Delivery Reports Test');
  console.log('===============================================================\n');

  // Test 1: Masking Helpers
  console.log('--- Subtest 1: Privacy Masking (FERPA/GDPR Compliance) ---');
  const maskedEmail1 = CommunicationAnalyticsService.maskEmail('john.doe@springfield.edu');
  assert(maskedEmail1.startsWith('j') && maskedEmail1.includes('***') && maskedEmail1.endsWith('@springfield.edu'), 'Masks standard email with name obscured', maskedEmail1);

  const maskedEmailShort = CommunicationAnalyticsService.maskEmail('a@b.com');
  assert(maskedEmailShort.includes('***@b.com'), 'Masks short email properly', maskedEmailShort);

  const maskedPhone = CommunicationAnalyticsService.maskPhone('+1 555-987-6543');
  assert(maskedPhone.endsWith('6543') && maskedPhone.includes('***'), 'Masks phone preserving last 4 digits', maskedPhone);

  const maskedInvalid = CommunicationAnalyticsService.maskPhone('');
  assert(maskedInvalid === '—', 'Masks empty phone to fallback dash');

  // Test 2: Overview Analytics Generation
  console.log('\n--- Subtest 2: Aggregate Analytics Overview ---');
  const overview = CommunicationAnalyticsService.getAnalyticsOverview({ datePreset: 'LAST_30_DAYS' });
  assert(overview !== null && typeof overview === 'object', 'Generates overview object');
  assert(typeof overview.summary.totalRecipients === 'number', 'Summary contains totalRecipients count');
  assert(typeof overview.summary.overallDeliveryRate === 'number', 'Summary contains overallDeliveryRate %');
  assert(overview.summary.overallDeliveryRate >= 0 && overview.summary.overallDeliveryRate <= 100, 'Delivery rate is between 0 and 100%');
  
  // Channels
  assert(!!overview.channelAnalytics.IN_APP, 'Contains IN_APP channel metrics');
  assert(!!overview.channelAnalytics.EMAIL, 'Contains EMAIL channel metrics');
  assert(!!overview.channelAnalytics.SMS, 'Contains SMS channel metrics');
  assert(!!overview.channelAnalytics.PUSH, 'Contains PUSH channel metrics');
  assert(typeof overview.channelAnalytics.IN_APP.deliveryRate === 'number', 'IN_APP has deliveryRate number');

  // Performance SLA
  assert(typeof overview.performance.avgDeliveryProcessingMs === 'number', 'Performance has processing latency ms');
  assert(typeof overview.performance.avgQueueWaitMs === 'number', 'Performance has queue wait latency ms');

  // Failure Analysis Categories
  assert(Array.isArray(overview.failureAnalysis) && overview.failureAnalysis.length >= 6, 'Contains failure taxonomy categories');
  const invalidRecipCategory = overview.failureAnalysis.find(f => f.category === 'INVALID_RECIPIENT');
  assert(!!invalidRecipCategory, 'Found INVALID_RECIPIENT failure category');

  // Test 3: Delivery Ledger & Pagination
  console.log('\n--- Subtest 3: Delivery Ledger Paginated Query ---');
  const ledgerPage1 = CommunicationAnalyticsService.getDeliveryReport({ page: 1, limit: 5 });
  assert(Array.isArray(ledgerPage1.data), 'Returns delivery ledger data array');
  assert(ledgerPage1.page === 1, 'Page number correctly set to 1');
  assert(ledgerPage1.limit === 5, 'Limit correctly set to 5');
  assert(typeof ledgerPage1.total === 'number', 'Returns total count');
  assert(ledgerPage1.totalPages >= 1, 'Returns totalPages >= 1');
  
  if (ledgerPage1.data.length > 0) {
    const firstRow = ledgerPage1.data[0];
    assert(!!firstRow.recipientContactMasked, 'Row contains masked recipient contact');
    assert(!firstRow.recipientContactMasked.includes('password'), 'Row does not expose passwords');
    assert(firstRow.recipientContactMasked.includes('***') || firstRow.recipientContactMasked === 'In-App User ID', 'Contact is masked or in-app format');
  }

  // Test 4: Export Reports
  console.log('\n--- Subtest 4: Report Exports (CSV & JSON) ---');
  const actor = { id: 'admin-1', name: 'Admin Sarah', role: 'SUPER_ADMIN' as UserRole };
  
  const csvExport = CommunicationAnalyticsService.exportReport('delivery', 'csv', {}, actor);
  assert(csvExport.mimeType === 'text/csv; charset=utf-8', 'CSV export has text/csv mime type');
  assert(csvExport.filename.endsWith('.csv'), 'Filename ends with .csv');
  assert(csvExport.content.includes('RecordID'), 'CSV content contains headers');

  const jsonExport = CommunicationAnalyticsService.exportReport('summary', 'json', {}, actor);
  assert(jsonExport.mimeType === 'application/json', 'JSON export has application/json mime type');
  assert(jsonExport.filename.endsWith('.json'), 'Filename ends with .json');
  const parsedJson = JSON.parse(jsonExport.content);
  assert(Array.isArray(parsedJson) || typeof parsedJson === 'object', 'JSON content is valid JSON object/array');

  // Test Audit Log generation for export
  const auditLogs = database.auditLogs || [];
  const exportLog = auditLogs.find(l => l.action === 'EXPORT' && l.entity === 'COMMUNICATION_REPORT');
  assert(!!exportLog, 'Export operation created an authoritative audit log record');

  // Test 5: Scheduled Communication Cancellation
  console.log('\n--- Subtest 5: Scheduled Communication Cancellation ---');
  // Create a scheduled campaign
  const scheduledCampaign = await BulkCampaignService.createCampaign({
    name: 'Scheduled Sports Day Alert',
    title: 'Sports Day Reminder',
    body: 'Please wear team colors tomorrow.',
    category: 'general',
    channels: ['IN_APP', 'EMAIL'],
    audienceType: 'SCHOOL_WIDE',
    scheduleType: 'SCHEDULED',
    scheduledAt: new Date(Date.now() + 86400000).toISOString(),
    status: 'SCHEDULED'
  }, actor);

  assert(scheduledCampaign.status === 'SCHEDULED', 'Created test campaign with status SCHEDULED');

  const cancelResult = CommunicationAnalyticsService.cancelScheduledCommunication(
    scheduledCampaign.id,
    'CAMPAIGN',
    actor
  );
  assert(cancelResult.success === true, 'Successfully cancelled scheduled campaign');
  
  const fetchedCampaign = BulkCampaignService.getCampaignById(scheduledCampaign.id);
  assert(fetchedCampaign?.campaign.status === 'CANCELLED', 'Campaign status updated to CANCELLED in database');

  // Test 6: Security & Data Hygiene
  console.log('\n--- Subtest 6: Security, Secrets Sanitization & Hygiene ---');
  const settings = CommunicationService.getSanitizedSettings();
  assert(!settings.email.password && (settings.email.passwordMasked?.includes('••••') || false), 'SMTP password is strictly sanitized/masked');
  assert(!settings.sms.authToken && (settings.sms.authTokenMasked?.includes('••••') || false), 'Twilio auth token is strictly sanitized/masked');
  assert(!settings.push.serverKey && (settings.push.serverKeyMasked?.includes('••••') || false), 'FCM server key is strictly sanitized/masked');

  console.log('\n===============================================================');
  console.log(`AUDIT RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('===============================================================');

  if (failed > 0) {
    process.exit(1);
  }
  process.exit(0);
}

runTests().catch((err) => {
  console.error('Audit suite crashed with error:', err);
  process.exit(1);
});
