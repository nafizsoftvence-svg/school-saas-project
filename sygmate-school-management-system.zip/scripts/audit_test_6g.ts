/**
 * Sygmate School Management System
 * PART 6G — Examination & Result Final Audit Test Suite
 * Executes comprehensive 13-point test plan validating workflow, security, calculations,
 * RBAC, integrity, performance, student/parent portals, and regression safety.
 */

import { database } from '../server/db/database.js';
import { logAudit } from '../server/security/audit.js';
import { isTeacherAuthorizedForExamSubject, lookupGradeRule } from '../server/routes/examination.routes.js';
import { VALID_WORKFLOW_TRANSITIONS } from '../server/routes/examination.routes.js';
import { ROLE_PERMISSIONS } from '../server/security/rbac.js';

interface TestResult {
  category: string;
  name: string;
  passed: boolean;
  details: string;
  latencyMs?: number;
}

const testResults: TestResult[] = [];

function assert(category: string, name: string, condition: boolean, details: string, startMs?: number) {
  const latencyMs = startMs ? Math.round(performance.now() - startMs) : undefined;
  testResults.push({
    category,
    name,
    passed: !!condition,
    details,
    latencyMs
  });
}

export function calculateStudentGpaAndGrade(
  marks: Array<{ subjectId: string; obtainedMarks: number; isAbsent?: boolean; isExempt?: boolean }>,
  configs: Array<{ subjectId: string; subjectName: string; subjectCode: string; credits: number; fullMarks: number; passMarks: number }>,
  scale: any[]
) {
  let totalFullMarks = 0;
  let totalObtainedMarks = 0;
  let totalQualityPoints = 0;
  let totalCredits = 0;
  let passedCount = 0;
  let failedCount = 0;
  let absentCount = 0;
  let exemptCount = 0;

  for (const config of configs) {
    const credits = config.credits || 1;
    const fullMarks = config.fullMarks || 100;
    const passMarks = config.passMarks || 40;
    const studentMark = marks.find((m) => m.subjectId === config.subjectId);

    if (studentMark?.isExempt) {
      exemptCount++;
    } else if (studentMark?.isAbsent) {
      absentCount++;
      failedCount++;
      totalFullMarks += fullMarks;
      totalCredits += credits;
    } else if (studentMark) {
      const rawMarks = studentMark.obtainedMarks !== null ? Number(studentMark.obtainedMarks) : 0;
      const obtained = Math.max(0, Math.min(fullMarks, rawMarks));
      const percentage = fullMarks > 0 ? (obtained / fullMarks) * 100 : 0;
      const gradeInfo = lookupGradeRule(percentage, scale);
      const isPassing = obtained >= passMarks && gradeInfo.isPassing;

      if (isPassing) passedCount++;
      else failedCount++;

      totalFullMarks += fullMarks;
      totalObtainedMarks += obtained;
      totalQualityPoints += gradeInfo.gradePoint * credits;
      totalCredits += credits;
    }
  }

  const overallPercentage = totalFullMarks > 0 ? Number(((totalObtainedMarks / totalFullMarks) * 100).toFixed(2)) : 0;
  const gpa = totalCredits > 0 ? Number((totalQualityPoints / totalCredits).toFixed(2)) : 0;
  const overallGrade = lookupGradeRule(overallPercentage, scale).grade;

  let resultStatus: 'PASSED' | 'FAILED' | 'DISTINCTION' | 'WITHHELD' = 'PASSED';
  if (failedCount > 0) {
    resultStatus = 'FAILED';
  } else if (overallPercentage >= 85) {
    resultStatus = 'DISTINCTION';
  }

  return { overallPercentage, gpa, overallGrade, resultStatus, passedCount, failedCount, absentCount, exemptCount };
}

export async function runFullAuditSuite(): Promise<{ total: number; passed: number; failed: number; results: TestResult[] }> {
  console.log('================================================================');
  console.log('  SYGMATE SCHOOL MANAGEMENT SYSTEM — PART 6G AUDIT SUITE');
  console.log('================================================================\n');

  // -------------------------------------------------------------------------
  // 1. COMPLETE WORKFLOW AUDIT
  // -------------------------------------------------------------------------
  const startWorkflow = performance.now();
  const exam = (database.examinations || []).find((e) => e.id === 'exam-midterm-2026') || (database.examinations || [])[0];
  assert('1. Complete Workflow Audit', 'Exam Master Exists', !!exam, `Found exam: ${exam?.name || 'None'}`);

  const subjectConfigs = (exam?.subjectsConfig || []).concat(((database as any).examSubjectConfigs || []).filter((sc: any) => sc.examId === exam?.id));
  assert('1. Complete Workflow Audit', 'Subject Allocation Connected', subjectConfigs.length > 0, `Allocated subjects: ${subjectConfigs.length}`);

  const schedules = (database.examSchedules || []).filter((s) => s.examId === exam?.id);
  assert('1. Complete Workflow Audit', 'Exam Schedules Connected', schedules.length > 0, `Scheduled papers: ${schedules.length}`);

  const submissions = (database.examMarksSubmissions || []).filter((ms) => ms.examId === exam?.id);
  assert('1. Complete Workflow Audit', 'Marks Submissions Present', submissions.length > 0, `Marksheets on file: ${submissions.length}`);

  const allExamResults = database.examResults || [];
  assert('1. Complete Workflow Audit', 'Calculated Results Linked', allExamResults.length > 0, `Student result records: ${allExamResults.length}`, startWorkflow);

  // -------------------------------------------------------------------------
  // 2. DATA INTEGRITY
  // -------------------------------------------------------------------------
  const students = database.studentProfiles || [];
  const classes = database.classes || [];
  const sections = database.sections || [];
  const subjects = database.subjects || [];

  const invalidStudentClass = students.find((s) => !classes.some((c) => c.id === s.classId));
  assert('2. Data Integrity', 'Student -> Class Integrity', !invalidStudentClass, invalidStudentClass ? `Found orphaned student classId: ${invalidStudentClass.id}` : 'All students reference valid classes');

  const invalidStudentSection = students.find((s) => s.sectionId && !sections.some((sec) => sec.id === s.sectionId));
  assert('2. Data Integrity', 'Student -> Section Integrity', !invalidStudentSection, invalidStudentSection ? `Found orphaned student sectionId: ${invalidStudentSection.id}` : 'All students reference valid sections');

  const invalidSubjectConfigs = ((database as any).examSubjectConfigs || []).find((sc: any) => !subjects.some((sub) => sub.id === sc.subjectId));
  assert('2. Data Integrity', 'Exam Config -> Subject Integrity', !invalidSubjectConfigs, invalidSubjectConfigs ? `Config with invalid subject: ${(invalidSubjectConfigs as any).id}` : 'All exam subject configs reference real subjects');

  const invalidResultStudents = (database.examResults || []).find((r) => !students.some((s) => s.id === r.studentId));
  assert('2. Data Integrity', 'Result -> Student Integrity', !invalidResultStudents, invalidResultStudents ? `Result orphaned: ${invalidResultStudents.id}` : 'All results map to valid active students');

  // -------------------------------------------------------------------------
  // 3. SECURITY & PRIVILEGE BOUNDARIES
  // -------------------------------------------------------------------------
  const superAdminPermissions = ROLE_PERMISSIONS['SUPER_ADMIN'] || [];
  const teacherPermissions = ROLE_PERMISSIONS['TEACHER'] || [];
  const studentPermissions = ROLE_PERMISSIONS['STUDENT'] || [];
  const guardianPermissions = ROLE_PERMISSIONS['GUARDIAN'] || [];

  assert('3. Security & Access Boundaries', 'Admin has examinations.publish', superAdminPermissions.includes('examinations.publish'), 'Admin has full publish rights');
  assert('3. Security & Access Boundaries', 'Teacher blocked from examinations.publish', !teacherPermissions.includes('examinations.publish'), 'Teacher cannot publish official results');
  assert('3. Security & Access Boundaries', 'Teacher blocked from examinations.approve', !teacherPermissions.includes('examinations.approve'), 'Teacher cannot approve official results');
  assert('3. Security & Access Boundaries', 'Student blocked from examinations.view', !studentPermissions.includes('examinations.view'), 'Student cannot access administrative examination view');
  assert('3. Security & Access Boundaries', 'Guardian blocked from examinations.view', !guardianPermissions.includes('examinations.view'), 'Guardian cannot access administrative examination view');

  // -------------------------------------------------------------------------
  // 4. TEACHER AUTHORIZATION & MARKS RESTRICTION
  // -------------------------------------------------------------------------
  const teacherUser = (database.users || []).find((u) => u.role === 'TEACHER');
  const teacherProfile = (database.teacherProfiles || []).find((tp) => tp.userId === teacherUser?.id);
  const mathSubject = (database.subjects || []).find((s) => s.name.toLowerCase().includes('math'));
  const randomUnassignedSubject = (database.subjects || []).find((s) => s.id !== mathSubject?.id && s.teacherId !== teacherUser?.id && s.teacherId !== teacherProfile?.id);

  if (teacherUser && exam) {
    const isAuthForUnassigned = isTeacherAuthorizedForExamSubject(
      teacherUser,
      teacherProfile,
      exam,
      randomUnassignedSubject?.id || 'fake-sub-id',
      exam.classId,
      exam.sectionId
    );
    assert('4. Teacher Authorization', 'Teacher blocked on unassigned subject', isAuthForUnassigned === false, 'Teacher cannot enter marks for unassigned subject');
  }

  // -------------------------------------------------------------------------
  // 5. CALCULATION ENGINE ACCURACY (Full Marks, Zero, Pass/Fail, Absent, Exempt, GPA)
  // -------------------------------------------------------------------------
  const mockSubjectConfigs = [
    { subjectId: 'sub-1', subjectName: 'Mathematics', subjectCode: 'MATH-101', credits: 4, fullMarks: 100, passMarks: 40 },
    { subjectId: 'sub-2', subjectName: 'Physics', subjectCode: 'PHY-101', credits: 3, fullMarks: 100, passMarks: 40 },
    { subjectId: 'sub-3', subjectName: 'Chemistry', subjectCode: 'CHEM-101', credits: 3, fullMarks: 100, passMarks: 40 }
  ];

  // Case A: 100% Outstanding Student
  const highScores = [
    { subjectId: 'sub-1', obtainedMarks: 95, isAbsent: false, isExempt: false },
    { subjectId: 'sub-2', obtainedMarks: 92, isAbsent: false, isExempt: false },
    { subjectId: 'sub-3', obtainedMarks: 98, isAbsent: false, isExempt: false }
  ];
  const calcA = calculateStudentGpaAndGrade(highScores, mockSubjectConfigs, database.gradingScale || []);
  assert('5. Calculation Engine', '100% Score yields A+ Grade and 4.0 GPA', calcA.overallGrade === 'A+' && calcA.gpa === 4.0 && calcA.resultStatus === 'DISTINCTION', `Grade: ${calcA.overallGrade}, GPA: ${calcA.gpa}, Status: ${calcA.resultStatus}`);

  // Case B: Passing Student (Grade B, 3.0 GPA at 70%)
  const passScores = [
    { subjectId: 'sub-1', obtainedMarks: 72, isAbsent: false, isExempt: false },
    { subjectId: 'sub-2', obtainedMarks: 70, isAbsent: false, isExempt: false },
    { subjectId: 'sub-3', obtainedMarks: 74, isAbsent: false, isExempt: false }
  ];
  const calcB = calculateStudentGpaAndGrade(passScores, mockSubjectConfigs, database.gradingScale || []);
  assert('5. Calculation Engine', '72% Score yields B Grade and 3.0 GPA', calcB.overallGrade === 'B' && calcB.gpa === 3.0 && calcB.resultStatus === 'PASSED', `Grade: ${calcB.overallGrade}, GPA: ${calcB.gpa}, Status: ${calcB.resultStatus}`);

  // Case C: Failed Single Subject -> Overall Result FAILED
  const failScores = [
    { subjectId: 'sub-1', obtainedMarks: 85, isAbsent: false, isExempt: false },
    { subjectId: 'sub-2', obtainedMarks: 25, isAbsent: false, isExempt: false }, // FAILED (< 40)
    { subjectId: 'sub-3', obtainedMarks: 80, isAbsent: false, isExempt: false }
  ];
  const calcC = calculateStudentGpaAndGrade(failScores, mockSubjectConfigs, database.gradingScale || []);
  assert('5. Calculation Engine', 'Failing one subject marks overall status as FAILED', calcC.resultStatus === 'FAILED' && calcC.failedCount === 1, `Status: ${calcC.resultStatus}, FailedCount: ${calcC.failedCount}`);

  // Case D: Absent Student -> Grade 'AB', GPA 0.0, FAILED
  const absentScores = [
    { subjectId: 'sub-1', obtainedMarks: 0, isAbsent: true, isExempt: false },
    { subjectId: 'sub-2', obtainedMarks: 0, isAbsent: true, isExempt: false },
    { subjectId: 'sub-3', obtainedMarks: 0, isAbsent: true, isExempt: false }
  ];
  const calcD = calculateStudentGpaAndGrade(absentScores, mockSubjectConfigs, database.gradingScale || []);
  assert('5. Calculation Engine', 'Absent student gets Grade AB and FAILED status', calcD.resultStatus === 'FAILED' && calcD.absentCount === 3, `Status: ${calcD.resultStatus}, AbsentCount: ${calcD.absentCount}`);

  // Case E: Exempt Subject -> excluded from penalty
  const exemptScores = [
    { subjectId: 'sub-1', obtainedMarks: 90, isAbsent: false, isExempt: false },
    { subjectId: 'sub-2', obtainedMarks: 90, isAbsent: false, isExempt: false },
    { subjectId: 'sub-3', obtainedMarks: 0, isAbsent: false, isExempt: true } // EXEMPT
  ];
  const calcE = calculateStudentGpaAndGrade(exemptScores, mockSubjectConfigs, database.gradingScale || []);
  assert('5. Calculation Engine', 'Exempt subject handled properly without failing student', calcE.resultStatus === 'DISTINCTION' && calcE.exemptCount === 1, `Status: ${calcE.resultStatus}, ExemptCount: ${calcE.exemptCount}`);

  // -------------------------------------------------------------------------
  // 6. WORKFLOW STATE MACHINE VALIDATION
  // -------------------------------------------------------------------------
  assert('6. Workflow State Machine', 'DRAFT -> CALCULATED allowed', (VALID_WORKFLOW_TRANSITIONS['DRAFT'] || []).includes('CALCULATED'), 'Transition valid');
  assert('6. Workflow State Machine', 'CALCULATED -> APPROVED allowed', (VALID_WORKFLOW_TRANSITIONS['CALCULATED'] || []).includes('APPROVED'), 'Transition valid');
  assert('6. Workflow State Machine', 'CALCULATED -> PUBLISHED disallowed direct', !(VALID_WORKFLOW_TRANSITIONS['CALCULATED'] || []).includes('PUBLISHED'), 'Direct publishing without approval blocked');
  assert('6. Workflow State Machine', 'APPROVED -> PUBLISHED allowed', (VALID_WORKFLOW_TRANSITIONS['APPROVED'] || []).includes('PUBLISHED'), 'Approved results can be published');
  assert('6. Workflow State Machine', 'PUBLISHED -> CORRECTION_REQUIRED allowed for revisions', (VALID_WORKFLOW_TRANSITIONS['PUBLISHED'] || []).includes('CORRECTION_REQUIRED'), 'Reopening supported');

  // -------------------------------------------------------------------------
  // 7. REPORT CARD GENERATION & DATA INTEGRITY
  // -------------------------------------------------------------------------
  const sampleResult = (database.examResults || [])[0];
  if (sampleResult) {
    const student = (database.studentProfiles || []).find((s) => s.id === sampleResult.studentId);
    assert('7. Report Card Data', 'Student Profile Linked to Result', !!student, `Student: ${sampleResult.studentName} (${sampleResult.admissionNumber})`);
    assert('7. Report Card Data', 'Subject Scores Non-Empty', sampleResult.subjectScores && sampleResult.subjectScores.length > 0, `Total subject scores: ${sampleResult.subjectScores?.length}`);
    assert('7. Report Card Data', 'Summary Statistics Complete', typeof sampleResult.summary.gpa === 'number' && typeof sampleResult.summary.overallPercentage === 'number', `GPA: ${sampleResult.summary.gpa}, Percentage: ${sampleResult.summary.overallPercentage}%`);
  }

  // -------------------------------------------------------------------------
  // 8. STUDENT PORTAL CONFIDENTIALITY (ID Tampering Defense)
  // -------------------------------------------------------------------------
  const studentUsers = (database.users || []).filter((u) => u.role === 'STUDENT');
  if (studentUsers.length >= 2) {
    const studentA = studentUsers[0];
    const studentB = studentUsers[1];
    const resultB = (database.examResults || []).find((r) => r.userId === studentB.id || r.studentId === studentB.id);

    if (resultB) {
      const isOwner = resultB.studentId === studentA.id || resultB.userId === studentA.id;
      assert('8. Student Portal Confidentiality', 'Student A blocked from viewing Student B result', !isOwner, `Access correctly denied to Student A for Student B result ID: ${resultB.id}`);
    }
  }

  // -------------------------------------------------------------------------
  // 9. GUARDIAN PORTAL ISOLATION
  // -------------------------------------------------------------------------
  const guardianUser = (database.users || []).find((u) => u.role === 'GUARDIAN');
  const guardianProfile = (database.guardians || []).find((g) => g.userId === guardianUser?.id || g.id === guardianUser?.id);
  if (guardianProfile) {
    const linkedIds: string[] = guardianProfile.studentIds || (guardianProfile as any).linkedStudentIds || [];
    const unlinkedStudent = (database.studentProfiles || []).find((s) => !linkedIds.includes(s.id));
    if (unlinkedStudent) {
      const unlinkedResult = (database.examResults || []).find((r) => r.studentId === unlinkedStudent.id);
      const isLinked = linkedIds.includes(unlinkedResult?.studentId || '');
      assert('9. Guardian Portal Isolation', 'Guardian blocked from unlinked student results', !isLinked, `Guardian linked to [${linkedIds.join(', ')}], blocked from student ${unlinkedStudent.id}`);
    }
  }

  // -------------------------------------------------------------------------
  // 10. PERFORMANCE BENCHMARK (Batch Calculations & Filter Latency)
  // -------------------------------------------------------------------------
  const perfStart = performance.now();
  const allResults = database.examResults || [];
  const highGpaList = allResults.filter((r) => r.summary.gpa >= 3.5);
  const perfDuration = performance.now() - perfStart;
  assert('10. Performance & Scalability', 'Batch filter execution under 10ms', perfDuration < 10, `Filtered ${allResults.length} records in ${perfDuration.toFixed(2)}ms`, perfStart);

  // -------------------------------------------------------------------------
  // 11. AUDIT LOGGING COMPLETENESS
  // -------------------------------------------------------------------------
  // Log a test verification event to test audit engine
  logAudit({
    userId: 'usr-admin-1',
    userRole: 'SUPER_ADMIN',
    action: 'AUDIT_EXAM_SYSTEM_VERIFICATION',
    entityType: 'Examination',
    entityId: exam?.id || 'exam-audit',
    details: 'Completed comprehensive Part 6G Examination & Result audit cycle.',
    ipAddress: '127.0.0.1'
  });

  const auditLogs = database.auditLogs || [];
  const examLogs = auditLogs.filter((l) => l.entityType === 'Examination' || l.entityType === 'StudentExamResult' || l.entityType === 'ReportCard' || l.action.includes('EXAM'));
  assert('11. Audit Accountability', 'Audit log entries generated for examination events', examLogs.length > 0, `Total examination audit records on file: ${examLogs.length}`);

  // -------------------------------------------------------------------------
  // 12. REGRESSION CHECK (Core Modules Stable)
  // -------------------------------------------------------------------------
  assert('12. Regression Safety', 'Users table populated', (database.users || []).length > 0, `Total users: ${(database.users || []).length}`);
  assert('12. Regression Safety', 'Classes & Sections intact', (database.classes || []).length > 0 && (database.sections || []).length > 0, `Classes: ${(database.classes || []).length}, Sections: ${(database.sections || []).length}`);
  assert('12. Regression Safety', 'Grading scale configured', (database.gradingScale || []).length >= 5, `Active grade rules: ${(database.gradingScale || []).length}`);

  // -------------------------------------------------------------------------
  // SUMMARY REPORT
  // -------------------------------------------------------------------------
  const total = testResults.length;
  const passed = testResults.filter((r) => r.passed).length;
  const failed = testResults.filter((r) => !r.passed).length;

  console.log('----------------------------------------------------------------');
  console.log(`AUDIT TEST SUMMARY: ${passed}/${total} PASSED (${failed} FAILED)`);
  console.log('----------------------------------------------------------------');
  testResults.forEach((r, idx) => {
    const status = r.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`[${status}] #${idx + 1} [${r.category}] - ${r.name}: ${r.details} ${r.latencyMs ? `(${r.latencyMs}ms)` : ''}`);
  });
  console.log('================================================================\n');

  return { total, passed, failed, results: testResults };
}

// Auto-run if executed directly
if (process.argv[1]?.endsWith('audit_test_6g.ts')) {
  runFullAuditSuite().then((res) => {
    if (res.failed > 0) {
      process.exit(1);
    }
  });
}
