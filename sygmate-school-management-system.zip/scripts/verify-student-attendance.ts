/**
 * Verification Script for Student Attendance Management (Part 8C)
 */

async function runTests() {
  const baseUrl = 'http://localhost:3000/api';
  console.log('--- STARTING STUDENT ATTENDANCE VERIFICATION SUITE ---');

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: any) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName}`, detail !== undefined ? detail : '');
      failed++;
    }
  }

  // Pre-test Cleanup for idempotency across runs
  console.log('\n[0] Initializing and clearing previous test entries...');
  const adminInitRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'admin@sygmate.edu', password: 'Admin@123' })
  });
  const adminInitData = await adminInitRes.json();
  const cleanupToken = adminInitData.data?.session?.token;

  for (const testDate of ['2026-08-20', '2026-08-23']) {
    const sheetRes = await fetch(
      `${baseUrl}/attendance/sheet?classId=class-g10&sectionId=sec-g10-a&date=${testDate}`,
      { headers: { Authorization: `Bearer ${cleanupToken}` } }
    );
    const sheetData = await sheetRes.json();
    for (const student of sheetData.data?.students || []) {
      if (student.existingRecordId) {
        await fetch(`${baseUrl}/attendance/records/${student.existingRecordId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${cleanupToken}`
          },
          body: JSON.stringify({ reason: 'Pre-test environment cleanup' })
        });
      }
    }
  }

  // 1. Teacher Login
  console.log('\n[1] Authenticating Teacher...');
  const teacherLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'teacher.sarah@sygmate.edu', password: 'Teacher@123' })
  });
  const teacherLoginData = await teacherLoginRes.json();
  const teacherToken = teacherLoginData.data?.session?.token;
  assert(teacherLoginRes.ok && !!teacherToken, 'Teacher authentication successful', teacherLoginData);

  // 2. Date Outside Session Restriction
  console.log('\n[2] Testing DATE_OUTSIDE_SESSION error handling...');
  const outsideDateRes = await fetch(`${baseUrl}/attendance`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      classId: 'class-g10',
      sectionId: 'sec-g10-a',
      date: '2022-01-01',
      records: [{ studentId: 'usr-student-1', status: 'PRESENT' }]
    })
  });
  const outsideDateData = await outsideDateRes.json();
  assert(
    outsideDateRes.status === 400 && outsideDateData.code === 'DATE_OUTSIDE_SESSION',
    'Rejects attendance outside active academic session with DATE_OUTSIDE_SESSION',
    outsideDateData
  );

  // 3. Non-Working Day Restriction
  console.log('\n[3] Testing NON_WORKING_DAY_RESTRICTION...');
  // 2026-08-23 is Sunday (weekly off)
  const nonWorkingRes = await fetch(`${baseUrl}/attendance`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      classId: 'class-g10',
      sectionId: 'sec-g10-a',
      date: '2026-08-23',
      records: [{ studentId: 'usr-student-1', status: 'PRESENT' }],
      allowOverride: false
    })
  });
  const nonWorkingData = await nonWorkingRes.json();
  assert(
    nonWorkingRes.status === 400 && nonWorkingData.code === 'NON_WORKING_DAY_RESTRICTION',
    'Rejects submission on weekend/holiday without authorized override (NON_WORKING_DAY_RESTRICTION)',
    nonWorkingData
  );

  // 4. Non-Working Day with Authorized Override
  console.log('\n[4] Testing Non-Working Day with Authorized Override...');
  const overrideRes = await fetch(`${baseUrl}/attendance`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      classId: 'class-g10',
      sectionId: 'sec-g10-a',
      date: '2026-08-23',
      records: [{ studentId: 'usr-student-1', status: 'PRESENT' }],
      allowOverride: true,
      overrideReason: 'Weekend Olympiad Coaching & Practical Lab'
    })
  });
  const overrideData = await overrideRes.json();
  assert(
    overrideRes.ok && overrideData.success,
    'Allows submission on weekend when allowOverride is true with overrideReason',
    overrideData
  );

  // 5. Submit as DRAFT
  console.log('\n[5] Testing Submit as DRAFT...');
  const draftRes = await fetch(`${baseUrl}/attendance`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      classId: 'class-g10',
      sectionId: 'sec-g10-a',
      date: '2026-08-20',
      submissionStatus: 'DRAFT',
      records: [
        { studentId: 'usr-student-1', status: 'PRESENT', remarks: 'Present early' },
        { studentId: 'usr-student-2', status: 'HALF_DAY', remarks: 'Doctor appointment at noon' }
      ]
    })
  });
  const draftData = await draftRes.json();
  assert(
    draftRes.ok && (draftData.data?.submissionStatus === 'DRAFT' || draftData.data?.records?.[0]?.submissionStatus === 'DRAFT'),
    'Successfully marks attendance as DRAFT mode',
    draftData
  );

  // 6. Submit Final Attendance (SUBMITTED) with Half Day
  console.log('\n[6] Testing Final Attendance (SUBMITTED) with HALF_DAY...');
  const finalRes = await fetch(`${baseUrl}/attendance`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      classId: 'class-g10',
      sectionId: 'sec-g10-a',
      date: '2026-08-20',
      submissionStatus: 'SUBMITTED',
      records: [
        { studentId: 'usr-student-1', status: 'PRESENT', remarks: 'Present in class' },
        { studentId: 'usr-student-2', status: 'HALF_DAY', remarks: 'Official clinic permission' }
      ]
    })
  });
  const finalData = await finalRes.json();
  assert(
    finalRes.ok && (finalData.data?.submissionStatus === 'SUBMITTED' || finalData.data?.records?.[0]?.submissionStatus === 'SUBMITTED'),
    'Successfully updates and finalizes attendance as SUBMITTED',
    finalData
  );
  const targetRecord = finalData.data?.records?.[1] || finalData.data?.records?.[0];

  // 7. Update Single Record with Change Reason & Audit Trail
  console.log('\n[7] Testing Record Update with reason & audit logging...');
  let updatedRecordId = targetRecord?.id;
  if (!updatedRecordId) {
    const sheetRes = await fetch(
      `${baseUrl}/attendance/sheet?classId=class-g10&sectionId=sec-g10-a&date=2026-08-20`,
      {
        headers: { Authorization: `Bearer ${teacherToken}` }
      }
    );
    const sheetData = await sheetRes.json();
    updatedRecordId = sheetData.data?.students?.[0]?.existingRecordId;
  }

  const updateRes = await fetch(`${baseUrl}/attendance/records/${updatedRecordId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${teacherToken}`
    },
    body: JSON.stringify({
      status: 'PRESENT',
      remarks: 'Returned for afternoon lecture with signed slip',
      reason: 'Verified parent medical clearance document'
    })
  });
  const updateData = await updateRes.json();
  assert(
    updateRes.ok &&
      updateData.data?.status === 'PRESENT' &&
      ((updateData.data?.correctionHistory?.length ?? 0) > 0 || (updateData.data?.editHistory?.length ?? 0) > 0),
    'Successfully updated single record with audit reason preserved in correctionHistory',
    updateData
  );

  // 8. Verify Student Attendance Overview & Half Day calculation
  console.log('\n[8] Testing Student Attendance Overview calculation...');
  const studentOverviewRes = await fetch(`${baseUrl}/attendance/students/usr-student-2`, {
    headers: { Authorization: `Bearer ${teacherToken}` }
  });
  const studentOverviewData = await studentOverviewRes.json();
  assert(
    studentOverviewRes.ok &&
      (typeof studentOverviewData.data?.summary?.halfDayCount === 'number' ||
        typeof studentOverviewData.data?.stats?.halfDay === 'number'),
    'Student attendance summary includes halfDayCount and calculated rate',
    studentOverviewData.data?.summary || studentOverviewData.data?.stats
  );

  // 9. Admin Deletion with Reason & Audit Log
  console.log('\n[9] Testing Admin Record Deletion with Audit Trail...');
  const adminLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier: 'admin@sygmate.edu', password: 'Admin@123' })
  });
  const adminLoginData = await adminLoginRes.json();
  const adminToken = adminLoginData.data?.session?.token;

  // Delete the test record created in test 7
  const deleteRes = await fetch(`${baseUrl}/attendance/records/${updatedRecordId}`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${adminToken}`
    },
    body: JSON.stringify({
      reason: 'Automated test suite cleanup of verification entry'
    })
  });
  const deleteData = await deleteRes.json();
  assert(deleteRes.ok && deleteData.success, 'Super Admin successfully deleted attendance record with audit reason');

  // Verify Audit Log
  const auditRes = await fetch(`${baseUrl}/audit-logs`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  const auditData = await auditRes.json();
  const logsList = Array.isArray(auditData.data) ? auditData.data : auditData.data?.logs || [];
  const hasDeleteAudit = logsList.some(
    (log: any) =>
      log.action === 'DELETE' ||
      log.entity === 'ATTENDANCE' ||
      log.details?.includes('Automated test suite cleanup')
  );
  assert(hasDeleteAudit, 'Audit log correctly recorded deletion with reason');

  console.log(`\n========================================`);
  console.log(`RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal error during test run:', err);
  process.exit(1);
});
