/**
 * Verification test suite for Stock Management (Part 14B)
 * Tests:
 * 1. Atomic Concurrency (Simultaneous stock deductions)
 * 2. Negative stock prevention
 * 3. Atomic stock transfers between locations
 * 4. Non-stockable item rejection
 * 5. Stock returns and physical count adjustments
 * 6. Audit ledger consistency
 */

import { StockService } from '../server/services/stock.service.js';
import { database } from '../server/db/database.js';

async function runTests() {
  console.log('=== STARTING STOCK MANAGEMENT TEST SUITE ===\n');
  let passedCount = 0;
  let failedCount = 0;

  function assert(condition: boolean, desc: string) {
    if (condition) {
      console.log(`✅ PASS: ${desc}`);
      passedCount++;
    } else {
      console.error(`❌ FAIL: ${desc}`);
      failedCount++;
    }
  }

  const schoolId = 'test_school_14b';
  const testUserId = 'test_user_admin';
  const testUserName = 'Admin Tester';

  // Setup test item and locations in database
  const locAId = 'test_loc_a';
  const locBId = 'test_loc_b';
  const stockableItemId = 'test_item_stockable_1';
  const nonStockableItemId = 'test_item_non_stockable_1';

  // Seed Locations
  if (!database.inventoryLocations) database.inventoryLocations = [];
  database.inventoryLocations.push({
    id: locAId,
    schoolId,
    name: 'Main Central Warehouse',
    code: 'WH-CENTRAL',
    status: 'ACTIVE',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  } as any);

  database.inventoryLocations.push({
    id: locBId,
    schoolId,
    name: 'Science Department Store',
    code: 'SCI-STORE',
    status: 'ACTIVE',
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  } as any);

  // Seed stockable item
  if (!database.inventoryItems) database.inventoryItems = [];
  database.inventoryItems.push({
    id: stockableItemId,
    schoolId,
    name: 'Standard Microscope Slides (Pack of 100)',
    itemCode: 'LAB-SLD-100',
    itemType: 'CONSUMABLE',
    isStockable: true,
    categoryId: 'cat_sci',
    categoryName: 'Science Supplies',
    unitId: 'unit_pk',
    unitName: 'Pack',
    unitShortCode: 'pk',
    locationId: locAId,
    locationName: 'Main Central Warehouse',
    minStockLevel: 5,
    reorderLevel: 10,
    unitPrice: 15.50,
    currentStock: 0,
    status: 'ACTIVE',
    isActive: true,
    createdBy: testUserId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  } as any);

  // Seed non-stockable item
  database.inventoryItems.push({
    id: nonStockableItemId,
    schoolId,
    name: 'Software Subscription License (Annual)',
    itemCode: 'LIC-ANNUAL',
    itemType: 'SERVICE',
    isStockable: false,
    categoryId: 'cat_it',
    categoryName: 'IT Software',
    unitId: 'unit_ea',
    unitName: 'Each',
    unitShortCode: 'ea',
    locationId: locAId,
    locationName: 'Main Central Warehouse',
    minStockLevel: 0,
    reorderLevel: 0,
    unitPrice: 500,
    currentStock: 0,
    status: 'ACTIVE',
    isActive: true,
    createdBy: testUserId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  } as any);

  console.log('[1] Non-Stockable Item Validation');
  try {
    await StockService.recordStockIn(schoolId, {
      itemId: nonStockableItemId,
      locationId: locAId,
      quantity: 10
    }, testUserId, testUserName);
    assert(false, 'Should reject stock in for non-stockable item');
  } catch (err: any) {
    assert(err.message.includes('non-stockable') || err.message.includes('SERVICE') || err.message.includes('stock operations'),
      `Correctly rejected non-stockable item: "${err.message}"`);
  }

  console.log('\n[2] Opening Stock Initialization');
  const openingResult = await StockService.recordOpeningStock(schoolId, {
    itemId: stockableItemId,
    locationId: locAId,
    quantity: 10,
    unitCost: 15.50,
    notes: 'Initial physical inventory count'
  }, testUserId, testUserName);

  assert(openingResult.balance.quantity === 10, `Opening stock recorded as 10 (actual: ${openingResult.balance.quantity})`);
  assert(openingResult.movement.movementType === 'OPENING_STOCK', 'Movement logged as OPENING_STOCK');
  assert(openingResult.movement.balanceAfter === 10, 'Balance after opening movement is 10');

  console.log('\n[3] Negative Stock Prevention on Stock Out');
  try {
    await StockService.recordStockOut(schoolId, {
      itemId: stockableItemId,
      locationId: locAId,
      quantity: 15, // Only 10 available
      purpose: 'Lab classes'
    }, testUserId, testUserName);
    assert(false, 'Should throw error when issuing more than available stock');
  } catch (err: any) {
    assert(err.message.includes('Insufficient stock') || err.message.includes('available'),
      `Correctly prevented negative stock: "${err.message}"`);
  }

  // Verify balance remained 10
  const postFailBalance = database.stockBalances.find(b => b.schoolId === schoolId && b.itemId === stockableItemId && b.locationId === locAId);
  assert(postFailBalance?.quantity === 10, `Balance remained exactly 10 after rejected deduction`);

  console.log('\n[4] Concurrency: 10 Simultaneous Deductions of 2 units (available = 10)');
  // We have 10 units. We launch 10 parallel stock deductions of 2 units each.
  // Exactly 5 should succeed (5 x 2 = 10 units) and 5 should fail with insufficient stock.
  // End balance must be exactly 0, never negative!
  const parallelDeductions = Array.from({ length: 10 }, (_, i) =>
    StockService.recordStockOut(schoolId, {
      itemId: stockableItemId,
      locationId: locAId,
      quantity: 2,
      recipient: `Concurrent Tester #${i + 1}`
    }, testUserId, testUserName)
      .then(() => ({ success: true, index: i }))
      .catch((err) => ({ success: false, index: i, error: err.message }))
  );

  const results = await Promise.all(parallelDeductions);
  const successCount = results.filter(r => r.success).length;
  const failureCount = results.filter(r => !r.success).length;

  console.log(`Concurrency Results: ${successCount} succeeded, ${failureCount} failed`);
  assert(successCount === 5, `Exactly 5 parallel deductions of 2 succeeded (actual: ${successCount})`);
  assert(failureCount === 5, `Exactly 5 parallel deductions failed due to insufficient stock (actual: ${failureCount})`);

  const endBalanceAfterConcurrency = database.stockBalances.find(b => b.schoolId === schoolId && b.itemId === stockableItemId && b.locationId === locAId);
  assert(endBalanceAfterConcurrency?.quantity === 0, `Final stock balance is exactly 0 and never negative (actual: ${endBalanceAfterConcurrency?.quantity})`);

  console.log('\n[5] Stock In Receipt');
  const stockInResult = await StockService.recordStockIn(schoolId, {
    itemId: stockableItemId,
    locationId: locAId,
    quantity: 20,
    unitCost: 16.00,
    referenceNumber: 'PO-2026-001',
    notes: 'Received new stock shipment'
  }, testUserId, testUserName);

  assert(stockInResult.balance.quantity === 20, `Stock balance updated to 20 after receipt (actual: ${stockInResult.balance.quantity})`);
  assert(stockInResult.movement.quantityIn === 20, 'Movement quantityIn is 20');

  console.log('\n[6] Atomic Stock Transfer Between Locations');
  const transferResult = await StockService.recordStockTransfer(schoolId, {
    itemId: stockableItemId,
    sourceLocationId: locAId,
    destinationLocationId: locBId,
    quantity: 8,
    referenceNumber: 'TRF-SCI-01',
    reason: 'Department allocation'
  }, testUserId, testUserName);

  assert(transferResult.sourceBalance.quantity === 12, `Source store balance deducted from 20 to 12 (actual: ${transferResult.sourceBalance.quantity})`);
  assert(transferResult.destBalance.quantity === 8, `Destination store balance increased from 0 to 8 (actual: ${transferResult.destBalance.quantity})`);
  assert(transferResult.sourceMovement.movementType === 'TRANSFER_OUT', 'Source movement logged as TRANSFER_OUT');
  assert(transferResult.destMovement.movementType === 'TRANSFER_IN', 'Destination movement logged as TRANSFER_IN');

  console.log('\n[7] Stock Return');
  const returnResult = await StockService.recordStockReturn(schoolId, {
    itemId: stockableItemId,
    locationId: locBId,
    quantity: 3,
    returnedBy: 'Prof. Miller',
    department: 'Chemistry',
    reason: 'Unused experimental slides'
  }, testUserId, testUserName);

  assert(returnResult.balance.quantity === 11, `Destination store balance after return is 11 (8 + 3 = 11, actual: ${returnResult.balance.quantity})`);
  assert(returnResult.movement.movementType === 'RETURN', 'Movement type logged as RETURN');

  console.log('\n[8] Physical Count Adjustment');
  // Count says 15, current is 11 -> adjustment +4
  const adjustResult = await StockService.recordStockAdjustment(schoolId, {
    itemId: stockableItemId,
    locationId: locBId,
    countedQuantity: 15,
    adjustmentReason: 'COUNT_DIFFERENCE',
    notes: 'Annual physical inventory count'
  }, testUserId, testUserName);

  assert(adjustResult.balance.quantity === 15, `Balance adjusted to counted quantity 15 (actual: ${adjustResult.balance.quantity})`);
  assert(adjustResult.movement.movementType === 'ADJUSTMENT_INCREASE', 'Movement logged as ADJUSTMENT_INCREASE');
  assert(adjustResult.movement.quantityIn === 4, `Movement difference recorded as +4 (actual: ${adjustResult.movement.quantityIn})`);

  console.log('\n[9] Ledger Audit Consistency');
  const ledgerResponse = await StockService.getStockMovements(schoolId, {
    itemId: stockableItemId,
    limit: 50
  });

  assert(ledgerResponse.data.length > 0, `Ledger contains ${ledgerResponse.data.length} movement records`);
  
  const invalid = ledgerResponse.data.find(m => !m.transactionId || !m.userId || !m.timestamp || typeof m.balanceAfter !== 'number');
  if (invalid) {
    console.log('Sample invalid movement:', invalid);
  }
  const allValid = !invalid;
  assert(allValid, 'All ledger movements possess full audit metadata');

  console.log('\n[10] Stock Summary Analytics');
  const summary = await StockService.getStockSummary(schoolId);
  assert(summary.totalStockableItems >= 1, `Summary reports stockable items: ${summary.totalStockableItems}`);
  assert(summary.totalUnitsInStock >= 27, `Total units in stock is correct across stores (12 + 15 = 27, actual: ${summary.totalUnitsInStock})`);
  assert(summary.locationBreakdown.length >= 2, `Location breakdown contains both stores`);

  console.log('\n=============================================');
  console.log(`TEST RESULTS: ${passedCount} PASSED, ${failedCount} FAILED`);
  console.log('=============================================\n');

  if (failedCount > 0) {
    process.exit(1);
  }
}

runTests().catch(err => {
  console.error('Test execution failed with unhandled exception:', err);
  process.exit(1);
});
