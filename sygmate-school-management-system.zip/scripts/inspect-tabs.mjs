import fs from 'fs';

const pages = [
  "src/pages/admin/AdminFrontOfficePage.tsx",
  "src/pages/admin/AdminInventoryPage.tsx",
  "src/pages/admin/AdminDocumentsPage.tsx",
  "src/pages/admin/AcademicStructurePage.tsx",
  "src/pages/admin/UserDirectoryPage.tsx",
  "src/pages/admin/AdminAdmissionsPage.tsx",
  "src/pages/admin/AdminStudentPromotionTransferPage.tsx",
  "src/pages/admin/staff/StaffManagementPage.tsx",
  "src/pages/admin/communication/CommunicationManagementPage.tsx",
  "src/pages/admin/AdminExaminationsPage.tsx",
  "src/pages/admin/attendance/AttendanceSettingsPage.tsx",
  "src/pages/admin/attendance/AdminAttendanceReportsPage.tsx",
  "src/pages/admin/AdminFinancialReportsPage.tsx",
  "src/pages/admin/AdminFeeCollectionPage.tsx",
  "src/pages/admin/AdminStudentFeesPage.tsx",
  "src/pages/admin/AdminDueManagementPage.tsx",
  "src/pages/admin/AdminFeeAdjustmentsPage.tsx",
  "src/pages/admin/AdminFeeStructurePage.tsx",
  "src/pages/admin/SchoolSettingsPage.tsx",
  "src/pages/admin/AdminIDCardAndDocumentsPage.tsx",
  "src/pages/admin/attendance/TeacherAttendanceManagementPage.tsx",
  "src/pages/admin/AdminStudentReportsPage.tsx",
  "src/pages/teacher/TeacherAttendancePage.tsx",
  "src/pages/teacher/TeacherMyAttendancePage.tsx",
  "src/pages/teacher/TeacherClassesPage.tsx",
  "src/pages/student/StudentSubjectsPage.tsx",
  "src/pages/student/StudentAttendancePage.tsx",
  "src/pages/guardian/GuardianAttendancePage.tsx",
  "src/pages/guardian/GuardianChildAcademicOverviewPage.tsx"
];

for (const p of pages) {
  if (!fs.existsSync(p)) continue;
  const content = fs.readFileSync(p, 'utf8');
  console.log(`\n=== ${p} ===`);

  // Regex to find buttons with tab switching
  const btnRegex = /onClick=\{[^{}]*set(?:Active)?(?:Main)?(?:Sub)?Tab\(['"]([^'"]+)['"]\)\}[^>]*>([\s\S]*?)<\/button>/g;
  let m;
  const btns = [];
  while ((m = btnRegex.exec(content)) !== null) {
    const rawLabel = m[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    btns.push({ tab: m[1], label: rawLabel });
  }

  // Also check if there is a tabs array defined
  const tabsArrayRegex = /const\s+(?:tabs|TABS|tabItems)\s*=\s*(\[[\s\S]*?\]);/;
  const tabsMatch = content.match(tabsArrayRegex);

  if (btns.length > 0) {
    console.log('Buttons found:', btns);
  } else if (tabsMatch) {
    console.log('Tabs array found:', tabsMatch[1].slice(0, 300));
  } else {
    // Check if there is Tabs component
    const hasTabs = content.match(/<Tabs\s+tabs=\{([^}]+)\}/);
    if (hasTabs) {
      console.log('Using Tabs component with:', hasTabs[1]);
    } else {
      console.log('No direct tab buttons found.');
    }
  }
}
